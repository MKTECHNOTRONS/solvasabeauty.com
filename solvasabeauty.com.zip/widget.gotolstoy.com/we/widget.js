var ys = Object.defineProperty,
    gs = Object.defineProperties;
var ms = Object.getOwnPropertyDescriptors;
var It = Object.getOwnPropertySymbols;
var De = Object.prototype.hasOwnProperty,
    ke = Object.prototype.propertyIsEnumerable;
var Ft = (e, t, o) => t in e ? ys(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : e[t] = o,
    m = (e, t) => {
        for (var o in t || (t = {})) De.call(t, o) && Ft(e, o, t[o]);
        if (It)
            for (var o of It(t)) ke.call(t, o) && Ft(e, o, t[o]);
        return e
    },
    w = (e, t) => gs(e, ms(t));
var Be = (e, t) => {
    var o = {};
    for (var s in e) De.call(e, s) && t.indexOf(s) < 0 && (o[s] = e[s]);
    if (e != null && It)
        for (var s of It(e)) t.indexOf(s) < 0 && ke.call(e, s) && (o[s] = e[s]);
    return o
};
var g = (e, t, o) => (Ft(e, typeof t != "symbol" ? t + "" : t, o), o);
var y = (e, t, o) => new Promise((s, n) => {
    var i = c => {
            try {
                a(o.next(c))
            } catch (d) {
                n(d)
            }
        },
        r = c => {
            try {
                a(o.throw(c))
            } catch (d) {
                n(d)
            }
        },
        a = c => c.done ? s(c.value) : Promise.resolve(c.value).then(i, r);
    a((o = o.apply(e, t)).next())
});
const D = {
        pageView: "pageView",
        sessionStart: "sessionStart",
        sessionEnd: "sessionEnd",
        videoPause: "videoPause",
        videoStart: "videoStart",
        videoResume: "videoResume",
        videoReplay: "videoReplay",
        clickCta: "clickCta",
        submitInput: "submitInput",
        collectInfo: "collectInfo",
        videoResponse: "videoResponse",
        audioResponse: "audioResponse",
        imageResponse: "imageResponse",
        tolstoyClick: "tolstoyClick",
        chapterSelected: "chapterSelected",
        chapterPickerOpened: "chapterPickerOpened",
        videoSeeked: "videoSeeked",
        shareClick: "shareClick",
        quizResult: "quizResult",
        autoplayStart: "autoplayStart"
    },
    f = {
        sessionStart: "tolstoyStarted",
        sessionEnd: "tolstoyReachedEnd",
        clickCta: "tolstoyAnswerClicked",
        submitInput: "tolstoyInputSubmit",
        collectInfo: "tolstoyLeadFormSubmit",
        videoResponse: "tolstoyVideoSubmit",
        audioResponse: "tolstoyAudioSubmit",
        imageResponse: "tolstoyImageSubmit",
        openGorgias: "tolstoyOpenGorgias",
        hideGorgias: "tolstoyHideGorgias",
        openIntercom: "tolstoyOpenIntercom",
        hideIntercom: "tolstoyHideIntercom",
        openTawkTo: "tolstoyOpenTawkTo",
        hideTawkTo: "tolstoyHideTawkTo",
        openLiveChat: "tolstoyOpenLiveChat",
        hideLiveChat: "tolstoyHideLiveChat",
        openHubSpot: "tolstoyOpenHubSpot",
        hideHubSpot: "tolstoyHideHubSpot",
        openHelpScout: "tolstoyOpenHelpScout",
        hideHelpScout: "tolstoyHideHelpScout",
        openDrift: "tolstoyOpenDrift",
        hideDrift: "tolstoyHideDrift",
        openZendesk: "tolstoyOpenZendesk",
        hideZendesk: "tolstoyHideZendesk"
    },
    Uc = "tolstoyEscapeKeyPressed",
    fs = "tolstoyWatchedProductIds",
    Dc = "showFeedProductModal",
    kc = "tolstoyWidgets",
    Bc = "showFeedCartMobile",
    $c = "tolstoyMoveToUrl",
    xc = "tolstoyCloseModalMessage",
    so = "tolstoyPlayerReady",
    Hc = "focusCloseButton",
    z = {
        OPEN: "open",
        CLOSE: "close",
        PLAY: "play",
        PAUSE: "pause"
    },
    Es = [z.OPEN, z.PLAY],
    ws = [z.CLOSE, z.PAUSE],
    Wc = {
        ready: "tolstoyPreConfigMessengerReady",
        vodAssetIds: "tolstoyVodAssetIds"
    },
    Vc = "rechargeMessaging",
    Fc = "tolstoyRechargeWidgetData",
    Yc = "tolstoyRequestRechargeWidgetData",
    Gc = "tolstoyRequestRechargeAddToCart",
    it = {
        static: "static",
        dynamic: "dynamic",
        hoverOver: "hoverOver"
    },
    jc = {
        under: "under",
        over: "over"
    },
    Ss = {
        carousel: "tolstoy-carousel",
        carouselContainer: "tolstoy-carousel-container",
        title: "tolstoy-carousel-title",
        videoCarouselContainer: "tolstoy-video-carousel-container",
        previousButton: "tolstoy-previous-button",
        nextButton: "tolstoy-next-button",
        arrowsContainer: "tolstoy-carousel-arrows-container",
        videosContainer: "tolstoy-carousel-videos-container",
        videoContainer: "tolstoy-carousel-video-container",
        video: "tolstoy-carousel-video",
        image: "tolstoy-carousel-image",
        dotsContainer: "tolstoy-dots-container",
        dot: "tolstoy-dot",
        playButtonContainer: "tolstoy-play-button-container",
        controlsContainer: "tolstoy-carousel-controls-container",
        expandButton: "tolstoy-carousel-expand-button",
        muteButton: "tolstoy-carousel-mute-button",
        playButton: "tolstoy-carousel-play-button",
        tileContainer: "tolstoy-carousel-tile-container",
        tile: "tolstoy-carousel-tile",
        centerTile: "tolstoy-carousel-center-tile",
        tileNameContainer: "tolstoy-tile-name-container",
        tileNameText: "tolstoy-carousel-tile-name-text",
        arrowButtonContainer: "tolstoy-carousel-arrow-button-container",
        arrowButton: "tolstoy-carousel-arrow-button",
        tileNameHeightPlaceholder: "tolstoy-tile-name-height-placeholder",
        productTile: "tolstoy-product-tile",
        productContent: "tolstoy-product-content",
        productTileImage: "tolstoy-product-tile-image",
        productTileTitle: "tolstoy-product-tile-title",
        tileText: "tolstoy-tile-text",
        variantTile: "tolstoy-product-variant-tile",
        variantTileIcon: "tolstoy-product-variant-tile-icon",
        variantTileTitle: "tolstoy-product-variant-tile-title",
        productTilePrice: "tolstoy-product-tile-price",
        productTileSubtitle: "tolstoy-product-tile-subtitle",
        productTileButton: "tolstoy-product-tile-button",
        productTileArrow: "tolstoy-product-tile-arrow",
        productTileFallback: "tolstoy-product-tile-fallback",
        descriptionTile: "tolstoy-description-tile",
        descriptionTileContent: "tolstoy-description-tile-content",
        descriptionTileButton: "tolstoy-description-tile-button"
    },
    Kc = 6,
    zc = 2,
    qc = 80,
    Zc = .3,
    Xc = 80,
    Qc = 12,
    Ts = 416,
    Jc = {
        DEFAULT: "default",
        SPOTLIGHT: "spotlight"
    },
    tl = {
        product: "product",
        videoName: "videoName",
        none: "none"
    },
    el = {
        shoppableVideoCarousel: "Shoppable Video Carousel",
        viewProduct: "View Product"
    },
    Is = {
        embed: "tolstoy-embed",
        iframe: "tolstoy-embed-iframe",
        videoPreview: "tolstoy-embed-video-preview",
        videoContainer: "tolstoy-embed-video-container",
        playButtonContainer: "tolstoy-embed-play-button-container",
        startText: "tolstoy-embed-start-text",
        startButtonContainer: "tolstoy-embed-start-button-container",
        startButton: "tolstoy-embed-start-button",
        embedContainer: "tolstoy-embed-container"
    },
    ol = 9 / 16,
    bs = {
        story: "tolstoy-stories",
        storiesMainContainer: "tolstoy-stories-main-container",
        storiesContainer: "tolstoy-stories-container",
        tilesContainer: "tolstoy-stories-tiles-container",
        tileName: "tolstoy-stories-tile-name",
        storyTile: "tolstoy-stories-tile",
        storyImage: "tolstoy-stories-story-image",
        storyVideo: "tolstoy-stories-story-video",
        plusTile: "tolstoy-stories-plus-tile",
        storyName: "tolstoy-stories-story-name",
        titleContainer: "tolstoy-stories-title",
        plusTileContainer: "tolstoy-stories-plus-tile-container",
        previousButton: "tolstoy-stories-previous-button",
        nextButton: "tolstoy-stories-next-button",
        onYouButton: "tolstoy-stories-on-you-button",
        onlyOnYouButton: "tolstoy-stories-only-on-you-button",
        playButtonContainer: "tolstoy-stories-play-button-container"
    },
    Cs = ".0000000.jpg",
    _s = ".avatar",
    sl = `${_s}${Cs}`,
    nl = {
        static: it.static,
        dynamic: it.dynamic
    },
    vs = {
        responsive: "responsive",
        fixed: "fixed"
    },
    il = {
        below: "below",
        overlay: "overlay"
    },
    rl = vs.fixed,
    al = 8,
    cl = 80,
    ll = 8,
    dl = 240,
    ul = 200,
    As = {
        tile: "tolstoy-tile",
        tileContainer: "tolstoy-tile-container",
        video: "tolstoy-tile-video",
        nativeCaptionsTrack: "tolstoy-tile-native-captions-track",
        customCaptionsTrack: "tolstoy-tile-custom-captions-track",
        imageOverlay: "tolstoy-tile-image-overlay",
        image: "tolstoy-tile-image",
        controlsOverlay: "tolstoy-tile-controls-overlay",
        controlsContainer: "tolstoy-tile-controls",
        playButtonOverlay: "tolstoy-tile-play-button-overlay",
        playButtonContainer: "tolstoy-tile-play-button-container",
        playButtonLabelContainer: "tolstoy-tile-play-button-label-container",
        playButtonLabel: "tolstoy-tile-play-button-label",
        timebarWrapper: "tolstoy-tile-timebar-wrapper",
        timebarContainer: "tolstoy-tile-timebar-container",
        timebar: "tolstoy-tile-timebar",
        timeIndicator: "tolstoy-tile-time-indicator",
        muteButton: "tolstoy-tile-mute-button",
        fullScreenButton: "tolstoy-tile-full-screen-button",
        togglesContainer: "tolstoy-tile-toggles",
        captionsButton: "tolstoy-tile-captions-button"
    },
    q = {
        collectionTile: "tolstoy-collection-tile",
        collectionTileHoverWrapper: "tolstoy-collection-tile-hover-wrapper",
        video: "tolstoy-collection-tile-video",
        controlsContainer: "tolstoy-collection-tile-controls-container",
        playButton: "tolstoy-collection-tile-play-button",
        muteButton: "tolstoy-collection-tile-mute-button"
    },
    no = {
        AUTOPLAY: "autoplay",
        CLICK: "click",
        HOVER: "hover"
    },
    Os = {
        CONSECUTIVELY: "consecutively",
        SIMULTANEOUSLY: "simultaneously"
    },
    pl = {
        LOOP: "loop",
        PLAY_ONCE: "playOnce"
    },
    Ps = {
        PDP: "pdp",
        PLAY: "play"
    },
    hl = "data-tolstoy-collection-tile-key",
    Rs = {
        playMode: no.AUTOPLAY,
        playVideos: Os.CONSECUTIVELY,
        autoplayDelay: 1,
        minProductsBetweenVideos: 2,
        mutedByDefault: !1,
        tileClickMode: Ps.PDP,
        shouldHideVideoWhenNotPlaying: !0,
        controls: {
            play: {
                enabled: !1,
                backgroundEnabled: !0,
                backgroundColor: "#0000004d",
                borderEnabled: !1,
                borderColor: "#ffffff",
                opacity: 1
            },
            mute: {
                enabled: !1,
                backgroundEnabled: !0,
                backgroundColor: "#0000004d",
                borderEnabled: !1,
                borderColor: "#ffffff",
                opacity: 1
            }
        }
    },
    io = "tolstoy-collection-page-tile",
    se = "carousel",
    Ls = "inTileCarousel",
    ro = "bubble",
    ne = "stories",
    ie = "embed",
    yl = "onYou",
    re = "tile",
    ao = "centeredModal",
    gt = "collectionTile",
    co = "collectionPageTile",
    gl = {
        clickedX: "stopShowingWidgetToClickedX",
        viewed: "stopShowingWidgetToViewed"
    },
    lo = {
        [se]: Ss.carousel,
        [ne]: bs.story,
        [ie]: Is.embed,
        [re]: As.tile,
        [gt]: q.collectionTile,
        [co]: io
    },
    Ms = "siteActivity",
    Ns = "pageVisit",
    ml = {
        notAllowedError: "NotAllowedError",
        abortError: "AbortError"
    },
    Us = 1,
    ft = {
        shop: "shop",
        appKey: "app-key",
        productId: "product-id",
        shouldUseCache: "should-use-cache",
        cacheVersion: "cache-version"
    },
    ye = {
        tolstoyAutoOpen: "tolstoyAutoOpen",
        tolstoyAutoOpenOnYou: "tolstoyAutoOpenOnYou",
        tolstoyStartVideo: "tolstoyStartVideo",
        tolstoyMoneyFormat: "tolstoyMoneyFormat"
    },
    Ds = "PRODUCT_ID",
    fl = {
        TOP: "top",
        BOTTOM: "bottom"
    },
    S = {
        embedView: "embedView",
        embedPlay: "embedPlay",
        embedPause: "embedPause",
        embedMute: "embedMute",
        embedUnmute: "embedUnmute",
        embedExpand: "embedExpand",
        tolstoyModalClose: "tolstoyModalClose",
        feedProductModalOpen: "feedProductModalOpen",
        feedProductModalClose: "feedProductModalClose",
        videoLoaded: "videoLoaded",
        pageView: "pageView",
        clickViewProduct: "clickViewProduct",
        openProductPageClick: "openProductPageClick",
        feedPlay: "feedPlay",
        feedPause: "feedPause",
        videoMuted: "videoMuted",
        videoUnmuted: "videoUnmuted",
        videoWatched: "videoWatched",
        openShareLink: "Open Share Link",
        feedNavigationArrowClick: "feedNavigationArrowClick",
        feedScroll: "feedScroll",
        sessionStart: "sessionStart",
        tolstoyStarted: "tolstoyStarted",
        abTestInitialized: "abTestInitialized",
        onYouClick: "onYouClick"
    },
    uo = "https://api.gotolstoy.com",
    ge = "https://apilb.gotolstoy.com",
    po = "https://cf-apilb.gotolstoy.com",
    ks = "https://player.gotolstoy.com",
    Bs = "https://on-you.gotolstoy.com",
    El = "https://play.gotolstoy.com/hero",
    ae = "widget.gotolstoy.com",
    ho = "https://videos.gotolstoy.com",
    $s = "https://api.gotolstoy.com/migrations/recreate-video",
    xs = "https://analytics-v2.gotolstoy.com/site-activity",
    Hs = "https://analytics-v2.gotolstoy.com/page-visit",
    Ws = e => {
        var t;
        return e != null && e.length ? `${(t=e[0])==null?void 0:t.toUpperCase()}${e==null?void 0:e.slice(1)}` : ""
    },
    B = e => {
        var o;
        if (!("URLSearchParams" in window)) return null;
        try {
            return new URLSearchParams((o = window.location) == null ? void 0 : o.search).get(e)
        } catch (s) {
            if (s) return null
        }
    },
    wl = (e, t) => Math.floor(Math.random() * (t - e + 1)) + e,
    yo = () => {
        const e = t => {
            const o = Math.floor(Math.random() * 16);
            return (t === "x" ? o : o & 3 | 8).toString(16)
        };
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, e)
    },
    go = () => B("td") === "true",
    Vs = e => {
        go() && console.log(e)
    },
    mo = e => {
        go() && console.error(e)
    },
    Fs = () => ["iPad Simulator", "iPhone Simulator", "iPod Simulator", "iPad", "iPhone", "iPod"].includes(navigator.platform) || navigator.userAgent.includes("Mac") && "ontouchend" in document,
    Sl = () => Fs() || window.screen.width <= 450 || window.screen.height <= 450,
    Tl = (e, t = 300) => {
        let o;
        return (...s) => {
            clearTimeout(o), o = setTimeout(() => {
                e(...s)
            }, t)
        }
    },
    Il = (e = 0) => y(void 0, null, function*() {
        return new Promise(t => {
            setTimeout(t, e)
        })
    }),
    bl = (e, t = 1) => {
        const o = Number(e);
        return Number.isNaN(o) ? 0 : Number.isInteger(o) ? o : Number.parseFloat(o.toFixed(t))
    },
    Cl = e => e.replace(/<[^>]*>?/gm, ""),
    Ys = e => e == null,
    _l = e => {
        const t = Math.floor(e / 60),
            o = Math.floor(e % 60);
        return `${t}:${o.toString().padStart(2,"0")}`
    },
    R = () => {
        var e, t;
        return ((t = (e = window.Shopify) == null ? void 0 : e.customerPrivacy) == null ? void 0 : t.currentVisitorConsent().analytics) !== "no"
    },
    Gs = e => {
        const t = /^[\da-f]{8}-[\da-f]{4}-[0-5][\da-f]{3}-[089ab][\da-f]{3}-[\da-f]{12}$/i;
        return e == null ? void 0 : e.match(t)
    },
    fo = e => Es.includes(e),
    js = e => ws.includes(e),
    Ks = (e, t) => {
        const o = e.src;
        return new URL(o).searchParams.get(t)
    },
    zs = (e, t) => e.getAttribute(`data-${t}`),
    Z = e => {
        const t = document.querySelectorAll(`script[src*="${ae}"]`);
        for (const o of t) {
            const s = zs(o, e) || Ks(o, e);
            if (s) return s
        }
    },
    qs = e => {
        var o;
        const t = (o = e == null ? void 0 : e.dataset) == null ? void 0 : o.productId;
        return t === "{{ product.id }}" ? null : t
    },
    Dt = () => {
        const e = Z(ft.productId);
        if (e) return e;
        const {
            stories: t,
            carousel: o,
            embed: s,
            tile: n
        } = lo, i = document.querySelectorAll(`.${t}, .${o}, .${s}, .${n}`);
        for (const r of i) {
            const a = qs(r);
            if (a) return a
        }
    },
    Eo = () => Z(ft.shouldUseCache) === "true",
    G = () => Z(ft.cacheVersion),
    Zs = "www.",
    wo = new RegExp("^((([A-Za-z]{3,9}:(?:\\/\\/)?)(?:[\\-;:&=\\+\\$,\\w]+@)?[A-Za-z0-9\\.\\-]+|(?:www\\.|[\\-;:&=\\+\\$,\\w]+@)[A-Za-z0-9\\.\\-]+)((?:\\/[\\+~%\\/\\.\\w\\-_]*)?\\??(?:[\\-\\+=&;%@\\.\\w_]*)#?(?:[\\.\\!\\/\\\\\\w]*))?)", "i"),
    $e = e => e ? !!wo.test(e) || e.startsWith("tel:") || e.startsWith("mailto:") || e.startsWith("_self:") : !1,
    xe = e => {
        const t = e.replace(Zs, ""),
            o = new URL(t);
        return `${o.origin}${o.pathname}${o.search}`
    },
    vl = (e, t) => !$e(e) || !$e(t) ? !1 : xe(e) === xe(t),
    Xs = () => {
        const e = new URLSearchParams(window.location.search),
            t = new URLSearchParams;
        for (const [o, s] of e) {
            const n = o.toLowerCase();
            o.length < 50 && s.length < 100 && (n.startsWith("custom_") || n.startsWith("utm_")) && t.append(o, s)
        }
        return t
    },
    Et = (e = {}) => {
        const t = new URLSearchParams;
        for (const [o, s] of Object.entries(e)) s != null && s !== "" && t.append(o, s);
        return t.toString()
    },
    Al = e => wo.test(e),
    Ol = e => new URLSearchParams(window.location.search).get("tolstoy") === e;
let bt = "";

function P() {
    return window.tolstoyAppKey || bt ? window.tolstoyAppKey || bt : (bt = Z(ft.appKey), bt)
}
const Qs = 4e3;
let So = !1;
const ce = [],
    Js = () => {
        for (; ce.length > 0;) {
            const {
                eventFunction: e,
                args: t
            } = ce.shift();
            e(...t)
        }
    };
setTimeout(() => {
    So = !0, Js()
}, Qs);
const me = e => (...t) => {
    if (So) return e(...t);
    ce.push({
        eventFunction: e,
        args: t
    })
};

function wt() {
    return Z(ft.shop)
}
const St = () => {
        var e;
        return (e = window.tolstoySettings) != null && e.shouldUseCache ? po : ge
    },
    tn = () => y(void 0, null, function*() {
        var i, r;
        const e = P(),
            t = ((i = window.Shopify) == null ? void 0 : i.shop) || wt(),
            o = Eo(),
            s = G(),
            n = o ? po : ge;
        try {
            const a = new URL(`${n}/actions/accounts/${e}`);
            return s && a.searchParams.set("v", s), t && a.searchParams.set("appUrl", t), (yield fetch(a.toString())).json()
        } catch (a) {
            (r = window.tolstoyCaptureError) == null || r.call(window, a, "Error loading account settings:")
        }
    }),
    en = e => y(void 0, null, function*() {
        var t;
        try {
            return R() ? (yield fetch(`${uo}/identify/identify`, {
                method: "POST",
                body: JSON.stringify({
                    data: e
                })
            })).json() : void 0
        } catch (o) {
            (t = window.tolstoyCaptureError) == null || t.call(window, o, "Error updating identification:")
        }
    }),
    Pl = (e, t) => y(void 0, null, function*() {
        var r;
        const o = Dt(),
            s = St(),
            n = G(),
            i = Et({
                widgetType: t,
                productId: o,
                publishId: e,
                v: n
            });
        try {
            return (yield fetch(`${s}/settings/widget/by-publish-id?${i}`)).json()
        } catch (a) {
            (r = window.tolstoyCaptureError) == null || r.call(window, a, "Error loading config:")
        }
    }),
    on = e => y(void 0, null, function*() {
        var n;
        const t = St(),
            o = G(),
            s = Et(w(m({}, e), {
                url: `${window.location.origin}${window.location.pathname}`,
                v: o
            }));
        try {
            return (yield fetch(`${t}/settings/widget/by-product-url?${s}`)).json()
        } catch (i) {
            (n = window.tolstoyCaptureError) == null || n.call(window, i, "Error getting product page config:")
        }
    }),
    sn = e => y(void 0, null, function*() {
        var n;
        const t = St(),
            o = G(),
            s = Et(w(m({}, e), {
                v: o
            }));
        try {
            return (yield fetch(`${t}/settings/widget/by-product-id?${s}`)).json()
        } catch (i) {
            (n = window.tolstoyCaptureError) == null || n.call(window, i, "Error getting product page config:")
        }
    }),
    nn = (e, t) => y(void 0, null, function*() {
        var i, r;
        const o = St(),
            s = G(),
            n = Et({
                appKey: e,
                collectionId: t,
                v: s
            });
        try {
            const c = yield(yield fetch(`${o}/settings/widget/get-collection-tile-config?${n}`)).json();
            if (Array.isArray(c) && c.some(d => d.project && d.collectionId)) {
                const d = ((i = window.Shopify) == null ? void 0 : i.shop) || wt();
                return c.filter(h => h.project.appUrl === d)
            }
        } catch (a) {
            (r = window.tolstoyCaptureError) == null || r.call(window, a, "Error getting collection tile config:")
        }
        return []
    }),
    rn = e => y(void 0, null, function*() {
        var o;
        const t = new URLSearchParams(e);
        try {
            return (yield fetch(`${ge}/settings/bubble?${t.toString()}`)).json()
        } catch (s) {
            (o = window.tolstoyCaptureError) == null || o.call(window, s, "Error getting bubble settings:")
        }
    }),
    Rl = (e, t) => y(void 0, null, function*() {
        var i;
        const o = St(),
            s = G(),
            n = Et({
                publishId: e,
                collectionId: t,
                v: s
            });
        try {
            return (yield fetch(`${o}/settings/collection-page-tile-config?${n}`)).json()
        } catch (r) {
            (i = window.tolstoyCaptureError) == null || i.call(window, r, "Error getting collection page tile config:")
        }
    }),
    To = e => y(void 0, null, function*() {
        var t;
        if (window.location.origin !== {}.VITE_BASE_URL && R()) try {
            return yield fetch(`${uo}/events/event`, {
                method: "POST",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(e)
            })
        } catch (o) {
            (t = window.tolstoyCaptureError) == null || t.call(window, o, "Error sending page view:")
        }
    }),
    le = me(To),
    Ll = e => y(void 0, null, function*() {
        var t;
        try {
            return yield fetch(`${$s}?publishId=${e}`)
        } catch (o) {
            (t = window.tolstoyCaptureError) == null || t.call(window, o)
        }
    }),
    an = me(e => {
        var t;
        if (R()) try {
            window.navigator.sendBeacon(xs, JSON.stringify(e))
        } catch (o) {
            const s = "Error occurred in createSiteActivityEvent";
            console.error(s, o), (t = window.tolstoyCaptureError) == null || t.call(window, o, s)
        }
    }),
    cn = me(e => {
        var t;
        if (R()) try {
            window.navigator.sendBeacon(Hs, JSON.stringify(e))
        } catch (o) {
            const s = "Error occurred in createPageVisitEvent";
            console.error(s, o), (t = window.tolstoyCaptureError) == null || t.call(window, o, s)
        }
    }),
    ln = "custom-blocks.tapcart.com",
    Tt = () => {
        var e, t, o;
        return !!((e = window == null ? void 0 : window.Tapcart) != null && e.isInitialized || (o = (t = document.location) == null ? void 0 : t.host) != null && o.includes(ln))
    },
    Io = () => {
        var t, o, s;
        const e = (s = (o = (t = window == null ? void 0 : window.Tapcart) == null ? void 0 : t.variables) == null ? void 0 : o.device) == null ? void 0 : s.id;
        return e == null ? void 0 : e.toLowerCase()
    },
    bo = () => {
        var e, t;
        return ((t = (e = window == null ? void 0 : window.location) == null ? void 0 : e.hostname) == null ? void 0 : t.includes) && window.location.hostname.includes("app.tapcart.com")
    },
    fe = {
        TOLSTOY_HIDE_WIDGET_STORAGE_KEY: "tolstoy-hide-widget",
        TOLSTOY_SESSION_ID_KEY: "tolstoy-session-id",
        TOLSTOY_SESSION_UNIQUE_ID_KEY: "tolstoy-session-unique-id",
        TOLSTOY_PRODUCT_RECOMMENDATIONS: "tolstoy-product-recommendation",
        TOLSTOY_ANONYMOUS_ID: "tolstoy-anonymousId",
        TOLSTOY_REPLY: "tolstoy-reply",
        TOLSTOY_GROUP: "tolstoy-group",
        TOLSTOY_PUBLISH_ID: "tolstoy-publishId",
        TOLSTOY_ACTIVITY_KEY: "tolstoy-activity",
        TOLSTOY_NOT_VISIBLE_OPENED_PUBLISH_ID_KEY: "tolstoy-not-visible-opened-publish-id",
        TOLSTOY_INTERACTION_DATE: "tolstoy-interaction-date",
        IS_SHOPIFY_CART_ANONYMOUS_ID_SET_KEY: "tolstoy-is-shopify-cart-anonymous-id-set",
        TOLSTOY_COOKIE_POLICY: "tolstoy-cookie-policy",
        TOLSTOY_RECREATE_RESOLUTIONS_PREFIX: "tolstoy-recreate-resolutions",
        TOLSTOY_AB_TEST_GROUP: "tolstoy-ab-test-group"
    },
    kt = {
        accepted: "accepted",
        rejected: "rejected"
    },
    C = {
        IDENTIFY_INFO_ID_KEY: "identifyInfoId",
        SESSION_COUNTER_KEY: "tolstoySessionCounter",
        LAST_SEEN_AT_KEY: "tolstoyLastSeenAtKey",
        FIRST_SEEN_AT_KEY: "tolstoyFirstSeenAtKey",
        TOLSTOY_VIEWERS_KEY: "tolstoyViewers",
        TOLSTOY_VIEWED_PRODUCTS: "tolstoyViewedProducts",
        CURRENT_CUSTOMER_EMAIL_KEY: "tolstoyCurrentCustomer",
        BUBBLE_TEXT_PREFIX: "bubbleText",
        NOTIFICATION_BADGE_PREFIX: "notificationBadge",
        RECREATE_NEW_RESOLUTION_PREFIX: "reCreateNewResolution"
    },
    {
        TOLSTOY_COOKIE_POLICY: Co
    } = fe;

function Lt() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
        const t = Math.trunc(Math.random() * 16);
        return (e === "x" ? t : t & 3 | 8).toString(16)
    })
}

function X(e) {
    var t;
    try {
        return e()
    } catch (o) {
        return (t = window.tolstoyCaptureError) == null || t.call(window, o), null
    }
}

function $(e) {
    return X(() => window.sessionStorage.getItem(e))
}

function N(e) {
    return X(() => localStorage.getItem(e)) || $(e)
}

function mt(e) {
    return N(e) || $(e)
}

function x(e, t, o = !1) {
    X(() => {
        if (!(Ee() === kt.rejected && !o)) return window.sessionStorage.setItem(e, t)
    })
}

function H(e, t, o = !1) {
    X(() => {
        if (Ee() !== kt.rejected) return localStorage.setItem(e, t);
        if (o) return window.sessionStorage.setItem(e, t)
    })
}

function j(e, t, o = !1) {
    X(() => {
        if (Ee() !== kt.rejected) return localStorage.setItem(e, t);
        if (o) return window.sessionStorage.setItem(e, t)
    })
}

function dn(e) {
    return X(() => window.sessionStorage.removeItem(e))
}
const Ee = () => mt(Co),
    un = e => {
        j(Co, e, !0)
    },
    _o = e => {
        const t = window.location.host;
        document.cookie = `${e}=; path=/; domain=.${t}; expires=Thu, 01 Jan 1970 00:00:00 UTC;`, document.cookie = `${e}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC;`
    },
    Pt = e => [...Object.values(fe), ...Object.values(C)].some(o => e.includes(o));

function pn() {
    const e = document.cookie.split("; ");
    for (const t of e) {
        const [o] = t.split("=");
        Pt(o.trim()) && _o(o)
    }
    for (const t in localStorage) Pt(t) && localStorage.removeItem(t);
    for (const t in sessionStorage) Pt(t) && sessionStorage.removeItem(t)
}
const hn = () => {
    const e = document.cookie.split("; ");
    for (const t of e) {
        const [o] = t.split("=");
        Pt(o.trim()) && _o(o)
    }
};
hn();
const {
    TOLSTOY_HIDE_WIDGET_STORAGE_KEY: we,
    TOLSTOY_SESSION_ID_KEY: Se,
    TOLSTOY_SESSION_UNIQUE_ID_KEY: vo,
    TOLSTOY_PRODUCT_RECOMMENDATIONS: yn,
    TOLSTOY_ANONYMOUS_ID: Ao,
    TOLSTOY_REPLY: gn,
    TOLSTOY_GROUP: Ml,
    TOLSTOY_PUBLISH_ID: mn,
    TOLSTOY_ACTIVITY_KEY: Bt,
    TOLSTOY_NOT_VISIBLE_OPENED_PUBLISH_ID_KEY: Oo,
    TOLSTOY_INTERACTION_DATE: He,
    IS_SHOPIFY_CART_ANONYMOUS_ID_SET_KEY: Po,
    TOLSTOY_RECREATE_RESOLUTIONS_PREFIX: Nl,
    TOLSTOY_AB_TEST_GROUP: Ro
} = fe;

function de(e) {
    return e ? `${He}-${e}` : He
}

function fn() {
    return mt(Ao)
}

function En(e) {
    !e || ["undefined", "false"].includes(e) || j(Ao, e)
}

function $t() {
    let t = (Tt() ? Io() : null) || fn() || Lt();
    return t === "false" && (t = Lt()), En(t), t
}

function wn(e) {
    j(mn, e, !0)
}

function Mt() {
    return JSON.parse($(Bt) || "{}")
}

function Lo({
    publishId: e,
    timeStamp: t,
    type: o,
    sessionId: s
}) {
    const n = Mt() || {},
        i = n[e] || [];
    n[e] = [...i, {
        timeStamp: t,
        type: o,
        sessionId: s
    }], x(Bt, JSON.stringify(n), !0)
}
const Sn = ({
        publishId: e,
        productId: t
    }) => {
        const o = In(),
            s = o[t] || [],
            n = {
                interactionDate: new Date().toISOString(),
                publishId: e,
                productId: t
            };
        s.push(n), o[t] = s, bn(o)
    },
    Tn = () => {
        x(Bt, "{}", !0)
    };

function Ul(e) {
    j(gn, e)
}

function Dl() {
    j(yn, !0)
}
const Yt = () => JSON.parse(N(C.TOLSTOY_VIEWERS_KEY) || "{}"),
    In = () => JSON.parse(mt(C.TOLSTOY_VIEWED_PRODUCTS) || "{}"),
    bn = e => {
        j(C.TOLSTOY_VIEWED_PRODUCTS, JSON.stringify(e))
    },
    Gt = e => {
        H(C.TOLSTOY_VIEWERS_KEY, JSON.stringify(e))
    };

function Cn(e) {
    return mt(de(e)) || mt(de())
}

function _n(e) {
    H(C.IDENTIFY_INFO_ID_KEY, e)
}

function vn() {
    return N(C.IDENTIFY_INFO_ID_KEY)
}

function An() {
    localStorage.removeItem(C.IDENTIFY_INFO_ID_KEY)
}
const On = e => {
        H(C.SESSION_COUNTER_KEY, e)
    },
    Mo = () => Number(N(C.SESSION_COUNTER_KEY)),
    Pn = e => {
        H(C.FIRST_SEEN_AT_KEY, e)
    },
    No = () => N(C.FIRST_SEEN_AT_KEY);

function Rn(e) {
    const t = new Date().toISOString();
    j(de(e), t)
}
const Uo = e => $(`${we}-${e}`),
    kl = e => x(`${we}-${e}`, "true", !0),
    Bl = e => window.sessionStorage.removeItem(`${we}-${e}`),
    xt = () => $(Se),
    Do = e => x(Se, e, !0),
    $l = () => dn(Se),
    Te = () => {
        const e = $(vo);
        return e || Ln()
    },
    Ln = () => {
        const e = Lt();
        return x(vo, e, !0), e
    },
    Mn = () => {
        const e = $(Oo);
        return !e || e === "null" ? null : e
    },
    Ie = e => x(Oo, e, !0),
    Nn = (e, t) => {
        const o = Mt() || {},
            s = o[e] || [];
        if (!(s != null && s.length)) return;
        const n = s[s.length - 1];
        n.sessionId = t, x(Bt, JSON.stringify(o), !0)
    },
    Un = () => $(Po),
    Dn = e => x(Po, e),
    xl = (e, t) => H(`${C.NOTIFICATION_BADGE_PREFIX}-${e}`, t, !0),
    Hl = e => N(`${C.NOTIFICATION_BADGE_PREFIX}-${e}`),
    Wl = (e, t, o) => H(`${C.BUBBLE_TEXT_PREFIX}-${e}-${t}`, o, !0),
    Vl = (e, t) => N(`${C.BUBBLE_TEXT_PREFIX}-${e}-${t}`),
    Fl = (e, t) => H(`${C.RECREATE_NEW_RESOLUTION_PREFIX}-${e}`, t, !0),
    Yl = e => N(`${C.RECREATE_NEW_RESOLUTION_PREFIX}-${e}`),
    kn = (e, t) => H(`${Ro}-${e}`, t, !0),
    Bn = e => N(`${Ro}-${e}`),
    $n = 1e3 * 60 * 60 * 24,
    ot = e => `tolstoy${Ws(e)}`,
    jt = e => {
        R() && (Hn(e), xn(e))
    },
    xn = e => {
        const {
            data: {
                name: t,
                text: o,
                facebookAnalyticsID: s,
                playlist: n,
                collectInfoType: i
            }
        } = e;
        if (!window.fbq || !s || !n) return;
        const r = `tolstoy-${n}`;
        switch (t) {
            case f.sessionStart:
                U(s, `${r}-click`, {
                    value: "Start Tolstoy"
                });
                break;
            case f.clickCta:
                U(s, `${r}-click`, {
                    value: o
                });
                break;
            case f.submitInput:
                U(s, `${r}-input`, {
                    value: o
                });
                break;
            case f.collectInfo:
                U(s, `${r}-${D.collectInfo}`, {
                    value: i
                });
                break;
            case f.videoResponse:
                U(s, `${r}-${D.videoResponse}`);
                break;
            case f.imageResponse:
                U(s, `${r}-${D.imageResponse}`);
                break;
            case f.audioResponse:
                U(s, `${r}-${D.audioResponse}`);
                break;
            case D.sessionEnd:
                U(s, `${r}-${D.sessionEnd}`);
                break
        }
    },
    U = (e, t, o) => {
        window.fbq("trackSingleCustom", e, t, o)
    },
    Hn = e => {
        const {
            data: {
                name: t,
                text: o,
                googleAnalyticsID: s,
                playlist: n,
                collectInfoType: i,
                productNames: r,
                totalTime: a,
                videoName: c,
                type: d,
                direction: h
            }
        } = e;
        if (!window.gtag && !window.dataLayer && !window.ga || !s || !n) return;
        const p = `tolstoy-${n}`;
        switch (t) {
            case S.pageView:
                break;
            case D.sessionStart:
            case f.sessionStart:
                v(s, p, f.sessionStart), v(s, p, "click", "Start Tolstoy");
                break;
            case f.clickCta:
                v(s, p, t, o);
                break;
            case f.collectInfo:
                v(s, p, t, i);
                break;
            case f.submitInput:
            case f.imageResponse:
            case f.audioResponse:
            case f.videoResponse:
            case f.sessionEnd:
                v(s, p, t);
                break;
            case S.tolstoyModalClose:
                v(s, p, S.tolstoyModalClose, a);
                break;
            case S.videoLoaded:
                r && v(s, p, "tolstoyVideoLoaded-products", r), v(s, p, "tolstoyVideoLoaded-videoName", c);
                break;
            case S.feedProductModalOpen:
            case S.feedProductModalClose:
            case S.clickViewProduct:
            case S.openProductPageClick:
                v(s, p, ot(t), r);
                break;
            case S.feedPlay:
            case S.feedPause:
            case S.videoMuted:
            case S.videoUnmuted:
            case S.videoWatched:
                v(s, p, ot(t), c);
                break;
            case S.openShareLink:
                v(s, p, ot("openShareLink"), d);
                break;
            case S.feedNavigationArrowClick:
            case S.feedScroll:
                v(s, p, ot(t), h);
                break;
            default:
                v(s, p, ot(t), o)
        }
    },
    v = (e, t, o, s) => {
        R() && (window.gtag ? window.gtag("event", o, {
            event_category: t,
            event_label: s,
            send_to: e
        }) : window.dataLayer && window.dataLayer.push({
            event: o,
            event_category: t,
            event_label: s,
            send_to: e
        }))
    },
    ue = {},
    Kt = (e, t) => {
        ue[e] = ue[e] || t
    };
let We = !1;
const Wn = () => {
        var e;
        if (!We) try {
            const t = P();
            Vn({
                appKey: t
            }), We = !0
        } catch (t) {
            console.error(t), (e = window.tolstoyCaptureError) == null || e.call(window, t)
        }
    },
    Vn = ({
        appKey: e
    } = {}) => {
        let t = 0,
            o = !1;
        if (Ie(null), !Gs(e)) return;
        const s = ({
            now: n,
            performanceNow: i
        }) => {
            var _;
            o = !1;
            let r = Mt();
            Kn(n, r), r = Mt();
            const a = Math.round(i - t),
                c = Te(),
                d = Fn(r),
                h = window.location.href.split("?")[0],
                p = Dt(),
                I = {
                    appKey: e,
                    sessionUniqueId: c,
                    timestamp: new Date().toISOString(),
                    anonymousId: $t(),
                    storeUrl: (_ = window.Shopify) == null ? void 0 : _.shop,
                    siteActivity: d,
                    eventName: Ms,
                    timeOnPage: a,
                    pageUrl: h,
                    currentPageProductId: p
                };
            an(I), o = !0, Tn()
        };
        document.addEventListener("visibilitychange", () => {
            var n;
            try {
                const i = Date.now(),
                    r = window.performance.now();
                document.visibilityState === "visible" && (t = r, o = !1, jn(i)), document.visibilityState === "hidden" && !o && s({
                    now: i,
                    performanceNow: r
                })
            } catch (i) {
                console.error(i), (n = window.tolstoyCaptureError) == null || n.call(window, i)
            }
        }), window.addEventListener("beforeunload", () => {
            var n;
            if (!o) try {
                const i = Date.now(),
                    r = window.performance.now();
                s({
                    now: i,
                    performanceNow: r
                })
            } catch (i) {
                console.error(i), (n = window.tolstoyCaptureError) == null || n.call(window, i)
            }
        })
    },
    Fn = e => {
        const t = {};
        for (const [o, s] of Object.entries(ue)) {
            const n = e[o];
            !(n != null && n.length) && !t[o] && (t[o] = {
                activity: {},
                totalTime: 0,
                impression: s
            });
            const i = Yn({
                publishId: o,
                activities: n
            });
            let r = 0;
            for (const a of Object.values(i)) r += a;
            t[o] = {
                activity: i,
                totalTime: r,
                impression: s
            }
        }
        return t
    },
    Yn = ({
        publishId: e,
        activities: t
    }) => {
        if (!e || !(t != null && t.length)) return {};
        const o = Date.now(),
            s = {},
            n = {};
        for (const {
                timeStamp: i,
                type: r,
                sessionId: a
            } of t) n[a] = n[a] || 0, s[a] === void 0 && (s[a] = !1), fo(r) && !s[a] && (s[a] = !0, n[a] -= i), js(r) && s[a] && (s[a] = !1, n[a] += i);
        for (const [i, r] of Object.entries(s)) r && (n[i] += o), (n[i] <= 0 || n[i] > $n) && delete n[i];
        return n
    },
    Gn = e => {
        var t;
        return (t = Object.entries(e).find(([o, s]) => {
            if (s.length === 0) return;
            const n = s[s.length - 1].type;
            return fo(n)
        })) == null ? void 0 : t[0]
    },
    jn = e => {
        const t = Mn(),
            o = xt();
        !t || !o || (Lo({
            publishId: t,
            timeStamp: e,
            type: z.OPEN,
            sessionId: o
        }), Ie(null))
    },
    Kn = (e, t) => {
        const o = Gn(t),
            s = xt();
        !o || !s || (Lo({
            publishId: o,
            timeStamp: e,
            type: z.CLOSE,
            sessionId: s
        }), Ie(o))
    },
    ko = () => {
        var n;
        const e = P();
        if (!e) return;
        const t = window.location.href.split("?")[0],
            o = Dt(),
            s = {
                appKey: e,
                sessionUniqueId: Te(),
                createdAt: new Date().toISOString(),
                anonymousId: $t(),
                appUrl: (n = window.Shopify) == null ? void 0 : n.shop,
                eventName: Ns,
                parentUrl: t,
                currentPageProductId: o
            };
        cn(s)
    },
    zn = () => {
        const e = new CustomEvent("tolstoyWidgetReady");
        window.dispatchEvent(e)
    },
    Gl = () => {
        const e = new CustomEvent(so);
        window.dispatchEvent(e)
    },
    Nt = {
        PDP_CAROUSEL: "pdp-carousel",
        VIDEO_PAGE: "video-page"
    },
    k = {
        HEADER: "header",
        HEADER_AND_BOTTOM_NAVBAR: "header-and-bottom-navbar",
        CUSTOM_SCREEN: "custom-screen",
        CUSTOM_SCREEN_AND_BOTTOM_NAVBAR: "custom-screen-and-bottom-navbar"
    },
    be = e => document.documentElement.style.setProperty("height", `${e}px`, "important"),
    qn = () => navigator.userAgent.toLowerCase().includes("android"),
    Zn = e => {
        const t = window.screen.availHeight,
            o = window.Tapcart.variables.device.windowHeight;
        switch (e) {
            case k.HEADER:
                return o;
            case k.HEADER_AND_BOTTOM_NAVBAR:
                return o;
            case k.CUSTOM_SCREEN:
                return t - 100;
            case k.CUSTOM_SCREEN_AND_BOTTOM_NAVBAR:
                return t - 184;
            default:
                return o || t
        }
    },
    Xn = e => {
        const t = window.screen.availHeight,
            o = window.Tapcart.variables.device.windowHeight;
        switch (e) {
            case k.HEADER:
                return o;
            case k.HEADER_AND_BOTTOM_NAVBAR:
                return o - 75;
            case k.CUSTOM_SCREEN:
                return t - 90;
            case k.CUSTOM_SCREEN_AND_BOTTOM_NAVBAR:
                return t - 175;
            default:
                return o || t
        }
    },
    Qn = e => qn() ? Zn(e) : Xn(e),
    Jn = (e, t) => {
        const o = Qn(t.navType);
        be(o)
    },
    ti = e => `
    <style>
      .tolstoy-video-page iframe {
        display: block !important;
      }
    </style>
    <tolstoy-video-page
      id="tolstoy-tv-container"
      class="tolstoy-video-page"
      data-publish-id="${e}"
    ></tolstoy-video-page>
  `,
    ei = (e = {}) => {
        const {
            height: t = 490
        } = e;
        let o = 0;
        const s = setInterval(function() {
            o++;
            const n = document.querySelector(".tolstoy-carousel-container"),
                i = document.querySelector(".tolstoy-carousel");
            n && i ? (i.style.display = "block", be(t), clearInterval(s)) : o >= 50 && clearInterval(s)
        }, 200)
    },
    oi = (e, t) => {
        be(0), ei(t)
    },
    si = e => {
        var o, s, n;
        const t = (n = (s = (o = window == null ? void 0 : window.Tapcart) == null ? void 0 : o.variables) == null ? void 0 : s.product) == null ? void 0 : n.id;
        return `
    <style>
      * {
        box-sizing: border-box;
        padding: 0;
        margin: 0;
        font-family: Helvetica;
      }
      
      .tolstoy-carousel-wrapper {
        padding-bottom: 25px;
      }
      
      .tolstoy-carousel iframe {
        display: block !important;
      }
    </style>
    <div class="tolstoy-carousel-wrapper">
      <tolstoy-carousel
        class="tolstoy-carousel"
        data-publish-id="${e}"
        style="display: none"
        ${t?`data-product-id="${t}"`:""}
      ></tolstoy-carousel>
    </div>
  `
    },
    ni = (e, t) => y(void 0, null, function*() {
        switch (t.blockType) {
            case Nt.PDP_CAROUSEL:
                oi(e, t);
                break;
            case Nt.VIDEO_PAGE:
                Jn(e, t);
                break
        }
    }),
    ii = `
<style>
#tapcart-dashboard-fallback-ui {
  padding: 8px;
  line-height: 20px;
  border: 1px solid black;
}
</style>
<div id="tapcart-dashboard-fallback-ui">
Tolstoy widget will appear here.
<br/>
Click on preview in top right to see widget.
</div>
`,
    ri = () => y(void 0, null, function*() {
        const e = document.querySelectorAll("tolstoy-block");
        if (e.length !== 0) {
            if (bo()) {
                for (const t of Array.from(e)) t.outerHTML = ii;
                return
            }
            for (const t of Array.from(e)) {
                const {
                    publishId: o,
                    blockType: s,
                    navType: n,
                    height: i
                } = t.dataset || {}, r = {
                    blockType: s,
                    navType: n,
                    height: i
                };
                let a = "";
                switch (s) {
                    case Nt.PDP_CAROUSEL:
                        a = si(o);
                        break;
                    case Nt.VIDEO_PAGE:
                        a = ti(o);
                        break
                }
                a && (t.outerHTML = a, ni(t, r))
            }
        }
    }),
    ai = function() {
        const t = typeof document != "undefined" && document.createElement("link").relList;
        return t && t.supports && t.supports("modulepreload") ? "modulepreload" : "preload"
    }(),
    ci = function(e) {
        return "https://widget.gotolstoy.com/we/" + e
    },
    Ve = {},
    O = function(t, o, s) {
        if (!o || o.length === 0) return t();
        const n = document.getElementsByTagName("link");
        return Promise.all(o.map(i => {
            if (i = ci(i), i in Ve) return;
            Ve[i] = !0;
            const r = i.endsWith(".css"),
                a = r ? '[rel="stylesheet"]' : "";
            if (!!s)
                for (let h = n.length - 1; h >= 0; h--) {
                    const p = n[h];
                    if (p.href === i && (!r || p.rel === "stylesheet")) return
                } else if (document.querySelector(`link[href="${i}"]${a}`)) return;
            const d = document.createElement("link");
            if (d.rel = r ? "stylesheet" : ai, r || (d.as = "script", d.crossOrigin = ""), d.href = i, document.head.appendChild(d), r) return new Promise((h, p) => {
                d.addEventListener("load", h), d.addEventListener("error", () => p(new Error(`Unable to preload CSS for ${i}`)))
            })
        })).then(() => t()).catch(i => {
            const r = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (r.payload = i, window.dispatchEvent(r), !r.defaultPrevented) throw i
        })
    },
    Bo = ({
        tagName: e,
        src: t,
        container: o,
        attributes: s,
        style: n,
        styleString: i,
        classNames: r,
        eventListeners: a
    }) => {
        const c = document.createElement(e);
        if (a)
            for (const [d, h] of Object.entries(a)) c.addEventListener(d, h);
        if (t && (c.src = t), s)
            for (const [d, h] of Object.entries(s)) c.setAttribute(d, h);
        if (i && (c.style.cssText = i), n)
            for (const [d, h] of Object.entries(n)) c.style[d] = h;
        return r && c.classList.add(...r), o && o.append(c), c
    },
    Fe = ({
        src: e,
        container: t,
        attributes: o
    }) => Bo({
        tagName: "script",
        src: e,
        container: t,
        attributes: o
    }),
    jl = ({
        src: e,
        container: t,
        attributes: o,
        style: s
    }) => Bo({
        tagName: "iframe",
        src: e,
        container: t,
        attributes: o,
        style: s
    }),
    li = ({
        callback: e,
        classNames: t
    }) => {
        const o = d => t.some(h => d.getElementsByClassName(h).length > 0),
            s = d => t.includes(d),
            n = d => [...d.classList].some(s),
            i = d => d.classList ? n(d) || o(d) : !1,
            r = d => d.type !== "childList" || d.addedNodes.length === 0 ? !1 : [...d.addedNodes].some(i),
            a = d => {
                d.some(r) && e()
            };
        new window.MutationObserver(a).observe(document.body, {
            subtree: !0,
            childList: !0
        })
    },
    di = ({
        callback: e
    }) => {
        window.addEventListener("DOMContentLoaded", e), window.addEventListener("load", e)
    },
    $o = ({
        callback: e,
        classNames: t
    }) => {
        di({
            callback: e
        }), "MutationObserver" in window && li({
            callback: e,
            classNames: t
        })
    },
    Kl = ({
        video: e,
        onError: t
    }) => e == null ? void 0 : e.play().catch(t),
    ui = e => {
        const t = document.createElement("div");
        return t.innerHTML = e.trim(), t.firstChild
    },
    pi = (e, t) => `${e}-${t}`,
    hi = (e, t) => `[data-tolstoy-element="${pi(e,t)}"]`,
    zl = (e, t) => window.document.querySelector(hi(e, t)),
    ql = (e, t) => `[${e}="${t}"]`,
    Zl = (e, t) => window.document.querySelector(`[${e}="${t}"]`),
    Xl = `<svg style="margin-left: 0.5px; width: 11px !important; height: 10px !important;" width="11" height="10" viewBox="0 0 14 13" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M13.0547 12.5938C12.8203 12.8281 12.3906 12.8281 12.1562 12.5938L7 7.39844L1.80469 12.5938C1.57031 12.8281 1.14062 12.8281 0.90625 12.5938C0.671875 12.3594 0.671875 11.9297 0.90625 11.6953L6.10156 6.5L0.90625 1.34375C0.671875 1.10938 0.671875 0.679688 0.90625 0.445312C1.14062 0.210938 1.57031 0.210938 1.80469 0.445312L7 5.64062L12.1562 0.445312C12.3906 0.210938 12.8203 0.210938 13.0547 0.445312C13.2891 0.679688 13.2891 1.10938 13.0547 1.34375L7.85938 6.5L13.0547 11.6953C13.2891 11.9297 13.2891 12.3594 13.0547 12.5938Z" fill="white"/>
</svg>
`,
    Ql = (e = "#FFFFFF") => `<svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.055 16.594a.662.662 0 0 1-.899 0L10 11.398l-5.195 5.196a.662.662 0 0 1-.899 0 .662.662 0 0 1 0-.899L9.102 10.5 3.906 5.344a.662.662 0 0 1 0-.899.662.662 0 0 1 .899 0L10 9.641l5.156-5.196a.662.662 0 0 1 .899 0 .662.662 0 0 1 0 .899L10.859 10.5l5.196 5.195a.662.662 0 0 1 0 .899Z" style="fill: ${e} !important;"
   /></svg>`,
    Jl = (e = "#fff", t = "") => `<svg class="${t}" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 3.532c0-1.554 1.696-2.514 3.029-1.715l14.113 8.468c1.294.777 1.294 2.653 0 3.43L7.029 22.183c-1.333.8-3.029-.16-3.029-1.715V3.532Z" fill="${e}"/></svg>`,
    td = '<svg width="10" height="18" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.797 16.664.648 9.204A1.071 1.071 0 0 1 .375 8.5c0-.195.078-.43.234-.625L7.758.415a.932.932 0 0 1 1.328-.04c.39.352.39.938.039 1.328L2.602 8.5l6.562 6.875a.932.932 0 0 1-.039 1.328.932.932 0 0 1-1.328-.039Z" fill="#090A0B"/></svg>',
    ed = '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.804 6.563 6.902 2.661l.619-.619L12.478 7l-4.983 4.983-.619-.619 3.927-3.926H1.96v-.875z" fill="#fff" stroke="#fff"/></svg>',
    od = `<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="20 16 10 12" fill="none">
  <path d="M22.1274 28L28.1274 22L22.1274 16" stroke="#5C5C5C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`,
    sd = (e = "#fff", t = "") => `
<svg class="${t}" width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g clipPath="url(#pauseIcon)">
    <path
      d="M4.375 2.5c-.633 0-1.125.516-1.125 1.125v6.75A1.11 1.11 0 0 0 4.375 11.5h.75c.61 0 1.125-.492 1.125-1.125v-6.75A1.14 1.14 0 0 0 5.125 2.5h-.75Zm4.5 0c-.633 0-1.125.516-1.125 1.125v6.75A1.11 1.11 0 0 0 8.875 11.5h.75c.61 0 1.125-.492 1.125-1.125v-6.75A1.14 1.14 0 0 0 9.625 2.5h-.75Z"
      fill="#fff"
    />
  </g>
  <defs>
    <clipPath id="pauseIcon">
      <path fill="${e}" d="M3 2.5h8v9H3z" />
    </clipPath>
  </defs>
</svg>
`,
    nd = ({
        color: e = "#fff",
        className: t = ""
    } = {}) => `<svg class="${t}" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Mute tolstoy video"><path d="M6.266 1.551a0.667 0.667 0 0 1 0.382 0.583v7.714c0 0.261 -0.161 0.482 -0.381 0.602a0.651 0.651 0 0 1 -0.703 -0.12L2.85 7.918h-1.346a1.269 1.269 0 0 1 -1.286 -1.286v-1.286c0 -0.703 0.562 -1.286 1.286 -1.286h1.346L5.563 1.671a0.651 0.651 0 0 1 0.703 -0.12Zm2.492 2.651 1.105 1.106 1.105 -1.106c0.18 -0.18 0.483 -0.18 0.663 0 0.201 0.201 0.201 0.502 0 0.683L10.526 5.991l1.106 1.104c0.201 0.201 0.201 0.502 0 0.683a0.44 0.44 0 0 1 -0.663 0l-1.106 -1.105 -1.104 1.106c-0.201 0.201 -0.502 0.201 -0.683 0 -0.201 -0.182 -0.201 -0.483 0 -0.684l1.105 -1.105L8.073 4.886c-0.2 -0.18 -0.2 -0.482 0 -0.683 0.182 -0.18 0.483 -0.18 0.684 0Z" fill="${e}"/></svg>`,
    id = ({
        color: e = "#fff",
        className: t = ""
    } = {}) => `<svg class="${t}" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Unmute tolstoy video"><path d="M6.627 1.55c.238.101.411.342.411.583v7.714c0 .261-.173.482-.411.603a.742.742 0 0 1-.757-.121l-2.921-2.41H1.5c-.779 0-1.385-.563-1.385-1.286V5.347c0-.703.606-1.286 1.385-1.286h1.449l2.921-2.39a.742.742 0 0 1 .757-.121Zm3.721 1.447c.931.723 1.537 1.788 1.537 2.993 0 1.225-.606 2.29-1.537 2.993a.542.542 0 0 1-.735-.06c-.195-.201-.152-.502.065-.683.714-.522 1.168-1.326 1.168-2.25 0-.904-.454-1.708-1.168-2.23a.475.475 0 0 1-.065-.683.565.565 0 0 1 .735-.08ZM9.029 4.503c.476.362.779.884.779 1.487 0 .623-.303 1.145-.779 1.507a.55.55 0 0 1-.736-.081.454.454 0 0 1 .087-.663.966.966 0 0 0 .389-.763.928.928 0 0 0-.389-.743.475.475 0 0 1-.087-.683.57.57 0 0 1 .736-.061Z" fill="${e}"/></svg>`,
    yi = () => `
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff0000" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-alert"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
`,
    gi = () => `
<svg width="40" height="20" xmlns="http://www.w3.org/2000/svg">
    <rect width="40" height="20" rx="3" ry="3" style="fill:blue;"/>
    <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-size="8" font-weight="normal" fill="white" letter-spacing="0.1px">
        Publish
    </text>
</svg>
`;
class mi {
    constructor(t) {
        g(this, "postMessage", t => {
            var o;
            (o = this.broadcaster) == null || o.postMessage(t)
        });
        g(this, "addEventListener", (...t) => {
            var o;
            (o = this.receiver) == null || o.addEventListener(...t)
        });
        this.name = t || yo();
        try {
            "BroadcastChannel" in self && (this.broadcaster = new BroadcastChannel(this.name), this.receiver = new BroadcastChannel(this.name))
        } catch (o) {
            console.error("self is not defined", o)
        }
    }
}
class xo {
    constructor({
        shouldIncludeLogs: t = !1,
        shouldArchivePastEvents: o = !1
    } = {}) {
        g(this, "subscribeMultipleEvents", ({
            eventNames: t,
            callback: o,
            shouldIncludePastEvents: s
        }) => {
            for (const n of t) this.subscribe({
                eventName: n,
                callback: o,
                shouldIncludePastEvents: s
            })
        });
        g(this, "unsubscribeMultipleEvents", ({
            eventNames: t,
            callback: o
        }) => {
            for (const s of t) this.unsubscribe({
                eventName: s,
                callback: o
            })
        });
        this.broadcastHub = new mi, this.eventCallbacks = {}, this.pastEvents = {}, this.shouldIncludeLogs = t, this.shouldArchivePastEvents = o
    }
    logMessage(t) {
        this.shouldIncludeLogs && console.log(t)
    }
    throwError(t) {
        if (this.shouldIncludeLogs) throw new Error(t)
    }
    archivePastEvent(t) {
        if (!this.shouldArchivePastEvents) return;
        const {
            eventName: o
        } = t;
        this.pastEvents[o] || (this.pastEvents[o] = []), this.pastEvents[o].push(t)
    }
    postMessage(t) {
        this.archivePastEvent(t), this.broadcastHub.postMessage(t)
    }
    postPastEvents({
        eventName: t,
        callback: o
    }) {
        if (this.pastEvents[t])
            for (const s of this.pastEvents[t]) o({
                data: w(m({}, s), {
                    isPastEvent: !0
                })
            })
    }
    subscribe({
        eventName: t,
        callback: o,
        shouldIncludePastEvents: s
    }) {
        if (this.eventCallbacks[t] || (this.eventCallbacks[t] = new Set), this.eventCallbacks[t].has(o)) {
            this.throwError(`Already subscribed to event ${t} with this callback`);
            return
        }
        this.eventCallbacks[t].add(o), s && this.postPastEvents({
            eventName: t,
            callback: o
        })
    }
    unsubscribe({
        eventName: t,
        callback: o
    }) {
        if (!this.eventCallbacks[t]) {
            this.throwError(`Not subscribed to event ${t}`);
            return
        }
        if (!this.eventCallbacks[t].has(o)) {
            this.throwError("Callback is not subscribed");
            return
        }
        if (!this.eventCallbacks[t].delete(o)) {
            this.logMessage(`Not subscribed to event ${t} with this callback`);
            return
        }
        this.logMessage(`Unsubscribed from event ${t}`)
    }
    initListener(t) {
        this.broadcastHub.addEventListener("message", t)
    }
}
class rt extends xo {
    constructor() {
        if (rt.instance) return rt.instance;
        super({
            shouldArchivePastEvents: !0
        });
        g(this, "eventHandler", o => {
            const {
                data: s = {}
            } = o, {
                eventName: n
            } = s;
            if (this.eventCallbacks[n])
                for (const i of this.eventCallbacks[n]) i(o)
        });
        g(this, "postMessage", o => {
            const s = o.transmissionId || yo();
            return super.postMessage(w(m({}, o), {
                transmissionId: s
            })), s
        });
        g(this, "init", () => {
            this.initListener(this.eventHandler)
        });
        rt.instance = this
    }
}
const u = new rt;
Object.freeze(u);
const fi = {
        modalOpen: "tolstoyModalOpen",
        playerReady: "tolstoyPlayerReady",
        toggleFeedCloseButton: "toggleFeedCloseButton",
        showFeedProductModal: "showFeedProductModal",
        reportModalOpen: "tolstoyReportModalOpen",
        reportModalClose: "tolstoyReportModalClose",
        modalMessagingReady: "tolstoyModalMessagingReady",
        closePlayer: "tolstoyClosePlayer",
        userEmailUpdate: "tolstoyUserEmailUpdate"
    },
    Ei = {
        isRebuyAppInstalled: "tolstoyIsRebuyAppInstalled",
        openRebuyCart: "tolstoyOpenRebuyCart",
        rebuyCartShown: "rebuyCartShown",
        rebuyCartHidden: "rebuyCartHidden"
    },
    wi = {
        openKendoModal: "tolstoyOpenKendoModal",
        changeZIndex: "tolstoyChangeZIndex"
    },
    Si = {
        isTapcart: "tolstoyIsTapcart",
        openTapcartProduct: "tolstoyOpenTapcartProduct"
    },
    Ti = {
        getProductsMetafields: "getProductsMetafields",
        returnProductsMetafields: "returnProductsMetafields"
    },
    Ii = {
        isAfterpayAppInstalled: "tolstoyIsAfterpayAppInstalled"
    },
    bi = {
        productCardClick: "tolstoyProductCardClick"
    },
    Ci = {
        spotlightCarouselQuickShopClick: "tolstoySpotlightCarouselQuickShopClick"
    },
    _i = {
        externalEventSubscribed: "tolstoyExternalEventSubscribed",
        productCardClickSubscribed: "tolstoyProductCardClickSubscribed"
    },
    vi = {
        setAnonymousIdToCart: "tolstoySetAnonymousIdToCart",
        blockAnonymousIdToCart: "tolstoyBlockAnonymousIdToCart",
        addToCart: "tolstoyAddToCart",
        addToCartSuccess: "tolstoyAddToCartSuccess",
        addToCartError: "tolstoyAddToCartError",
        addToCartSoldOut: "tolstoyAddToCartSoldOut",
        addToCartDisableDefault: "tolstoyAddToCartDisableDefault",
        cartItemQuantityChange: "tolstoyCartItemQuantityChange",
        cartItemQuantityChangeSuccess: "tolstoyCartItemQuantityChangeSuccess",
        cartItemQuantityChangeError: "tolstoyCartItemQuantityChangeError",
        cartDataRequest: "tolstoyCartDataRequest",
        cartDataResponse: "tolstoyCartDataResponse"
    },
    Ai = {
        loginWithMultipassUrlRequest: "tolstoyLoginWithMultipassUrl",
        loginWithMultipassUrlResponse: "tolstoyLoginWithMultipassUrlResponseMessage"
    },
    Oi = {
        productRecommendationsRequest: "tolstoyProductRecommendationsRequest",
        productRecommendationsResponse: "tolstoyProductRecommendationsResponse"
    },
    Pi = {
        requestProductsUpdate: "tolstoyRequestProductsUpdate",
        productUpdateResponse: "tolstoyProductUpdateResponse",
        moveToUrl: "tolstoyMoveToUrl",
        isNonBaseCurrency: "tolstoyIsNonBaseCurrency"
    },
    Ri = {
        urlChange: "urlChange",
        urlLocaleUpdate: "tolstoyUrlLocaleUpdate"
    },
    Li = {
        openCommerceSettingsUpdate: "tolstoyOpenCommerceSettingsUpdate"
    },
    l = w(m(m(m(m(m(m(m(m(m(m(m(m(m(m(m({}, fi), Ei), wi), Ii), Ti), bi), Ci), _i), Si), vi), Ai), Oi), Pi), Ri), Li), {
        rejectCookiePolicy: "rejectCookiePolicy"
    }),
    Ho = "widget-loading",
    rd = "widget-onyou",
    ad = "widget-onyou-enableAllPages",
    Mi = "widget-video-fallback",
    cd = "carousel-show-dots",
    ld = "carousel-videos",
    dd = "hide-spotlight-plus-button",
    ud = "app-use-creator-profile",
    Ni = "block-shopify-add-to-cart-attribute",
    pd = "shopify-price-formatting",
    Ui = "Nunito Sans, sans-serif",
    hd = "tolstoy-custom-font-family",
    yd = "tolstoy-custom-heading-font-family",
    Ye = [];

function Di(e, t) {
    const o = "italic",
        s = "normal",
        n = {
            ".ttf": "truetype",
            ".otf": "opentype",
            ".woff": "woff",
            ".woff2": "woff2"
        },
        i = document.createElement("style");
    for (const r of Object.keys(e)) {
        const a = e[r],
            c = r.includes(o),
            d = r.split("-")[1] || r.replace(o, "") || s,
            h = c ? o : s,
            p = Object.keys(n).find(E => a.includes(E)),
            I = n[p],
            _ = a.replace("http://", "https://");
        i.append(document.createTextNode(`@font-face { font-family: '${t}'; src: url("${_}") format("${[I]}"); font-weight: ${d}; font-style: ${h}; font-display: swap;}`))
    }
    document.head.append(i)
}
const Wo = (e, t = 1) => {
        if (!(!e || t === 3)) {
            if (!document.querySelector("#tolstoyWidgetElement")) {
                setTimeout(() => {
                    Wo(e, t + 1)
                }, 1e3);
                return
            }
            document.querySelector("#tolstoyWidgetElement").style.fontFamily = `${e}, ${Ui}`
        }
    },
    ki = e => {
        const t = document.head.querySelectorAll("style");
        return Array.from(t).some(o => o.textContent.includes(`@font-face { font-family: '${e}';`))
    };

function Ge(e, t = "tolstoy-custom-font-family") {
    if (!e || Ye.includes(t) || ki(t)) return;
    const {
        sources: o
    } = e;
    Di(o, t), Wo(t), Ye.push(t)
}
let nt, je = "";
const Bi = e => {
        var o;
        const t = document.querySelector("#smile-ui-container");
        e && (je = (t == null ? void 0 : t.style.display) || ""), (o = t == null ? void 0 : t.style) == null || o.setProperty("display", e || je)
    },
    $i = e => {
        let t = 0;
        return o => {
            try {
                o()
            } catch (s) {
                try {
                    if (!R()) return;
                    fetch("https://api.gotolstoy.com/events/event", {
                        method: "POST",
                        headers: {
                            Accept: "application/json",
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            eventName: "widgetError",
                            text: s.message,
                            timestamp: new Date().toISOString(),
                            parentUrl: window.location.href,
                            appKey: e.data.appKey,
                            publishId: e.data.publishId,
                            sessionId: e.data.sessionId,
                            source: e.data.name,
                            answerKey: `${t}`,
                            currentPageProductId: o.toString(),
                            formData: `${(s&&s.stack||"").slice(0,1999)}`
                        })
                    })
                } catch (n) {
                    mo(n)
                }
            } finally {
                t++
            }
        }
    },
    xi = e => {
        if (e.data.name === f.sessionStart || e.data.name === D.autoplayStart) {
            const t = $i(e);
            t(() => wn(e.data.publishId)), t(() => Rn(e.data.appKey)), t(() => Do(e.data.sessionId)), t(() => Nn(e.data.publishId, e.data.sessionId)), t(() => Bi("none")), t(() => Hi(e.data.anonymousId))
        }
    },
    Hi = e => {
        window.Shopify && u.postMessage({
            eventName: l.setAnonymousIdToCart,
            anonymousId: e
        })
    },
    gd = ({
        data: {
            name: e,
            publishId: t,
            productIds: o
        } = {}
    }) => {
        if (e === fs)
            for (const s of o) Sn({
                productId: s,
                publishId: t
            })
    },
    md = e => {
        ze[e.data.name] && ze[e.data.name](e.data)
    },
    fd = e => {
        qe[e.data.name] && setTimeout(() => qe[e.data.name](), 500)
    },
    Wi = () => {
        var e, t;
        window.GorgiasChat && ((t = (e = window.GorgiasChat).open) == null || t.call(e), window.tolstoyWidget.hide(), document.head.insertAdjacentHTML("beforeend", "<style>#gorgias-chat-container iframe#chat-button { visibility: visible !important; display: block !important; }</style>"))
    },
    Vi = () => {
        var e, t;
        window.GorgiasChat && ((t = (e = window.GorgiasChat).close) == null || t.call(e), document.head.insertAdjacentHTML("beforeend", "<style>#gorgias-chat-container iframe#chat-button { visibility: hidden; display: none; }</style>"))
    },
    Fi = () => {
        window.adaEmbed && (window.adaEmbed.toggle(), window.tolstoyWidget.hide())
    },
    Yi = () => {
        document.head.insertAdjacentHTML("beforeend", "<style>#ada-button-frame { display: none; }</style>")
    },
    Gi = () => {
        window.fcWidget && (window.fcWidget.show(), window.fcWidget.open(), window.tolstoyWidget.hide())
    },
    ji = () => {
        window.fcWidget && (window.fcWidget.close(), window.fcWidget.hide(), window.tolstoyWidget.show())
    },
    Ki = () => {
        var e, t;
        if (!nt && ((e = window.Reamaze) != null && e.popup)) {
            window.Reamaze.popup(), window.tolstoyWidget.hide();
            return
        }
        window._support && nt && ((t = window.Reamaze) != null && t.reload) && (window._support.ui = nt, window.Reamaze.reload(), nt = null, window.tolstoyWidget.hide())
    },
    zi = () => {
        var e, t;
        (e = window._support) != null && e.ui && ((t = window.Reamaze) != null && t.reload) && (nt = window._support.ui, delete window._support.ui, window.Reamaze.reload(), window.tolstoyWidget.show())
    },
    qi = () => {
        const e = setTimeout(() => clearInterval(t), 9e3),
            t = setInterval(() => {
                window.Intercom && (window.Intercom("show"), window.tolstoyWidget.hide(), clearInterval(t), clearTimeout(e), window.Intercom("onHide", () => {
                    window.tolstoyWidget.show()
                }))
            })
    },
    Zi = () => {
        const e = setTimeout(() => clearInterval(t), 9e3),
            t = setInterval(() => {
                window.Intercom && (window.Intercom("update", {
                    hide_default_launcher: !0
                }), clearInterval(t), clearTimeout(e))
            }, 100)
    },
    Xi = () => {
        window.Tawk_API && (window.Tawk_API.maximize(), window.tolstoyWidget.hide())
    };

function Qi() {
    window.Tawk_API && window.Tawk_API.hideWidget()
}
const Ji = () => {
    window.LiveChatWidget && (window.LiveChatWidget.call("maximize"), window.tolstoyWidget.hide())
};

function tr() {
    window.LiveChatWidget && window.LiveChatWidget.call("hide")
}
const er = () => {
    window.HubSpotConversations && window.HubSpotConversations.widget && (window.HubSpotConversations.widget.open(), window.tolstoyWidget.hide())
};

function or() {
    window.HubSpotConversations && window.HubSpotConversations.widget && window.HubSpotConversations.widget.close()
}
const sr = () => {
        window.Beacon && (window.Beacon("open"), window.tolstoyWidget.hide(), window.Beacon("config", {
            display: {
                zIndex: "99999"
            }
        }))
    },
    nr = () => {
        window.Beacon && window.Beacon("config", {
            display: {
                zIndex: "0"
            }
        })
    },
    ir = () => {
        window.drift && (window.drift.api.toggleChat(), window.tolstoyWidget.hide())
    },
    rr = () => {
        window.drift && window.drift.api.widget.hide()
    },
    ar = () => {
        var e, t;
        window.zE && (window.zE("messenger", "open"), (t = (e = document.querySelector('[title="Button to launch messaging window"]')) == null ? void 0 : e.style) == null || t.setProperty("display", "block"), window.tolstoyWidget.hide())
    },
    cr = () => {
        const e = setTimeout(() => clearInterval(t), 5e3),
            t = setInterval(() => {
                var n, i, r;
                const o = document.querySelector('[title="Button to launch messaging window"]'),
                    s = document.querySelector('[title="Message from company"]');
                (n = o == null ? void 0 : o.style) == null || n.setProperty("display", "none"), (r = (i = s == null ? void 0 : s.parentElement) == null ? void 0 : i.style) == null || r.setProperty("display", "none"), o && s && (clearInterval(t), clearTimeout(e))
            }, 100);
        window.zE && window.zE("messenger", "close")
    },
    lr = () => {
        window.tidioChatApi && (window.tidioChatApi.show(), window.tidioChatApi.open(), window.tolstoyWidget.hide())
    },
    dr = () => {
        window.tidioChatApi && window.tidioChatApi.close()
    },
    ur = e => {
        if (window.certainly) switch (window.certainly.widgetStatus({
            action: "open"
        }), window.tolstoyWidget.hide(), e.data.key) {
            case "PmkMI":
                window.certainly.goTo({
                    module: "670442"
                });
                break;
            case "_23Hl":
                window.certainly.goTo({
                    module: "670178"
                });
                break;
            case "P9rfq":
                window.certainly.goTo({
                    module: "670179"
                });
                break
        }
    },
    pr = () => {
        window.certainly && window.certainly.widgetStatus({
            action: "hide"
        })
    },
    Ke = e => {
        document.head.insertAdjacentHTML("beforeend", `<style>${e} { visibility: hidden; display: none; }</style>`)
    },
    hr = () => {
        Ke("#vfChat+div"), Ke("#vfChat+div+div")
    },
    yr = "tolstoyHideFreshChat",
    gr = "tolstoyOpenFreshChat",
    mr = "tolstoyHideReamaze",
    fr = "tolstoyOpenReamaze",
    Er = "tolstoyHideAda",
    wr = "tolstoyOpenAda",
    Sr = "tolstoyHideTidio",
    Tr = "tolstoyOpenTidio",
    Ir = "tolstoyHideCertainly",
    br = "tolstoyOpenCertainly",
    Cr = "tolstoyHideVfChat",
    ze = {
        [f.openGorgias]: Wi,
        [f.openIntercom]: qi,
        [f.openTawkTo]: Xi,
        [f.openLiveChat]: Ji,
        [f.openHubSpot]: er,
        [f.openDrift]: ir,
        [f.openZendesk]: ar,
        [f.openHelpScout]: sr,
        [gr]: Gi,
        [fr]: Ki,
        [wr]: Fi,
        [Tr]: lr,
        [br]: ur
    },
    qe = {
        [f.hideGorgias]: Vi,
        [f.hideIntercom]: Zi,
        [f.hideTawkTo]: Qi,
        [f.hideLiveChat]: tr,
        [f.hideHubSpot]: or,
        [f.hideDrift]: rr,
        [f.hideZendesk]: cr,
        [f.hideHelpScout]: nr,
        [yr]: ji,
        [mr]: zi,
        [Er]: Yi,
        [Cr]: hr,
        [Sr]: dr,
        [Ir]: pr
    };
class _r {
    constructor({
        config: t,
        playerType: o,
        collectionId: s
    }) {
        this.config = t, this.publishId = t.publishId, this.playerType = o, this.sessionId = xt() || Lt(), this.anonymousId = $t(), this.currentPageProductId = Dt(), this.collectionId = s, this.errors = {}
    }
    getIsMobile() {
        return window.screen.width <= 450 || window.screen.height <= 450
    }
    getAnalyticsParams(t = {}) {
        var d;
        const {
            id: o,
            appKey: s,
            name: n,
            googleAnalyticsID: i
        } = this.config, r = window.location.href.split("?")[0], a = (d = window.Shopify) == null ? void 0 : d.shop, c = this.errors;
        return m({
            appKey: s,
            publishId: this.publishId,
            sessionId: this.sessionId,
            anonymousId: this.anonymousId,
            currentPageProductId: this.currentPageProductId,
            isMobile: this.getIsMobile(),
            pageUrl: r,
            storeUrl: a,
            appUrl: a,
            googleAnalyticsID: i,
            projectId: o,
            playlist: n,
            timestamp: new Date().toISOString(),
            parentUrl: window.location.href,
            playerType: this.playerType,
            customParams: c ? JSON.stringify(c) : void 0,
            collectionId: this.collectionId
        }, t)
    }
    sendEventToAllSources(t) {
        le(t), jt({
            data: w(m({}, t), {
                name: t.eventName
            })
        })
    }
    sendEventImmediately(t = {}, o = !1) {
        const s = this.getAnalyticsParams(t);
        To(s), !o && jt({
            data: w(m({}, s), {
                name: s.eventName
            })
        })
    }
    sendEvent(t = {}, o = !1) {
        if (!R()) return;
        const s = this.getAnalyticsParams(t);
        s.eventName === S.onYouClick && console.log("Analytics::sendEvent::params", s), le(s), !o && jt({
            data: w(m({}, s), {
                name: s.eventName
            })
        })
    }
    handlePageView() {
        Kt(this.publishId, !1), this.sendEvent({
            eventName: S.pageView
        })
    }
    handleEmbedView() {
        Kt(this.publishId, !0), this.sendEvent({
            eventName: S.embedView
        })
    }
    handleOnYouClick() {
        Kt(this.publishId, !0), Do(this.sessionId), this.sendEvent({
            eventName: S.onYouClick
        })
    }
    handleSessionStart() {
        const t = this.getAnalyticsParams({
            eventName: S.sessionStart
        });
        this.sendEventToAllSources(t), xi({
            data: w(m({}, t), {
                name: f.sessionStart
            })
        }), window.postMessage(w(m({}, t), {
            name: f.sessionStart
        }), "*")
    }
    handleVideoLoaded(t = {}) {
        const o = this.getAnalyticsParams(w(m({}, t), {
            eventName: S.videoLoaded
        }));
        this.sendEventToAllSources(o)
    }
    handleVideoWatched(t = {}) {
        const o = this.getAnalyticsParams(w(m({}, t), {
            eventName: S.videoWatched
        }));
        this.sendEventToAllSources(o)
    }
}
const zt = {
    A: "A",
    B: "B"
};
class vr {
    constructor(t) {
        this.widgetType = t
    }
    sendAbTestInitializedEvent({
        abTestId: t,
        group: o,
        excludeExternalAnalytics: s,
        probability: n
    }) {
        const i = {
            abTestId: t,
            eventName: S.abTestInitialized,
            sessionUniqueId: Te(),
            testGroup: o,
            probability: n
        };
        this.analytics.sendEventImmediately(i, s)
    }
    initializeGroup({
        abTestId: t,
        probability: o,
        excludeExternalAnalytics: s
    }) {
        const n = Bn(t);
        if (n) {
            this.group = n;
            return
        }
        const r = Math.random() > o ? zt.B : zt.A;
        this.group = r, this.sendAbTestInitializedEvent({
            abTestId: t,
            group: r,
            excludeExternalAnalytics: s,
            probability: o
        }), kn(t, r)
    }
    init(t) {
        if (!t) return;
        const {
            abTestSettings: o = {}
        } = t, {
            isEnabled: s,
            abTestId: n,
            probability: i,
            groupASettings: r = {},
            groupBSettings: a = {},
            excludeExternalAnalytics: c
        } = o;
        if (s) return this.analytics = new _r({
            config: t,
            playerType: this.widgetType
        }), this.initializeGroup({
            abTestId: n,
            probability: i,
            excludeExternalAnalytics: c
        }), this.group === zt.A ? r : a
    }
}
const Ce = ({
        config: e,
        featureKey: t
    }) => {
        var o;
        return (o = e == null ? void 0 : e.featureSettings) == null ? void 0 : o[t]
    },
    Ar = ({
        config: e,
        featureKey: t
    }) => {
        var o;
        return !!((o = e == null ? void 0 : e.featureSettings) != null && o[t])
    },
    Ed = (e = {}) => {
        const t = Ce({
            config: e,
            featureKey: Ho
        });
        return t == null ? void 0 : t.playerLazy
    },
    Vo = (e = {}) => {
        const t = Ce({
            config: e,
            featureKey: Ho
        });
        return t == null ? void 0 : t.playerOrigin
    },
    wd = (e = {}) => {
        const t = Ce({
            config: e,
            featureKey: Mi
        });
        return t == null ? void 0 : t.dontUseFallback
    },
    Sd = ".webp",
    Td = {
        VIDEO: "video",
        IMAGE: "image",
        GALLERY: "gallery"
    },
    st = {
        XS: 250,
        S: 480,
        M: 960,
        L: 1280,
        XL: 1920
    },
    Id = {
        [st.XS]: "_250",
        [st.S]: "_480",
        [st.M]: "_960",
        [st.L]: "_1280",
        [st.XL]: "_1920"
    },
    Fo = {
        "250x140": "250x140",
        "250x250": "250x250",
        "480x480": "480x480",
        "960x540": "960x540"
    },
    Yo = ({
        path: e = `${ho}/public`,
        ownerId: t = "",
        assetId: o = "",
        suffix: s = "",
        extension: n = ""
    }) => `${e}/${t}/${o}/${o}${s}${n}`,
    bd = ({
        stockAsset: e = {},
        posterSettings: t = {}
    }) => {
        const {
            useShopifyPoster: o = !0
        } = t, {
            shopifyPosterUrl: s,
            posterUrl: n
        } = e || {};
        return s && o ? s : n
    },
    Or = ({
        step: e,
        extension: t,
        posterSettings: o,
        size: s = Fo["250x250"],
        custom: n = {
            condition: "",
            callback: ""
        },
        path: i = `${ho}/public`
    }) => {
        var J;
        const {
            videoOwner: r,
            videoId: a,
            stockAsset: c = {},
            mediaAssets: d
        } = e;
        if (!a) return "";
        const {
            avatarUrl: h,
            posterUrl: p,
            hasOriginal: I,
            shopifyPosterUrl: _
        } = c || {}, {
            shopifyAttributes: E = {},
            shopifySpotlightAttributes: A = {},
            useShopifyPoster: T = !1
        } = o || {}, L = m(m({}, E), A), M = !!((J = Object.keys(L)) != null && J.length), Q = _ && T && M;
        if (p) return p;
        if (d && (d != null && d.images) && (d != null && d.images[s]) && !Q) return d.images[s];
        const W = !I && (h || p);
        if (_ && !1) {
            let tt = "width=300";
            return T && (tt = new URLSearchParams(L).toString()), `${_}&${tt}`
        }
        return p != null && p.endsWith(t) || p && !I ? p : n != null && n.condition && (n != null && n.callback) && n.condition({
            posterUrl: p,
            avatarUrl: h,
            extension: t,
            isDuplicated: W
        }) ? n.callback(c) : Yo({
            path: i,
            ownerId: r,
            assetId: a,
            extension: t
        })
    },
    Pr = ".avatar.0000000.webp",
    Rr = ".401.0000000.webp",
    Cd = ".avatar.0000000.jpg",
    _d = ".0000000.jpg",
    Lr = 480,
    Mr = ({
        isMobile: e,
        isStory: t,
        isPlayInTileFirst: o,
        isTile: s
    }) => o || s ? "_640.mp4" : e || t ? "_preview.mp4" : "_preview_embed.mp4",
    Ze = ({
        step: e,
        isStory: t,
        isPlayInTileFirst: o,
        height: s = Ts,
        isTile: n
    }) => {
        const {
            videoOwner: i,
            stockAsset: r,
            videoId: a
        } = e, c = window.innerWidth <= 450, d = Mr({
            isMobile: c,
            isStory: t,
            isPlayInTileFirst: o,
            isTile: n
        }), h = r == null ? void 0 : r.videoUrl, p = !!(r != null && r.shopifyFileId), I = r == null ? void 0 : r.previewUrl, _ = r == null ? void 0 : r.hasOriginal, E = r == null ? void 0 : r.gifUrl, A = p && !_;
        return I && !o && s < Lr && !n ? I : h && p ? h : h && !p ? h != null && h.includes("vimeo") ? h : `${h.split(".mp4")[0]}${d}` : E && A ? `${E.split(".mp4")[0]}${d}` : Yo({
            ownerId: i,
            assetId: a,
            extension: d
        })
    },
    vd = (e, t, o = Fo["480x480"]) => {
        const n = window.innerWidth <= 450 ? Pr : Rr;
        return Or({
            step: e,
            extension: n,
            posterSettings: t,
            size: o
        })
    },
    Ad = (e, t) => {
        const o = () => {
            if (e.autoplay) {
                e.src = "";
                return
            }
            e.src = t
        };
        e.addEventListener("ended", o, {
            once: !0
        })
    },
    Nr = (e, t, o) => o ? `${e}-${t}-${o}` : `${e}-${t}`,
    Od = e => e.dataset.publishId ? e.dataset.publishId.toLowerCase() : e.id ? e.id.split("_")[0].toLowerCase() : "",
    Pd = e => {
        var t;
        return (t = e == null ? void 0 : e.dataset) == null ? void 0 : t.collectionId
    },
    Rd = e => {
        var s, n, i, r, a, c;
        const t = (i = (n = (s = e == null ? void 0 : e.design) == null ? void 0 : s.branding) == null ? void 0 : n.typography) == null ? void 0 : i.font,
            o = (c = (a = (r = e == null ? void 0 : e.design) == null ? void 0 : r.branding) == null ? void 0 : a.typography) == null ? void 0 : c.fontHeading;
        !(t != null && t.family) && !(o != null && o.family) || (t != null && t.family && Ge(t), o != null && o.family && Ge(o, "tolstoy-custom-heading-font-family"))
    },
    Ld = ({
        step: e,
        embedMotion: t,
        isStory: o,
        loadAll: s = !1,
        isCarouselPlayInTileFirst: n
    }) => {
        if (t === it.static || n) return null;
        const r = window.innerWidth <= 450,
            a = t === it.hoverOver,
            c = t === it.dynamic;
        return c && s ? Ze({
            step: e,
            isStory: o
        }) : a && r || c ? null : Ze({
            step: e,
            isStory: o
        })
    },
    Ur = e => {
        const t = e.getBoundingClientRect();
        return t.top >= -t.height && t.left >= 0 && t.bottom <= (window.innerHeight || document.documentElement.clientHeight) && t.right <= (window.innerWidth || document.documentElement.clientWidth)
    },
    Go = (e, t) => window.document.querySelectorAll(`[data-tolstoy-element="${Nr(e,t)}"]`),
    Dr = ({
        videoClass: e,
        publishId: t,
        removeEventListenerFunction: o
    }) => {
        const s = Go(e, t);
        for (const n of s) n.pause(), o == null || o(n)
    },
    kr = ({
        videoClass: e,
        publishId: t,
        setIsDynamicVideoRunning: o,
        onVideoEnd: s
    }) => {
        o(!1), Dr({
            videoClass: e,
            publishId: t,
            removeEventListenerFunction: n => {
                n.removeEventListener("ended", s)
            }
        })
    },
    Md = ({
        videoClass: e,
        isDynamicVideoRunning: t,
        setIsDynamicVideoRunning: o,
        dynamicVideoHandler: s,
        publishId: n,
        onVideoEnd: i
    }) => {
        const r = Go(e, n);
        if (r.length === 0) return;
        const a = Ur(r[0]);
        !a && t ? (kr({
            videoClass: e,
            publishId: n,
            setIsDynamicVideoRunning: o,
            onVideoEnd: i
        }), o(!1)) : a && !t && (s(), o(!0))
    },
    Nd = r => y(void 0, [r], function*({
        publishId: e,
        productId: t,
        widgetType: o,
        tags: s,
        appUrl: n,
        variantId: i
    }) {
        const a = t && t !== Ds ? sn : on,
            c = window.tolstoyAppKey || P() || "",
            d = new URLSearchParams(window.location.search),
            h = i || d.get("variant"),
            p = yield a({
                productId: t,
                defaultPublishId: e,
                widgetType: o,
                appKey: c,
                tags: s,
                appUrl: n,
                variantId: h
            });
        return (new vr(o).init(p) || {}).hideElement ? {
            disabled: !0
        } : (p != null && p.disabled || (Ar({
            config: p,
            featureKey: Ni
        }) && u.postMessage({
            eventName: l.blockAnonymousIdToCart,
            appKey: c
        }), p != null && p.openCommerceSettings && u.postMessage({
            eventName: l.openCommerceSettingsUpdate,
            openCommerceSettings: p.openCommerceSettings
        })), p)
    });

function Ud(e, t) {
    return !!(t == null ? e : !t)
}
const Dd = e => {
        const t = a => {
                const c = ui(a);
                return c.style.verticalAlign = "middle", c.style.margin = "0 5px", c.style.marginBottom = "3px", c
            },
            o = document.createElement("p"),
            s = t(yi()),
            n = t(gi());
        return o.append(s), ({
            "Invalid publishId": ["Add the publish ID from the", n, "tab of your project in Tolstoy"],
            "Project is not live": ["Your project is in draft. Publish project in the", n, " tab of your project in Tolstoy"],
            "Project is deleted": ["Project has been deleted"],
            "No videos found": ["Select videos in the Videos tab of your project in Tolstoy"],
            "No filtered videos found": ["Select videos in the Videos tab of your project in Tolstoy"],
            "No connections found": ["Select videos in the Videos tab of your project in Tolstoy"],
            "No videos found for product": ["Add tagged videos for this product in the Videos tab of your project in Tolstoy"]
        }[e] || ["Couldn't find product page"]).forEach(a => {
            typeof a == "string" ? o.append(document.createTextNode(a)) : o.append(a)
        }), o
    },
    Br = ({
        element: e
    }) => {
        const t = e.getBoundingClientRect();
        return t.width === 0 || t.height === 0 ? !1 : t.top >= 0 && t.left >= 0 && t.bottom <= (window.innerHeight || document.documentElement.clientHeight) && t.right <= (window.innerWidth || document.documentElement.clientWidth)
    },
    kd = () => new URLSearchParams(window.location.search).get("variant"),
    $r = e => {
        const t = e.getBoundingClientRect();
        return t.width > 200 && t.height > 200
    };

function xr(e) {
    const t = window.getComputedStyle(e),
        o = [":hover", ":focus", ":active", ":visited", ":focus-within", ":focus-visible", ":target", ":checked", ":disabled"],
        s = [];
    for (const i of document.styleSheets) {
        let r = [];
        try {
            r = i.cssRules || i.rules
        } catch (c) {}
        const a = (c, d = null) => {
            for (const h of c) {
                if (h instanceof CSSMediaRule && a(h.cssRules, h.conditionText || h.media.mediaText), !(h instanceof CSSStyleRule)) continue;
                const p = h.selectorText.replace(new RegExp(o.join("|"), "g"), "").trim();
                if (p) try {
                    p && e.matches(p) && s.push({
                        selector: h.selectorText,
                        style: h.style,
                        cssText: h.cssText,
                        originalRule: h,
                        media: d ? {
                            condition: d,
                            matches: window.matchMedia(d).matches
                        } : null
                    })
                } catch (I) {}
            }
        };
        a(r)
    }
    const n = e.style.cssText ? {
        selector: "inline",
        cssText: e.style.cssText
    } : null;
    return {
        computed: Object.fromEntries(Array.from(t).map(i => [i, t.getPropertyValue(i)])),
        rules: n ? [...s, n] : s
    }
}

function Xe(e) {
    let t;
    const o = document.styleSheets;
    for (const s of o)
        if (!s.href) {
            t = s;
            break
        }
    if (!t) {
        const s = document.createElement("style");
        document.head.append(s), t = s.sheet
    }
    t.insertRule(e, t.cssRules.length)
}

function Hr(e) {
    const {
        rules: t
    } = xr(e);
    t.forEach(o => {
        if (o.selector.includes("img")) {
            const s = o.cssText.replace(/img\s*\+\s*img/, `img + .${q.collectionTileHoverWrapper}`);
            if (s === o.cssText) {
                const n = o.cssText.replace("img", `.${q.collectionTileHoverWrapper}`);
                Xe(n)
            } else Xe(s)
        }
    })
}
const Wr = e => {
    const t = e.attributes,
        o = new Set;
    for (const s of t) {
        const n = String(s.value || "").split(/[,\s]+/).filter(Boolean);
        for (const i of n) {
            const r = jo(i);
            r && o.add(r)
        }
    }
    return Array.from(o)
};

function jo(e) {
    try {
        return !e || !e.includes("//") ? null : new URL(e != null && e.startsWith("//") ? `https:${e}` : e).pathname.split("/").pop().split(".").slice(0, -1).join(".")
    } catch (t) {
        return null
    }
}
const Vr = ({
        config: e,
        project: t,
        collectionId: o
    }, s) => {
        var i;
        if (!e || !t || !o) return;
        const n = ((i = e.settings || Rs) == null ? void 0 : i.playMode) === no.HOVER;
        Object.entries((e == null ? void 0 : e.productsMap) || {}).forEach(([r, a]) => {
            var I, _;
            const c = ((I = a == null ? void 0 : a.images) == null ? void 0 : I.map(E => E.src)) || ((_ = a == null ? void 0 : a.variants) == null ? void 0 : _.map(E => E == null ? void 0 : E.imageUrl));
            if (!c) return;
            const d = c.map(E => jo(E));
            let h = s.map(({
                fileNames: E,
                element: A,
                isLarge: T,
                externalElement: L
            }) => {
                const M = d.findLastIndex(Q => E.some(W => W.includes(Q) && W.length < 1.3 * Q.length));
                return {
                    imgElement: A,
                    externalImgElement: L,
                    imageIndex: M,
                    isLarge: T,
                    fileName: d[M]
                }
            }).filter(({
                imageIndex: E
            }) => E !== -1);
            const p = h.filter(({
                isLarge: E
            }) => E);
            if (p.length > 0 && (h = p), h.length > 0) {
                console.log("(tolstoy) isSwapImagePlugin", n);
                const {
                    externalImgElement: E
                } = h.at(n ? 0 : -1), A = [...E.classList].join(" ").split(" ").filter(Boolean), T = document.createElement("div");
                if (T.innerHTML = `<tolstoy-collection-tile
            data-collection-id="${o}"
            class="${q.collectionTile}"
            data-publish-id="${t.publishId}"
            data-product-id="${r}"
            style="mix-blend-mode: normal !important;"
          ></tolstoy-collection-tile>`, E.parentElement)
                    if (n) {
                        Hr(E);
                        const {
                            width: L,
                            height: M
                        } = E.getBoundingClientRect();
                        T.style.width = `${L}px`, T.style.height = `${M}px`, T.classList.add(q.collectionTileHoverWrapper, ...A), T.firstChild.style.zIndex = "0", E.style.display = "none", E.parentElement.insertBefore(T, E), T.append(E)
                    } else A && T.firstChild.classList.add(...A), T.firstChild.style.zIndex = "1", E.parentElement.insertBefore(T.firstChild, E)
            }
        })
    },
    Fr = e => y(void 0, null, function*() {
        if (e != null && e.length && !document.querySelector(`.${q.collectionTile}`)) {
            const {
                waitForImages: t,
                getImgExternalElement: o
            } = yield O(() =>
                import ("./65c2814d6/image-utils.0a27b809.js"), []), s = yield t();
            console.log("(tolstoy) initCollectionTileTemplates with configs", e);
            const n = s.map(i => ({
                element: i,
                externalElement: o(i),
                isLarge: $r(i),
                fileNames: Wr(i)
            })).reverse();
            console.log("(tolstoy) preloadedConfigs", e), e.forEach(i => Vr(i, n))
        }
    }),
    qt = "data-status",
    Yr = [gt],
    Ct = {
        loading: "loading",
        loaded: "loaded",
        failed: "notFound"
    },
    Gr = ({
        element: e,
        callback: t,
        outOfViewCallback: o
    }) => {
        const s = new window.IntersectionObserver(n => {
            n[0].isIntersecting === !0 && n[0].intersectionRatio > .9 ? (o || s.unobserve(e), t()) : n[0].intersectionRatio < .1 && (o == null || o())
        }, {
            threshold: [.1, .9]
        });
        s.observe(e)
    };
class jr {
    constructor({
        name: t,
        component: o,
        elementClassname: s,
        preloadedConfigs: n
    }) {
        this.name = t, this.Component = o, this.widgets = [], this.initialized = !1, this.elementClassname = s, this.preloadedConfigs = Array.isArray(n) ? n : [], this.initTemplatesState = this.initAdditionalTemplates()
    }
    init() {
        return y(this, null, function*() {
            yield this.initTemplatesState;
            const t = this.getElements();
            if (t.length !== 0) {
                for (const o of t)
                    if (this.getShouldInitializeElement(o)) {
                        this.setElementStatus(o, Ct.loading);
                        try {
                            const s = new this.Component;
                            if (yield s.init(o, this.preloadedConfigs.find(n => n.projectId === o.dataset.projectId)), !s.getIsInitialized()) {
                                this.setElementStatus(o, Ct.failed);
                                continue
                            }
                            this.widgets.push(s), this.initializeEvents({
                                element: o,
                                widget: s
                            }), this.setElementStatus(o, Ct.loaded)
                        } catch (s) {
                            this.setElementStatus(o, Ct.failed), console.log(`error starting  tolstoy ${this.name}`, o.id, s)
                        }
                    }
                this.widgets.length > 0 && (this.initialized = !0)
            }
        })
    }
    deleteElementStatus(t) {
        delete t.removeAttribute(qt)
    }
    getElementStatus(t) {
        return t.getAttribute(qt)
    }
    getIsTolstoyPreview() {
        return window.tolstoyPreview
    }
    getIsElementHidden(t) {
        var o;
        return ((o = window.getComputedStyle(t)) == null ? void 0 : o.display) === "none" || !t.offsetParent
    }
    setElementStatus(t, o) {
        return t.setAttribute(qt, o)
    }
    getShouldInitializeElement(t) {
        return t.classList.contains(io) && !this.getElementStatus(t) ? !0 : !this.getElementStatus(t) && !this.getIsElementHidden(t) || !this.getElementStatus(t) && Tt() || this.getIsTolstoyPreview()
    }
    setComponent(t) {
        this.Component = t
    }
    initAdditionalTemplates() {
        return y(this, null, function*() {
            try {
                this.name === gt && (yield Fr(this.preloadedConfigs))
            } catch (t) {
                console.error("error initializing additional templates", t)
            }
        })
    }
    getElements() {
        return Yr.includes(this.name) ? [document.querySelector(`.${this.elementClassname}`)].filter(Boolean) : [...document.querySelectorAll(`.${this.elementClassname}`)]
    }
    shouldLoad() {
        return this.initTemplatesState.isResolved ? this.getElements().length > 0 : !0
    }
    initializeEvents({
        element: t,
        widget: o
    }) {
        var s;
        (s = o.handlePageView) == null || s.call(o), this.registerEmbedViewListener({
            element: t,
            callback: o.handleView,
            outOfViewCallback: o.handleOutOfView
        })
    }
    registerEmbedViewListener({
        element: t,
        callback: o,
        outOfViewCallback: s
    }) {
        Br({
            element: t
        }) && (o(), !s) || Gr({
            element: t,
            callback: o,
            outOfViewCallback: s
        })
    }
}
let Qe = !1;
const Ko = () => y(void 0, null, function*() {
    if (Qe) return;
    (yield O(() =>
        import ("./65c2814d6/widget.events.3214c86c.js"), [])).initializeWidgetEvents(), Qe = !0
});
class Kr {
    constructor() {
        g(this, "loadEmbedWidgets", () => y(this, null, function*() {
            const t = Object.entries(this.embedWidgetsMap).map(r => y(this, [r], function*([o, {
                embedWidget: s,
                loaded: n,
                loading: i
            }]) {
                if (s.shouldLoad()) {
                    if (i) {
                        setTimeout(() => this.loadEmbedWidgets(), 2e3);
                        return
                    }
                    n || (yield this.loadEmbedWidget({
                        embedWidgetName: o,
                        embedWidget: s
                    })), yield s.init()
                }
            }));
            yield Promise.all(t)
        }));
        g(this, "handleUrlChange", () => {
            for (const t of Object.keys(this.embedWidgetsMap)) this.embedWidgetsMap[t].loaded = !1;
            this.loadEmbedWidgets()
        });
        this.domUpdatesListenerInitialized = !1, this.widgets = [], this.embedWidgetsMap = {}
    }
    init(t) {
        return y(this, null, function*() {
            const o = [],
                s = [se, ne, ie, re, gt];
            for (const n of s) {
                const i = lo[n],
                    r = new jr({
                        name: n,
                        elementClassname: i,
                        preloadedConfigs: t
                    });
                this.embedWidgetsMap[n] = {
                    embedWidget: r,
                    loaded: !1
                }, o.push(i)
            }
            this.registerDomUpdatesListenerIfNeeded(o), this.subscribeToUrlChange(), yield this.loadEmbedWidgets()
        })
    }
    loadEmbedWidget(s) {
        return y(this, arguments, function*({
            embedWidgetName: t,
            embedWidget: o
        }) {
            this.embedWidgetsMap[t].loading = !0;
            let n;
            switch (t) {
                case se:
                    {
                        n = yield O(() =>
                            import ("./65c2814d6/carousel-loader.1552aa52.js"), []);
                        break
                    }
                case ne:
                    {
                        n = yield O(() =>
                            import ("./65c2814d6/story.d7da8cf7.js"), ["65c2814d6/modal.eb93a2a4.css", "65c2814d6/story.28102514.css"]);
                        break
                    }
                case ie:
                    {
                        n = yield O(() =>
                            import ("./65c2814d6/embed.249a1537.js"), ["65c2814d6/modal.eb93a2a4.css", "65c2814d6/embed.550ffe5d.css"]);
                        break
                    }
                case re:
                    {
                        n = yield O(() =>
                            import ("./65c2814d6/tile.6da71938.js"), ["65c2814d6/tile.4607c378.css"]);
                        break
                    }
                case gt:
                    {
                        n = yield O(() =>
                            import ("./65c2814d6/collection-tile-controller.7d94ea0a.js"), ["65c2814d6/collection-tile-controller.af177681.css"]);
                        break
                    }
                case co:
                    {
                        n = yield O(() =>
                            import ("./65c2814d6/collection-page-tile-controller.a0118e2b.js"), ["65c2814d6/collection-page-tile-controller.5d04a287.css"]);
                        break
                    }
            }
            o.setComponent(n.default), yield Ko(), this.embedWidgetsMap[t].loaded = !0, this.embedWidgetsMap[t].loading = !1
        })
    }
    registerDomUpdatesListenerIfNeeded(t) {
        if (this.domUpdatesListenerInitialized) return;
        $o({
            classNames: t,
            callback: () => this.loadEmbedWidgets()
        }), this.domUpdatesListenerInitialized = !0
    }
    subscribeToUrlChange() {
        u.subscribe({
            eventName: l.urlChange,
            callback: this.handleUrlChange
        })
    }
}
const F = ro,
    zr = new Set(["5bzilmwoe1fon", "z7uu0kcyzumt0"]),
    zo = e => zr.has(e) ? ao : F;
class qr {
    constructor() {
        this.initialized = !1, this.widgets = [], this.start = this.start.bind(this), this.startPart = this.startPart.bind(this), this.hide = this.hide.bind(this), this.show = this.show.bind(this), this.on = this.on.bind(this), this.recreate = this.recreate.bind(this), window.tolstoyWidget = w(m({}, window.tolstoyWidget), {
            start: this.start,
            startPart: this.startPart,
            show: this.show,
            hide: this.hide,
            on: this.on,
            recreate: this.recreate
        })
    }
    init(n) {
        return y(this, arguments, function*({
            bubbleSettings: t,
            widgetId: o,
            Component: s
        }) {
            var a, c;
            this.bubbleSettings = t;
            const i = new s(t);
            if (yield i.init(), this.widgets.push(i), this.updateViewerIdentifyAttributes(), (a = window.tolstoySettings) != null && a.noReload || this.registerEvents(), (((c = window.tolstoySettings) == null ? void 0 : c.alwaysShow) || Uo(o) !== "true") && !t.exitIntentPublishId) {
                const d = zo(o);
                this.show(d), this.recreate(o, d)
            } else this.hide()
        })
    }
    updateViewerIdentifyAttributes() {
        const t = Number(Mo() || 0) + 1;
        On(t.toString()), No() || Pn(new Date().toISOString())
    }
    handleMouseDown() {
        this.userInteracted = !0, document.removeEventListener("mousedown", this.handleMouseDown)
    }
    registerEvents() {
        document.addEventListener("mousedown", () => {
            this.handleMouseDown()
        }), document.body.addEventListener("mouseleave", () => y(this, null, function*() {
            var s;
            const t = (s = this.bubbleSettings) == null ? void 0 : s.exitIntentPublishId;
            if (t && this.userInteracted) {
                const n = this.widgets.find(i => {
                    var r;
                    return (r = i == null ? void 0 : i.bubbleSettings) == null ? void 0 : r.exitIntentPublishId
                });
                n && (yield this.recreate(t, n.name, {
                    startPlayerImmediately: !0
                }))
            }
        }))
    }
    start(t = F) {
        const o = K(this.widgets, t);
        o && o.start()
    }
    startPart(t, o = F) {
        const s = K(this.widgets, o);
        s && s.startPart(t)
    }
    hide(t = F) {
        const o = K(this.widgets, t);
        o && o.hide()
    }
    show(t = F) {
        const o = K(this.widgets, t);
        o && o.show()
    }
    on(t, o, s = F) {
        const n = K(this.widgets, s);
        n && n.eventChange(t, o)
    }
    recreate(t, o = F, s = {}) {
        const n = K(this.widgets, o);
        n && n.recreate(t, s)
    }
}
const K = (e, t) => e.find(o => o.name === t);
class qo {
    addHours(t, o = new Date) {
        return o.setTime(o.getTime() + t * 60 * 60 * 1e3), o
    }
    getTolstoyViewers() {
        const t = Yt();
        for (const [s, n] of Object.entries(t)) {
            const i = n.restrictionLimits;
            !i || !(i != null && i.time && new Date(i == null ? void 0 : i.time) <= new Date) || delete t[s].restrictionLimits
        }
        const o = JSON.stringify(t);
        return Gt(t), o
    }
    updateRestrictions(t, o) {
        var r;
        const s = Yt(),
            n = (r = s[o]) == null ? void 0 : r.restrictionLimits;
        if (!n || (n == null ? void 0 : n.type) !== t) return;
        const i = n[t];
        n[t] = i ? i + 1 : 1, n.limit && n.clickLimit === n[t] && (n.time = this.addHours(n == null ? void 0 : n.limit)), s[o].restrictionLimits = n, Gt(s)
    }
    updateRules(t) {
        const o = (t == null ? void 0 : t.publishId) || void 0,
            s = t == null ? void 0 : t.limit,
            n = Yt();
        let i = n[o];
        const r = i == null ? void 0 : i.restrictionLimits;
        i ? i.impressionCount += 1 : i = {
            impressionCount: 1,
            playCount: 0
        };
        let a = n.undefined;
        if (a ? a.impressionCount += 1 : a = {
                impressionCount: 1,
                playCount: 0
            }, s) {
            let c = {
                limit: Number(s.timeLimit),
                type: s.type,
                clickLimit: Number(s.clickLimit)
            };
            r && (c = m(m({}, r), c)), i.restrictionLimits = c
        } else r && (i.restrictionLimits = null);
        n[o] = i, n.undefined = a, Gt(n)
    }
}
class Ut {
    static isValidUrl(t) {
        return t ? t.startsWith("tel:") || t.startsWith("mailto:") ? !0 : t.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_+.~#?&//=]*)/g) !== null : !1
    }
    static isAndroid() {
        return navigator.userAgent.toLowerCase().indexOf("android") > -1
    }
    static isInIframe() {
        try {
            return window.self !== window.top
        } catch (t) {
            return !0
        }
    }
    static isIos() {
        return /iPad|iPhone|iPod/.test(navigator.platform) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1
    }
    static getMobileOperatingSystem() {
        const t = navigator.userAgent || navigator.vendor || window.opera;
        return /windows phone/i.test(t) ? "Windows Phone" : /android/i.test(t) ? "Android" : /iPad|iPhone|iPod/.test(t) && !window.MSStream ? "iOS" : navigator.userAgent.match(/Mac/) && navigator.maxTouchPoints && navigator.maxTouchPoints > 2 ? "ipad" : null
    }
    static isMobile() {
        return Ut.getMobileOperatingSystem() != null
    }
    static isSafari() {
        return window.safari !== void 0
    }
    static enforceProtocol(t, o = "https") {
        return t.startsWith("http") || t.startsWith("//") || t.startsWith("tel:") || t.startsWith("mailto:") ? t : `${o}://${t}`
    }
    static removeProtocol(t) {
        return t.replace(/(^\w+:|^)\/\//, "")
    }
    static stripUrl(t) {
        return Ut.removeProtocol(t).replace(/^www./, "").replace(/\/$/, "")
    }
    static stringifyUrlParams(t) {
        const o = new URLSearchParams;
        return Object.entries(t).forEach(([s, n]) => {
            o.set(s, n)
        }), o.toString()
    }
}
const Zr = "player-version",
    Xr = (e, t, o) => {
        if (o) return `${Bs}`;
        const s = Vo(e);
        if (s) {
            const i = B("td"),
                r = Zo(e);
            return i && r ? s.replace("2.0.0", "2.0.0-ls") : r ? s.replace("2.0.0", "2.0.0-l") : i ? s.replace("2.0.0", "2.0.0-s") : s
        }
        let n = `${ks}`;
        return t && (n += "/feed"), e.publishId && (n += `/${e.publishId}`), n
    },
    Je = () => {
        var e;
        return !!(window.Shopify && ((e = window.Shopify) != null && e.routes))
    },
    Zo = e => e.playerLazy || B("pl"),
    Qr = e => {
        var t, o;
        return (o = (t = e == null ? void 0 : e.featureSettings) == null ? void 0 : t[Zr]) == null ? void 0 : o.version
    },
    Jr = e => {
        var t;
        return (t = e == null ? void 0 : e.carouselEmbed) != null && t.carouselPlayInTileFirst ? Ls : ""
    },
    ta = () => {
        var e, t, o, s;
        return ((e = window._st) == null ? void 0 : e.cid) || ((s = (o = (t = window.ShopifyAnalytics) == null ? void 0 : t.meta) == null ? void 0 : o.page) == null ? void 0 : s.customerId) || ""
    },
    ea = () => new URLSearchParams(window.location.search).get("authToken"),
    oa = () => {
        var e;
        return ((e = window.tolstoyUserInfo) == null ? void 0 : e.email) || window.tolstoyUser
    },
    sa = () => B(ye.tolstoyAutoOpen) || window.tolstoyAutoOpen,
    Bd = () => B(ye.tolstoyAutoOpenOnYou) || window.tolstoyAutoOpenOnYou,
    $d = () => B(ye.tolstoyStartVideo) || window.tolstoyStartVideo,
    na = () => {
        const e = window.tolstoyMoneyFormat;
        return e ? encodeURIComponent(e) : ""
    },
    ia = ({
        data: e,
        isFeed: t,
        isOnYou: o,
        email: s,
        isDynamic: n,
        modalId: i,
        tolstoyStartVideo: r
    }) => {
        var Ht, J, tt, Wt, _e, ve, Ae, Oe, Pe, Re, Le;
        const c = [`url=${`${window.location.origin}${window.location.pathname}`.slice(0,1999)}`, `modalId=${i}`];
        e.publishId && c.push(`publishId=${e.publishId}`);
        const d = ea();
        d && c.push(`authToken=${d}`);
        const h = s || oa();
        if (h && c.push(`email=${encodeURIComponent(h)}`), e.productId && c.push(`productId=${e.productId}`), o) {
            const V = localStorage.getItem("tolstoy-anonymousId"),
                Me = ((Ht = window.Shopify) == null ? void 0 : Ht.shop) || wt(),
                Vt = Array.from(document.querySelectorAll("div") || {}).find(et => et.textContent.trim() === "Size & Fit"),
                Ne = Array.from(((J = Vt == null ? void 0 : Vt.nextElementSibling) == null ? void 0 : J.childNodes) || {}).filter(et => et.nodeType === Node.TEXT_NODE).map(et => et.textContent.trim()).join(" ");
            Me && c.push(`appUrl=${Me}`), V && c.push(`tolstoyAnonymousId=${V}`);
            const Ue = xt();
            return Ue && c.push(`sessionId=${Ue}`), Ne && c.push(`productFitDetails=${encodeURIComponent(Ne)}`), c
        }
        e.currentProductDbId && c.push(`currentPageDbProductId=${e.currentProductDbId}`);
        const p = ((tt = window.Shopify) == null ? void 0 : tt.shop) || "",
            I = !!(Je() && p);
        if (c.push("host", `safari=${!!(window!=null&&window.safari)}`, `dontDownload=${!!e.dontDownload}`, `playerType=${e.playerType}`, `isShopifyStore=${I}`, `shopifyStoreUrl=${p}`, `ai=${$t()}`), Je()) {
            const V = (_e = (Wt = window.Shopify) == null ? void 0 : Wt.routes) == null ? void 0 : _e.root;
            V && c.push(`shopifyRootRoute=${V}`)
        }
        if ((ve = window.tolstoyUserInfo) != null && ve.name && c.push(`name=${encodeURIComponent(window.tolstoyUserInfo.name)}`), (Ae = window.tolstoyUserInfo) != null && Ae.phone && c.push(`phone=${encodeURIComponent(window.tolstoyUserInfo.phone)}`), window.tolstoyMoneyFormat) {
            const V = na();
            c.push(`tolstoyMoneyFormat=${V}`)
        }
        r && c.push(`tolstoyStartVideo=${r}`), e.testGroup && c.push(`group=${e.testGroup}`), e.sneakpeek && c.push("sneakpeek"), e.sneakpeek_hidden && c.push("sneakpeek_hidden"), e.token && c.push(`token=${e.token}`), e.gclid && c.push(`gclid=${e.gclid}`), e.widgetDelay && c.push("delay"), e.isShoppable === !1 && c.push(`isShoppable=${e.isShoppable}`), e.si && c.push(`si=${e.si}`);
        const _ = B("td");
        _ && c.push(`td=${_}`);
        const E = Zo(e);
        E && c.push(`pl=${E}`);
        const A = Qr(e);
        A && c.push(`pv=${A}`);
        const T = Jr(e);
        T && c.push(`playerVariant=${T}`), n && c.push("isDynamic=true");
        const L = ta();
        L && c.push(`customerId=${L}`);
        const M = Xs();
        M.size > 0 && c.push(M.toString()), Tt() && c.push("isTapcart=true");
        const W = Vo(e);
        return W && e.publishId && c.push(`publishId=${e.publishId}`), W && t && c.push("isFeed=true"), (Oe = window.tolstoySettings) != null && Oe.shouldUseCache && c.push(`shouldUseCache=${(Pe=window.tolstoySettings)==null?void 0:Pe.shouldUseCache}`), (Re = window.tolstoySettings) != null && Re.cacheVersion && c.push(`cacheVersion=${(Le=window.tolstoySettings)==null?void 0:Le.cacheVersion}`), R() || c.push("userConsent=false"), c
    },
    xd = ({
        data: e,
        isFeed: t,
        isOnYou: o,
        email: s,
        isDynamic: n,
        modalId: i,
        tolstoyStartVideo: r
    }) => {
        const a = Xr(e, t, o),
            c = ia({
                data: e,
                isFeed: t,
                isOnYou: o,
                email: s,
                isDynamic: n,
                modalId: i,
                tolstoyStartVideo: r
            });
        return `${a}?${c.join("&")}`
    };
class at {
    constructor() {
        var t;
        if (at.instance) return at.instance;
        at.instance = this, this.appKey = P(), this.shop = ((t = window.Shopify) == null ? void 0 : t.shop) || wt(), this.accountSettings = null, this.rules = new qo, this.shouldUseCache = null, this.cacheVersion = null, this.hasLiveBubble = null
    }
    init() {
        return y(this, null, function*() {
            var t, o, s;
            if (!(!this.appKey && !this.shop)) {
                if (this.accountSettings) return this.accountSettings;
                try {
                    this.accountSettings = yield tn(), this.rules.updateRules(this.accountSettings), (((t = this.accountSettings) == null ? void 0 : t.shouldUseCache) || Eo()) && (window.tolstoySettings = window.tolstoySettings || {}, window.tolstoySettings.shouldUseCache = !0);
                    const i = ((o = this.accountSettings) == null ? void 0 : o.cacheVersion) || G();
                    return i && (window.tolstoySettings = window.tolstoySettings || {}, window.tolstoySettings.cacheVersion = i), this.hasLiveBubble = ((s = this.accountSettings) == null ? void 0 : s.hasLiveBubble) || !!window.tolstoyWidgetId || sa(), this.accountSettings
                } catch (n) {
                    return mo("Error loading account settings"), null
                }
            }
        })
    }
}
const Xo = new at;
class ra {
    constructor() {
        g(this, "getBubbleSettings", () => y(this, null, function*() {
            var a;
            const t = window.location.href,
                o = ((a = window.Shopify) == null ? void 0 : a.shop) || wt();
            if (!this.appKey && !o) return;
            const s = vn(),
                n = this.rules.getTolstoyViewers(),
                i = o || window.location.host,
                r = {
                    timestamp: Date.now(),
                    url: t,
                    sessionCount: Number(Mo() || 0),
                    lastSeenAt: new Date().toISOString(),
                    firstSeenAt: No(),
                    tolstoySeenCounter: n,
                    isMobile: Ut.isMobile(),
                    domain: i,
                    appUrl: o,
                    appKey: this.appKey
                };
            s && (r.identifyInfoId = s);
            try {
                const c = yield rn(r);
                return c ? (this.rules.updateRules(c), c) : null
            } catch (c) {
                return null
            }
        }));
        g(this, "init", () => y(this, null, function*() {
            var r, a, c, d;
            if (!((r = this.account) != null && r.hasLiveBubble)) return;
            const t = yield this.getBubbleSettings();
            this.subscribeToUrlChange();
            const o = window.tolstoyWidgetId || (t == null ? void 0 : t.publishId) || (t == null ? void 0 : t.exitIntentPublishId);
            if (!o) {
                (c = (a = this.widget) == null ? void 0 : a.hide) == null || c.call(a);
                return
            }
            if (!((d = window.tolstoySettings) == null ? void 0 : d.alwaysShow) && Uo(o) === "true") return;
            const n = zo(o);
            let i;
            n === ao ? i = yield O(() =>
                import ("./65c2814d6/centered-modal.3f09a40b.js"), ["65c2814d6/modal.eb93a2a4.css"]): n === ro && (i = yield O(() =>
                import ("./65c2814d6/bubble.2f3603d5.js"), ["65c2814d6/modal.eb93a2a4.css", "65c2814d6/bubble.4d99fbce.css"])), yield Ko(), this.widget ? (this.widget.recreate(o, n), this.widget.show()) : (this.widget = new qr, yield this.widget.init({
                bubbleSettings: t,
                widgetId: o,
                Component: i.default
            }))
        }));
        g(this, "handleUrlChange", () => {
            this.unsubscribeFromUrlChange(), this.init()
        });
        this.account = Xo, this.rules = new qo, this.appKey = P()
    }
    subscribeToUrlChange() {
        u.subscribe({
            eventName: l.urlChange,
            callback: this.handleUrlChange
        })
    }
    unsubscribeFromUrlChange() {
        u.unsubscribe({
            eventName: l.urlChange,
            callback: this.handleUrlChange
        })
    }
}
const aa = {
        tvContainer: "tolstoy-video-page"
    },
    ca = "tolstoy-tv-container",
    Hd = "tolstoy-tv",
    Wd = {};
class la {
    constructor() {
        this.domUpdatesListenerInitialized = !1, this.loaded = !1
    }
    init() {
        return y(this, null, function*() {
            yield this.loadVideo(), !this.loaded && this.registerDomUpdatesListenerIfNeeded()
        })
    }
    loadVideo() {
        return y(this, null, function*() {
            const t = document.querySelector(`#${ca}`);
            if (!t) return;
            const o = (yield O(() =>
                import ("./65c2814d6/tv.827859d1.js"), ["65c2814d6/tv.176639ca.css"])).default;
            new o({
                tolstoyContainer: t
            }).init(), this.loaded = !0
        })
    }
    registerDomUpdatesListenerIfNeeded() {
        if (this.domUpdatesListenerInitialized) return;
        const t = [aa.tvContainer];
        $o({
            classNames: t,
            callback: () => this.loadVideo()
        }), this.domUpdatesListenerInitialized = !0
    }
}
const da = [l.urlChange],
    ua = e => {
        switch (e.data.eventName) {
            case l.urlChange:
                return ko();
            default:
                return null
        }
    },
    pa = ["(+https://whatis.contentkingapp.com)", "Shopify-Observe-Synthetic-Checks", "+http://www.google.com/bot.html", "https://naver.me/spd", "HeadlessChrome", "(+http://www.facebook.com/externalhit_uatext.php)", "Bytespider", "bot"],
    ha = () => pa.some(e => window.navigator.userAgent.includes(e)),
    Y = {
        addToCart: "tolstoy_add_to_cart",
        spotlightCarouselQuickShopClick: "tolstoy_spotlight_carousel_quick_shop_click",
        productCardClick: "tolstoy_product_card_click"
    },
    b = {
        addToCartSuccess: "tolstoy_add_to_cart_success",
        addToCartError: "tolstoy_add_to_cart_error",
        rejectCookiePolicy: "tolstoy_reject_cookie_policy",
        tolstoyZIndexChange: "tolstoy_z_index_change",
        urlLocaleUpdate: "tolstoy_url_locale_update",
        productUpdate: "tolstoy_product_update"
    },
    Qo = Object.values(Y),
    ya = new Set([b.addToCartSuccess, b.addToCartError, b.rejectCookiePolicy, b.tolstoyZIndexChange, b.urlLocaleUpdate, b.productUpdate]),
    ga = ({
        eventName: e,
        callback: t
    }) => {
        if (!Qo.includes(e)) {
            console.error(`Event ${e} is not a valid event`);
            return
        }
        if (!t) {
            console.error("Callback must be provided");
            return
        }
        if (typeof t != "function") {
            console.error("Callback must be a function");
            return
        }
        return !0
    };
class ct extends xo {
    constructor() {
        if (ct.instance) return ct.instance;
        super({
            shouldIncludeLogs: !0
        });
        g(this, "eventHandler", ({
            data: o = {}
        }) => {
            const {
                eventName: s
            } = o;
            if (this.eventCallbacks[s])
                for (const n of this.eventCallbacks[s]) try {
                    n(o)
                } catch (i) {
                    console.error(i)
                }
        });
        g(this, "subscribe", (o, s, n = {}) => {
            if (ga({
                    eventName: o,
                    callback: s
                })) try {
                super.subscribe({
                    eventName: o,
                    callback: s
                }), u.postMessage({
                    eventName: l.externalEventSubscribed,
                    subscribedEventName: o,
                    payload: n
                });
                const i = new CustomEvent("TOLSTOY_WIDGET_V2_SUBSCRIBE", {
                    detail: {
                        eventName: o,
                        payload: n,
                        callback: s
                    }
                });
                window.dispatchEvent(i), console.log("Subscribed to event", o)
            } catch (i) {
                console.error(i)
            }
        });
        g(this, "unsubscribe", (o, s) => super.unsubscribe({
            eventName: o,
            callback: s
        }));
        g(this, "initInternalMessagingSubscriptions", () => {
            u.subscribeMultipleEvents({
                eventNames: Qo,
                callback: this.eventHandler
            })
        });
        ct.instance = this
    }
    init() {
        this.initInternalMessagingSubscriptions(), this.initListener(this.eventHandler)
    }
}
const Rt = new ct;
Object.freeze(Rt);
const ma = e => {
    const {
        eventName: t
    } = e;
    if (!t) {
        console.error("eventName is required");
        return
    }
    if (!ya.has(t)) {
        console.error(`${t} is not a valid eventName`);
        return
    }
    return !0
};
class fa {
    constructor() {
        g(this, "postMessage", (t = {}) => {
            ma(t) && u.postMessage(t)
        })
    }
    closePlayer() {
        u.postMessage({
            eventName: l.closePlayer
        })
    }
    changeEmail(t) {
        window.tolstoyUser = t, u.postMessage({
            eventName: l.userEmailUpdate,
            email: t
        })
    }
    identify() {
        return y(this, arguments, function*(t = {}) {
            var n;
            const {
                email: o,
                userId: s
            } = t;
            if (!o && !s) {
                console.error("No email or userId");
                return
            }
            try {
                o && this.changeEmail(o), s && (t.userId = s.toString()), t.appKey = P();
                const i = yield en(t);
                _n(i == null ? void 0 : i.id)
            } catch (i) {
                console.error("Error occurred while updating identify info:", i), (n = window.tolstoyCaptureError) == null || n.call(window, i, "Error occurred while updating identify info:"), An()
            }
        })
    }
}
const pe = new fa;
Object.freeze(pe);
const Ea = [l.modalOpen];
class wa {
    constructor() {
        g(this, "internalMessagingHandler", t => {
            switch (t.data.eventName) {
                case l.modalOpen:
                    this.sendIsAfterpayAppInstalledMessage();
                    return;
                default:
                    return null
            }
        })
    }
    sendIsAfterpayAppInstalledMessage() {
        u.postMessage({
            eventName: l.isAfterpayAppInstalled,
            value: !!(window != null && window.Afterpay)
        })
    }
    initInternalMessagingSubscriptions() {
        u.subscribeMultipleEvents({
            eventNames: Ea,
            callback: this.internalMessagingHandler
        })
    }
    init() {
        this.initInternalMessagingSubscriptions()
    }
}
const Jo = new wa;
Object.freeze(Jo);
const Sa = () => {
        pn(), un(kt.rejected), u.postMessage({
            eventName: l.rejectCookiePolicy
        })
    },
    Ta = [b.rejectCookiePolicy];
class lt {
    constructor() {
        g(this, "externalMessagingHandler", t => {
            switch (t.data.eventName) {
                case b.rejectCookiePolicy:
                    return Sa();
                default:
                    return null
            }
        });
        g(this, "initExternalMessagingSubscriptions", () => {
            u.subscribeMultipleEvents({
                eventNames: Ta,
                callback: this.externalMessagingHandler
            })
        });
        if (lt.instance) return lt.instance;
        lt.instance = this
    }
    init() {
        this.initExternalMessagingSubscriptions()
    }
}
const ts = new lt;
Object.freeze(ts);
const Ia = {
        itemSoldOut: "itemSoldOut"
    },
    es = {
        tolstoyAnonymousId: "__tolstoyAnonymousId"
    },
    ba = ({
        description: e
    }) => {
        switch (e) {
            case Ia.itemSoldOut:
                return l.addToCartSoldOut;
            default:
                return l.addToCartError
        }
    },
    Ca = ({
        data: e
    }) => {
        const {
            description: t
        } = e, o = ba({
            description: t
        });
        u.postMessage(w(m({}, e), {
            eventName: o
        }))
    },
    _a = ({
        data: e
    }) => {
        const {
            variantId: t,
            productId: o,
            transmissionId: s,
            quantity: n,
            productHandle: i,
            templateSuffix: r
        } = e;
        u.postMessage({
            variantId: t,
            productId: o,
            transmissionId: s,
            quantity: n,
            productHandle: i,
            eventName: Y.addToCart,
            templateSuffix: r
        })
    },
    va = ({
        data: e
    }) => {
        const {
            product: t,
            transmissionId: o
        } = e;
        u.postMessage({
            product: t,
            transmissionId: o,
            eventName: Y.spotlightCarouselQuickShopClick
        })
    },
    Aa = ({
        data: e
    }) => {
        const {
            subscribedEventName: t,
            payload: o = {}
        } = e, {
            disableDefault: s
        } = o;
        switch (t) {
            case Y.addToCart:
            case Y.spotlightCarouselQuickShopClick:
                s && u.postMessage({
                    eventName: l.addToCartDisableDefault
                });
                break;
            default:
                return null
        }
    },
    Oa = ({
        data: e
    }) => {
        u.postMessage(w(m({}, e), {
            eventName: l.addToCartSuccess
        }))
    },
    Pa = [l.addToCart, l.spotlightCarouselQuickShopClick, l.externalEventSubscribed],
    Ra = [b.addToCartSuccess, b.addToCartError];
class dt {
    constructor() {
        g(this, "internalMessagingHandler", t => {
            switch (t.data.eventName) {
                case l.addToCart:
                    return _a(t);
                case l.spotlightCarouselQuickShopClick:
                    return va(t);
                case l.externalEventSubscribed:
                    return Aa(t);
                default:
                    return null
            }
        });
        g(this, "externalMessagingHandler", t => {
            switch (t.data.eventName) {
                case b.addToCartSuccess:
                    return Oa(t);
                case b.addToCartError:
                    return Ca(t);
                default:
                    return null
            }
        });
        g(this, "initInternalMessagingSubscriptions", () => {
            u.subscribeMultipleEvents({
                eventNames: Pa,
                callback: this.internalMessagingHandler
            })
        });
        g(this, "initExternalMessagingSubscriptions", () => {
            u.subscribeMultipleEvents({
                eventNames: Ra,
                callback: this.externalMessagingHandler
            })
        });
        if (dt.instance) return dt.instance;
        dt.instance = this
    }
    init() {
        this.initInternalMessagingSubscriptions(), this.initExternalMessagingSubscriptions()
    }
}
const os = new dt;
Object.freeze(os);
const La = [l.openKendoModal];
class Ma {
    constructor() {
        g(this, "internalMessagingHandler", t => {
            var o, s;
            switch (t.data.eventName) {
                case l.openKendoModal:
                    u.postMessage({
                        eventName: l.changeZIndex,
                        zIndex: 1e3
                    }), (s = (o = window.KENDO) == null ? void 0 : o.openQuickModalByHandle) == null || s.call(o, t.data.productHandle);
                    const n = t.data.quantity;
                    if (n <= 1) return;
                    for (let i = 1; i < n; i++) setTimeout(() => {
                        var a;
                        const r = document.querySelector(".quantity-selector__action--increment");
                        (a = r == null ? void 0 : r.click) == null || a.call(r)
                    }, 1e3 + i * 150);
                    return;
                default:
                    return null
            }
        })
    }
    initInternalMessagingSubscriptions() {
        u.subscribeMultipleEvents({
            eventNames: La,
            callback: this.internalMessagingHandler
        })
    }
    init() {
        this.initInternalMessagingSubscriptions()
    }
}
const ss = new Ma;
Object.freeze(ss);
const ns = {
        USD: "$",
        CAD: "CA$",
        EUR: "€",
        AED: "د.إ.‏",
        AFN: "؋",
        ALL: "Lek",
        AMD: "դր.",
        ARS: "$",
        AUD: "AU$",
        AZN: "ман.",
        BAM: "KM",
        BDT: "৳",
        BGN: "лв.",
        BHD: "د.ب.‏",
        BIF: "FBu",
        BND: "$",
        BOB: "Bs",
        BRL: "R$",
        BWP: "P",
        BYN: "руб.",
        BZD: "$",
        CDF: "FrCD",
        CHF: "CHF",
        CLP: "$",
        CNY: "CN¥",
        COP: "$",
        CRC: "₡",
        CVE: "CV$",
        CZK: "Kč",
        DJF: "Fdj",
        DKK: "kr",
        DOP: "RD$",
        DZD: "د.ج.‏",
        EEK: "kr",
        EGP: "ج.م.‏",
        ERN: "Nfk",
        ETB: "Br",
        GBP: "£",
        GEL: "GEL",
        GHS: "GH₵",
        GNF: "FG",
        GTQ: "Q",
        HKD: "$",
        HNL: "L",
        HRK: "kn",
        HUF: "Ft",
        IDR: "Rp",
        ILS: "₪",
        INR: "₹",
        IQD: "د.ع.‏",
        IRR: "﷼",
        ISK: "kr",
        JMD: "$",
        JOD: "د.أ.‏",
        JPY: "￥",
        KES: "Ksh",
        KHR: "៛",
        KMF: "FC",
        KRW: "₩",
        KWD: "د.ك.‏",
        KZT: "тңг.",
        LBP: "ل.ل.‏",
        LKR: "SL Re",
        LTL: "Lt",
        LVL: "Ls",
        LYD: "د.ل.‏",
        MAD: "د.م.‏",
        MDL: "MDL",
        MGA: "MGA",
        MKD: "MKD",
        MMK: "K",
        MOP: "MOP$",
        MUR: "MURs",
        MXN: "MX$",
        MYR: "RM",
        MZN: "MTn",
        NAD: "N$",
        NGN: "₦",
        NIO: "C$",
        NOK: "kr",
        NPR: "नेरू",
        NZD: "$",
        OMR: "ر.ع.‏",
        PAB: "B/.",
        PEN: "S/.",
        PHP: "₱",
        PKR: "₨",
        PLN: "zł",
        PYG: "₲",
        QAR: "ر.ق.‏",
        RON: "RON",
        RSD: "дин.",
        RUB: "₽.",
        RWF: "FR",
        SAR: "ر.س.‏",
        SDG: "SDG",
        SEK: "kr",
        SGD: "$",
        SOS: "Ssh",
        SYP: "ل.س.‏",
        THB: "฿",
        TND: "د.ت.‏",
        TOP: "T$",
        TRY: "TL",
        TTD: "$",
        TWD: "NT$",
        TZS: "TSh",
        UAH: "₴",
        UGX: "USh",
        UYU: "$",
        UZS: "UZS",
        VEF: "Bs.F.",
        VND: "₫",
        XAF: "FCFA",
        XOF: "CFA",
        YER: "ر.ي.‏",
        ZAR: "R",
        ZMK: "ZK",
        ZWL: "ZWL$"
    },
    Na = e => ({
        id: e.id,
        price: e.price,
        compareAtPrice: e.price,
        currencyCode: e.currency,
        currencySymbol: ns[e.currency],
        variants: [{
            price: e.price,
            compareAtPrice: e.price
        }]
    }),
    Ua = (e = "") => e.replace("_", "-"),
    Da = [l.openCommerceSettingsUpdate, l.requestProductsUpdate],
    Zt = {},
    _t = {};
class ka {
    constructor() {
        g(this, "fetchProduct", t => y(this, null, function*() {
            const o = `${this.apiBaseUrl}/products/${t}`,
                s = new URL(o);
            s.searchParams.append("client_id", this.clientId), s.searchParams.append("locale", this.locale), s.searchParams.append("currency", this.currencyCode), s.searchParams.append("expand", "prices");
            try {
                const i = yield(yield fetch(s)).json();
                return Na(i)
            } catch (n) {
                console.error("Error fetching product price", n)
            }
        }));
        g(this, "getProduct", t => y(this, null, function*() {
            if (Zt[t]) return Zt[t];
            if (_t[t]) return _t[t];
            const o = this.fetchProduct(t);
            _t[t] = o;
            const s = yield o;
            return Zt[t] = s, delete _t[t], s
        }));
        g(this, "onRequestProductsUpdateMessage", o => y(this, [o], function*({
            productIds: t
        }) {
            const n = [...new Set(t)].map(r => this.getProduct(r)),
                i = (yield Promise.all(n)).filter(Boolean);
            for (const r of i) u.postMessage({
                eventName: l.productUpdateResponse,
                product: r,
                isProductUpdateResponse: !0
            })
        }));
        g(this, "internalMessagingHandler", t => {
            switch (t.data.eventName) {
                case l.openCommerceSettingsUpdate:
                    return this.onOpenCommerceSettingsUpdate(t.data);
                case l.requestProductsUpdate:
                    return this.onRequestProductsUpdateMessage(t.data);
                default:
                    return null
            }
        });
        var t, o, s, n;
        this.isOpenCommerceStore = !!window.CQuotient, this.siteId = (t = window.CQuotient) == null ? void 0 : t.siteId, this.locale = Ua((o = window.CQuotient) == null ? void 0 : o.locale), this.apiBaseUrl = "", this.clientId = "", this.currencyCode = (n = (s = window.pageContext) == null ? void 0 : s.ecommerce) == null ? void 0 : n.currencyCode
    }
    postUrlLocaleUpdateIfNeeded(t) {
        this.locale !== t && u.postMessage({
            eventName: l.urlLocaleUpdate,
            urlLocale: this.locale
        })
    }
    postIsNonBaseCurrencyIfNeeded(t) {
        this.currencyCode !== t && u.postMessage({
            eventName: l.isNonBaseCurrency,
            currencyCode: this.currencyCode
        })
    }
    onOpenCommerceSettingsUpdate({
        openCommerceSettings: t
    }) {
        const {
            apiVersion: o,
            clientId: s,
            baseLocale: n,
            baseCurrency: i
        } = t;
        this.apiBaseUrl = `https://${window.location.host}/s/${this.siteId}/dw/shop/${o}`, this.clientId = s, this.postUrlLocaleUpdateIfNeeded(n), this.postIsNonBaseCurrencyIfNeeded(i)
    }
    initInternalMessagingSubscriptions() {
        u.subscribeMultipleEvents({
            eventNames: Da,
            callback: this.internalMessagingHandler
        })
    }
    init() {
        this.isOpenCommerceStore && this.initInternalMessagingSubscriptions()
    }
}
const Ba = new ka,
    $a = [l.externalEventSubscribed, l.productCardClick],
    xa = ({
        subscribedEventName: e,
        payload: t
    }) => {
        switch (e) {
            case Y.productCardClick:
                {
                    const {
                        disableProductModal: o = !0
                    } = t;u.postMessage({
                        eventName: l.productCardClickSubscribed,
                        isDisableProductModal: o
                    });
                    break
                }
            default:
                return null
        }
    },
    Ha = ({
        data: e
    }) => {
        const {
            eventName: t
        } = e;
        switch (t) {
            case l.externalEventSubscribed:
                {
                    const {
                        subscribedEventName: o,
                        payload: s
                    } = e;xa({
                        subscribedEventName: o,
                        payload: s
                    });
                    break
                }
            case l.productCardClick:
                {
                    const {
                        variantId: o,
                        productId: s,
                        externalProductIds: n,
                        productHandle: i
                    } = e;u.postMessage({
                        eventName: Y.productCardClick,
                        variantId: o,
                        productId: s,
                        taggedProductIds: n,
                        productHandle: i
                    });
                    break
                }
            default:
                return null
        }
    };
class Wa {
    initInternalMessagingSubscriptions() {
        u.subscribeMultipleEvents({
            eventNames: $a,
            callback: Ha
        })
    }
    init() {
        this.initInternalMessagingSubscriptions()
    }
}
const is = new Wa;
Object.freeze(is);
const Va = [l.getProductsMetafields];
class Fa {
    constructor() {
        g(this, "internalMessagingHandler", ({
            data: t
        }) => {
            var o;
            switch (t.eventName) {
                case l.getProductsMetafields:
                    if (!((o = t == null ? void 0 : t.productIds) != null && o.length)) return;
                    u.postMessage({
                        productsExtraData: this.getProductsMetafields(t.productIds),
                        modalId: t.modalId,
                        eventName: l.returnProductsMetafields
                    });
                    return;
                default:
                    return null
            }
        })
    }
    getProductsMetafields(t = []) {
        var s, n;
        const o = {};
        for (const i of t) o[i] = (n = (s = window == null ? void 0 : window.metafields) == null ? void 0 : s.products) == null ? void 0 : n[i];
        return o
    }
    initInternalMessagingSubscriptions() {
        u.subscribeMultipleEvents({
            eventNames: Va,
            callback: this.internalMessagingHandler
        })
    }
    init() {
        this.initInternalMessagingSubscriptions()
    }
}
const rs = new Fa;
Object.freeze(rs);
const Ya = [b.productUpdate],
    Ga = ["id", "descriptionHtml", "description_html", "variants", "price", "compare_at_price", "title"],
    ja = ["id", "price", "compare_at_price", "title"],
    Ka = e => Ga.includes(e),
    za = e => Array.isArray(e) ? e.flatMap((t, o) => {
        const n = Object.keys(t).filter(i => !ja.includes(i));
        return n.length === 0 ? [] : `variants[${o}]: { ${n.join(", ")} }`
    }) : ["variants (must be an array)"],
    qa = ({
        product: e
    }) => {
        const o = Object.keys(e).filter(s => !Ka(s));
        if (e.variants && o.push(...za(e.variants)), o.length > 0) {
            console.error(`Fields ${o.join(", ")} are not supported for product update.`);
            return
        }
        u.postMessage({
            product: e,
            eventName: l.productUpdateResponse
        })
    },
    Za = ({
        data: e
    }) => {
        switch (e.eventName) {
            case b.productUpdate:
                return qa(e);
            default:
                return null
        }
    };
class Xa {
    initExternalMessagingSubscriptions() {
        u.subscribeMultipleEvents({
            eventNames: Ya,
            callback: Za
        })
    }
    init() {
        this.initExternalMessagingSubscriptions()
    }
}
const as = new Xa;
Object.freeze(as);
const Qa = [l.openRebuyCart],
    Xt = {
        show: "rebuy:smartcart.show",
        hide: "rebuy:smartcart.hide",
        init: "rebuy:smartcart.init"
    };
class Ja {
    constructor() {
        g(this, "sendIsRebuyAppInstalledMessage", () => {
            var t, o;
            if (!((t = window == null ? void 0 : window.Rebuy) != null && t.SmartCart)) {
                document.addEventListener(Xt.init, this.sendIsRebuyAppInstalledMessage, {
                    once: !0
                });
                return
            }
            u.postMessage({
                eventName: l.isRebuyAppInstalled,
                value: !!((o = window == null ? void 0 : window.Rebuy) != null && o.SmartCart)
            }), this.initRebuyEventListeners()
        });
        g(this, "internalMessagingHandler", t => {
            var o, s;
            switch (t.data.eventName) {
                case l.openRebuyCart:
                    return (s = (o = window == null ? void 0 : window.Rebuy) == null ? void 0 : o.SmartCart) == null ? void 0 : s.show();
                default:
                    return null
            }
        })
    }
    initInternalMessagingSubscriptions() {
        u.subscribeMultipleEvents({
            eventNames: Qa,
            callback: this.internalMessagingHandler
        })
    }
    initRebuyEventListeners() {
        document.addEventListener(Xt.show, () => {
            u.postMessage({
                eventName: l.rebuyCartShown
            })
        }), document.addEventListener(Xt.hide, () => {
            u.postMessage({
                eventName: l.rebuyCartHidden
            })
        })
    }
    init() {
        this.initInternalMessagingSubscriptions(), this.sendIsRebuyAppInstalledMessage()
    }
}
const cs = new Ja;
Object.freeze(cs);
const tc = () => {
        var e, t;
        return Number((t = (e = window.Shopify) == null ? void 0 : e.currency) == null ? void 0 : t.rate) === 1
    },
    Vd = e => typeof e == "string" && e.includes("cdn.shopify.com"),
    to = {
        soldOut: "already sold out",
        sellingPlanRequired: "Variant can only be purchased with a selling plan."
    },
    ec = [l.addToCartDisableDefault, l.setAnonymousIdToCart, l.loginWithMultipassUrlRequest, l.cartItemQuantityChange, l.cartDataRequest, l.productRecommendationsRequest, l.requestProductsUpdate, l.blockAnonymousIdToCart],
    eo = [l.addToCart, l.spotlightCarouselQuickShopClick],
    Qt = e => ({
        headers: {
            "Content-Type": "application/json"
        },
        method: "POST",
        body: JSON.stringify(e)
    });
let oo = !1,
    Jt = !1;
const te = {},
    vt = {};
class ut {
    constructor() {
        g(this, "getProduct", t => y(this, null, function*() {
            if (te[t]) return te[t];
            if (vt[t]) return vt[t];
            const o = this.fetchRawProduct(t);
            vt[t] = o;
            const s = yield o;
            return te[t] = s, delete vt[t], s
        }));
        g(this, "onRequestProductsUpdateMessage", o => y(this, [o], function*({
            handles: t
        }) {
            const n = [...new Set(t)].map(r => this.getProduct(r)),
                i = (yield Promise.all(n)).filter(Boolean);
            for (const r of i) u.postMessage({
                eventName: l.productUpdateResponse,
                product: r,
                isProductUpdateResponse: !0
            })
        }));
        g(this, "shopifyAddToCart", r => y(this, [r], function*({
            variantId: t,
            productHandle: o,
            sellingPlanId: s,
            quantity: n = Us,
            transmissionId: i
        }) {
            const a = {};
            Jt || (a._isAddedFromTolstoy = !0);
            const c = {
                id: t,
                quantity: n,
                properties: a
            };
            s && (c.selling_plan = s);
            const h = Qt({
                items: [c]
            });
            try {
                const p = yield fetch(`${this.storeRootUrl}cart/add.js`, h);
                if (!p.ok) {
                    const I = yield p.json();
                    return this.handleAddToCartError({
                        error: I,
                        variantId: t,
                        productHandle: o,
                        transmissionId: i
                    })
                }
                this.triggerExternalCartUpdate(), u.postMessage({
                    eventName: l.addToCartSuccess,
                    variantId: t,
                    transmissionId: i,
                    shouldEndTransmission: !1
                }), this.getCart({
                    transmissionId: i
                })
            } catch (p) {
                console.log(p), this.handleAddToCartError({
                    error: p,
                    variantId: t,
                    productHandle: o,
                    transmissionId: i
                })
            }
        }));
        g(this, "shopifyUpdateItemQuantity", n => y(this, [n], function*({
            variantId: t,
            quantity: o,
            transmissionId: s
        }) {
            const i = {
                    updates: {
                        [t]: o
                    }
                },
                r = Qt(i);
            try {
                const a = yield fetch(`${this.storeRootUrl}cart/update.js`, r);
                if (!a.ok) {
                    const c = yield a.json();
                    return this.handleUpdateItemQuantityError({
                        error: c,
                        variantId: t,
                        transmissionId: s
                    })
                }
                this.triggerExternalCartUpdate(), u.postMessage({
                    eventName: l.cartItemQuantityChangeSuccess,
                    variantId: t,
                    transmissionId: s,
                    shouldEndTransmission: !1
                }), this.getCart({
                    transmissionId: s
                })
            } catch (a) {
                this.handleUpdateItemQuantityError({
                    error: a,
                    variantId: t,
                    transmissionId: s
                })
            }
        }));
        g(this, "internalMessagingHandler", t => {
            switch (t.data.eventName) {
                case l.addToCart:
                    return this.shopifyAddToCart(t.data);
                case l.spotlightCarouselQuickShopClick:
                    return this.shopifyQuickShopClick(t.data);
                case l.addToCartDisableDefault:
                    return this.disableAddToCart(t.data);
                case l.blockAnonymousIdToCart:
                    return this.blockAnonymousIdToCart(t.data);
                case l.setAnonymousIdToCart:
                    return this.setAnonymousIdToCart(t.data);
                case l.loginWithMultipassUrlRequest:
                    return this.loginWithMultipassUrl(t.data);
                case l.cartItemQuantityChange:
                    return this.shopifyUpdateItemQuantity(t.data);
                case l.cartDataRequest:
                    return this.getCart(t.data);
                case l.productRecommendationsRequest:
                    return this.getProductRecommendations(t.data);
                case l.requestProductsUpdate:
                    return this.onRequestProductsUpdateMessage(t.data);
                default:
                    return null
            }
        });
        g(this, "initInternalMessagingSubscriptions", () => {
            if (u.subscribeMultipleEvents({
                    eventNames: ec,
                    callback: this.internalMessagingHandler
                }), oo) {
                Vs("Add to cart disabled");
                return
            }
            u.subscribeMultipleEvents({
                eventNames: eo,
                callback: this.internalMessagingHandler
            })
        });
        var t, o, s, n;
        if (ut.instance) return ut.instance;
        ut.instance = this, this.isShopifyStore = !!((t = window.Shopify) != null && t.shop && ((o = window.Shopify) != null && o.routes)), this.storeRootUrl = (n = (s = window.Shopify) == null ? void 0 : s.routes) == null ? void 0 : n.root
    }
    getIsProductSoldOutError(t) {
        return t.includes(to.soldOut)
    }
    getIsSellingPlanError(t) {
        return t.includes(to.sellingPlanRequired)
    }
    formatProduct(t) {
        var n, i, r;
        if (!t) return null;
        const o = ((i = (n = window.Shopify) == null ? void 0 : n.currency) == null ? void 0 : i.active) || ((r = window.Shopify) == null ? void 0 : r.currency),
            s = window.tolstoyCurrencySymbol || ns[o];
        return w(m({}, t), {
            id: String(t.id),
            price: t.price / 100,
            compare_at_price: t.compare_at_price ? t.compare_at_price / 100 : t.compare_at_price,
            currencyCode: o,
            currencySymbol: s,
            variants: t.variants.map(a => w(m({}, a), {
                price: a.price / 100,
                compare_at_price: a.compare_at_price ? a.compare_at_price / 100 : a.compare_at_price
            }))
        })
    }
    fetchRawProduct(t) {
        return y(this, null, function*() {
            const o = this.storeRootUrl + `products/${t}.js`;
            try {
                const n = yield(yield fetch(o)).json();
                return this.formatProduct(n)
            } catch (s) {}
        })
    }
    handleSellingPlanError(t, o) {
        return y(this, null, function*() {
            const s = yield this.getProduct(o);
            if (!s) return;
            const {
                id: n
            } = s.selling_plan_groups[0].selling_plans[0];
            return this.shopifyAddToCart({
                variantId: t,
                productHandle: o,
                sellingPlanId: n
            })
        })
    }
    handleAddToCartError({
        error: t,
        variantId: o,
        productHandle: s,
        transmissionId: n
    }) {
        const {
            description: i
        } = t;
        if (this.getIsProductSoldOutError(i)) {
            u.postMessage({
                eventName: l.addToCartSoldOut,
                variantId: o,
                transmissionId: n
            });
            return
        }
        if (this.getIsSellingPlanError(i)) return this.handleSellingPlanError(o, s);
        u.postMessage({
            eventName: l.addToCartError,
            error: i,
            variantId: o,
            transmissionId: n
        })
    }
    handleUpdateItemQuantityError({
        error: t,
        variantId: o,
        transmissionId: s
    }) {
        const {
            description: n
        } = t;
        u.postMessage({
            eventName: l.cartItemQuantityChangeError,
            error: n,
            variantId: o,
            transmissionId: s
        })
    }
    getCart(o) {
        return y(this, arguments, function*({
            transmissionId: t
        }) {
            try {
                const n = yield(yield fetch(`${this.storeRootUrl}cart.js`, {
                    method: "GET"
                })).json();
                u.postMessage({
                    eventName: l.cartDataResponse,
                    cart: n,
                    transmissionId: t
                })
            } catch (s) {}
        })
    }
    triggerExternalCartUpdate() {
        var t, o, s, n, i, r, a, c, d, h, p;
        (i = (n = (s = (o = (t = window.VueMiniCart) == null ? void 0 : t.$store) == null ? void 0 : o._actions) == null ? void 0 : s.initCart) == null ? void 0 : n[0]) == null || i.call(n), (c = (a = (r = window.slate) == null ? void 0 : r.cart) == null ? void 0 : a.reloadCart) == null || c.call(a), (d = window.tolstoyCartRefresh) == null || d.call(window), (h = window.monster_refresh) == null || h.call(window), (p = window.updateMiniCart) == null || p.call(window)
    }
    disableAddToCart() {
        oo = !0, u.unsubscribeMultipleEvents({
            eventNames: eo,
            callback: this.internalMessagingHandler
        })
    }
    postUrlLocaleUpdateIfNeeded() {
        var t, o, s, n;
        ((o = (t = window.Shopify) == null ? void 0 : t.routes) == null ? void 0 : o.root) !== "/" && u.postMessage({
            eventName: l.urlLocaleUpdate,
            urlLocale: (n = (s = window.Shopify) == null ? void 0 : s.routes) == null ? void 0 : n.root
        })
    }
    postIsNonBaseCurrencyIfNeeded() {
        tc() || u.postMessage({
            eventName: l.isNonBaseCurrency
        })
    }
    shopifyQuickShopClick({
        product: t
    }) {
        const {
            variants: o,
            handle: s,
            quantity: n = 1
        } = t, i = o[0].id;
        return this.shopifyAddToCart({
            variantId: i,
            productHandle: s,
            quantity: n
        })
    }
    getProductRecommendations(s) {
        return y(this, arguments, function*({
            productId: t,
            transmissionId: o
        }) {
            const n = `${this.storeRootUrl}recommendations/products.json?product_id=${t}`;
            try {
                const i = yield fetch(n, {
                    method: "GET"
                }), {
                    products: r
                } = yield i.json();
                u.postMessage({
                    eventName: l.productRecommendationsResponse,
                    productId: t,
                    products: r,
                    transmissionId: o
                })
            } catch (i) {}
        })
    }
    loginWithMultipassUrl(s) {
        return y(this, arguments, function*({
            multipassUrl: t,
            transmissionId: o
        }) {
            try {
                const n = yield fetch(t);
                u.postMessage({
                    eventName: l.loginWithMultipassUrlResponse,
                    statusCode: n.status,
                    transmissionId: o
                })
            } catch (n) {}
        })
    }
    setAnonymousIdToCart(o) {
        return y(this, arguments, function*({
            anonymousId: t
        }) {
            if (Un() === "true" || Jt || !R()) return;
            const s = {
                    attributes: {
                        [es.tolstoyAnonymousId]: t
                    }
                },
                n = Qt(s);
            try {
                yield fetch(`${this.storeRootUrl}cart/update.js`, n), Dn(!0)
            } catch (i) {
                console.error(i)
            }
        })
    }
    blockAnonymousIdToCart(o) {
        return y(this, arguments, function*({
            appKey: t
        }) {
            const s = Cn(t);
            Ys(s) || (yield this.setAnonymousIdToCart({
                anonymousId: null
            })), Jt = !0
        })
    }
    forceClearAnonymousIdFromCart() {
        var o;
        if (((o = window.Shopify) == null ? void 0 : o.shop) !== "mlt-boutique.myshopify.com") return;
        const t = P();
        t && this.blockAnonymousIdToCart({
            appKey: t
        })
    }
    init() {
        this.isShopifyStore && (this.initInternalMessagingSubscriptions(), this.postUrlLocaleUpdateIfNeeded(), this.postIsNonBaseCurrencyIfNeeded(), this.forceClearAnonymousIdFromCart())
    }
}
const ls = new ut;
Object.freeze(ls);
const oc = [l.addToCart, l.playerReady, l.productCardClick],
    sc = {
        cartUpdated: "cart/updated"
    },
    nc = ({
        productId: e,
        variantId: t
    }) => {
        const o = {
            productId: String(e)
        };
        return t && (o.variantId = String(t)), window.Tapcart.actions.openProduct(o)
    },
    ic = e => {
        const o = setTimeout(() => {
            u.postMessage(w(m({}, e), {
                eventName: l.addToCartError
            }))
        }, 4e3);
        window.Tapcart.registerEventHandler(sc.cartUpdated, () => {
            clearTimeout(o), u.postMessage(w(m({}, e), {
                eventName: l.addToCartSuccess
            }))
        })
    },
    rc = e => y(void 0, null, function*() {
        const {
            variantId: t,
            productId: o
        } = e;
        try {
            ic(e), window.Tapcart.actions.addToCart({
                lineItems: [{
                    variantId: String(t || o),
                    quantity: 1
                }]
            })
        } catch (s) {
            return u.postMessage(w(m({}, e), {
                error: s,
                eventName: l.addToCartError
            }))
        }
    }),
    ac = () => {
        var e, t, o, s, n, i;
        try {
            const r = Io();
            if (!r) return;
            const c = [...((o = (t = (e = window == null ? void 0 : window.Tapcart) == null ? void 0 : e.variables) == null ? void 0 : t.cart) == null ? void 0 : o.attributes) || [], {
                key: es.tolstoyAnonymousId,
                value: r
            }];
            (i = (n = (s = window == null ? void 0 : window.Tapcart) == null ? void 0 : s.actions) == null ? void 0 : n.updateCartAttributes) == null || i.call(n, {
                attributes: c
            })
        } catch (r) {
            le({
                text: r == null ? void 0 : r.message,
                parentUrl: window.location.href,
                appKey: P(),
                source: "tapcart",
                eventName: "widgetError",
                timestamp: new Date().toISOString()
            })
        }
    };
class cc {
    constructor() {
        g(this, "internalMessagingHandler", t => {
            switch (t.data.eventName) {
                case l.playerReady:
                    return this.disableCartDefault();
                case l.productCardClick:
                    return nc(t.data);
                case l.addToCart:
                    return rc(t.data);
                default:
                    return null
            }
        })
    }
    disableCartDefault() {
        u.postMessage({
            eventName: l.addToCartDisableDefault
        })
    }
    initInternalMessagingSubscriptions() {
        u.subscribeMultipleEvents({
            eventNames: oc,
            callback: this.internalMessagingHandler
        })
    }
    init() {
        Tt() && (this.initInternalMessagingSubscriptions(), ac())
    }
}
const ds = new cc;
Object.freeze(ds);
const lc = [b.urlLocaleUpdate],
    dc = ({
        data: e
    }) => {
        switch (e.eventName) {
            case b.urlLocaleUpdate:
                const {
                    payload: t
                } = e;
                u.postMessage({
                    eventName: l.urlLocaleUpdate,
                    urlLocale: t.urlLocale
                });
                break;
            default:
                return null
        }
    };
class pt {
    constructor() {
        if (pt.instance) return pt.instance;
        pt.instance = this
    }
    initExternalMessagingSubscriptions() {
        u.subscribeMultipleEvents({
            eventNames: lc,
            callback: dc
        })
    }
    init() {
        this.initExternalMessagingSubscriptions();
        const t = window.history.pushState,
            o = window.history.replaceState;
        let s = window.location.href;
        const n = () => {
            window.location.href !== s && (s = window.location.href, u.postMessage({
                eventName: l.urlChange
            }))
        };
        window.history.pushState = function() {
            t.apply(window.history, arguments), n()
        }, window.history.replaceState = function() {
            o.apply(window.history, arguments), n()
        }
    }
}
const us = new pt;
Object.freeze(us);
const uc = [b.addToCartSuccess, b.addToCartError];
class ht {
    constructor() {
        g(this, "postMessageToWidgetV2", t => {
            const {
                data: o
            } = t || {}, {
                eventName: s,
                subscribedEventName: n
            } = o || {};
            if (!s && !n) return;
            const i = new CustomEvent("TOLSTOY_WIDGET_V2_MESSAGE", {
                detail: w(m({}, o), {
                    eventName: n || s
                })
            });
            window.dispatchEvent(i)
        });
        g(this, "initExternalMessagingSubscriptions", () => {
            u.subscribeMultipleEvents({
                eventNames: uc,
                callback: this.postMessageToWidgetV2
            })
        });
        if (ht.instance) return ht.instance;
        ht.instance = this
    }
    init() {
        this.initExternalMessagingSubscriptions()
    }
}
const ps = new ht;
Object.freeze(ps);
class pc {
    constructor() {
        this.domUpdatesListenerInitialized = !1, this.loaded = !1
    }
    init() {
        return y(this, null, function*() {})
    }
    loadVideo() {
        return y(this, null, function*() {})
    }
    registerDomUpdatesListenerIfNeeded() {}
}
const hc = [l.addToCartError, l.addToCartSuccess, l.addToCartSoldOut, l.isRebuyAppInstalled, l.isAfterpayAppInstalled, l.openRebuyCart, l.returnProductsMetafields, l.rejectCookiePolicy, l.productCardClickSubscribed, l.isTapcart, l.urlLocaleUpdate, l.loginWithMultipassUrlResponse, l.cartDataResponse, l.cartItemQuantityChangeSuccess, l.cartItemQuantityChangeError, l.productRecommendationsResponse, l.productUpdateResponse, l.isNonBaseCurrency, l.eventListenersInitialized],
    At = {},
    ee = {},
    Ot = {},
    oe = [];
class yt {
    constructor() {
        g(this, "eventHandler", ({
            data: t = {}
        }) => {
            const {
                modalId: o,
                eventName: s
            } = t;
            if (o) switch (s) {
                case l.addToCart:
                case l.openRebuyCart:
                case l.openKendoModal:
                case l.getProductsMetafields:
                case l.productCardClick:
                case l.loginWithMultipassUrlRequest:
                case l.cartItemQuantityChange:
                case l.cartDataRequest:
                case l.productRecommendationsRequest:
                case l.requestProductsUpdate:
                case l.moveToUrl:
                case l.showFeedProductModal:
                case l.reportModalOpen:
                case l.reportModalClose:
                case so:
                    return this.postInternalMessage({
                        modalId: o,
                        data: t
                    });
                case l.modalMessagingReady:
                    return this.postInternalMessage({
                        modalId: o,
                        data: t
                    }), this.handleModalMessagingReady({
                        modalId: o
                    });
                case l.toggleFeedCloseButton:
                    return this.postInternalMessage({
                        modalId: o,
                        data: t
                    });
                default:
                    return null
            }
        });
        g(this, "internalEventHandler", ({
            data: t
        }) => {
            this.postMessageToModal(t)
        });
        g(this, "initInternalMessagingSubscriptions", () => {
            u.subscribeMultipleEvents({
                eventNames: hc,
                callback: this.internalEventHandler
            })
        });
        if (yt.instance) return yt.instance;
        yt.instance = this
    }
    registerIframe({
        modalId: t,
        modalIframe: o
    }) {
        At[t] = o
    }
    postInternalMessage({
        modalId: t,
        data: o
    }) {
        delete o.modalId;
        const s = u.postMessage(o);
        Ot[s] = t
    }
    handleModalMessagingReady({
        modalId: t
    }) {
        ee[t] = !0;
        const o = At[t];
        for (const s of oe) {
            const {
                transmissionId: n
            } = s, i = Ot[n];
            (!i || i === t) && this.postMessageToIframe({
                iframe: o,
                message: s
            })
        }
    }
    postMessageToIframe({
        iframe: t,
        message: o
    }) {
        var s;
        (s = t.contentWindow) == null || s.postMessage(o, "*")
    }
    postMessageToAllIframes({
        message: t
    }) {
        oe.push(t);
        for (const [o, s] of Object.entries(At)) ee[o] && this.postMessageToIframe({
            iframe: s,
            message: t
        })
    }
    postMessageToModal(t) {
        const c = t,
            {
                transmissionId: o,
                shouldEndTransmission: s = !0
            } = c,
            n = Be(c, ["transmissionId", "shouldEndTransmission"]),
            i = Ot[o];
        if (!i) return this.postMessageToAllIframes({
            message: n
        });
        if (!ee[i]) {
            oe.push(t);
            return
        }
        const a = At[i];
        this.postMessageToIframe({
            iframe: a,
            message: n
        }), s && delete Ot[o]
    }
    init() {
        this.initInternalMessagingSubscriptions(), window.addEventListener("message", this.eventHandler)
    }
}
const he = new yt;
Object.freeze(he);
const yc = 50,
    gc = "8b32dacc-8f1d-4cce-b641-9f60e88f9414",
    mc = () => {
        var t, o;
        const e = (o = (t = document.querySelector("script[data-collection-id]")) == null ? void 0 : t.dataset) == null ? void 0 : o.collectionId;
        return e != null && e.includes("{{ collection.id") || !e ? null : e
    },
    fc = () => y(void 0, null, function*() {
        try {
            const e = P(),
                t = mc(),
                o = Z("collection-gallery-projects");
            if (!o) return console.log("(tolstoy) collectionGalleryProjectsString", o), [];
            const s = JSON.parse(o);
            if (console.log("(tolstoy) collectionGalleryProjects", s), console.log("(tolstoy) collectionId", t, "appKey", e), t && e && (s != null && s.length)) return nn(e, t)
        } catch (e) {
            console.log(e)
        }
        return []
    }),
    Ec = () => {
        var t, o;
        const e = ((t = document.currentScript) == null ? void 0 : t.src) || ((o =
            import.meta) == null ? void 0 : o.url);
        if (e != null && e.includes("/we/widget.js")) {
            Fe({
                src: `https://${ae}/wes/widget.js`,
                container: document.head,
                attributes: {
                    type: "module"
                }
            });
            return
        }
        Fe({
            src: `https://${ae}/ws/widget.js`,
            container: document.head
        })
    },
    wc = () => !!document.body,
    Sc = () => {
        try {
            return window.self !== window.top
        } catch (e) {
            return !0
        }
    },
    Tc = () => Sc() && window.location.host === "theordinary.com",
    hs = () => y(void 0, null, function*() {
        var e, t, o, s, n, i;
        try {
            if (window.tolstoyWidget || Tc()) return;
            if (ha()) {
                console.debug("Bot user");
                return
            }
            if (!wc()) {
                setTimeout(hs, yc);
                return
            }
            if (Tt() && (yield ri(), bo())) return;
            if (B("td") === "true" && !((o = (t = (e = document.currentScript) == null ? void 0 : e.src) == null ? void 0 : t.includes) != null && o.call(t, "/ws/widget.js")) && !((i = (n = (s =
                    import.meta) == null ? void 0 : s.url) == null ? void 0 : n.includes) != null && i.call(n, "/wes/widget.js"))) {
                Ec();
                return
            }
            Wn(), Ac(), Oc(), Pc(), Rc(), Lc(), Mc(), ko();
            const [, r] = yield Promise.all([Ic(), fc()]);
            console.log("(tolstoy) additionalConfigs", r), yield Promise.all([bc(), Cc(), vc(), _c(r)]), zn()
        } catch (r) {
            console.log("error", r)
        }
    }),
    Ic = () => y(void 0, null, function*() {
        return Xo.init()
    }),
    bc = e => new ra(e).init(),
    Cc = () => new la().init(),
    _c = e => new Kr().init(e),
    vc = () => new pc().init(),
    Ac = () => (u.init(), u),
    Oc = () => (he.init(), he),
    Pc = () => {
        Rt.init();
        const {
            subscribe: e,
            unsubscribe: t
        } = Rt;
        return window.tolstoyWidget = w(m({}, window.tolstoyWidget), {
            subscribe: e,
            unsubscribe: t
        }), Rt
    },
    Rc = () => {
        const {
            postMessage: e,
            closePlayer: t,
            identify: o,
            changeEmail: s
        } = pe;
        return window.tolstoyWidget = w(m({}, window.tolstoyWidget), {
            postMessage: e,
            closePlayer: t,
            identify: o,
            changeEmail: s
        }), pe
    },
    Lc = () => {
        ls.init(), us.init(), os.init(), cs.init(), ss.init(), ds.init(), Jo.init(), ts.init(), is.init(), Ba.init(), as.init(), ps.init(), P() === gc && rs.init()
    },
    Mc = () => {
        u.subscribeMultipleEvents({
            eventNames: da,
            callback: ua
        })
    };
hs();
export {
    z as $, ad as A, B, se as C, cl as D, nl as E, Ui as F, Ed as G, Rd as H, l as I, Cd as J, Kt as K, kc as L, Go as M, Ce as N, Ho as O, bs as P, Ze as Q, Fs as R, vs as S, Kl as T, u as U, rl as V, Pr as W, al as X, ll as Y, il as Z, O as _, qs as a, fd as a$, ml as a0, Is as a1, ie as a2, As as a3, Yo as a4, Ys as a5, Td as a6, bl as a7, Tl as a8, Br as a9, ao as aA, Pl as aB, ro as aC, qo as aD, Ge as aE, Hl as aF, Vl as aG, so as aH, Yt as aI, Gt as aJ, gl as aK, Wl as aL, xl as aM, Xl as aN, Gl as aO, kl as aP, Bl as aQ, wd as aR, ho as aS, Uo as aT, Ut as aU, vr as aV, yo as aW, he as aX, vl as aY, Do as aZ, Nn as a_, $l as aa, kd as ab, re as ac, _r as ad, Ud as ae, _l as af, bd as ag, hl as ah, no as ai, q as aj, pl as ak, Os as al, sd as am, nd as an, id as ao, S as ap, f as aq, xi as ar, Ps as as, gt as at, Sl as au, Rs as av, El as aw, co as ax, Pd as ay, Rl as az, wt as b, Il as b$, Ql as b0, Vs as b1, jl as b2, Lo as b3, ca as b4, Hd as b5, ta as b6, Tt as b7, Io as b8, $d as b9, sa as bA, Bd as bB, yl as bC, oa as bD, xd as bE, Wc as bF, Hc as bG, Dc as bH, Bc as bI, Uc as bJ, xc as bK, $c as bL, Ol as bM, xt as bN, Yl as bO, Ll as bP, Fl as bQ, Fc as bR, Vc as bS, Gc as bT, Yc as bU, jc as bV, Xc as bW, ld as bX, zl as bY, ui as bZ, pi as b_, Wd as ba, wl as bb, ks as bc, na as bd, md as be, jt as bf, gd as bg, Dl as bh, Rn as bi, Ul as bj, wn as bk, Ts as bl, Qc as bm, ol as bn, Ss as bo, Ad as bp, zc as bq, Kc as br, it as bs, Dr as bt, Ls as bu, Zc as bv, Ar as bw, cd as bx, qc as by, b as bz, Dd as c, hi as c0, ql as c1, vd as c2, Cl as c3, yd as c4, hd as c5, el as c6, ed as c7, Vd as c8, Zl as c9, od as ca, tl as cb, zn as cc, pd as cd, dd as ce, ud as cf, Al as cg, Je as ch, Mt as ci, D as cj, fl as ck, Id as cl, Sd as cm, Nd as d, Jc as e, Nr as f, Od as g, P as h, td as i, Bo as j, _d as k, mo as l, Jl as m, Ld as n, Or as o, st as p, ul as q, Rr as r, Fo as s, Cs as t, sl as u, Md as v, kr as w, dl as x, ne as y, rd as z
};