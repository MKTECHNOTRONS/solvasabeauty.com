var p = (s, t, e) => new Promise((a, i) => {
    var l = o => {
            try {
                r(e.next(o))
            } catch (u) {
                i(u)
            }
        },
        c = o => {
            try {
                r(e.throw(o))
            } catch (u) {
                i(u)
            }
        },
        r = o => o.done ? a(o.value) : Promise.resolve(o.value).then(l, c);
    r((e = e.apply(s, t)).next())
});
import {
    n as h,
    j as d,
    a1 as n,
    f as y,
    m,
    K as b,
    g as v,
    d as g,
    a2 as E,
    G as C,
    H as _,
    l as B
} from "../widget.js";
import {
    M as f
} from "./modal.eb2bcf55.js";
import "./recharge.cbcf93a4.js";
import "./color.e07a28b3.js";
import "./activity-event-helper.8640d488.js";
const w = "_tolstoyEmbed_13q7x_1",
    x = "_embedContainer_13q7x_7",
    T = "_videoContainer_13q7x_19",
    I = "_videoPreview_13q7x_26",
    L = "_playButtonContainer_13q7x_43",
    P = "_startButtonContainer_13q7x_47",
    N = "_startText_13q7x_62";
const z = s => {
        const t = {
                preload: "metadata",
                playsinline: !0,
                muted: !0,
                autoplay: !0,
                disablepictureinpicture: !0,
                loop: !0,
                src: s
            },
            e = d({
                tagName: "video",
                classNames: [I, n.videoPreview],
                attributes: t
            });
        return e.addEventListener("loadeddata", () => {
            e.muted = !0, e.play()
        }), e
    },
    S = s => {
        const t = `${y(n.embedContainer,s)}`,
            e = d({
                tagName: "button",
                classNames: [L, n.playButtonContainer],
                attributes: {
                    "aria-label": "Open Tolstoy widget",
                    "data-tolstoy-element": t
                }
            }),
            a = m();
        return e.innerHTML = a, e
    },
    q = () => {
        const s = d({
            div: "div",
            classNames: [N, n.startText]
        });
        return s.innerHTML = "Begin an interactive conversation", s
    },
    M = s => {
        const t = d({
                tagName: "div",
                classNames: [P, n.startButtonContainer]
            }),
            e = q(),
            a = S(s);
        return t.append(a), t.append(e), t
    },
    V = s => {
        var r;
        const t = (r = s == null ? void 0 : s.steps) == null ? void 0 : r[0],
            e = h({
                step: t
            }),
            a = d({
                tagName: "div",
                classNames: [x, n.embedContainer]
            }),
            i = d({
                tagName: "div",
                classNames: [T, n.videoContainer]
            }),
            l = z(e),
            c = M(s.publishId);
        return i.append(l), i.append(c), a.append(i), a
    };
class U {
    constructor() {
        this.initialized = !1, this.handleView = this.handleView.bind(this), this.playerReadyMessages = [], this.playerReady = !1
    }
    getIframe() {
        return document.querySelector(`#${n.iframe}-${this.data.publishId}`)
    }
    getIsInitialized() {
        return this.initialized
    }
    subscribeForEmbedEvents(t) {
        t == null || t.addEventListener("keypress", e => {
            (e.code === "Space" || e.code === "Enter") && this.start()
        }), t == null || t.addEventListener("click", () => {
            this.start()
        }), t == null || t.setAttribute("hasClickEvent", !0), t == null || t.setAttribute("role", "button"), t == null || t.setAttribute("tabindex", "0")
    }
    handleView() {
        b(this.data.publishId, !0), this.modal.sendEmbedView()
    }
    start() {
        this.modal.open()
    }
    init(t) {
        return p(this, null, function*() {
            const e = v(t);
            if (!e) {
                this.initialized = !1;
                return
            }
            try {
                const a = yield g({
                    publishId: e,
                    widgetType: E
                });
                if (!a || a.disabled) {
                    this.initialized = !1, t.innerHTML = "";
                    return
                }
                a.playerType = E, C(a) && (a.playerLazy = !0), t.style.width = "100%", t.style.height = "100%", t.classList.add(w), t.classList.add(n.embed);
                const i = V(a, t);
                t.append(i), this.subscribeForEmbedEvents(t), a.modalWrapperElement = i, this.data = a, b(e, !1), _(this.data), this.modal = new f(this.data), this.initialized = !0
            } catch (a) {
                B(a), this.initialized = !1
            }
        })
    }
}
export {
    U as
    default
};