var D = Object.defineProperty,
    N = Object.defineProperties;
var R = Object.getOwnPropertyDescriptors;
var g = Object.getOwnPropertySymbols;
var k = Object.prototype.hasOwnProperty,
    W = Object.prototype.propertyIsEnumerable;
var f = (l, e, t) => e in l ? D(l, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : l[e] = t,
    c = (l, e) => {
        for (var t in e || (e = {})) k.call(e, t) && f(l, t, e[t]);
        if (g)
            for (var t of g(e)) W.call(e, t) && f(l, t, e[t]);
        return l
    },
    E = (l, e) => N(l, R(e));
var p = (l, e, t) => (f(l, typeof e != "symbol" ? e + "" : e, t), t);
var w = (l, e, t) => new Promise((s, o) => {
    var n = r => {
            try {
                d(t.next(r))
            } catch (h) {
                o(h)
            }
        },
        i = r => {
            try {
                d(t.throw(r))
            } catch (h) {
                o(h)
            }
        },
        d = r => r.done ? s(r.value) : Promise.resolve(r.value).then(n, i);
    d((t = t.apply(l, e)).next())
});
import {
    I as a,
    bz as A,
    aW as H,
    bA as U,
    bB as V,
    ad as Y,
    bC as x,
    a2 as _,
    L as M,
    ap as T,
    b0 as G,
    aN as $,
    bD as z,
    b9 as K,
    bE as C,
    aX as X,
    bF as I,
    U as b,
    $ as u,
    aH as S,
    aY as Z,
    bG as j,
    bH as J,
    bI as Q,
    bJ as q,
    bK as ee,
    bL as te,
    bM as se,
    bN as ie,
    aa as oe,
    bO as ae,
    bP as ne,
    bQ as le
} from "../widget.js";
import {
    R as re
} from "./recharge.cbcf93a4.js";
import {
    g as de
} from "./color.e07a28b3.js";
import {
    h as L,
    a as he,
    i as me
} from "./activity-event-helper.8640d488.js";
const ce = "data-test-id",
    xe = "tolstoy-text-bubble-container",
    ue = "tolstoy-modal",
    Ge = "tolstoy-widget",
    $e = "tolstoy-content-container",
    ze = "tolstoy-widget-video",
    ye = "_mainContainer_itciw_1",
    pe = "_tolstoyModal_itciw_16",
    fe = "_tolstoyEmbedModal_itciw_27",
    be = "_tolstoyCenteredModal_itciw_42",
    O = "_tolstoyModalVertical_itciw_52",
    ge = "_feedSmallModal_itciw_61",
    Ee = "_tolstoyModalHorizontal_itciw_72",
    we = "_tolstoyModalBottomLeft_itciw_113",
    _e = "_tolstoyModalBottomRight_itciw_118",
    Me = "_iframeContainer_itciw_123",
    Te = "_iframeLoaderContainer_itciw_138",
    Ce = "_iframeLoaderBox_itciw_148",
    Ie = "_iframeLoader_itciw_138";
const Se = "_tolstoyIframe_itciw_173",
    Le = "_feedTolstoyIframe_itciw_197",
    Oe = "_closeButton_itciw_201",
    Pe = "_feedCloseButton_itciw_220",
    Be = "_mobileFeedCloseButton_itciw_241",
    P = "_hideFeedCloseButton_itciw_272",
    ve = "_closeButtonVertical_itciw_318",
    Fe = "_tolstoyIframeVertical_itciw_323",
    Ae = "_embedTolstoyIframe_itciw_335",
    B = "_rebuyCartShown_itciw_340",
    v = "_tolstoyWidgetShown_itciw_355",
    De = "_feedModal_itciw_359",
    Ne = "_tolstoyModalVerticalSmall_itciw_374";
const F = "hide-feed-close-button",
    Re = [a.rebuyCartShown, a.rebuyCartHidden, a.toggleFeedCloseButton, a.moveToUrl, a.changeZIndex, a.closePlayer, a.userEmailUpdate],
    ke = [A.tolstoyZIndexChange],
    m = {
        PLAYER: "player",
        ON_YOU: "on_you"
    };
class Ke {
    constructor(e, t = m.PLAYER) {
        p(this, "internalMessagingHandler", e => {
            switch (e.data.eventName) {
                case a.rebuyCartShown:
                    this.modal.classList.add(B), window.removeEventListener("touchmove", this.preventDefault);
                    break;
                case a.rebuyCartHidden:
                    this.modal.classList.remove(B), this.lockScreen();
                    break;
                case a.toggleFeedCloseButton:
                    this.toggleFeedCloseButton(e.data);
                    break;
                case a.moveToUrl:
                    this.redirectToUrl(e.data);
                    break;
                case a.changeZIndex:
                    this.changeZIndex(e);
                    break;
                case a.closePlayer:
                    this.hide();
                    break;
                case a.userEmailUpdate:
                    this.changeEmail(e.data.email);
                    break;
                default:
                    return null
            }
        });
        p(this, "externalMessagingHandler", e => {
            switch (e.data.eventName) {
                case A.tolstoyZIndexChange:
                    this.changeZIndex(e);
                    break;
                default:
                    return null
            }
        });
        p(this, "initExternalMessagingSubscriptions", () => {
            b.subscribeMultipleEvents({
                eventNames: ke,
                callback: this.externalMessagingHandler
            })
        });
        var n, i;
        this.type = t, this.id = H();
        const s = U(),
            o = V();
        this.isAutoOpen = t === m.PLAYER && s === e.publishId || t === m.ON_YOU && o, this.initInternalMessagingSubscriptions(), this.initExternalMessagingSubscriptions(), this.autoplay = e.autoplay, this.widgetDelay = e.widgetDelay, this.isModalCentered = e.centeredModal, this.onWidgetOpen = null, this.onWidgetClose = null, this.modal = document.createElement("div"), this.modal.ariaLabel = `${e.name} modal`, this.modal.setAttribute("role", "dialog"), this.modal.ariaModal = "true", this.modal.ariaHidden = "true", this.mainContainer = document.createElement("div"), this.mainContainer.addEventListener("click", () => {
            this.hide()
        }), this.mainContainer.setAttribute("role", "button"), this.mainContainer.setAttribute("tabindex", "0"), this.email = e.email || "", this.publishId = e.publishId, this.isOpen = !1, this.modalWrapperElement = e.modalWrapperElement, this.isEmbed = this.getIsEmbedPlayerType(e.playerType), this.setDisplaySettings(e), this.subscribeForPlayerStart(), this.preConfigMessages = [], this.preConfigMessagingReady = !1, this.subscribeForPreConfigMessaging(), this.subscribeToOnKeyPress(), this.subscribeForWidgetCloseWhenAnotherOpens(), this.load(e), this.modal.setAttribute(ce, ue), this.subscribeToFeedMessages(e), this.subscribeForVideoEvents(), this.playerReady = !1, this.playerReadyMessages = [], this.lockScreen = this.lockScreen.bind(this), this.onTabKey = this.onTabKey.bind(this), this.sendAnalyticsData(e), this.playerLazy = e.playerLazy, this.minimizeOnClose = (i = (n = e.feedSettings) == null ? void 0 : n.minimizeOnClose) != null ? i : !1, this.publishId = e.publishId, this.rechargeMessaging = new re(this.tolstoyIframe), this.analyticsHandler = new Y({
            config: e,
            playerType: t === m.ON_YOU ? x : _
        }), this.lastFocusedElement = null, this.isAutoOpen && this.open()
    }
    getIsEmbedPlayerType(e) {
        return e === _
    }
    postMessageToWindow(e, t) {
        window.postMessage({
            name: M,
            type: e,
            eventData: t
        }, "*")
    }
    setDisplaySettings(e) {
        var o;
        const t = window.screen.width <= 450 || window.screen.height <= 450;
        if (this.isMobile = t, this.modal.style.display = "none", this.mainContainer.style.display = "none", this.isEmbed) {
            this.modal.classList.add(fe);
            return
        }
        this.modal.classList.add("tolstoy-modal", this.isModalCentered ? be : pe);
        const s = ((o = e.feedSettings) == null ? void 0 : o.isFullscreenFeed) !== !1;
        e.feed && (s || t) ? this.modal.classList.add(De) : e.feed ? (this.modal.classList.add(O), this.modal.classList.add(ge)) : e.verticalOrientation ? (this.modal.classList.add(O), this.modal.classList.add(Ne)) : this.modal.classList.add(Ee), e.widgetPosition === "bottomLeft" ? this.modal.classList.add(we) : this.modal.classList.add(_e)
    }
    changeEvent(e, t) {
        this[e] = t
    }
    handleCloseButtonEvent() {
        this.hide(), window.postMessage({
            name: T.tolstoyModalClose
        }, "*")
    }
    appendCloseButton(e) {
        var r, h;
        if (this.isEmbed) return;
        const {
            feedButtonsBorderRadius: t,
            opacity: s = .2,
            backgroundColor: o = "#000000",
            color: n
        } = ((h = (r = e == null ? void 0 : e.design) == null ? void 0 : r.player) == null ? void 0 : h.controls) || {}, i = document.createElement("div");
        i.ariaLabel = `${e.name} modal close`, i.setAttribute("role", "button"), i.setAttribute("tabindex", "0");
        const d = this.isFullscreenFeed || this.type === m.ON_YOU ? Pe : Be;
        i.classList.add("minimize-tolstoy-modal", this.isFeed ? d : Oe), i.innerHTML = this.isFeed ? G(n) : $, i.addEventListener("click", y => {
            y.preventDefault(), this.handleCloseButtonEvent()
        }), i.setAttribute("role", "button"), i.setAttribute("aria-label", "Close"), i.addEventListener("keydown", y => {
            (y.key === "Enter" || y.key === " ") && this.handleCloseButtonEvent()
        }), this.modal.append(i), this.isFeed && (this.feedXButton = i, i.style.setProperty("border-radius", `${t}px`, "important"), i.style.setProperty("background-color", de(o, s)))
    }
    subscribeToOnKeyPress() {
        window.addEventListener("keydown", e => {
            this.isOpen && e.key === "Escape" && this.hide()
        })
    }
    load(e) {
        var d;
        const t = e.feed,
            s = e.dynamic,
            o = ((d = e.feedSettings) == null ? void 0 : d.isFullscreenFeed) !== !1;
        this.isFeed = t, this.isFullscreenFeed = o, this.appendCloseButton(e);
        const n = document.createElement("div");
        n.classList.add(Me), this.modal.append(n);
        const i = document.createElement("iframe");
        switch (i.classList.add(Se), e.verticalOrientation && (i.classList.add(Fe), i.classList.add(ve)), this.isEmbed && i.classList.add(Ae), t && (o || this.isMobile) && i.classList.add(Le), i.allow = "autoplay *; clipboard-write *;camera *; microphone *; encrypted-media *; fullscreen *; display-capture *;", this.email = this.email || z(), this.type) {
            case m.ON_YOU:
                i.src = C({
                    data: e,
                    isOnYou: !0,
                    email: this.email,
                    modalId: this.id
                }), i.name = "tolstoy-on-you-modal", i.title = "tolstoy-on-you", i.ariaLabel = `Tolstoy On You : ${e.name}`;
                break;
            default:
                const r = K();
                i.src = C({
                    data: e,
                    isFeed: t,
                    email: this.email,
                    isDynamic: s,
                    modalId: this.id,
                    tolstoyStartVideo: this.isAutoOpen && r
                }), i.name = "tolstoy-modal", i.title = `tolstoy-${e.playerType}`, i.ariaLabel = `Tolstoy Player : ${e.name}`;
                break
        }
        n.append(i), i.addEventListener("load", () => {
            this.removePlayerLoader()
        }), this.tolstoyIframe = i, X.registerIframe({
            modalId: this.id,
            modalIframe: i
        }), this.appendPlayerLoader(n), this.appendHtmlContent(), this.safePostPreConfigMessage({
            eventName: I.vodAssetIds,
            vodAssetIds: e.vodAssetIds,
            appKey: e.appKey
        })
    }
    appendPlayerLoader(e) {
        this.playerLoader = document.createElement("div"), this.playerLoader.classList.add(Te);
        const t = document.createElement("div");
        t.classList.add(Ce), this.playerLoader.append(t);
        const s = document.createElement("div");
        s.classList.add(Ie), t.append(s), e.append(this.playerLoader)
    }
    removePlayerLoader() {
        this.playerLoader && (this.playerLoader.remove(), this.playerLoader = null)
    }
    appendHtmlContent() {
        this.isModalCentered ? (this.mainContainer.classList.add("main-container", ye), this.mainContainer.append(this.modal), document.documentElement.append(this.mainContainer)) : this.isEmbed ? this.modalWrapperElement.append(this.modal) : document.documentElement.append(this.modal)
    }
    changeEmail(e) {
        if (e === this.email || !e) return;
        let t = "";
        t = this.email ? this.tolstoyIframe.src.replace(this.email, e) : this.tolstoyIframe.src + `&email=${e}`, this.email = e, this.tolstoyIframe.src = t
    }
    safePostMessageToIframe(e) {
        var t, s;
        if (!this.playerReady) return this.playerReadyMessages.push(e);
        (s = (t = this.tolstoyIframe) == null ? void 0 : t.contentWindow) == null || s.postMessage(e, "*")
    }
    safePostPreConfigMessage(e) {
        var t, s;
        if (!this.preConfigMessagingReady) return this.preConfigMessages.push(e);
        (s = (t = this.tolstoyIframe) == null ? void 0 : t.contentWindow) == null || s.postMessage(e, "*")
    }
    openPlayerModal() {
        this.lastFocusedElement = document.activeElement, this.modal.style.setProperty("display", "inline", "important"), this.mainContainer.style.setProperty("display", "flex", "important"), this.tolstoyIframe.focus(), this.safePostMessageToIframe({
            name: a.modalOpen
        }), b.postMessage({
            eventName: a.modalOpen
        }), this.postMessageToWindow(u.OPEN, {
            stopDynamicEmbed: this.isFeed && this.isFullscreenFeed,
            publishId: this.publishId,
            hideBubblePreview: !this.isEmbed
        }), L({
            type: u.OPEN,
            publishId: this.publishId
        })
    }
    verifyPostMessage(e) {
        return e.data ? e.source === this.tolstoyIframe.contentWindow : !1
    }
    subscribeForPlayerStart() {
        window.addEventListener("message", e => {
            var t, s;
            if (this.verifyPostMessage(e)) {
                if (e.data.eventName === S) {
                    this.playerReady = !0;
                    for (const o of this.playerReadyMessages || [])(s = (t = this.tolstoyIframe) == null ? void 0 : t.contentWindow) == null || s.postMessage(o, "*");
                    this.playerReadyMessages = []
                }
                if (e.data.eventName === S && !this.isOpen && this.autoplay) {
                    this.isOpen = !0, this.widgetDelay || this.startAutoPlay();
                    return
                }
                e.data.name === "tolstoyShowWidget" && this.open()
            }
        })
    }
    subscribeForPreConfigMessaging() {
        window.addEventListener("message", e => {
            var t, s;
            if (this.verifyPostMessage(e) && e.data.name === I.ready) {
                this.preConfigMessagingReady = !0;
                for (const o of this.preConfigMessages || [])(s = (t = this.tolstoyIframe) == null ? void 0 : t.contentWindow) == null || s.postMessage(o, "*");
                this.preConfigMessages = []
            }
        })
    }
    subscribeForWidgetCloseWhenAnotherOpens() {
        window.addEventListener("message", e => {
            const {
                name: t,
                type: s,
                eventData: o
            } = e.data;
            t !== M || s !== u.OPEN || o.publishId !== this.publishId && (this.isEmbed || this.hide(!1))
        })
    }
    subscribeForVideoEvents() {
        window.addEventListener("message", e => {
            e.data && he(e)
        })
    }
    startAutoPlay() {
        this.openPlayerModal(), this.safePostMessageToIframe({
            name: "tolstoyAutoplay"
        })
    }
    handleMoveToUrl(e) {
        var o;
        const t = [window.location.toString()],
            s = (o = window.Shopify) == null ? void 0 : o.shop;
        if (s && t.push(`https://${s}${window.location.pathname}`), t.some(n => Z(n, e))) return window.history.pushState({
            publishId: this.publishId
        }, ""), this.hide();
        window.open(e, "_self", "noopener, noreferrer")
    }
    toggleFeedCloseButton({
        hideOnFullScreen: e,
        hideCloseButton: t
    }) {
        if (t && (this.isMobile || !this.isFullscreenFeed || e)) {
            this.feedXButton.classList.add(F, P);
            return
        }
        this.feedXButton.classList.remove(F, P)
    }
    focusCloseButton() {
        this.feedXButton.focus()
    }
    subscribeToFeedMessages() {
        window.addEventListener("message", e => {
            if (e.data.name === j && e.data.publishId === this.publishId) {
                this.focusCloseButton();
                return
            }
            if (this.feedXButton && (e.data.name === J || e.data.name === Q)) {
                const {
                    isOpen: s
                } = e.data;
                this.toggleFeedCloseButton({
                    hideCloseButton: s
                })
            }[q, ee].includes(e.data.name) && this.publishId === e.data.publishId && this.hide(), e.data.name === te && this.handleMoveToUrl(e.data.url)
        })
    }
    delayedShow() {
        this.playerLazy || this.safePostMessageToIframe({
            name: "tolstoyWidgetShown"
        }), this.autoplay && this.startAutoPlay()
    }
    popHistoryOnFeedClose() {
        var e;
        ((e = window.history.state) == null ? void 0 : e.publishId) === this.publishId && (!this.isFullscreenFeed && !this.isMobile || window.history.back())
    }
    hide(e = !0) {
        var s;
        if (!this.isOpen) return;
        if (this.modal.ariaHidden = "true", this.modal.style.setProperty("display", "none", "important"), this.mainContainer.style.setProperty("display", "none", "important"), window.removeEventListener("keydown", this.onTabKey), this.isOpen = !1, this.lastFocusedElement && typeof this.lastFocusedElement.focus == "function" && setTimeout(() => {
                this.lastFocusedElement.focus(), this.lastFocusedElement = null
            }, 100), e) {
            const o = se(this.publishId);
            this.postMessageToWindow(u.CLOSE, {
                publishId: this.publishId,
                showPreviouslyHiddenBubblePreview: !this.isEmbed,
                hideBubbleFromEmailCampaign: o && !this.minimizeOnClose,
                showBubbleFromEmailCampaign: o && this.minimizeOnClose
            })
        }
        this.safePostMessageToIframe({
            name: T.tolstoyModalClose
        });
        const t = ie();
        me({
            publishId: this.publishId,
            sessionId: t
        }) && (L({
            type: u.CLOSE,
            publishId: this.publishId
        }), oe()), this.safePostMessageToIframe({
            name: "tolstoyReset"
        }), document.body.classList.remove("tolstoy-widget-shown", v), (window.screen.width <= 450 || window.screen.height <= 450) && (window.removeEventListener("orientationchange", this.lockScreen), window.removeEventListener("touchmove", this.preventDefault)), window.postMessage({
            name: "tolstoyWidgetClose"
        }, "*"), (s = this.onWidgetClose) == null || s.call(this), this.isFeed && this.popHistoryOnFeedClose()
    }
    show() {
        this.isOpen || this.safePostMessageToIframe({
            name: "tolstoyReset"
        })
    }
    isPortrait() {
        var e, t;
        return ((t = (e = window.screen) == null ? void 0 : e.orientation) == null ? void 0 : t.type) === "portrait-primary" || window.orientation === 0
    }
    preventDefault(e) {
        e.stopPropagation(), e.preventDefault()
    }
    lockScreen() {
        if (this.modal.style.display !== "none") {
            if (this.isPortrait()) {
                this.mainContainer.addEventListener("touchmove", this.preventDefault, {
                    passive: !1
                });
                return
            }
            this.mainContainer.removeEventListener("touchmove", this.preventDefault)
        }
    }
    addBrowserBackButtonClickEventListener() {
        if (!this.isFullscreenFeed && !this.isMobile) return;
        const e = () => {
                this.hide(), window.removeEventListener("popstate", e)
            },
            t = () => {
                try {
                    return E(c({}, window.history.state), {
                        publishId: this.publishId
                    })
                } catch (s) {
                    return {
                        publishId: this.publishId
                    }
                }
            };
        window.addEventListener("popstate", e), window.history.pushState(t(), "")
    }
    onTabKey(e) {
        var t;
        e.key === "Tab" && (window.document.activeElement !== this.tolstoyIframe && ((t = this.tolstoyIframe) == null || t.focus()), e.stopPropagation(), e.preventDefault())
    }
    hidePreviewElement() {
        this.modalWrapperElement.firstChild.style.visibility = "hidden"
    }
    getShouldHideBodyScrollBar() {
        return this.isEmbed ? !1 : this.isMobile ? !0 : this.isFeed && this.isFullscreenFeed
    }
    open(e) {
        var s;
        this.modal.ariaHidden = "false", this.isFeed ? (this.initialPartNumber = e, this.sendTolstoyPlayMessage(), this.openPlayerModal(), this.addBrowserBackButtonClickEventListener()) : (this.openPlayerModal(), this.initialPartNumber = e, this.sendTolstoyPlayMessage()), this.isEmbed && this.hidePreviewElement(), window.addEventListener("keydown", this.onTabKey), this.isOpen = !0, (s = this.onWidgetOpen) == null || s.call(this), window.postMessage({
            name: "tolstoyWidgetOpen"
        }, "*"), !this.isEmbed && (window.screen.width <= 450 || window.screen.height <= 450) && (this.lockScreen(), window.addEventListener("orientationchange", this.lockScreen)), this.getShouldHideBodyScrollBar() && document.body.classList.add("tolstoy-widget-shown", v), this.type === m.ON_YOU && this.analyticsHandler.handleOnYouClick()
    }
    remove() {
        this.isOpen = !1, this.modal.remove(), this.mainContainer.remove()
    }
    sendTolstoyPlayMessage() {
        typeof this.initialPartNumber == "number" ? this.safePostMessageToIframe({
            eventName: "tolstoyPlay",
            partNumber: this.initialPartNumber
        }) : this.safePostMessageToIframe({
            name: "tolstoyPlay"
        })
    }
    sendEmbedView(e = {}) {
        this.safePostMessageToIframe(c({
            name: "embedView"
        }, e))
    }
    sendPageView(e = {}) {
        this.safePostMessageToIframe(c({
            name: "pageView"
        }, e))
    }
    sendEvent(e, t = {}) {
        this.safePostMessageToIframe(c({
            name: e
        }, t))
    }
    sendAnalyticsData({
        appKey: e,
        id: t,
        owner: s,
        name: o,
        publishId: n,
        facebookAnalyticsID: i,
        googleAnalyticsID: d,
        playerLazy: r
    }) {
        if (!r) return;
        const h = {
            accountId: s,
            appKey: e,
            isMobile: this.isMobile,
            publishId: n,
            projectId: t,
            facebookAnalyticsID: i,
            googleAnalyticsID: d,
            playlist: o
        };
        this.safePostMessageToIframe({
            name: "analyticsData",
            params: h
        })
    }
    reCreateResolutions(e) {
        return w(this, null, function*() {
            ae(e) || (yield ne(e), le(e, "true"))
        })
    }
    loadFullPlayer() {
        this.safePostMessageToIframe({
            name: "tolstoyLoadFullPlayer"
        })
    }
    redirectToUrl({
        url: e
    }) {
        if (e === window.location.href) {
            this.hide();
            return
        }
        window.open(e, "_self", "noopener, noreferrer")
    }
    changeZIndex(e) {
        this.modal.style.setProperty("z-index", e.data.zIndex, "important"), e.data.timeout && setTimeout(() => {
            this.modal.style.removeProperty("z-index")
        }, e.data.timeout)
    }
    initInternalMessagingSubscriptions() {
        b.subscribeMultipleEvents({
            eventNames: Re,
            callback: this.internalMessagingHandler
        })
    }
}
export {
    ce as D, Ke as M, $e as T, Ge as W, m as a, ze as b, xe as c
};