var a = (o, i, e) => new Promise((p, n) => {
    var u = r => {
            try {
                s(e.next(r))
            } catch (t) {
                n(t)
            }
        },
        c = r => {
            try {
                s(e.throw(r))
            } catch (t) {
                n(t)
            }
        },
        s = r => r.done ? p(r.value) : Promise.resolve(r.value).then(u, c);
    s((e = e.apply(o, i)).next())
});
import "../widget.js";
const d = o => a(void 0, null, function*() {});
export {
    d as r
};