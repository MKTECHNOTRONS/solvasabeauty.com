const t = "widget-poster-settings";
export {
    t as F
};