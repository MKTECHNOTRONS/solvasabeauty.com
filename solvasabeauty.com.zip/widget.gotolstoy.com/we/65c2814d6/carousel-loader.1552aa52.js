var w = Object.defineProperty;
var C = (s, i, t) => i in s ? w(s, i, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: t
}) : s[i] = t;
var f = (s, i, t) => (C(s, typeof i != "symbol" ? i + "" : i, t), t);
var d = (s, i, t) => new Promise((o, h) => {
    var a = r => {
            try {
                n(t.next(r))
            } catch (u) {
                h(u)
            }
        },
        e = r => {
            try {
                n(t.throw(r))
            } catch (u) {
                h(u)
            }
        },
        n = r => r.done ? o(r.value) : Promise.resolve(r.value).then(a, e);
    n((t = t.apply(s, i)).next())
});
import {
    g as T,
    a as I,
    b as S,
    _ as c,
    c as P,
    d as b,
    C as L,
    l as _,
    e as m
} from "../widget.js";
const y = ({
    data: s
}) => {
    var i;
    return ((i = s == null ? void 0 : s.carouselEmbed) == null ? void 0 : i.carouselType) === m.SPOTLIGHT
};
class D {
    constructor() {
        f(this, "handleView", () => {
            if (this.carousel) return this.carousel.handleView()
        })
    }
    init(i) {
        return d(this, null, function*() {
            var n, r, u, g, p, E;
            const t = T(i),
                o = I(i),
                h = ((n = window.Shopify) == null ? void 0 : n.shop) || S(),
                a = ((g = (u = (r = i.dataset) == null ? void 0 : r.tags) == null ? void 0 : u.split(",")) == null ? void 0 : g.filter(Boolean)) || "";
            let e;
            if ((p = window.Shopify) != null && p.designMode) {
                const l = (yield c(() =>
                    import ("./carousel-skeleton.7a4a7034.js"), ["65c2814d6/carousel.7d7e32de.css"])).default;
                e = new l, e.init(i)
            }
            if (!t && !o && !(a != null && a.length)) {
                this.initialized = !1, e && e.init(i, {
                    carouselTitleEnabled: !0,
                    carouselTitleText: P("Invalid publishId")
                });
                return
            }
            try {
                const l = yield b({
                    publishId: t,
                    productId: o,
                    widgetType: L,
                    tags: a,
                    appUrl: h
                });
                if (!l || l.disabled) {
                    this.initialized = !1, i.innerHTML = "";
                    return
                }
                return this.initElements({
                    element: i,
                    data: l,
                    productId: o
                })
            } catch (l) {
                throw e && l.message && e.init(i, {
                    carouselTitleEnabled: !0,
                    carouselTitleText: ((E = l.additionalData) == null ? void 0 : E.element) || l.message
                }), _(l), this.initialized = !1, l
            }
        })
    }
    initElements({
        element: i,
        data: t,
        productId: o
    }) {
        return y({
            data: t
        }) ? this.initSpotlightElement({
            element: i,
            data: t,
            productId: o
        }) : this.initCarouselElement({
            element: i,
            data: t,
            productId: o
        })
    }
    initCarouselElement(h) {
        return d(this, arguments, function*({
            element: i,
            data: t,
            productId: o
        }) {
            const a = (yield c(() =>
                    import ("./carousel.1defa696.js"), ["65c2814d6/modal.eb93a2a4.css", "65c2814d6/carousel.7d7e32de.css"])).default,
                e = new a;
            e.initElements(i, t, o), this.initialized = !0, this.carousel = e
        })
    }
    initSpotlightElement(h) {
        return d(this, arguments, function*({
            element: i,
            data: t,
            productId: o
        }) {
            var a;
            try {
                const e = {
                        productId: o,
                        maxCarouselWidth: ((a = i == null ? void 0 : i.parentElement) == null ? void 0 : a.offsetWidth) || window.innerWidth
                    },
                    n = u => {
                        this.spotlightCarousel = u
                    },
                    r = (yield c(() =>
                        import ("./spotlight-carousel-controller.ddb736de.js"), ["65c2814d6/carousel.7d7e32de.css", "65c2814d6/spotlight-carousel-controller.3c9498c9.css"])).default;
                if (r({
                        config: t,
                        options: e
                    }, {
                        onSetSpotlightCarousel: n
                    }), !this.spotlightCarousel) return;
                i.innerHTML = this.spotlightCarousel.render().outerHTML, this.spotlightCarousel.onMount(), this.initialized = !0
            } catch (e) {
                _(e)
            }
        })
    }
    getIsInitialized() {
        return this.initialized
    }
    handlePageView() {
        if (this.spotlightCarousel) return this.spotlightCarousel.handlePageView();
        if (this.carousel) return this.carousel.handlePageView()
    }
}
export {
    D as
    default
};