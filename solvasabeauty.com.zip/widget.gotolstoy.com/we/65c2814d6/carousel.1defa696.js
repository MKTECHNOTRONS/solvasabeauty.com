var H = Object.defineProperty,
    F = Object.defineProperties;
var z = Object.getOwnPropertyDescriptors;
var S = Object.getOwnPropertySymbols;
var U = Object.prototype.hasOwnProperty,
    X = Object.prototype.propertyIsEnumerable;
var T = (h, t, e) => t in h ? H(h, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : h[t] = e,
    p = (h, t) => {
        for (var e in t || (t = {})) U.call(t, e) && T(h, e, t[e]);
        if (S)
            for (var e of S(t)) X.call(t, e) && T(h, e, t[e]);
        return h
    },
    V = (h, t) => F(h, z(t));
var v = (h, t, e) => new Promise((i, s) => {
    var n = r => {
            try {
                a(e.next(r))
            } catch (d) {
                s(d)
            }
        },
        l = r => {
            try {
                a(e.throw(r))
            } catch (d) {
                s(d)
            }
        },
        a = r => r.done ? i(r.value) : Promise.resolve(r.value).then(n, l);
    a((e = e.apply(h, t)).next())
});
import {
    a as P
} from "./assets.utils.6157eb1e.js";
import {
    bl as f,
    f as y,
    bn as b,
    bo as o,
    Q as C,
    bp as $,
    bq as I,
    br as G,
    R as L,
    T as A,
    bs as E,
    bt as N,
    ap as m,
    ae as w,
    bu as M,
    bv as q,
    bw as Q,
    bx as K,
    w as j,
    v as J,
    L as Y,
    bm as g,
    W,
    r as D,
    k as Z,
    g as tt,
    a as et,
    b as it,
    d as st,
    C as O,
    l as x,
    G as nt,
    H as ot,
    K as B,
    by as rt,
    a0 as _,
    $ as k
} from "../widget.js";
import {
    r as at
} from "./re-create-resolutions.0fd18212.js";
import {
    M as lt
} from "./modal.eb2bcf55.js";
import {
    d as dt,
    v as ht
} from "./carousel.svgs.2da59777.js";
import {
    g as R
} from "./carousel-html.f71a636e.js";
import "./recharge.cbcf93a4.js";
import "./color.e07a28b3.js";
import "./activity-event-helper.8640d488.js";
const ct = ({
        property: h,
        value: t
    }) => CSS != null && CSS.supports ? CSS.supports(h, t) : !1,
    ut = () => ct({
        property: "aspect-ratio",
        value: "9 / 16"
    });

function mt(h) {
    switch (h) {
        case "undefined":
            return;
        case "null":
            return null;
        case "true":
            return !0;
        case "false":
            return !1;
        default:
            return h
    }
}
class St {
    constructor() {
        this.start = this.start.bind(this), this.init = this.init.bind(this), this.onDrag = this.onDrag.bind(this), this.onDragStart = this.onDragStart.bind(this), this.onDragStop = this.onDragStop.bind(this), this.handlePageView = this.handlePageView.bind(this), this.handleView = this.handleView.bind(this), this.handleDynamicVideos = this.handleDynamicVideos.bind(this), this.onViewPortChange = this.onViewPortChange.bind(this), this.onVideoEnd = this.onVideoEnd.bind(this), this.stopDynamicVideos = this.stopDynamicVideos.bind(this), this.setIsDynamicVideoRunning = this.setIsDynamicVideoRunning.bind(this), this.modalMessageHandler = this.modalMessageHandler.bind(this), this.tilesNumber = 0, this.selectedDot = 0, this.scrollX = 0, this.timeout = null, this.dotsNumber = 0, this.isDynamicVideoRunning = !1, this.dynamicVideoIndex = 0, this.isPlayInTileFirst = !1, this.lastContainerClientWidthUsedInCalculation = null, this.isMuted = !1, this.isCreateResolutionCalled = !1, this.tileHeight = f
    }
    get isScrollAvailable() {
        return this.data.carouselEmbed.carouselSteps.length - this.tilesNumber > 0
    }
    getElement(t) {
        return window.document.querySelector(`[data-tolstoy-element="${y(t,this.data.publishId)}"]`)
    }
    getAllElements(t) {
        return window.document.querySelectorAll(`[data-tolstoy-element="${y(t,this.data.publishId)}"]`)
    }
    setTileWidthByVideosContainer(t) {
        const {
            carouselSpacingHorizontal: e = g,
            carouselItemSizeType: i = "responsive",
            carouselItemHeight: s = f
        } = this.data.carouselEmbed, n = this.data.carouselEmbed.carouselSteps.length;
        let l = this.tilesNumber;
        t.clientWidth <= 450 && n >= 2 && (l += .4);
        const a = t.clientWidth;
        this.lastContainerClientWidthUsedInCalculation = a;
        let r;
        i === "responsive" ? (r = (a + e) / l - e, this.tileHeight = r / b) : (this.tileHeight = s, r = s * b);
        const d = `${Math.max(r,rt)}px`;
        t.style.gridTemplateColumns = `repeat(${n}, ${d})`, t.style.justifyContent = this.isScrollAvailable ? "start" : "center", ut() || (t.style.height = `${this.tileHeight}px`)
    }
    setTileWidth() {
        const t = this.getAllElements(o.videosContainer);
        for (const e of t) this.setTileWidthByVideosContainer(e)
    }
    reinitVideos() {
        const t = this.getAllElements(o.video);
        for (const [e, i] of t.entries()) {
            if (!i.src) continue;
            const s = this.data.carouselEmbed.carouselSteps[e],
                n = C({
                    step: s,
                    height: this.tileHeight
                });
            if (i.src !== n) {
                if (e === this.dynamicVideoIndex) {
                    $(i, n);
                    continue
                }
                if (i.autoplay) {
                    i.src = "";
                    continue
                }
                i.src = n
            }
        }
    }
    getNumberOfTiles() {
        const {
            carouselItemSizeType: t = "responsive",
            carouselItemsPerRow: e = 5,
            carouselItemHeight: i = f,
            carouselSpacingHorizontal: s = g,
            carouselSteps: n
        } = this.data.carouselEmbed, l = this.getElement(o.videosContainer), a = l.clientWidth;
        this.lastContainerClientWidthUsedInCalculation = a;
        const r = this.getElement(o.videoContainer),
            d = r == null ? void 0 : r.clientWidth;
        if (!l) return;
        if (d && d > a) {
            this.tilesNumber = 1;
            return
        }
        const c = i * b,
            u = Math.floor((a + s) / (c + s));
        if (a <= 450 && u < (n == null ? void 0 : n.length)) {
            if (u < I) {
                this.tilesNumber = Math.max(u, 1);
                return
            }
            this.tilesNumber = I;
            return
        }
        if (t === "responsive") {
            this.tilesNumber = e;
            return
        }
        this.tilesNumber = Math.max(Math.min(u, G), I)
    }
    onVideoEnd() {
        if (this.data.loopFirstVideo) return this.handleDynamicVideos();
        const t = this.dynamicVideoIndex,
            e = this.data.carouselEmbed.carouselSteps.length;
        if (this.tilesNumber || this.getNumberOfTiles(), this.tilesNumber && t + 1 >= this.tilesNumber - 1 && t < e) {
            const s = this.getAllElements(o.video)[t];
            s == null || s.removeEventListener("ended", this.onVideoEnd), this.onDotClick(t + 2 - this.tilesNumber)
        }
        this.dynamicVideoIndex = P(this.data.carouselEmbed.carouselSteps, this.dynamicVideoIndex), this.handleDynamicVideos()
    }
    handleDynamicVideos() {
        const t = this.dynamicVideoIndex,
            e = this.getAllElements(o.video),
            i = e[t];
        if (!(e != null && e.length)) return;
        const s = n => {
            if (n.name !== _.abortError) {
                if (n.name !== _.notAllowedError) throw n;
                t === 0 && L() && this.modal.loadFullPlayer()
            }
        };
        if (!i) {
            this.dynamicVideoIndex = 0, this.onDotClick(0), this.handleDynamicVideos();
            return
        }
        if (i.removeEventListener("ended", this.onVideoEnd), !i.src) {
            const n = this.data.carouselEmbed.carouselSteps[t];
            if (i.src = C({
                    step: n,
                    height: this.tileHeight
                }), L()) {
                try {
                    i.autoplay = "true"
                } catch (l) {
                    s(l)
                }
                i.addEventListener("ended", this.onVideoEnd, {
                    once: !0
                });
                return
            }
            i.addEventListener("canplay", () => A({
                video: i,
                onError: s
            }), {
                once: !0
            })
        }
        A({
            video: i,
            onError: s
        }), i.addEventListener("ended", this.onVideoEnd, {
            once: !0
        })
    }
    handleHoverOverVideos() {
        const t = this.getAllElements(o.videoContainer);
        for (const e of t) e.addEventListener("mouseenter", i => {
            i.target.children[0].play(), i.target.children[0].loop = !0
        }), e.addEventListener("mouseleave", i => {
            i.target.children[0].loop = !1, i.target.children[0].pause(), i.target.children[0].currentTime = 0
        })
    }
    handleCarouselMotion(t) {
        this.isPlayInTileFirst || (t === E.dynamic && this.handleDynamicEvents(), t === E.hoverOver && this.handleHoverOverVideos())
    }
    initDots() {
        const t = this.data.carouselEmbed.carouselSteps.length - this.tilesNumber;
        this.dotsNumber = t ? t + 1 : 0
    }
    renderDots() {
        const t = this.data.carouselEmbed.carouselSteps.length - this.tilesNumber,
            e = this.getElement(o.dotsContainer);
        if (!e) return;
        if (!t) {
            e.innerHTML = "";
            return
        }
        let i = "";
        for (let s = 0; s <= t; s++) i += `<div
        role="button"
        tabindex="0"
        ${this.selectedDot===s?"style = 'opacity: 1'":""}
        class="${dt} ${o.dot}"
        data-tolstoy-element="${y(o.dot,this.data.publishId)}"
      ></div>`;
        e.innerHTML = i
    }
    addExpandButtonOnClick() {
        const t = this.getAllElements(o.expandButton);
        for (const [e, i] of t.entries()) i.getAttribute("hasClickEvent") || (i.addEventListener("click", s => {
            clearTimeout(this.timeout), s.stopPropagation(), N({
                videoClass: o.video,
                publishId: this.data.publishId
            }), this.sendInTileCarouselEvent({
                eventName: m.embedExpand
            }), this.start(e)
        }), i.setAttribute("hasClickEvent", "true"))
    }
    addMuteButtonOnClick() {
        var s, n, l;
        const t = (l = (n = (s = this.data.design) == null ? void 0 : s.player) == null ? void 0 : n.controls) == null ? void 0 : l.isFeedMuted,
            e = this.getAllElements(o.muteButton),
            i = Array.from(this.getAllElements(o.video).values());
        for (const a of e.values()) {
            const r = i.find(d => d.dataset.tolstoyVideoId === a.dataset.tolstoyVideoId);
            a.getAttribute("hasClickEvent") || (a.addEventListener("click", d => {
                d.stopPropagation(), this.isMuted ? this.sendInTileCarouselEvent({
                    eventName: m.embedUnmute
                }) : this.sendInTileCarouselEvent({
                    eventName: m.embedMute
                }), this.isMuted = !this.isMuted;
                const c = mt(r.dataset.tolstoyIsSoundAllowed);
                r.muted = this.isMuted || w(t, c);
                const u = this.getElement(o.videosContainer);
                u.dataset.carouselMuted = String(this.isMuted)
            }), a.setAttribute("hasClickEvent", "true"))
        }
    }
    handlePlayInTileEventListener(t, e) {
        const i = this.getAllElements(o.playButtonContainer)[e],
            s = this.getAllElements(o.controlsContainer)[e];
        if (t.getAttribute("isPlayingInTile")) {
            i.style.setProperty("display", "flex"), s.style.setProperty("display", "none"), t.removeAttribute("isPlayingInTile");
            return
        }
        i.style.setProperty("display", "none"), s.style.setProperty("display", "flex"), t.setAttribute("isPlayingInTile", !0)
    }
    sendInTileCarouselEvent({
        eventName: t,
        params: e = {}
    }) {
        this.modal.sendEvent(t, p({
            playerVariant: M
        }, e))
    }
    handlePlayInTileFirst(t, e) {
        var a, r, d;
        const i = (d = (r = (a = this.data.design) == null ? void 0 : a.player) == null ? void 0 : r.controls) == null ? void 0 : d.isFeedMuted,
            n = this.getAllElements(o.video)[t],
            l = this.data.carouselEmbed.carouselSteps[t];
        if (n.src || (n.src = C({
                step: l,
                isPlayInTileFirst: !0,
                height: this.tileHeight
            }), n.addEventListener("canplay", n.play, {
                once: !0
            }), n.addEventListener("play", () => this.handlePlayInTileEventListener(e, t)), n.addEventListener("pause", () => this.handlePlayInTileEventListener(e, t))), e.getAttribute("isPlayingInTile")) return this.sendInTileCarouselEvent({
            eventName: m.embedPause
        }), n.pause();
        this.sendInTileCarouselEvent({
            eventName: m.embedPlay
        }), N({
            videoClass: o.video,
            publishId: this.data.publishId
        }), n.muted = this.isMuted || w(i, l.isSoundAllowed), n.play()
    }
    addOnVideoClickEvents() {
        const t = this.getAllElements(o.videoContainer);
        for (const [e, i] of t.entries()) i.getAttribute("hasClickEvent") || (i == null || i.addEventListener("keypress", s => {
            (s.code === "Space" || s.code === "Enter") && this.start(e)
        }), i.addEventListener("click", () => {
            if (clearTimeout(this.timeout), this.isPlayInTileFirst) return this.handlePlayInTileFirst(e, i);
            this.start(e)
        }), i.setAttribute("hasClickEvent", "true"), i.setAttribute("tabindex", "0"), i.setAttribute("role", "button"))
    }
    addOnDotClickEvent() {
        const t = this.getAllElements(o.dot);
        for (const e of this.removeDotEventListenerArray || []) e();
        this.removeDotEventListenerArray = [];
        for (const [e, i] of t.entries()) {
            const s = () => this.onDotClick(e);
            i.addEventListener("click", s), this.removeDotEventListenerArray = [...this.removeDotEventListenerArray, () => i.removeEventListener("click", s)]
        }
    }
    getPreviousNextDisplaySettings() {
        return window.innerWidth <= 450 ? "none" : this.isScrollAvailable ? "flex" : "none"
    }
    addPreviousNextElements() {
        const t = this.getElement(o.previousButton),
            e = this.getElement(o.nextButton),
            i = this.getPreviousNextDisplaySettings();
        t.style.display = i, e.style.display = i
    }
    paintSelectedDot(t) {
        const e = this.getAllElements(o.dot);
        for (const [i, s] of e.entries()) {
            if (i === t) {
                s.style.opacity = 1;
                continue
            }
            s.style.opacity = q
        }
    }
    onDotClick(t) {
        const e = this.getElement(o.videosContainer);
        if (!e) return;
        this.paintSelectedDot(t), this.selectedDot = t;
        let i = this.getVideoWidth() * t;
        t === 0 && (i = 0), e.scrollTo({
            left: i,
            behavior: "smooth"
        }), this.scrollX = i
    }
    scrollIntoTile(t) {
        const e = this.getElement(o.videosContainer);
        if (!e) return;
        const i = this.getVideoWidth() * t;
        e.scrollTo({
            left: i,
            behavior: "smooth"
        }), this.scrollX = i
    }
    initTiles() {
        this.getElement(o.videosContainer) && (this.getNumberOfTiles(), this.setTileWidth(), this.reinitVideos(), this.initDots(), this.addPreviousNextElements(), Q({
            config: this.data,
            featureKey: K
        }) && (this.renderDots(), this.addOnDotClickEvent()))
    }
    setSizeOfElements() {
        const t = this.getElement(o.carouselContainer);
        t && (t.style.maxWidth = `${window.innerWidth}px`)
    }
    addScreenListeners() {
        if (!("ResizeObserver" in window)) return;
        const t = this.getElement(o.videosContainer);
        if (!t) return;
        let e = 0;
        const i = new window.ResizeObserver(s => {
            (t == null ? void 0 : t.clientWidth) !== this.lastContainerClientWidthUsedInCalculation && (this.lastContainerClientWidthUsedInCalculation = t.clientWidth, e >= 10 && i.disconnect(), window.requestAnimationFrame(() => {
                !Array.isArray(s) || s.length === 0 || (this.setSizeOfElements(), this.initTiles(), this.onDotClick(0), e++)
            }))
        });
        i.observe(t)
    }
    addPreviousNextEvents() {
        const t = this.getElement(o.previousButton);
        this.getElement(o.nextButton).addEventListener("click", () => {
            if (this.selectedDot + 1 > this.dotsNumber - 1) {
                this.onDotClick(0);
                return
            }
            this.onDotClick(this.selectedDot + 1)
        }), t.addEventListener("click", () => {
            if (this.selectedDot - 1 < 0) {
                this.onDotClick(this.dotsNumber - 1);
                return
            }
            this.onDotClick(this.selectedDot - 1)
        })
    }
    changeVideoPointerEvents(t) {
        const e = this.getAllElements(o.videoContainer);
        for (const i of e) i.style.pointerEvents = t
    }
    onDragStart(t) {
        this.timeout = setTimeout(() => {
            this.startDragLocation = t.pageX || t.changedTouches[0].clientX, this.isDragging = !0, this.changeVideoPointerEvents("none")
        }, 200)
    }
    getVideoWidth() {
        const {
            carouselSpacingHorizontal: t = g
        } = this.data.carouselEmbed;
        return this.getElement(o.videoContainer).getBoundingClientRect().width + t
    }
    getCurrentScrolledTileIndex(t) {
        const e = this.getVideoWidth();
        if (!e) return 0;
        const i = t / e;
        return Math.round(i)
    }
    paintScrollDots(t) {
        const e = this.getVideoWidth();
        let i = Math.round(t / e);
        return i < 0 && (i = 0), i >= this.dotsNumber && (i = this.dotsNumber - 1), this.selectedDot = i, this.paintSelectedDot(i), i
    }
    onDragStop() {
        if (this.changeVideoPointerEvents("all"), !this.isDragging) {
            clearTimeout(this.timeout);
            return
        }
        if (this.isDragging = !1, this.scrollX = this.draggedX, !this.dotsNumber) {
            const i = this.getCurrentScrolledTileIndex(this.draggedX);
            this.scrollIntoTile(i);
            return
        }
        const e = this.paintScrollDots(this.draggedX);
        window.innerWidth > 450 && this.onDotClick(e)
    }
    onDrag(t) {
        if (t.preventDefault(), !this.isDragging) return;
        const e = this.getElement(o.videosContainer),
            i = t.pageX || t.changedTouches[0].clientX;
        let s = this.scrollX + (this.startDragLocation - i);
        s > e.scrollWidth - e.offsetWidth && (s = e.scrollWidth - e.offsetWidth), s < 0 && (s = 0), this.draggedX = s, e.scrollTo({
            left: s
        })
    }
    addSlider() {
        const t = this.getElement(o.videosContainer);
        t.addEventListener("mousedown", this.onDragStart), t.addEventListener("mousemove", this.onDrag), t.addEventListener("mouseleave", this.onDragStop), t.addEventListener("mouseup", this.onDragStop), t.addEventListener("scroll", e => {
            this.isDragging || (this.scrollX = e.target.scrollLeft, this.paintScrollDots(e.target.scrollLeft))
        })
    }
    stopDynamicVideos() {
        j({
            videoClass: o.video,
            onVideoEnd: this.onVideoEnd,
            publishId: this.data.publishId,
            setIsDynamicVideoRunning: this.setIsDynamicVideoRunning
        })
    }
    handleOpenEvent(t) {
        var e;
        (e = t.eventData) != null && e.stopDynamicEmbed && this.stopDynamicVideos()
    }
    setIsDynamicVideoRunning(t) {
        this.isDynamicVideoRunning = t
    }
    onViewPortChange() {
        J({
            videoClass: o.video,
            isDynamicVideoRunning: this.isDynamicVideoRunning,
            setIsDynamicVideoRunning: this.setIsDynamicVideoRunning,
            dynamicVideoHandler: this.handleDynamicVideos,
            publishId: this.data.publishId,
            onVideoEnd: this.onVideoEnd
        })
    }
    modalMessageHandler({
        data: t
    }) {
        if (t.name !== Y) return;
        const i = {
            [k.OPEN]: s => this.handleOpenEvent(s),
            [k.CLOSE]: s => this.onViewPortChange(s)
        }[t.type];
        i == null || i(t)
    }
    handleDynamicEvents() {
        this.onViewPortChange(), window.addEventListener("load", this.onViewPortChange), window.addEventListener("scroll", this.onViewPortChange), window.addEventListener("message", this.modalMessageHandler)
    }
    initSkeleton({
        element: t,
        data: e
    }) {
        const s = {
            carouselEmbed: V(p({
                carouselSteps: [{}, {}, {}, {}, {}],
                carouselBorderColor: null,
                carouselBorderWidth: null,
                carouselBorder: null,
                carouselSpacingHorizontal: g,
                carouselPlayButtonOpacity: .1,
                carouselBorderRadius: 8,
                carouselTitleEnabled: !1,
                skeleton: !0,
                carouselShape: "9/16"
            }, e), {
                carouselMotion: "static"
            }),
            publishId: "skeleton"
        };
        this.data = s, t.innerHTML = R(s), this.addPreviousNextElements(), this.addScreenListeners()
    }
    overrideDataByQueryParam(t) {
        const e = new URLSearchParams(window.location.search);
        e.get("tolstoyCarouselMotion") === E.dynamic && (t.carouselEmbed.carouselMotion = E.dynamic), e.get("tolstoyLoadAll") && (t.carouselEmbed.loadAll = !0);
        const i = Math.min(t.carouselEmbed.carouselSteps.length, Number(e.get("tolstoyNumVideos")));
        e.get("tolstoyNumVideos") && (t.carouselEmbed.carouselSteps = t.carouselEmbed.carouselSteps.slice(0, i))
    }
    addOnErrorEventToVideos() {
        const {
            publishId: t
        } = this.data, e = document.querySelectorAll(`.${o.video}`);
        for (const i of e) i.addEventListener("error", s => v(this, null, function*() {
            s.type === "error" && s.target.error === null && (i.poster.includes(W) ? i.poster = i.poster.replace(W, D) : i.poster.includes(D) && (i.poster = i.poster.replace(D, Z)), t && !this.isCreateResolutionCalled && (yield at(), this.isCreateResolutionCalled = !0))
        }))
    }
    init(t) {
        return v(this, null, function*() {
            var l, a, r, d;
            const e = tt(t),
                i = et(t),
                s = ((l = window.Shopify) == null ? void 0 : l.shop) || it(),
                n = ((d = (r = (a = t.dataset) == null ? void 0 : a.tags) == null ? void 0 : r.split(",")) == null ? void 0 : d.filter(Boolean)) || "";
            if (!e && !i && !(n != null && n.length)) {
                this.initialized = !1;
                return
            }
            try {
                const c = yield st({
                    publishId: e,
                    productId: i,
                    widgetType: O,
                    tags: n,
                    appUrl: s
                });
                if (!c || c.disabled) {
                    this.initialized = !1, t.innerHTML = "";
                    return
                }
                this.initElements(t, c, i)
            } catch (c) {
                throw x(c), this.initialized = !1, c
            }
        })
    }
    initElements(t, e, i) {
        var s, n, l, a;
        try {
            const r = e.carouselEmbed;
            this.overrideDataByQueryParam(e), this.isPlayInTileFirst = r.carouselPlayInTileFirst, e.playerType = O, e.productId = i, e.loopFirstVideo = ((s = t == null ? void 0 : t.dataset) == null ? void 0 : s.loopFirstVideo) === "true", nt(e) && (e.playerLazy = !0), this.data = e, (a = (l = (n = this.data.design) == null ? void 0 : n.player) == null ? void 0 : l.controls) != null && a.isFeedMuted && (this.isMuted = !0), t.innerHTML = R(e), this.dynamicVideoIndex = P(this.data.carouselEmbed.carouselSteps), window.location.origin !== {}.VITE_BASE_URL && (this.modal = new lt(this.data)), this.initTiles(), this.handleCarouselMotion(r.carouselMotion), this.addScreenListeners(), this.addOnVideoClickEvents(r.carouselPlayInTileFirst), this.addPreviousNextEvents(), this.addSlider(), ot(this.data), this.addOnErrorEventToVideos(), B(e.publishId, !1), this.isPlayInTileFirst && (this.addExpandButtonOnClick(), this.addMuteButtonOnClick()), window != null && window.safari && this.getElement(o.videosContainer).classList.remove(ht), this.initialized = !0
        } catch (r) {
            x(r), this.initialized = !1
        }
    }
    getIsInitialized() {
        return this.initialized
    }
    start(t) {
        var e;
        (e = this.modal) == null || e.open(t)
    }
    getEventParams() {
        const t = {
            currentPageProductId: this.data.productId
        };
        return this.isPlayInTileFirst && (t.playerVariant = M), t
    }
    handlePageView() {
        this.data.playerLazy && this.modal.sendPageView(this.getEventParams())
    }
    handleView() {
        B(this.data.publishId, !0), this.modal.sendEmbedView(this.getEventParams())
    }
}
export {
    St as
    default
};