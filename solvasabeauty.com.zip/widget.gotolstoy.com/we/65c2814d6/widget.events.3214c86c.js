import {
    ar as n,
    be as i,
    a$ as r,
    bf as d,
    bg as l,
    bh as c,
    bi as m,
    bj as y,
    bk as h
} from "../widget.js";
let e = !1;
const p = () => {
        window.addEventListener("message", t => {
            t.data && (n(t), i(t), r(t), d(t), l(t))
        })
    },
    u = () => {
        const t = new URLSearchParams(window.location.search),
            a = t.get("tolstoy-reply"),
            o = t.get("tolstoy-product-recommendation"),
            s = t.get("tolstoy-app-key");
        o && (c(), m(s)), a && (y(a), h(a)), e = !0
    },
    g = () => {
        e || (p(), u())
    };
export {
    g as initializeWidgetEvents
};