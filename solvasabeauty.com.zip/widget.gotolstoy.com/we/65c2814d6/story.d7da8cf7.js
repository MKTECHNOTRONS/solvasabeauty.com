var pt = Object.defineProperty,
    ft = Object.defineProperties;
var St = Object.getOwnPropertyDescriptors;
var U = Object.getOwnPropertySymbols;
var Tt = Object.prototype.hasOwnProperty,
    bt = Object.prototype.propertyIsEnumerable;
var W = (n, t, e) => t in n ? pt(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : n[t] = e,
    V = (n, t) => {
        for (var e in t || (t = {})) Tt.call(t, e) && W(n, e, t[e]);
        if (U)
            for (var e of U(t)) bt.call(t, e) && W(n, e, t[e]);
        return n
    },
    x = (n, t) => ft(n, St(t));
var D = (n, t, e) => (W(n, typeof t != "symbol" ? t + "" : t, e), e);
var N = (n, t, e) => new Promise((s, i) => {
    var o = a => {
            try {
                d(e.next(a))
            } catch (h) {
                i(h)
            }
        },
        l = a => {
            try {
                d(e.throw(a))
            } catch (h) {
                i(h)
            }
        },
        d = a => a.done ? s(a.value) : Promise.resolve(a.value).then(o, l);
    d((e = e.apply(n, t)).next())
});
import {
    i as It,
    g as vt,
    a as X
} from "./assets.utils.6157eb1e.js";
import {
    I as at,
    P as r,
    f as p,
    h as q,
    i as lt,
    D as $,
    j as A,
    E as G,
    W as w,
    J as O,
    k as z,
    S as R,
    m as _t,
    n as Ct,
    o as Ot,
    F as Bt,
    p as Vt,
    q as j,
    r as xt,
    s as Z,
    t as $t,
    u as wt,
    v as Pt,
    w as At,
    l as k,
    x as Mt,
    g as Nt,
    a as Lt,
    b as Rt,
    c as Wt,
    d as Dt,
    y as K,
    z as kt,
    A as Ht,
    B as Yt,
    G as zt,
    H as Ft,
    K as J,
    L as qt,
    M as Gt,
    N as Ut,
    O as Xt,
    Q as jt,
    R as Q,
    T as tt,
    U as Zt,
    V as et,
    X as Kt,
    Y as st,
    Z as Jt,
    $ as it,
    a0 as nt
} from "../widget.js";
import {
    r as ot
} from "./re-create-resolutions.0fd18212.js";
import {
    M as H,
    a as rt
} from "./modal.eb2bcf55.js";
import {
    g as Qt
} from "./color.e07a28b3.js";
import "./recharge.cbcf93a4.js";
import "./activity-event-helper.8640d488.js";
const L = {
        visible: "visible",
        hidden: "hidden"
    },
    te = [at.urlChange],
    ee = "synthesia",
    se = "vimeo",
    ie = [ee, se],
    ne = "_stories_1v61q_1",
    oe = "_storiesContainer_1v61q_7",
    re = "_storiesVideoContainer_1v61q_12",
    ae = "_tilesContainer_1v61q_19",
    le = "_playButtonContainer_1v61q_32",
    de = "_playButtonContainerStatic_1v61q_50",
    F = "_storyTile_1v61q_59",
    ce = "_storyVideoImage_1v61q_63",
    dt = "_storyVideo_1v61q_63",
    ue = "_textOverlayContainer_1v61q_85",
    he = "_textOverlay_1v61q_85",
    ye = "_storySkeletonTile_1v61q_119";
const me = "_skeletonContent_1v61q_133",
    Ee = "_storyImage_1v61q_153",
    ge = "_storyName_1v61q_163",
    ct = "_arrowButtonContainer_1v61q_170",
    pe = "_nextArrowButtonContainer_1v61q_211";
const ut = "56bfe6cb-0926-420a-ac48-4d36a3a2ea07",
    fe = ({
        storiesBorderRadius: n,
        storiesBorderEnabled: t,
        storiesBorderWidth: e,
        storiesBorderColor: s,
        storiesBorderType: i,
        storiesBorderOpacity: o
    }, {
        tileSize: l = $
    }) => {
        const a = `border-radius: ${n*(l/$)}px;`;
        if (!t) return a;
        const h = Qt(s, o);
        return `
		${a}
		border: ${e}px ${i} ${h};
    padding: 2px;
	`
    },
    Se = ({
        storiesStoryNameEnabled: n,
        storiesStoryNameFontSize: t,
        storiesStoryNameColor: e
    }) => n ? `
		font-size: ${t}px;
		color: ${e};
	` : "display: none;",
    ht = ({
        storiesRectangleWidth: n,
        storiesRectangleHeight: t,
        isCircle: e,
        isResponsive: s
    }) => e ? "1" : s ? "9/16" : `${n}/${t}`,
    Te = ({
        storiesAlignment: n
    }) => {
        switch (n) {
            case "left":
                return "justify-content: flex-start; justify-items: flex-start";
            case "right":
                return "justify-content: flex-end; justify-items: flex-end";
            case "center":
                return "justify-content: center; justify-items: center";
            default:
                return "justify-content: flex-start; justify-items: flex-start;"
        }
    },
    be = ({
        storiesItemsSizeType: n,
        storiesItemsSpacing: t
    }, {
        numberOfTiles: e,
        tileSize: s
    }, i) => {
        if (!n) return 8;
        if (n === R.fixed) return t;
        const o = e * s,
            l = (e - 1) * t;
        return o + l <= i ? t : i / e - s
    },
    Ie = (n, t, e) => `gap: ${be(n,t,e)}px;`,
    ve = ({
        imageUrl: n,
        key: t,
        borderCss: e,
        publishId: s,
        storiesCircleSize: i,
        partName: o,
        stepIndex: l,
        storiesRectangleWidth: d,
        storiesRectangleHeight: a,
        isCircle: h,
        isResponsive: c
    }) => {
        const u = [Ee, r.storyImage],
            m = {
                alt: o || `Story video ${l+1} preview`,
                "aria-label": `Tolstoy story preview: ${o}`,
                "data-tolstoy-element": `${p(r.storyImage,s)}_${t}`,
                loading: "lazy"
            },
            E = yt({
                storiesCircleSize: i,
                isCircle: h,
                isResponsive: c,
                storiesRectangleWidth: d,
                storiesRectangleHeight: a
            });

        function f(b) {
            const g = b.currentTarget;
            g.src.includes(w) ? g.src = g.src.replace(w, O) : g.src.includes(O) && (g.src = g.src.replace(O, z))
        }
        return A({
            tagName: "img",
            classNames: u,
            attributes: m,
            styleString: e,
            style: E,
            src: n,
            eventListeners: {
                error: f
            }
        }).outerHTML
    },
    yt = ({
        storiesCircleSize: n,
        isCircle: t,
        isResponsive: e,
        storiesRectangleWidth: s,
        storiesRectangleHeight: i
    }) => t ? {
        height: `${n}px`,
        width: `${n}px`
    } : e ? {
        "aspect-ratio": "9/16",
        height: "100%"
    } : {
        width: `${s}px`,
        height: `${i}px`,
        "aspect-ratio": `${s}/${i}`
    },
    _e = ({
        videoUrl: n,
        posterUrl: t,
        borderCss: e,
        publishId: s,
        storiesCircleSize: i,
        partName: o,
        isCircle: l,
        isResponsive: d,
        storiesRectangleWidth: a,
        storiesRectangleHeight: h
    }) => {
        const c = [dt, r.storyVideo],
            u = {
                playsinline: "",
                muted: "",
                "aria-hidden": !0,
                poster: t,
                "aria-label": `Tolstoy story video: ${o}`,
                "data-tolstoy-element": p(r.storyVideo, s)
            },
            m = yt({
                storiesCircleSize: i,
                isCircle: l,
                isResponsive: d,
                storiesRectangleWidth: a,
                storiesRectangleHeight: h
            });
        return A({
            tagName: "video",
            src: n,
            classNames: c,
            attributes: u,
            styleString: e,
            style: m
        }).outerHTML
    },
    mt = ({
        storiesEmbed: n,
        publishId: t,
        className: e = ""
    }) => {
        const {
            storiesPlayButtonSizePercent: s,
            storiesPlayButtonColor: i,
            storiesPlayButtonOpacity: o,
            storiesPlayButtonBackground: l,
            storiesPlayButtonBackgroundColor: d,
            storiesPlayButtonBorder: a,
            storiesPlayButtonBorderColor: h
        } = n, c = `
    width: ${s}%;
    opacity: ${o};
    background: ${l?d:"transparent"};
    border: ${a?2:0}px solid ${h};
  `, u = _t(i);
        return `
    <div
      aria-label="Open Tolstoy widget"
      class="${le} ${r.playButtonContainer} ${e}"
      data-tolstoy-element="${p(r.playButtonContainer,t)}"
      style="${c}"
    >
      ${u}
    </div>
  `
    },
    Ce = n => `<button
    class="${ct} ${r.previousButton}"
    data-tolstoy-element="${p(r.previousButton,n)}"
    data-visibility="hidden"
    aria-label="Tolstoy stories: previous button"
    type="button"
    style="left: 0;${q()===ut?"display: flex !important;":""}"
  >
    ${lt}
  </button>`,
    Oe = n => `<button
    class="${`${ct} ${pe} ${r.nextButton}`}"
    data-tolstoy-element="${p(r.nextButton,n)}"
    aria-label="Tolstoy stories: next button"
    type="button"
    style="right: 0;${q()===ut?"display: flex !important;":""}"
  >
    ${lt}
</button>`,
    Be = ({
        storyNameHtml: n,
        publishId: t,
        key: e,
        videoHtml: s,
        maxWidth: i,
        ariaLabel: o,
        storiesRectangleWidth: l,
        storiesRectangleHeight: d,
        isCircle: a,
        isResponsive: h,
        storiesEmbed: c
    }) => {
        const u = [F, r.storyTile],
            m = {
                tabindex: 0,
                "aria-label": `Open ${o}`,
                "data-tolstoy-element": `${p(r.storyTile,t)}_${e}`,
                role: "button"
            },
            E = {
                "max-width": i,
                "aspect-ratio": ht({
                    isCircle: a,
                    isResponsive: h,
                    storiesRectangleWidth: l,
                    storiesRectangleHeight: d
                })
            },
            T = A({
                tagName: "div",
                classNames: u,
                attributes: m,
                style: {
                    "max-width": i
                }
            }),
            b = A({
                tagName: "div",
                classNames: [ce],
                style: E
            });
        b.innerHTML = s;
        const g = A({
                tagName: "div",
                classNames: [dt],
                styleString: "background:transparent;display:flex;width:100%;height:100%;",
                style: E
            }),
            S = s && c.storiesPlayButtonEnabled ? mt({
                storiesEmbed: c,
                publishId: t
            }) : "";
        return T.innerHTML = b.outerHTML + S + n + g.outerHTML, T.outerHTML
    },
    Ve = (n, t, e, s) => !s && !n ? e : t,
    xe = ({
        imageHtml: n,
        storyNameHtml: t,
        publishId: e,
        key: s,
        skeleton: i,
        videoHtml: o,
        storiesMotion: l,
        storiesCircleSize: d,
        partName: a,
        storiesRectangleWidth: h,
        storiesRectangleHeight: c,
        isCircle: u,
        isResponsive: m,
        storiesEmbed: E
    }) => {
        const f = `${a||"Story video"}`,
            T = `${Ve(u,d,h,m)}px`;
        if (i) return `
		<div class="${F} ${r.storyTile} ${ye}"
			data-tolstoy-element="${p(r.storyTile,e)}_${s}"
			style="max-width: ${T};"
		aria-label="Tolstoy stories skeleton"
		>
		<div class="${me}"></div>
		</div>
	`;
        if (!l || l === G.dynamic) return Be({
            storyNameHtml: t,
            publishId: e,
            key: s,
            videoHtml: o,
            storiesCircleSize: d,
            ariaLabel: f,
            maxWidth: T,
            storiesRectangleWidth: h,
            storiesRectangleHeight: c,
            isCircle: u,
            isResponsive: m,
            storiesEmbed: E
        });
        const b = [F, r.storyTile],
            g = {
                tabindex: 0,
                "aria-label": `Open ${f}`,
                "data-tolstoy-element": `${p(r.storyTile,e)}_${s}`,
                role: "button"
            },
            S = {
                "max-width": `${T}`,
                "aspect-ratio": ht({
                    isCircle: u,
                    isResponsive: m,
                    storiesRectangleWidth: h,
                    storiesRectangleHeight: c
                })
            },
            I = A({
                tagName: "div",
                classNames: b,
                attributes: g,
                style: S
            }),
            v = o && E.storiesPlayButtonEnabled ? mt({
                storiesEmbed: E,
                publishId: e,
                className: de
            }) : "";
        return I.innerHTML = n + v + t, I.outerHTML
    };
let Et = !1;
const gt = n => {
        Et && (n.style.fontFamily = `'tolstoy-custom-font-family', ${Bt}`)
    },
    $e = ({
        avatarUrl: n,
        posterUrl: t
    }) => n || (ie.some(e => t.includes(e)) ? t : t.replace($t, wt)),
    we = ({
        posterUrl: n,
        avatarUrl: t,
        extension: e,
        isDuplicated: s
    }) => (n == null ? void 0 : n.endsWith(e)) || (t == null ? void 0 : t.endsWith(e)) || s,
    Pe = ({
        storiesTitleEnabled: n,
        storiesTitleText: t,
        storiesTitleFontSize: e,
        storiesMobileTitleFontSize: s,
        storiesTitleFontWeight: i,
        storiesTitleColor: o,
        storiesAlignment: l
    }, d) => {
        if (!n || !t) return "";
        const a = typeof t == "string" ? t : t.textContent,
            h = window.innerWidth < 450 ? s : e,
            c = document.createElement("div");
        return c.classList.add(r.titleContainer), c.tolstoyElement = p(r.titleContainer, d), c.style.textAlign = l, c.style.fontSize = `${h}px`, c.style.fontWeight = i, c.style.color = o, c.setAttribute("role", "heading"), c.setAttribute("aria-level", "2"), c.setAttribute("aria-label", `Tolstoy stories title: ${a.replace(/\s+/g," ")}`), c.append(t), gt(c), c.outerHTML
    },
    Ae = ({
        storyNameCss: n,
        partName: t,
        key: e,
        publishId: s,
        isTextOverlay: i,
        storiesEmbed: {
            storiesBorderRadius: o,
            storiesStoryNameTextAlign: l,
            storiesStoryNameAlignment: d,
            storiesStoryNamePadding: a,
            storiesStoryNameFontWeight: h
        },
        storiesCircleSize: c
    }) => {
        const u = document.createElement("div"),
            m = document.createElement("div");
        u.classList.add(ge, r.tileName), u.dataset.tolstoyElement = `${p(r.storyName,s)}_${e}`, m.style = n, m.style.fontWeight = h, m.setAttribute("aria-label", t), m.append(t), gt(u), i && (u.classList.add(ue), m.classList.add(he), u.style.textAlign = l, u.style.justifyContent = l, u.style.alignItems = d, u.style.padding = `${a!=null?a:"8px"}`);
        const E = o * (c / $);
        return i && (u.style.borderRadius = `${E}px`), u.append(m), u.outerHTML
    },
    Me = (n, t, e, s) => {
        let i = "";
        const o = [...n.storiesSteps],
            {
                skeleton: l,
                storiesMotion: d
            } = n,
            {
                tileSize: a = $,
                storiesRectangleWidth: h,
                storiesRectangleHeight: c,
                isCircle: u,
                isResponsive: m,
                isTextOverlay: E
            } = e,
            f = fe(n, e),
            T = Se(n),
            b = s == null ? void 0 : s["widget-poster-settings"];
        let g = 0;
        for (const S of o) {
            const {
                partName: I,
                key: v
            } = S, y = It(S), M = y ? "" : Ct({
                step: S,
                embedMotion: G.dynamic,
                isStory: !0
            }), _ = y ? vt(S, {
                size: Vt.XS
            }) : Ot({
                step: S,
                extension: a >= j ? xt : w,
                posterSettings: b,
                size: a >= j ? Z["480x480"] : Z["250x250"],
                custom: {
                    condition: we,
                    callback: $e
                }
            }), P = _e({
                videoUrl: M,
                posterUrl: _,
                key: v,
                borderCss: f,
                publishId: t,
                storiesCircleSize: a,
                partName: I,
                storiesRectangleWidth: h,
                storiesRectangleHeight: c,
                isCircle: u,
                isResponsive: m,
                step: S
            }), C = ve({
                imageUrl: _,
                key: v,
                borderCss: f,
                publishId: t,
                storiesCircleSize: a,
                partName: I,
                stepIndex: g,
                storiesRectangleWidth: h,
                storiesRectangleHeight: c,
                isCircle: u,
                isResponsive: m
            }), B = Ae({
                partName: I,
                key: v,
                storyNameCss: T,
                publishId: t,
                isTextOverlay: E,
                storiesEmbed: n,
                storiesCircleSize: a
            });
            i += xe({
                imageHtml: C,
                storyNameHtml: B,
                publishId: t,
                key: v,
                skeleton: l,
                videoHtml: P,
                storiesMotion: d,
                storiesCircleSize: a,
                partName: I,
                storiesRectangleWidth: h,
                storiesRectangleHeight: c,
                isCircle: u,
                isResponsive: m,
                storiesEmbed: n
            }), g++
        }
        return i
    },
    Ne = ({
        storiesAlignment: n
    }, t, e) => `
    <a
      style="
        text-align: ${n||"left"};
        text-decoration: underline;
        cursor: pointer;
      "
      data-tolstoy-element="${p(e,t)}"
      aria-label="See it on you"
    >
      See it on you
    </a>
  `,
    Y = ({
        storiesEmbed: n,
        publishId: t,
        design: e,
        featureSettings: s
    }, i, o, l, d = !1) => {
        var m, E, f;
        Et = !!((f = (E = (m = e == null ? void 0 : e.branding) == null ? void 0 : m.typography) == null ? void 0 : E.font) != null && f.family);
        const a = Pe(n, t),
            h = Me(n, t, o, s),
            c = Te(n),
            u = Ie(n, o, i);
        return ` 
    <div v-pre class="${r.storiesMainContainer} ${ne}">
			${a}
      <div
        class="${oe} ${r.storiesContainer}"
        style="${c}"
        data-tolstoy-element="${p(r.storiesContainer,t)}"
      >
        <div class="${re}">
          ${Ce(t)}
          <div
            class="${ae} ${r.tilesContainer}"
            style="${u}"
            data-tolstoy-element="${p(r.tilesContainer,t)}"
            aria-label="Tolstoy Stories"
            role="group"
          >
            ${h}
          </div>
          ${Oe(t)}
        </div>
      </div>
      ${d?Ne(n,t,l):""}
		</div>
	`
    },
    Le = "data-tolstoy-element^",
    Re = ({
        element: n
    }) => {
        if (q() !== "56bfe6cb-0926-420a-ac48-4d36a3a2ea07") return !1;
        try {
            const t = document.getElementsByTagName("quick-shop")[0];
            return t ? t.contains(n) : !1
        } catch (t) {
            return !1
        }
    };
class Ge {
    constructor() {
        D(this, "removeWindowEventListeners", () => {
            window.removeEventListener("load", this.onViewPortChange), window.removeEventListener("scroll", this.onViewPortChange), window.removeEventListener("message", this.modalMessageHandler)
        });
        D(this, "internalMessagingHandler", ({
            data: t
        }) => {
            switch (t.eventName) {
                case at.urlChange:
                    this.removeWindowEventListeners();
                    break;
                default:
                    return null
            }
        });
        this.initialized = !1, this.handlePageView = this.handlePageView.bind(this), this.handleView = this.handleView.bind(this), this.onViewPortChange = this.onViewPortChange.bind(this), this.onVideoEnd = this.onVideoEnd.bind(this), this.stopDynamicVideos = this.stopDynamicVideos.bind(this), this.setIsDynamicVideoRunning = this.setIsDynamicVideoRunning.bind(this), this.handleDynamicVideos = this.handleDynamicVideos.bind(this), this.modalMessageHandler = this.modalMessageHandler.bind(this), this.onScroll = this.onScroll.bind(this), this.scrollToPrevious = this.scrollToPrevious.bind(this), this.scrollToNext = this.scrollToNext.bind(this), this.currentVideoPlaying = 0, this.isDynamicVideoRunning = !1, this.dynamicVideoIndex = 0, this.isCreateResolutionCalled = !1, this.initInternalMessagingSubscriptions()
    }
    onVideoEnd() {
        this.dynamicVideoIndex = X(this.data.storiesEmbed.storiesSteps, this.dynamicVideoIndex), this.handleDynamicVideos()
    }
    onViewPortChange() {
        Pt({
            videoClass: r.storyVideo,
            isDynamicVideoRunning: this.isDynamicVideoRunning,
            setIsDynamicVideoRunning: this.setIsDynamicVideoRunning,
            dynamicVideoHandler: this.handleDynamicVideos,
            publishId: this.data.publishId,
            onVideoEnd: this.onVideoEnd
        })
    }
    setIsDynamicVideoRunning(t) {
        this.isDynamicVideoRunning = t
    }
    stopDynamicVideos() {
        At({
            videoClass: r.storyVideo,
            onVideoEnd: this.onVideoEnd,
            publishId: this.data.publishId,
            setIsDynamicVideoRunning: this.setIsDynamicVideoRunning
        })
    }
    start(t) {
        var e, s;
        (e = this.modal) == null || e.open(t), (s = this.onYouModal) == null || s.hide()
    }
    getElementByPublicId(t) {
        return window.document.querySelector(`[data-tolstoy-element="${p(t,this.data.publishId)}"]`)
    }
    getAllElements(t, e = window.document) {
        return e.querySelectorAll(t)
    }
    getIdWithPrefixSelector(t) {
        return `[${Le}=${t}]`
    }
    addOnClickEventsToStoryTiles(t) {
        const e = p(r.storyTile, this.data.publishId),
            s = this.getIdWithPrefixSelector(e),
            i = this.getAllElements(s, t);
        i.entries().length === 0 && k("No tiles found");
        for (const [o, l] of i.entries()) l.getAttribute("hasClickEvent") || (l == null || l.addEventListener("keypress", d => {
            (d.code === "Space" || d.code === "Enter") && this.start(o)
        }), l.addEventListener("click", () => {
            this.start(o)
        }), l.setAttribute("hasClickEvent", !0), l.setAttribute("role", "button"), l.setAttribute("tabindex", "0"))
    }
    addOnClickEventToPlusTile() {
        const t = this.getElementByPublicId(r.plusTile);
        t && (t.setAttribute("role", "button"), t.setAttribute("aria-label", "Plus"), t.setAttribute("tabindex", "0"), t.addEventListener("click", () => {
            this.start(this.numberOfTiles)
        }))
    }
    addOnClickEventToOnYouButton(t) {
        const e = this.getElementByPublicId(t);
        e && (e.setAttribute("role", "button"), e.setAttribute("aria-label", "On You"), t === r.onlyOnYouButton ? e.addEventListener("click", () => {
            var s, i;
            (s = this.modal) == null || s.hide(), (i = this.onYouModalOnly) == null || i.open()
        }) : t === r.onYouButton && e.addEventListener("click", () => {
            var s, i;
            (s = this.modal) == null || s.hide(), (i = this.onYouModal) == null || i.open()
        }))
    }
    getMaxTilesNumber() {
        const {
            storiesItemsSizeType: t = et,
            storiesItemsPerRow: e = Kt,
            storiesCircleSize: s = $,
            storiesItemsSpacing: i = st
        } = this.data.storiesEmbed;
        if (t === R.responsive) return e;
        const o = this.parentWidth - s,
            l = s + i;
        return Math.floor(o / l) + 1
    }
    getCircleSize(t) {
        const {
            storiesItemsSizeType: e = et,
            storiesCircleSize: s = $,
            storiesItemsSpacing: i = st
        } = this.data.storiesEmbed;
        if (e === R.responsive) {
            const o = this.parentWidth / t - i;
            return Math.min(o, Mt)
        }
        return s
    }
    initTileNumbers() {
        const {
            storiesEmbed: t
        } = this.data, {
            storiesSteps: e,
            storiesRectangleWidth: s = $,
            storiesRectangleHeight: i = $,
            storiesItemsShape: o,
            storiesItemsSizeType: l,
            storiesStoryNameType: d
        } = t, a = e.length, h = this.getMaxTilesNumber(), c = this.getCircleSize(h);
        this.numberOfTiles = Math.min(a, h);
        const u = o === "circle",
            m = l === R.responsive,
            E = d === Jt.overlay;
        this.tilesData = {
            numberOfSteps: a,
            numberOfTiles: this.numberOfTiles,
            tileSize: c,
            storiesRectangleWidth: s,
            storiesRectangleHeight: i,
            isCircle: u,
            isResponsive: m,
            isTextOverlay: E
        }
    }
    addOnErrorEventToImages() {
        const {
            publishId: t
        } = this.data, e = p(r.storyImage, t), s = this.getIdWithPrefixSelector(e), i = this.getAllElements(s);
        for (const o of i) o.addEventListener("error", () => N(this, null, function*() {
            o.src.includes(w) ? o.src = o.src.replace(w, O) : o.src.includes(O) && (o.src = o.src.replace(O, z)), t && !this.isCreateResolutionCalled && (yield ot(), this.isCreateResolutionCalled = !0)
        }))
    }
    addOnErrorEventToVideos() {
        const {
            publishId: t
        } = this.data, e = document.querySelectorAll(`.${r.storyVideo}`);
        for (const s of e) s.addEventListener("error", i => N(this, null, function*() {
            i.type === "error" && i.target.error === null && (s.poster.includes(w) ? s.poster = s.poster.replace(w, O) : s.poster.includes(O) && (s.poster = s.poster.replace(O, z)), t && !this.isCreateResolutionCalled && (yield ot(), this.isCreateResolutionCalled = !0))
        }))
    }
    initSkeleton({
        element: t,
        data: e
    }) {
        const i = {
            storiesEmbed: x(V({
                storiesSteps: [{}, {}, {}, {}, {}, {}],
                storiesBorderColor: null,
                storiesBorderWidth: null,
                storiesBorder: null,
                storiesPlayButtonOpacity: .1,
                storiesBorderRadius: 50,
                storiesTitle: null,
                skeleton: !0,
                storiesAlignment: "left"
            }, e), {
                storiesMotion: "static"
            }),
            featureSettings: {},
            publishId: "skeleton"
        };
        this.data = i;
        const {
            parentElement: {
                clientWidth: o
            }
        } = t;
        this.parentWidth = o, this.initTileNumbers(), t.innerHTML = Y(i, o, this.tilesData, r.onYouButton), this.handleScrollEvents()
    }
    init(t, e, s) {
        return N(this, null, function*() {
            var h, c, u, m, E, f, T, b, g, S, I, v;
            const i = Nt(t),
                o = e || Lt(t),
                l = ((h = window.Shopify) == null ? void 0 : h.shop) || Rt(),
                d = ((m = (u = (c = t.dataset) == null ? void 0 : c.tags) == null ? void 0 : u.split(",")) == null ? void 0 : m.filter(Boolean)) || "",
                a = !i && !o && !(d != null && d.length);
            if (window.tolstoyWidget = x(V({}, window.tolstoyWidget), {
                    [i]: {
                        init: (y, M) => {
                            var _, P, C, B;
                            (P = (_ = this == null ? void 0 : this.modal) == null ? void 0 : _.remove) == null || P.call(_), (B = (C = this.onYouModal) == null ? void 0 : C.remove) == null || B.call(C), this.init(t, y, M)
                        }
                    }
                }), (E = window.Shopify) != null && E.designMode && a && this.initSkeleton({
                    element: t,
                    data: {
                        storiesTitleText: Wt("Invalid publishId"),
                        storiesTitleEnabled: !0,
                        storiesAlignment: "center"
                    }
                }), a) {
                this.initialized = !1;
                return
            }
            if (!Re({
                    element: t
                })) {
                (f = window.Shopify) != null && f.designMode && this.initSkeleton({
                    element: t,
                    data: {
                        storiesTitleText: "Loading...",
                        storiesTitleEnabled: !1,
                        storiesAlignment: "center"
                    }
                });
                try {
                    const y = yield Dt({
                        publishId: i,
                        productId: o,
                        widgetType: K,
                        tags: d,
                        appUrl: l,
                        variantId: s
                    }), M = (T = y == null ? void 0 : y.featureSettings) == null ? void 0 : T[kt], _ = (b = y == null ? void 0 : y.featureSettings) == null ? void 0 : b[Ht], P = (S = (g = y == null ? void 0 : y.storiesEmbed) == null ? void 0 : g.storiesOnYouEnabled) != null ? S : !0, C = Yt("oyd") === "true", B = C || P && o && M;
                    if (!y) {
                        this.initialized = !1, t.innerHTML = "";
                        return
                    }
                    if (C || B && y.disabled && _) {
                        y.productId = o, y.feedSettings = x(V({}, y.feedSettings), {
                            isFullscreenFeed: !1
                        }), this.data = y, this.onYouModalOnly = new H(x(V({}, y), {
                            verticalOrientation: !0,
                            productId: o
                        }), rt.ON_YOU), t.innerHTML = Y(x(V({}, y), {
                            storiesEmbed: {
                                storiesSteps: []
                            }
                        }), 0, {
                            numberOfTiles: 0
                        }, r.onlyOnYouButton, B), this.addOnClickEventToOnYouButton(r.onlyOnYouButton);
                        return
                    }
                    if (y.disabled) {
                        this.initialized = !1, t.innerHTML = "";
                        return
                    }
                    this.initElements({
                        element: t,
                        data: y,
                        productId: o,
                        isOnYouEnabled: B
                    })
                } catch (y) {
                    throw (I = window.Shopify) != null && I.designMode && y.message && this.initSkeleton({
                        element: t,
                        data: {
                            storiesTitleText: ((v = y.additionalData) == null ? void 0 : v.element) || y.message,
                            storiesTitleEnabled: !0,
                            storiesAlignment: "center"
                        }
                    }), k(y), this.initialized = !1, y
                }
            }
        })
    }
    initElements({
        element: t,
        data: e,
        productId: s,
        isOnYouEnabled: i
    }) {
        try {
            e.playerType = K, e.productId = s, zt(e) && (e.playerLazy = !0), this.data = e, this.dynamicVideoIndex = X(this.data.storiesEmbed.storiesSteps);
            const {
                parentElement: {
                    clientWidth: o
                }
            } = t;
            this.parentWidth = o, this.initTileNumbers(), t.innerHTML = Y(e, o, this.tilesData, r.onYouButton, i), window.location.origin !== {}.VITE_BASE_URL && (this.modal = new H(this.data), i && s && (this.onYouModal = new H(x(V({}, this.data), {
                productId: s,
                feedSettings: x(V({}, this.data.feedSettings), {
                    isFullscreenFeed: !1
                })
            }), rt.ON_YOU))), Ft(this.data), this.addOnClickEventsToStoryTiles(), this.addOnClickEventToPlusTile(), this.addOnClickEventToOnYouButton(r.onYouButton), this.addOnErrorEventToImages(), this.addOnErrorEventToVideos(), this.handleScrollEvents(), this.handleMotion(this.data), J(e.publishId, !1), this.initialized = !0
        } catch (o) {
            k(o), this.initialized = !1
        }
    }
    getIsInitialized() {
        return this.initialized
    }
    handleMotion({
        storiesEmbed: t
    }) {
        const {
            storiesMotion: e
        } = t;
        (!e || e === G.dynamic) && this.handleDynamicEvents()
    }
    getEventParams() {
        return {
            currentPageProductId: this.data.productId
        }
    }
    handlePageView() {
        this.data.playerLazy && this.modal.sendPageView(this.getEventParams())
    }
    handleView() {
        J(this.data.publishId, !0), this.modal.sendEmbedView(this.getEventParams())
    }
    handleOpenEvent(t) {
        var e;
        (e = t.eventData) != null && e.stopDynamicEmbed && this.stopDynamicVideos()
    }
    modalMessageHandler({
        data: t
    }) {
        if (t.name !== qt) return;
        const s = {
            [it.OPEN]: i => this.handleOpenEvent(i),
            [it.CLOSE]: i => this.onViewPortChange(i)
        }[t.type];
        s == null || s(t)
    }
    handleDynamicEvents() {
        this.onViewPortChange(), window.addEventListener("load", this.onViewPortChange), window.addEventListener("scroll", this.onViewPortChange), window.addEventListener("message", this.modalMessageHandler)
    }
    onScroll(t) {
        const e = t.target,
            s = e.scrollLeft,
            i = 1,
            o = e.scrollWidth - e.clientWidth - i;
        s ? this.getElementByPublicId(r.previousButton).dataset.visibility = L.visible : this.getElementByPublicId(r.previousButton).dataset.visibility = L.hidden, o <= s ? this.getElementByPublicId(r.nextButton).dataset.visibility = L.hidden : this.getElementByPublicId(r.nextButton).dataset.visibility = L.visible
    }
    scrollToNext() {
        const t = this.getElementByPublicId(r.tilesContainer),
            e = t.scrollLeft,
            s = t.scrollWidth - t.clientWidth;
        let i = e + t.clientWidth;
        e === s && (i = 0), i > s && (i = s), t.scroll({
            left: i,
            behavior: "smooth",
            block: "nearest"
        })
    }
    scrollToPrevious() {
        const t = this.getElementByPublicId(r.tilesContainer),
            e = t.scrollLeft,
            s = t.scrollWidth - t.clientWidth;
        let i = e - t.clientWidth;
        e || (i = s), i < 0 && (i = 0), t.scroll({
            left: i,
            block: "nearest",
            behavior: "smooth"
        })
    }
    handleScrollEvents() {
        const t = this.getElementByPublicId(r.tilesContainer);
        if (!t) return;
        const e = this.getElementByPublicId(r.nextButton),
            s = this.getElementByPublicId(r.previousButton);
        if (t.scrollWidth - t.clientWidth <= 1) {
            e.style.display = "none", s.style.display = "none";
            return
        }
        s.addEventListener("click", this.scrollToPrevious), e.addEventListener("click", this.scrollToNext), t.addEventListener("scroll", this.onScroll)
    }
    handleDynamicVideos() {
        var l;
        const t = this.dynamicVideoIndex,
            e = Gt(r.storyVideo, this.data.publishId),
            s = e[t];
        if (!(e != null && e.length)) return;
        const {
            scrollActiveStoryIntoView: i
        } = Ut({
            config: this.data,
            key: Xt
        }) || {};
        i && ((l = s == null ? void 0 : s.scrollIntoViewIfNeeded) == null || l.call(s));
        const o = d => {
            if (d.name !== nt.abortError) {
                if (d.name !== nt.notAllowedError) throw d;
                t === 0 && Q() && this.modal.loadFullPlayer()
            }
        };
        if (!s) {
            this.dynamicVideoIndex = 0, this.handleDynamicVideos();
            return
        }
        if (!s.src) {
            const d = this.data.storiesEmbed.storiesSteps[t];
            if (s.src = jt({
                    step: d,
                    isStory: !0
                }), Q()) {
                try {
                    s.autoplay = "true"
                } catch (a) {
                    o(a)
                }
                s.addEventListener("ended", this.onVideoEnd, {
                    once: !0
                });
                return
            }
            s.addEventListener("canplay", () => {
                tt({
                    video: s,
                    onError: o
                })
            }, {
                once: !0
            })
        }
        tt({
            video: s,
            onError: o
        }), s.addEventListener("ended", this.onVideoEnd, {
            once: !0
        })
    }
    initInternalMessagingSubscriptions() {
        Zt.subscribeMultipleEvents({
            eventNames: te,
            callback: this.internalMessagingHandler
        })
    }
}
export {
    Ge as
    default
};