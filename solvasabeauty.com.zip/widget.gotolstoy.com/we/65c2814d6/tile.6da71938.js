var j = Object.defineProperty,
    U = Object.defineProperties;
var W = Object.getOwnPropertyDescriptors;
var V = Object.getOwnPropertySymbols;
var z = Object.prototype.hasOwnProperty,
    D = Object.prototype.propertyIsEnumerable;
var E = (s, t, e) => t in s ? j(s, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : s[t] = e,
    b = (s, t) => {
        for (var e in t || (t = {})) z.call(t, e) && E(s, e, t[e]);
        if (V)
            for (var e of V(t)) D.call(t, e) && E(s, e, t[e]);
        return s
    },
    x = (s, t) => U(s, W(t));
var r = (s, t, e) => (E(s, typeof t != "symbol" ? t + "" : t, e), e);
var g = (s, t, e) => new Promise((i, a) => {
    var o = h => {
            try {
                d(e.next(h))
            } catch (p) {
                a(p)
            }
        },
        l = h => {
            try {
                d(e.throw(h))
            } catch (p) {
                a(p)
            }
        },
        d = h => h.done ? i(h.value) : Promise.resolve(h.value).then(o, l);
    d((e = e.apply(s, t)).next())
});
import {
    j as c,
    a3 as n,
    f as $,
    Q as R,
    o as Z,
    a4 as H,
    r as G,
    s as q,
    a5 as f,
    m as X,
    a6 as I,
    a7 as N,
    $ as Y,
    a8 as Q,
    a9 as J,
    aa as K,
    g as tt,
    a as et,
    b as st,
    ab as it,
    d as nt,
    ac as k,
    ad as at,
    ae as ot,
    l as lt,
    af as M
} from "../widget.js";
import {
    h as rt
} from "./activity-event-helper.8640d488.js";
import {
    I as dt
} from "./embed-widgets.constants.04f1426d.js";
import {
    g as ht
} from "./color.e07a28b3.js";
const ct = {
        addStyleToTextElement: (s, t) => {
            s.style.display = "inline-block", s.style.padding = "0 5px", s.style.color = t.text.color, s.style.fontSize = t.text.size, s.style.textShadow = t.text.shadow
        },
        addCaptionsCss: s => {
            s.style.position = "absolute", s.style.width = "100%", s.style.height = "100%", s.style.display = "flex", s.style.justifyContent = "center", s.style.alignItems = "center", s.style.top = "0", s.style.pointerEvents = "none"
        },
        addToCaptionsContainerCss: s => {
            s.style.textAlign = "center"
        }
    },
    ut = ({
        spread: s,
        maxOpacity: t,
        falloff: e,
        depth: i
    }) => Array.from({
        length: i
    }).map((a, o) => `0 0 ${o*s}px rgba(0, 0, 0, ${o===0?t:t/(o+e)})`).join(","),
    mt = {
        defaultColors: ["#FF2323", "#66FF00", "#00FFFF"],
        text: {
            color: "white",
            size: "32px",
            shadow: ut({
                spread: 3,
                maxOpacity: .85,
                falloff: .15,
                depth: 8
            })
        }
    },
    F = b({}, mt),
    {
        addCaptionsCss: pt,
        addStyleToTextElement: yt,
        addToCaptionsContainerCss: Ct
    } = ct;
class vt {
    constructor({
        videoElement: t,
        captionsUrl: e,
        theme: i = F,
        className: a = ""
    }) {
        r(this, "addCaptionsElement", () => {
            const t = document.createElement("div");
            return t.className = this.className, this.videoElement.parentElement.appendChild(t), pt(t), this.captionsTextContainer = document.createElement("div"), Ct(this.captionsTextContainer, this.videoElement), t.append(this.captionsTextContainer), t
        });
        r(this, "createTextElement", t => {
            const e = document.createElement("span");
            return e.innerText = t, yt(e, this.theme), e
        });
        r(this, "setText", t => {
            if (this.captionsTextContainer.innerHTML = "", !t) return;
            this.captionsText = t;
            const e = this.createTextElement(t);
            this.captionsTextContainer.appendChild(e)
        });
        this.className = a, this.theme = i, this.videoElement = t, this.captionsContainer = this.addCaptionsElement(), this.loadCaptions(e)
    }
    loadCaptions(t) {
        const e = document.createElement("track");
        e.kind = "captions", e.src = t, this.videoElement.appendChild(e), this.videoElement.textTracks[0].mode = "hidden", e.addEventListener("load", () => this.onTrackLoaded())
    }
    onTrackLoaded() {
        const t = this.videoElement.textTracks[0];
        t && (t.mode = "hidden", t.oncuechange = () => {
            const e = t.activeCues[0];
            e ? this.setText(e.text) : this.setText("")
        })
    }
    hide() {
        this.captionsContainer.style.display = "none"
    }
    show() {
        this.captionsContainer.style.display = "flex"
    }
}
const gt = "_tileContainer_1y02j_1",
    Et = "_video_1y02j_13",
    bt = "_customCaptionsTrack_1y02j_28",
    ft = "_imageOverlay_1y02j_34",
    St = "_image_1y02j_34",
    u = "_hidden_1y02j_62",
    Bt = "_controlsOverlay_1y02j_70",
    Tt = "_controlsContainer_1y02j_87",
    wt = "_timebarWrapper_1y02j_88",
    _t = "_playButtonOverlay_1y02j_101",
    Lt = "_timebarContainer_1y02j_125",
    Ot = "_timebar_1y02j_88",
    Pt = "_timeIndicator_1y02j_145",
    Vt = "_togglesContainer_1y02j_150",
    S = "_toggleButton_1y02j_158",
    xt = "_playButtonContainer_1y02j_176",
    It = "_playButtonLabelContainer_1y02j_194",
    Nt = "_playButtonLabel_1y02j_194",
    kt = "_enableCaptionsSvg_1y02j_219",
    Mt = "_disableCaptionsSvg_1y02j_227",
    $t = "_muteSvg_1y02j_235",
    Ht = "_unmuteSvg_1y02j_243";
const Ft = `<svg class="${$t}" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Mute tolstoy video"><path d="M6.266 1.551a0.667 0.667 0 0 1 0.382 0.583v7.714c0 0.261 -0.161 0.482 -0.381 0.602a0.651 0.651 0 0 1 -0.703 -0.12L2.85 7.918h-1.346a1.269 1.269 0 0 1 -1.286 -1.286v-1.286c0 -0.703 0.562 -1.286 1.286 -1.286h1.346L5.563 1.671a0.651 0.651 0 0 1 0.703 -0.12Zm2.492 2.651 1.105 1.106 1.105 -1.106c0.18 -0.18 0.483 -0.18 0.663 0 0.201 0.201 0.201 0.502 0 0.683L10.526 5.991l1.106 1.104c0.201 0.201 0.201 0.502 0 0.683a0.44 0.44 0 0 1 -0.663 0l-1.106 -1.105 -1.104 1.106c-0.201 0.201 -0.502 0.201 -0.683 0 -0.201 -0.182 -0.201 -0.483 0 -0.684l1.105 -1.105L8.073 4.886c-0.2 -0.18 -0.2 -0.482 0 -0.683 0.182 -0.18 0.483 -0.18 0.684 0Z" fill="#fff"/></svg>`,
    At = `<svg class="${Ht}" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Unmute tolstoy video"><path d="M6.627 1.55c.238.101.411.342.411.583v7.714c0 .261-.173.482-.411.603a.742.742 0 0 1-.757-.121l-2.921-2.41H1.5c-.779 0-1.385-.563-1.385-1.286V5.347c0-.703.606-1.286 1.385-1.286h1.449l2.921-2.39a.742.742 0 0 1 .757-.121Zm3.721 1.447c.931.723 1.537 1.788 1.537 2.993 0 1.225-.606 2.29-1.537 2.993a.542.542 0 0 1-.735-.06c-.195-.201-.152-.502.065-.683.714-.522 1.168-1.326 1.168-2.25 0-.904-.454-1.708-1.168-2.23a.475.475 0 0 1-.065-.683.565.565 0 0 1 .735-.08ZM9.029 4.503c.476.362.779.884.779 1.487 0 .623-.303 1.145-.779 1.507a.55.55 0 0 1-.736-.081.454.454 0 0 1 .087-.663.966.966 0 0 0 .389-.763.928.928 0 0 0-.389-.743.475.475 0 0 1-.087-.683.57.57 0 0 1 .736-.061Z" fill="#fff"/></svg>`,
    jt = '<svg width="15" height="15" viewBox="0 0 15 15" fill="none" aria-label="Fullscreen Tolstoy video"  xmlns="http://www.w3.org/2000/svg"><path d="M2 2.5C2 2.22386 2.22386 2 2.5 2H5.5C5.77614 2 6 2.22386 6 2.5C6 2.77614 5.77614 3 5.5 3H3V5.5C3 5.77614 2.77614 6 2.5 6C2.22386 6 2 5.77614 2 5.5V2.5ZM9 2.5C9 2.22386 9.22386 2 9.5 2H12.5C12.7761 2 13 2.22386 13 2.5V5.5C13 5.77614 12.7761 6 12.5 6C12.2239 6 12 5.77614 12 5.5V3H9.5C9.22386 3 9 2.77614 9 2.5ZM2.5 9C2.77614 9 3 9.22386 3 9.5V12H5.5C5.77614 12 6 12.2239 6 12.5C6 12.7761 5.77614 13 5.5 13H2.5C2.22386 13 2 12.7761 2 12.5V9.5C2 9.22386 2.22386 9 2.5 9ZM12.5 9C12.7761 9 13 9.22386 13 9.5V12.5C13 12.7761 12.7761 13 12.5 13H9.5C9.22386 13 9 12.7761 9 12.5C9 12.2239 9.22386 12 9.5 12H12V9.5C12 9.22386 12.2239 9 12.5 9Z" fill="#fff" fill-rule="evenodd" clip-rule="evenodd"></path></svg>',
    Ut = `<svg class=${kt} width="15" height="15" viewBox="0 0 15 15" fill="none" aria-label="Fullscreen Tolstoy video"  xmlns="http://www.w3.org/2000/svg"><text x="-0.5" y="10.5" letter-spacing="-0.5" font-weight=300 font-family="sans-serif" font-size="10" fill="white">[cc]</text></svg>`,
    Wt = `<svg class=${Mt} width="15" height="15" viewBox="0 0 15 15" fill="none" aria-label="Fullscreen Tolstoy video"  xmlns="http://www.w3.org/2000/svg"><text x="-0.5" y="10.5" letter-spacing="-0.5" text-decoration="line-through" font-weight=300 font-family="sans-serif" font-size="10" fill="white">[cc]</text></svg>`,
    m = (s, t, e) => {
        const i = `${t}-${e}`;
        return $(s, i)
    },
    zt = ({
        step: s,
        publishId: t,
        shouldAutoplay: e,
        variantId: i
    }) => {
        const a = R({
                step: s,
                isTile: !0
            }),
            {
                partName: o
            } = s,
            l = {
                crossOrigin: "anonymous",
                playsinline: "",
                controlsList: "nodownload",
                muted: "",
                disablePictureInPicture: "",
                disableRemotePlayback: "",
                preload: "metadata",
                "aria-label": o,
                "data-tolstoy-element": m(n.video, t, i)
            };
        return e && (l.loop = "", l.autoplay = ""), c({
            tagName: "video",
            classNames: [Et, n.video],
            attributes: l,
            src: a
        })
    },
    Dt = ({
        step: s,
        publishId: t,
        variantId: e
    }) => {
        const i = c({
                tagName: "div",
                classNames: [ft, n.imageOverlay],
                attributes: {
                    "data-tolstoy-element": m(n.imageOverlay, t, e)
                }
            }),
            a = Z({
                step: s,
                extension: G,
                posterSettings: {
                    useShopifyPoster: !1
                },
                size: q["960x540"]
            }),
            {
                partName: o
            } = s,
            l = c({
                tagName: "img",
                classNames: [St, n.image],
                src: a,
                alt: o,
                attributes: {
                    loading: "lazy"
                }
            });
        return i.append(l), i
    },
    Rt = (s = {}) => {
        const {
            tilePlayButtonHasBackground: t = !0,
            tilePlayButtonBackgroundColor: e,
            tilePlayButtonBackgroundOpacity: i = .65,
            tilePlayButtonHasBorder: a,
            tilePlayButtonBorderColor: o = "#000"
        } = s, l = {};
        if (t) {
            const d = ht(e, i);
            l.backgroundColor = d
        } else l.backgroundColor = "transparent";
        return a && (l.border = `2px solid ${o}`), l
    },
    Zt = ({
        tileEmbed: s,
        publishId: t,
        variantId: e
    }) => {
        const i = Rt(s),
            a = c({
                tagName: "button",
                classNames: [xt, n.playButtonContainer],
                attributes: {
                    "aria-label": "Play",
                    role: "button",
                    "data-tolstoy-element": m(n.playButtonContainer, t, e)
                },
                style: i
            }),
            o = X();
        return a.innerHTML = o, a
    },
    Gt = ({
        step: s,
        publishId: t,
        variantId: e
    }) => {
        const i = c({
                tagName: "div",
                classNames: [It, n.playButtonLabelContainer],
                attributes: {
                    "data-tolstoy-element": m(n.playButtonLabelContainer, t, e)
                }
            }),
            {
                partName: a
            } = s,
            o = c({
                tagName: "p",
                classNames: [Nt, n.playButtonLabel],
                attributes: {
                    "aria-label": `Video name: ${a}`,
                    preload: "metadata"
                }
            });
        return i.append(o), o.innerHTML = a, i
    },
    qt = ({
        publishId: s,
        isAllowedToUnmute: t,
        shouldShowCaptions: e,
        variantId: i
    }) => {
        const a = c({
                tagName: "div",
                classNames: [Tt, n.controlsContainer]
            }),
            o = c({
                tagName: "div",
                classNames: [Pt, n.timeIndicator],
                attributes: {
                    "data-tolstoy-element": m(n.timeIndicator, s, i)
                }
            });
        o.innerHTML = " ", a.append(o);
        const l = c({
            tagName: "div",
            classNames: [Vt, n.togglesContainer]
        });
        if (a.append(l), t) {
            const h = c({
                tagName: "button",
                classNames: [S, n.muteButton],
                attributes: {
                    "data-tolstoy-element": m(n.muteButton, s, i),
                    "aria-label": "Mute"
                }
            });
            h.innerHTML = `${Ft}${At}`, l.append(h)
        }
        if (e) {
            const h = c({
                tagName: "button",
                classNames: [S, n.captionsButton],
                attributes: {
                    "data-tolstoy-element": m(n.captionsButton, s, i),
                    "aria-label": "Closed Captions"
                }
            });
            h.innerHTML = `${Wt}${Ut}`, l.append(h)
        }
        const d = c({
            tagName: "button",
            classNames: [S, n.fullScreenButton],
            attributes: {
                "data-tolstoy-element": m(n.fullScreenButton, s, i),
                "aria-label": "Fullscreen"
            }
        });
        return d.innerHTML = `${jt}`, l.append(d), a
    },
    Xt = ({
        publishId: s,
        tileEmbed: t,
        isAllowedToUnmute: e,
        shouldShowCaptions: i,
        variantId: a
    }) => {
        const o = c({
            tagName: "div",
            classNames: [Bt, n.controlsOverlay],
            attributes: {
                role: "button",
                tabindex: "0",
                "aria-label": "Controls",
                "data-tolstoy-element": m(n.controlsOverlay, s, a)
            }
        });
        if (!t.tileShouldShowControls) return o;
        const l = c({
                tagName: "div",
                classNames: [wt, n.timebarWrapper],
                attributes: {
                    "data-tolstoy-element": m(n.timebarWrapper, s, a)
                }
            }),
            d = c({
                tagName: "div",
                classNames: [Lt, n.timebarContainer],
                attributes: {
                    "data-tolstoy-element": m(n.timebarContainer, s, a)
                }
            }),
            h = c({
                tagName: "div",
                classNames: [Ot, n.timebar],
                attributes: {
                    "data-tolstoy-element": m(n.timebar, s, a)
                }
            });
        l.append(d);
        const p = qt({
            publishId: s,
            isAllowedToUnmute: e,
            shouldShowCaptions: i,
            variantId: a
        });
        return o.append(p, l), d.append(h), o
    },
    Yt = ({
        step: s,
        publishId: t,
        tileEmbed: e,
        variantId: i
    }) => {
        const a = c({
                tagName: "div",
                classNames: [_t, n.playButtonOverlay],
                attributes: {
                    "data-tolstoy-element": m(n.playButtonOverlay, t, i)
                }
            }),
            o = Zt({
                publishId: t,
                tileEmbed: e,
                variantId: i
            }),
            l = Gt({
                step: s,
                publishId: t,
                variantId: i
            });
        return a.append(o, l), a
    },
    Qt = (s = {}) => {
        const t = {},
            {
                tileVerticalMargin: e,
                tileHorizontalMargin: i,
                tileBorderRadius: a
            } = s;
        return f(e) || (t.marginTop = `${e}px`, t.marginBottom = `${e}px`), f(i) || (t.marginLeft = `${i}px`, t.marginRight = `${i}px`), f(a) || (t.borderRadius = `${a}px`), t
    },
    Jt = ({
        tileEmbed: s,
        publishId: t,
        variantId: e
    }) => {
        const i = Qt(s);
        return c({
            tagName: "div",
            classNames: [gt, n.tileContainer],
            style: i,
            attributes: {
                "data-tolstoy-element": m(n.tileContainer, t, e)
            }
        })
    },
    Kt = ({
        step: s,
        publishId: t,
        tileEmbed: e,
        isAllowedToUnmute: i,
        shouldShowCaptions: a,
        shouldAutoplay: o,
        variantId: l
    }) => {
        const d = zt({
                step: s,
                publishId: t,
                shouldAutoplay: o,
                variantId: l
            }),
            h = Dt({
                step: s,
                publishId: t,
                variantId: l
            }),
            p = Xt({
                publishId: t,
                tileEmbed: e,
                isAllowedToUnmute: i,
                shouldShowCaptions: a,
                variantId: l
            }),
            C = Yt({
                step: s,
                publishId: t,
                tileEmbed: e,
                variantId: l
            }),
            v = Jt({
                tileEmbed: e,
                publishId: t,
                variantId: l
            });
        return v.append(d, h, C, p), v
    },
    te = e => g(void 0, [e], function*({
        publishId: s,
        step: t
    }) {
        const {
            videoOwner: i,
            videoId: a
        } = t, o = H({
            ownerId: i,
            assetId: a,
            extension: ".vtt"
        });
        try {
            const d = yield(yield fetch(o)).text(), h = new Blob([d], {
                type: "text/vtt"
            }), p = URL.createObjectURL(h);
            return c({
                tagName: "track",
                classNames: [n.nativeCaptionsTrack],
                attributes: {
                    default: !0,
                    kind: "captions",
                    srclang: "en-us",
                    label: "Tolstoy Subtitles",
                    "data-tolstoy-element": m(n.nativeCaptionsTrack, s)
                },
                src: p
            })
        } catch (l) {}
    }),
    ee = navigator.platform === "iPhone" || navigator.platform === "iPhone Simulator";
class le {
    constructor() {
        r(this, "handlePageView", () => {
            this.analyticsHandler.handlePageView()
        });
        r(this, "handleView", () => {
            this.hasEmbedViewed || (this.analyticsHandler.handleEmbedView(), this.hasEmbedViewed = !0), this.handleAutoplay()
        });
        r(this, "handleOutOfView", () => {
            this.videoElement.pause(), this.sessionStartedTimeout && (clearTimeout(this.sessionStartedTimeout), this.sessionStartedTimeout = null)
        });
        r(this, "handleAutoplay", () => {
            !this.shouldAutoplay || this.isUserPaused || (this.handleVolumeChange(), this.hideControlsOverlay(0), this.videoElement.play(), this.handleSendVideoLoaded(), !(this.hasSessionStarted || this.sessionStartedTimeout) && (this.sessionStartedTimeout = setTimeout(() => {
                this.analyticsHandler.handleSessionStart(), this.hasSessionStarted = !0
            }, dt)))
        });
        r(this, "hideControlsOverlay", (t = 1500) => {
            this.controlsOverlayTimeout && clearTimeout(this.controlsOverlayTimeout), this.isControlsOverlayShown = !0, this.controlsOverlayTimeout = setTimeout(() => {
                this.controlsOverlayElement.classList.add(u), this.isControlsOverlayShown = !1
            }, t)
        });
        r(this, "handleSendVideoWatched", () => {
            const [t] = this.data.steps, e = this.getElementByPublicId(n.video);
            this.shouldSendVideoWatchedEvent = !1, this.analyticsHandler.handleVideoWatched({
                videoId: t.videoId,
                type: t.type || I.VIDEO,
                videoWatchedTime: N(e.currentTime, 3),
                videoDuration: N(e.duration, 3)
            })
        });
        r(this, "handleSendVideoLoaded", () => {
            if (this.hasVideoLoaded) return;
            const [t] = this.data.steps;
            this.hasVideoLoaded = !0, this.analyticsHandler.handleVideoLoaded({
                text: t.partName,
                videoId: t.videoId,
                type: t.type || I.VIDEO
            })
        });
        r(this, "handleTileClick", t => {
            if (t.preventDefault(), this.isMobile && !this.isPaused && !this.isControlsOverlayShown && this.shouldShowControls) {
                this.controlsOverlayElement.classList.remove(u), this.hideControlsOverlay();
                return
            }
            if (this.isPaused = !this.isPaused, this.isPaused && !this.shouldAutoplay || this.isPaused && !this.isInitialMute && this.shouldAutoplay) {
                this.isUserPaused = !0, this.videoElement.pause(), this.playButtonContainerElement.classList.remove(u), this.controlsOverlayElement.classList.remove(u), clearTimeout(this.controlsOverlayTimeout);
                return
            }
            this.isUserPaused = !1, this.isAllowedToUnmute && (this.videoElement.muted = !1), this.isInitialMute && (this.isInitialMute = !1, this.isPaused = !1), this.isMuted = !1, this.tileContainerElement.dataset.tileMuted = !1, this.videoElement.play(), this.shouldSendVideoWatchedEvent = !0, this.handleSendVideoLoaded(), this.imageOverlayElement.classList.add(u), this.playButtonContainerElement.classList.add(u), this.playButtonLabelContainerElement.classList.add(u), this.hideControlsOverlay(), rt({
                type: Y.OPEN,
                publishId: this.publishId
            }), !this.hasSessionStarted && (this.sessionStartedTimeout && (clearTimeout(this.sessionStartedTimeout), this.sessionStartedTimeout = null), this.analyticsHandler.handleSessionStart(), this.hasSessionStarted = !0)
        });
        r(this, "handlePlay", t => {
            this.isPaused !== t.target.paused && (this.isPaused = t.target.paused, this.imageOverlayElement.classList.add(u), this.playButtonContainerElement.classList.add(u), this.playButtonLabelContainerElement.classList.add(u), this.hideControlsOverlay())
        });
        r(this, "handlePause", t => {
            this.isPaused !== t.target.paused && (this.isPaused = t.target.paused, this.playButtonContainerElement.classList.remove(u))
        });
        r(this, "handleTimebarClick", t => {
            t.stopPropagation(), this.hideControlsOverlay();
            const e = this.timebarContainerElement.getBoundingClientRect(),
                i = t.clientX - e.left,
                a = e.width,
                o = i / a,
                d = this.videoElement.duration * o;
            this.videoElement.currentTime = d
        });
        r(this, "handleTimeUpdate", Q(() => {
            const t = this.videoElement.currentTime,
                e = this.videoElement.duration,
                i = t / e * 100;
            this.timebarElement.style.width = `${i}%`, this.timeIndicatorElement.textContent = `${M(t)} / ${M(e)}`
        }, 100));
        r(this, "handleMuteClick", t => {
            t.stopPropagation(), this.hideControlsOverlay(), this.isAllowedToUnmute && (this.videoElement.muted = !this.videoElement.muted), this.isMuted = !this.isMuted, this.tileContainerElement.dataset.tileMuted = this.isMuted
        });
        r(this, "handleCaptionsClick", t => {
            if (t.stopPropagation(), this.captionsVisible = !this.captionsVisible, this.tileContainerElement.dataset.tileEnabledCaptions = this.captionsVisible, this.captionsVisible) {
                this.customCaptions.show();
                return
            }
            this.customCaptions.hide()
        });
        r(this, "handleFullScreenClick", t => g(this, null, function*() {
            t.stopPropagation();
            const e = document.fullscreenElement !== null;
            if (ee && !e) {
                if (this.videoElement.webkitEnterFullScreen(), this.captionsVisible) {
                    const [i] = this.data.steps;
                    this.nativeCaptionsElement = yield te({
                        publishId: this.publishId,
                        step: i
                    }), this.videoElement.appendChild(this.nativeCaptionsElement)
                }
                return
            }
            if (e) {
                document.exitFullscreen();
                return
            }
            this.tileContainerElement.requestFullscreen()
        }));
        r(this, "handleFullScreenChange", t => {
            document.fullscreenElement === null && this.videoElement.removeChild(this.nativeCaptionsElement)
        });
        r(this, "handleVolumeChange", t => {
            this.isMuted !== this.videoElement.muted && (this.isMuted = this.videoElement.muted, this.tileContainerElement.dataset.tileMuted = this.isMuted)
        });
        r(this, "resetVideo", () => {
            this.handleSendVideoWatched(), this.videoElement.currentTime = 0, this.videoElement.pause(), this.imageOverlayElement.classList.remove(u), this.playButtonContainerElement.classList.remove(u), this.playButtonLabelContainerElement.classList.remove(u), this.controlsOverlayElement.classList.remove(u), this.isPaused = !0, this.isControlsOverlayShown = !1, clearTimeout(this.controlsOverlayTimeout), this.sessionStartedTimeout && (clearTimeout(this.sessionStartedTimeout), this.sessionStartedTimeout = null)
        });
        r(this, "handleDocumentVisible", () => {
            J({
                element: this.videoElement
            }) && this.handleView()
        });
        r(this, "handleVisibilityChange", () => {
            if (document.visibilityState === "visible") {
                this.handleDocumentVisible();
                return
            }
            if (this.isPaused) {
                this.shouldSendVideoWatchedEvent && this.handleSendVideoWatched();
                return
            }
            this.resetVideo(), K()
        });
        this.initialized = !1, this.isPaused = !0, this.isUserPaused = !1, this.analyticsHandler = null, this.hasSessionStarted = !1, this.hasEmbedViewed = !1, this.isMuted = !1, this.isInitialMute = !1, this.isMobile = window.innerWidth <= 450, this.isAllowedToUnmute = !0, this.customCaptions = null, this.captionsVisible = !1, this.shouldShowControls = null, this.shouldShowCaptions = null, this.nativeCaptionsElement = null, this.shouldSendVideoWatchedEvent = !1, this.sessionStartedTimeout = null
    }
    getIsInitialized() {
        return this.initialized
    }
    getElementByPublicId(t) {
        const e = `${this.publishId}-${this.variantId}`;
        return window.document.querySelector(`[data-tolstoy-element="${$(t,e)}"]`)
    }
    initElements(t, e) {
        this.initialized = !0;
        const {
            steps: i,
            publishId: a,
            tileEmbed: o
        } = e, [l] = i, d = Kt({
            step: l,
            publishId: a,
            tileEmbed: o,
            isAllowedToUnmute: this.isAllowedToUnmute,
            shouldShowCaptions: this.shouldShowCaptions,
            shouldAutoplay: this.shouldAutoplay,
            variantId: this.variantId
        });
        t.innerHTML = d.outerHTML, this.videoElement = this.getElementByPublicId(n.video), this.tileContainerElement = this.getElementByPublicId(n.tileContainer), this.imageOverlayElement = this.getElementByPublicId(n.imageOverlay), this.playButtonContainerElement = this.getElementByPublicId(n.playButtonContainer), this.playButtonLabelContainerElement = this.getElementByPublicId(n.playButtonLabelContainer), this.controlsOverlayElement = this.getElementByPublicId(n.controlsOverlay), this.muteButtonElement = this.getElementByPublicId(n.muteButton), this.fullScreenButtonElement = this.getElementByPublicId(n.fullScreenButton), this.captionsButtonElement = this.getElementByPublicId(n.captionsButton), this.timebarWrapperElement = this.getElementByPublicId(n.timebarWrapper), this.timebarContainerElement = this.getElementByPublicId(n.timebarContainer), this.timebarElement = this.getElementByPublicId(n.timebar), this.timeIndicatorElement = this.getElementByPublicId(n.timeIndicator), this.shouldAutoplay && (this.playButtonContainerElement.classList.add(u), this.playButtonLabelContainerElement.classList.add(u), this.imageOverlayElement.classList.add(u))
    }
    loadCustomCaptions(t) {
        const {
            videoOwner: e,
            videoId: i
        } = t, a = H({
            ownerId: e,
            assetId: i,
            extension: ".vtt"
        });
        this.customCaptions = new vt({
            videoElement: this.videoElement,
            captionsUrl: a,
            theme: x(b({}, F), {
                defaultColors: ["#FFFFFF"]
            }),
            className: `${n.customCaptionsTrack} ${bt}`
        }), this.captionsVisible || this.customCaptions.hide()
    }
    initEvents() {
        this.controlsOverlayElement.addEventListener("click", this.handleTileClick), this.videoElement.addEventListener("ended", this.resetVideo), document.addEventListener("visibilitychange", this.handleVisibilityChange), document.addEventListener("fullscreenchange", this.handleFullScreenChange), this.videoElement.addEventListener("webkitendfullscreen", this.handleFullScreenChange), this.videoElement.addEventListener("play", this.handlePlay), this.videoElement.addEventListener("pause", this.handlePause), setTimeout(() => {
            this.handleVisibilityChange()
        }, 100), this.shouldShowControls && (this.shouldShowCaptions && this.captionsButtonElement.addEventListener("click", this.handleCaptionsClick), this.videoElement.addEventListener("volumechange", this.handleVolumeChange), this.videoElement.addEventListener("timeupdate", this.handleTimeUpdate), this.muteButtonElement.addEventListener("click", this.handleMuteClick), this.fullScreenButtonElement.addEventListener("click", this.handleFullScreenClick), this.timebarWrapperElement.addEventListener("click", this.handleTimebarClick))
    }
    init(t) {
        return g(this, null, function*() {
            var d, h, p, C, v, B, T, w, _, L, O;
            const e = tt(t),
                i = et(t),
                a = ((d = window.Shopify) == null ? void 0 : d.shop) || st(),
                o = ((C = (p = (h = t.dataset) == null ? void 0 : h.tags) == null ? void 0 : p.split(",")) == null ? void 0 : C.filter(Boolean)) || "",
                l = it();
            if (!e && !i && o.length === 0) {
                this.initialized = !1;
                return
            }
            try {
                const y = yield nt({
                    publishId: e,
                    productId: i,
                    widgetType: k,
                    tags: o,
                    appUrl: a,
                    variantId: l
                });
                if (!y || y.disabled) {
                    this.initialized = !1, t.innerHTML = "";
                    return
                }
                this.data = y, this.publishId = y.publishId, this.variantId = l, this.analyticsHandler = new at({
                    config: y,
                    playerType: k
                }), this.shouldShowControls = (v = this.data.tileEmbed) == null ? void 0 : v.tileShouldShowControls, this.shouldShowCaptions = (B = this.data.tileEmbed) == null ? void 0 : B.tileShouldShowCaptions, this.shouldAutoplay = (T = this.data.tileEmbed) == null ? void 0 : T.tileShouldAutoplay, this.shouldAutoplay && (this.isInitialMute = !0, this.isPaused = !1);
                const A = (O = (L = (_ = (w = this.data) == null ? void 0 : w.design) == null ? void 0 : _.player) == null ? void 0 : L.controls) == null ? void 0 : O.isFeedMuted,
                    P = y.steps[0];
                this.isAllowedToUnmute = !ot(A, P.isSoundAllowed), this.initElements(t, y, i), this.initEvents(), this.shouldShowCaptions && this.shouldShowControls && this.loadCustomCaptions(P), this.tileContainerElement.dataset.tileEnabledCaptions = this.captionsVisible
            } catch (y) {
                throw lt(y), this.initialized = !1, y
            }
        })
    }
}
export {
    le as
    default
};