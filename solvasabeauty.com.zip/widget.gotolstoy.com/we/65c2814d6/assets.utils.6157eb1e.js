import {
    a6 as o,
    a4 as r,
    cl as t,
    cm as E,
    p as i
} from "../widget.js";
const a = e => (e == null ? void 0 : e.type) === o.IMAGE,
    l = e => (e == null ? void 0 : e.type) === o.GALLERY,
    c = ({
        videoOwner: e,
        videoId: I
    }, {
        size: n = i.M
    } = {}) => r({
        ownerId: e,
        assetId: I,
        suffix: t[n],
        extension: E
    }),
    g = (e, I = -1) => {
        for (let n = I + 1; n < e.length; n++)
            if (!a(e[n])) return n
    };
export {
    g as a, l as b, c as g, a as i
};