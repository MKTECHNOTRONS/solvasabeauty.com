var o = (n, e, a) => new Promise((r, t) => {
    var h = s => {
            try {
                i(a.next(s))
            } catch (d) {
                t(d)
            }
        },
        E = s => {
            try {
                i(a.throw(s))
            } catch (d) {
                t(d)
            }
        },
        i = s => s.done ? r(s.value) : Promise.resolve(s.value).then(h, E);
    i((a = a.apply(n, e)).next())
});
import {
    aH as c,
    bR as R,
    I as g,
    bS as y,
    bT as T,
    bU as l
} from "../widget.js";
class M {
    constructor(e) {
        this.tolstoyIframe = e, this.rechargeMessagingHandler = this.rechargeMessagingHandler.bind(this), this.playerReady = !1, this.playerReadyMessages = [], this.subscribeForPlayerStart(), this.init()
    }
    subscribeForPlayerStart() {
        window.addEventListener("message", e => {
            var a, r;
            if (e.data && e.data.eventName === c) {
                this.playerReady = !0;
                for (const t of this.playerReadyMessages || [])(r = (a = this.tolstoyIframe) == null ? void 0 : a.contentWindow) == null || r.postMessage(t, "*");
                this.playerReadyMessages = []
            }
        })
    }
    safePostMessageToWindow(e) {
        var a;
        if (!this.playerReady) return this.playerReadyMessages.push(e);
        (a = this.tolstoyIframe) == null || a.contentWindow.postMessage(e, "*")
    }
    getRechargeWidgetData() {
        return o(this, null, function*() {
            if (!window.ReChargeWidget) return;
            const e = yield window.ReChargeWidget.api.fetchWidgetData();
            this.safePostMessageToWindow({
                eventName: R,
                rechargeWidgetData: e
            })
        })
    }
    rechargeAddToCart(r) {
        return o(this, arguments, function*({
            rechargeCartItem: e,
            variantId: a
        }) {
            if (window.ReChargeWidget) try {
                yield window.ReChargeWidget.api.postToCart(e), this.safePostMessageToWindow({
                    eventName: g.addToCartSuccess,
                    variantId: a
                })
            } catch (t) {
                this.safePostMessageToWindow({
                    eventName: g.addToCartError,
                    error: "Error adding to cart",
                    variantId: a
                })
            }
        })
    }
    rechargeMessagingHandler(e) {
        if (e.data.name === y) switch (e.data.type) {
            case l:
                return this.getRechargeWidgetData();
            case T:
                return this.rechargeAddToCart(e.data);
            default:
                return null
        }
    }
    init() {
        window.addEventListener("message", this.rechargeMessagingHandler)
    }
}
export {
    M as R
};