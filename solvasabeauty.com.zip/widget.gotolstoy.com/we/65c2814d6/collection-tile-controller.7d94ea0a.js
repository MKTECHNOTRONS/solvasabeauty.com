var Y = Object.defineProperty,
    j = Object.defineProperties;
var R = Object.getOwnPropertyDescriptors;
var C = Object.getOwnPropertySymbols;
var F = Object.prototype.hasOwnProperty,
    K = Object.prototype.propertyIsEnumerable;
var V = (n, e, t) => e in n ? Y(n, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : n[e] = t,
    g = (n, e) => {
        for (var t in e || (e = {})) F.call(e, t) && V(n, t, e[t]);
        if (C)
            for (var t of C(e)) K.call(e, t) && V(n, t, e[t]);
        return n
    },
    P = (n, e) => j(n, R(e));
var l = (n, e, t) => (V(n, typeof e != "symbol" ? e + "" : e, t), t);
var S = (n, e, t) => new Promise((i, s) => {
    var o = d => {
            try {
                r(t.next(d))
            } catch (h) {
                s(h)
            }
        },
        a = d => {
            try {
                r(t.throw(d))
            } catch (h) {
                s(h)
            }
        },
        r = d => d.done ? i(d.value) : Promise.resolve(d.value).then(o, a);
    r((t = t.apply(n, e)).next())
});
import {
    ag as W,
    a4 as $,
    ah as _,
    ai as y,
    aj as c,
    a6 as L,
    a7 as b,
    T as q,
    ak as D,
    al as p,
    m as z,
    am as G,
    an as J,
    ao as Q,
    ap as M,
    aq as X,
    ar as Z,
    as as tt,
    b as et,
    ab as it,
    a as st,
    d as nt,
    at as w,
    au as ot,
    ad as at,
    av as lt
} from "../widget.js";
import {
    C as dt,
    c as f,
    g as rt
} from "./style.utils.8bf9e7cc.js";
import {
    F as ht
} from "./features.constants.50ee80f5.js";
const ct = "_tile_1g5j1_9",
    ut = "_video_1g5j1_16",
    pt = "_controlsContainer_1g5j1_22",
    k = "_controlButton_1g5j1_30",
    yt = "_playIcon_1g5j1_58",
    gt = "_pauseIcon_1g5j1_62",
    O = "_isPlaying_1g5j1_66",
    ft = "_mutedIcon_1g5j1_75",
    mt = "_unmutedIcon_1g5j1_79",
    x = "_isMuted_1g5j1_83",
    U = "_hidden_1g5j1_91";
const Et = ({
        vodAsset: n,
        posterSettings: e
    }) => {
        const t = W({
            stockAsset: n.stockAsset,
            posterSettings: e
        });
        return t || $({
            ownerId: n.owner,
            assetId: n.id,
            extension: ".0000000.jpg"
        })
    },
    Tt = n => {
        var i;
        const e = (i = n.stockAsset) == null ? void 0 : i.videoUrl;
        return e || $({
            ownerId: n.owner,
            assetId: n.id,
            suffix: "_640",
            extension: ".mp4"
        })
    },
    vt = () => window.location.pathname.includes("/collections/"),
    It = (n, e = 0) => n > e ? e : e - n;
class m extends dt {
    constructor(t, i) {
        super(t, i);
        l(this, "handleIntersection", t => {
            t.forEach(i => {
                var o, a;
                const s = this.isInViewport;
                this.isInViewport = i.isIntersecting, s !== this.isInViewport && ((a = (o = this.props).onViewportChange) == null || a.call(o, this, this.isInViewport))
            })
        });
        l(this, "handleVideoEnded", t => {
            const {
                settings: i
            } = this.props;
            if (this.isVideoFinished = !0, this.props.onVideoEnded(t, this), this.isAutoplay && i.shouldHideVideoWhenNotPlaying && !this.isPlaying) return this.hideTile();
            this.isPlaying || this.videoElement.load()
        });
        l(this, "handleMetadataLoaded", t => {
            const i = t.target;
            this.analytics.videoDuration = i == null ? void 0 : i.duration
        });
        l(this, "handleTimeUpdate", t => {
            const i = t.target,
                {
                    hasVideoLoaded: s,
                    hasVideoPlayed: o,
                    previousTime: a
                } = this.analytics;
            !s && (i == null ? void 0 : i.currentTime) > 0 && !i.paused && (this.analytics.hasVideoLoaded = !0, this.sendVideoStartPlayingAnalytics()), o || (this.analytics.hasVideoPlayed = !0);
            const r = It(a, i == null ? void 0 : i.currentTime);
            this.analytics.watchedTime += r, this.analytics.previousTime = (i == null ? void 0 : i.currentTime) || 0
        });
        l(this, "handleSeeking", t => {
            const i = t.target;
            i != null && i.currentTime || this.analytics.loopCount++, this.analytics.isSeeked = !0, this.analytics.previousTime = i == null ? void 0 : i.currentTime
        });
        l(this, "sendVideoStartPlayingAnalytics", () => {
            const {
                product: t,
                vodAsset: i,
                analyticsHandler: s
            } = this.props, o = t ? JSON.stringify(t) : "", a = t != null && t.id ? JSON.stringify([t == null ? void 0 : t.id]) : "";
            s.handleVideoLoaded({
                products: o,
                productIds: a,
                text: i.name,
                videoId: i.id,
                type: i.type || L.VIDEO,
                productNames: `${(t==null?void 0:t.title)||""}`
            })
        });
        l(this, "sendVideoViewAnalytics", () => {
            const {
                isSeeked: t,
                loopCount: i,
                watchedTime: s,
                videoDuration: o,
                hasVideoPlayed: a
            } = this.analytics, {
                vodAsset: r,
                analyticsHandler: d
            } = this.props;
            a && d.handleVideoWatched({
                videoId: r.id,
                videoLoopCount: i,
                type: r.type || L.VIDEO,
                videoWatchedTime: b(s, 3),
                videoDuration: b(o, 3),
                isVideoSeeked: t
            })
        });
        l(this, "mute", () => this.setMuted(!0));
        l(this, "unmute", () => this.setMuted(!1));
        const {
            playMode: s
        } = t.settings || {};
        this.isAutoplay = [y.AUTOPLAY, y.HOVER].includes(s), this.isInViewport = !1, this.isVideoFinished = !1, this.analytics = {
            loopCount: 0,
            watchedTime: 0,
            previousTime: 0,
            videoDuration: 0,
            isSeeked: !1,
            hasVideoLoaded: !1,
            hasVideoPlayed: !1
        }, this.observer = new IntersectionObserver(this.handleIntersection, {
            threshold: .5
        })
    }
    static getKey(t, i, s) {
        return `${t}_${i}_${s}`
    }
    static findElementByKey(t) {
        return document.querySelector(`[${_}="${t}"]`)
    }
    onMount() {
        super.onMount();
        const {
            settings: t
        } = this.props;
        this.tileElement = m.findElementByKey(this.key), this.videoElement = this.tileElement.querySelector("video");
        const i = this.tileElement.querySelector(`.${c.playButton}`),
            s = this.tileElement.querySelector(`.${c.muteButton}`);
        this.observer.observe(this.tileElement), this.tileElement.addEventListener("click", o => this.props.onClick(o, this)), this.tileElement.setAttribute("role", "button"), this.tileElement.setAttribute("tabindex", "0"), this.videoElement.addEventListener("seeking", this.handleSeeking), this.videoElement.addEventListener("timeupdate", this.handleTimeUpdate), this.videoElement.addEventListener("ended", o => this.handleVideoEnded(o)), this.videoElement.addEventListener("loadedmetadata", this.handleMetadataLoaded), this.mute(), i && i.addEventListener("click", o => this.props.onPlayClick(o, this)), s && s.addEventListener("click", o => this.props.onMuteClick(o, this)), this.isAutoplay && t.shouldHideVideoWhenNotPlaying && this.hideTile()
    }
    onUnmount() {
        this.observer && this.observer.disconnect(), super.onUnmount()
    }
    play({
        isMuted: t = !1
    } = {}) {
        const {
            settings: i
        } = this.props;
        if (!this.videoElement || this.isPlaying) return;
        const s = o => {
            console.error(o)
        };
        q({
            video: this.videoElement,
            onError: s
        }), this.tileElement.classList.add(O), this.isPlaying = !0, this.setMuted(t), !this.analytics.hasVideoLoaded && !this.videoElement.currentTime && !this.videoElement.paused && (this.analytics.hasVideoLoaded = !0, this.sendVideoStartPlayingAnalytics()), this.isAutoplay && i.shouldHideVideoWhenNotPlaying && this.showTile()
    }
    pause() {
        !this.videoElement || !this.isPlaying || (this.videoElement.pause(), this.tileElement.classList.remove(O), this.isPlaying = !1, this.props.settings.shouldHideVideoWhenNotPlaying && this.hideTile(), this.sendVideoViewAnalytics())
    }
    hideTile() {
        this.tileElement.classList.add(U)
    }
    showTile() {
        this.tileElement.classList.remove(U)
    }
    setMuted(t) {
        this.videoElement && (this.isMuted = t, this.videoElement.muted = t, this.videoElement.removeAttribute("muted"), t ? this.tileElement.classList.add(x) : this.tileElement.classList.remove(x))
    }
    shouldLoop() {
        const {
            playbackMode: t,
            playMode: i,
            playVideos: s
        } = this.props.settings || {};
        return [y.CLICK, y.HOVER].includes(i) ? !0 : t === D.LOOP && s === p.SIMULTANEOUSLY
    }
    render() {
        const {
            initialElement: t,
            vodAsset: i,
            settings: s,
            featureSettings: o
        } = this.props, a = Et({
            vodAsset: i,
            posterSettings: o == null ? void 0 : o[ht]
        }), r = Tt(i), {
            controls: d
        } = s || {}, {
            play: h = {},
            mute: E = {}
        } = d || {};
        t.setAttribute(_, this.key), t.classList.add(ct);
        const u = this.shouldLoop();
        return t.innerHTML = `
      <video
        src="${r}"
        poster="${a}"
        class="${f(ut,c.video)}"
        ${u?"loop":""}
        playsinline
      ></video>
      <div class="${f(c.controlsContainer,pt)}">
        <button
          aria-label="Mute/unmute video sound"
          class="${f(c.playButton,k)}"
          style="${N({config:h})}"
          type="button"
        >
          ${z("#fff",yt)}
          ${G("#fff",gt)}
        </button>
        <button
          aria-label="Mute/unmute video sound"
          class="${f(c.muteButton,k)}"
          style="${N({config:E})}"
          type="button"
        >
          ${J({className:ft})}
          ${Q({className:mt})}
        </button>
      </div>
    `, t
    }
}
const N = ({
    config: n
}) => `
  display: ${n.enabled?"flex":"none"};
  border: ${n.borderEnabled?`1px solid ${n.borderColor||"#fff"}`:"none"};
  background: ${n.backgroundEnabled?n.backgroundColor:"none"};
  opacity: ${n.opacity||1};
`;
class Ct {
    constructor() {
        l(this, "handleVisibilityChange", () => {
            if (document.visibilityState === "visible") {
                this.resumePlayingTiles();
                return
            }
            this.savePlayingTiles(), this.pauseAllTiles()
        });
        l(this, "onTileEnded", (e, t) => {
            if (this.isAutoplay)
                if (this.config.settings.playVideos === p.CONSECUTIVELY) {
                    const i = this.config.settings.playbackMode === D.LOOP,
                        s = this.currentActiveIndex + 1;
                    if (i) this.currentActiveIndex = s >= this.tiles.length ? 0 : s;
                    else {
                        if (s >= this.tiles.length) return;
                        this.currentActiveIndex = s
                    }
                    this.playTile(this.currentActiveIndex)
                } else t.pause()
        });
        l(this, "onTileClick", (e, t) => {
            if (e.stopPropagation(), e.preventDefault(), this.config.settings.tileClickMode === tt.PLAY) {
                this.onTilePlayClick(e, t);
                return
            }
            if (!t.props.product) return;
            const s = rt(t.props.product);
            this.sendAnalyticsOpenProductPageEvent(t.props.product), window.open(s, "_self", "noopener, noreferrer")
        });
        l(this, "onTilePlayClick", (e, t) => {
            e.stopPropagation(), e.preventDefault(), this.currentActiveIndex = this.tiles.indexOf(t), t.isPlaying ? this.pauseTile(this.currentActiveIndex) : this.playTile(this.currentActiveIndex)
        });
        l(this, "onTileMuteClick", (e, t) => {
            e.stopPropagation(), e.preventDefault(), this.isMuted = !t.isMuted, this.isMuted ? t.mute() : t.unmute(), t.isPlaying || (this.currentActiveIndex = this.tiles.indexOf(t), this.playTile(this.currentActiveIndex))
        });
        l(this, "handleTileViewportChange", (e, t) => {
            const i = this.tiles.indexOf(e);
            if (this.isAutoplay) {
                if (t ? this.tilesInViewport.add(i) : (this.tilesInViewport.delete(i), this.pauseTile(i)), this.config.settings.playVideos === p.SIMULTANEOUSLY) {
                    t ? this.playTile(i) : this.pauseTile(i);
                    return
                }
                if (this.config.settings.playVideos === p.CONSECUTIVELY)
                    if (!t && i === this.currentActiveIndex) {
                        const s = this.tiles.findIndex((o, a) => this.tilesInViewport.has(a) && !this.tiles[a].isVideoFinished);
                        s !== -1 && (this.currentActiveIndex = s, this.playTile(s))
                    } else t && (this.tilesInViewport.size === 1 || this.currentActiveIndex === null && !e.isVideoFinished) && (this.currentActiveIndex = i, this.playTile(i))
            }
        });
        l(this, "handlePageView", () => {
            var e;
            (e = this.analyticsHandler) == null || e.handlePageView()
        });
        l(this, "handleView", () => {
            var e;
            (e = this.analyticsHandler) == null || e.handleEmbedView()
        });
        this.tiles = [], this.config = null, this.publishId = null, this.initialized = !1, this.currentActiveIndex = null, this.analyticsHandler = null, this.isMuted = !0, this.isAutoplay = !1, this.autoplayTimeout = null, this.isReducedMotion = !1, this.analytics = {
            isSessionStarted: !1
        }, this.savedTiles = new Set, this.tilesInViewport = new Set
    }
    subscribeOnEvents() {
        document.addEventListener("visibilitychange", this.handleVisibilityChange)
    }
    savePlayingTiles() {
        this.savedTiles = new Set;
        for (const [e, t] of this.tiles.entries()) t.isPlaying && this.savedTiles.add(e)
    }
    resumePlayingTiles() {
        for (const e of this.savedTiles) this.playTile(e);
        this.savedTiles = new Set
    }
    sendAnalyticsSessionStartEvent() {
        if (this.analytics.isSessionStarted) return;
        const e = this.analyticsHandler.getAnalyticsParams({
                eventName: M.sessionStart
            }),
            t = {
                data: P(g({}, e), {
                    name: X.sessionStart
                })
            };
        this.analyticsHandler.handleSessionStart(), Z(t), this.analytics.isSessionStarted = !0
    }
    sendAnalyticsOpenProductPageEvent(e) {
        this.sendAnalyticsSessionStartEvent(), this.analyticsHandler.sendEvent({
            eventName: M.openProductPageClick,
            products: e ? JSON.stringify(e) : "",
            productIds: e != null && e.id ? JSON.stringify([e == null ? void 0 : e.id]) : "",
            productNames: `${(e==null?void 0:e.title)||""}`
        })
    }
    startAutoplay() {
        const {
            autoplayDelay: e
        } = this.config.settings;
        if (!e) {
            this.autoplay();
            return
        }
        this.autoplayTimeout = setTimeout(() => {
            this.autoplay()
        }, e * 1e3)
    }
    autoplay() {
        if (this.config.settings.playVideos === p.CONSECUTIVELY) {
            const e = this.tiles.findIndex((t, i) => this.tilesInViewport.has(i) && !t.isVideoFinished);
            e !== -1 && (this.currentActiveIndex = e, this.playTile(e))
        } else this.tiles.forEach((e, t) => {
            this.tilesInViewport.has(t) && this.playTile(t)
        })
    }
    playTile(e) {
        const t = this.tiles[e];
        t && (this.autoplayTimeout && clearTimeout(this.autoplayTimeout), this.config.settings.playVideos === p.CONSECUTIVELY && this.pauseAllTiles(), t.play({
            isMuted: this.isMuted
        }), this.analytics.isSessionStarted || this.sendAnalyticsSessionStartEvent())
    }
    pauseTile(e) {
        const t = this.tiles[e];
        t && t.pause()
    }
    pauseAllTiles() {
        this.tiles.forEach(e => e.pause())
    }
    renderCollectionTiles(e) {
        var d;
        const {
            settings: t,
            productIdVodMap: i
        } = this.config, {
            maxVideosPerPage: s
        } = t, o = -1, a = ((d = window.Shopify) == null ? void 0 : d.shop) || et(), r = it();
        e.forEach((h, E) => S(this, null, function*() {
            var A;
            const u = st(h),
                T = i[u],
                H = this.config.productsMap[u];
            if (!T || E <= o || this.tiles.length >= s && s > 0) return;
            const B = m.getKey(this.publishId, u, T.id),
                v = yield nt({
                    publishId: this.publishId,
                    productId: u,
                    widgetType: w,
                    tags: (A = this.config) == null ? void 0 : A.tags,
                    appUrl: a,
                    variantId: r
                }), I = new m({
                    product: H,
                    vodAsset: T,
                    initialElement: h,
                    settings: this.config.settings,
                    featureSettings: v == null ? void 0 : v.featureSettings,
                    analyticsHandler: this.analyticsHandler,
                    onClick: this.onTileClick,
                    onPlayClick: this.onTilePlayClick,
                    onMuteClick: this.onTileMuteClick,
                    onVideoEnded: this.onTileEnded,
                    onViewportChange: this.handleTileViewportChange
                }, {
                    key: B
                });
            h.outerHTML = I.render().outerHTML, I.onMount(), this.tiles.push(I)
        }))
    }
    initElements(e) {
        const t = [...document.querySelectorAll(`.${c.collectionTile}`)];
        e.settings.hideOnMobile && ot() || (this.config = e, this.publishId = e.publishId, this.analyticsHandler = new at({
            config: this.config,
            playerType: w
        }), this.renderCollectionTiles(t), this.initialized = !0, this.isReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)") === !0 || window.matchMedia("(prefers-reduced-motion: reduce)").matches === !0, this.isAutoplay = !this.isReducedMotion && [y.AUTOPLAY, y.HOVER].includes(this.config.settings.playMode), this.isAutoplay ? this.startAutoplay() : this.isMuted = this.config.settings.mutedByDefault, this.subscribeOnEvents())
    }
    init(i, s) {
        return S(this, arguments, function*(e, {
            config: t
        }) {
            var a, r, d;
            if (!vt()) return;
            const o = ((d = (r = (a = e.dataset) == null ? void 0 : a.tags) == null ? void 0 : r.split(",")) == null ? void 0 : d.filter(Boolean)) || "";
            this.initElements(P(g({}, t), {
                settings: g(g({}, lt), t.settings || {}),
                tags: o
            }))
        })
    }
    getIsInitialized() {
        return this.initialized
    }
}
export {
    Ct as
    default
};