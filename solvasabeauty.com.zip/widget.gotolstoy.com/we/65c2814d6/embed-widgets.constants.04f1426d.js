const I = 1e4;
export {
    I
};