const e = t => t ? Math.round(t * 255).toString(16).toUpperCase().padStart(2, "0") : "",
    n = (t, r) => `${t}${e(r)}`;
export {
    n as g
};