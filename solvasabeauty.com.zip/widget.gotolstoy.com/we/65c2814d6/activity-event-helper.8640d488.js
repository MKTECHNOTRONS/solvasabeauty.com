import {
    bN as i,
    b3 as c,
    a2 as l,
    $ as a,
    ci as u,
    cj as m
} from "../widget.js";
const y = ({
        type: s,
        publishId: e
    }) => {
        if (!s || !e) return;
        const t = Date.now(),
            n = i();
        c({
            publishId: e,
            timeStamp: t,
            type: s,
            sessionId: n
        })
    },
    S = s => {
        const {
            videoPause: e,
            videoResume: t
        } = m, {
            publishId: n,
            playerType: o
        } = s.data;
        if (o !== l || ![e, t].includes(s.data.name)) return;
        const r = Date.now(),
            E = i(),
            d = s.data.name === e ? a.PAUSE : a.PLAY;
        c({
            publishId: n,
            timeStamp: r,
            type: d,
            sessionId: E
        })
    },
    T = ({
        publishId: s,
        sessionId: e
    }) => {
        var o;
        if (!s || !e) return !1;
        const t = (o = u()) == null ? void 0 : o[s];
        if (!(t != null && t.length)) return !1;
        const n = t[t.length - 1];
        return n.type === a.OPEN && n.sessionId === e
    };
export {
    S as a, y as h, T as i
};