import {
    cg as d,
    ch as m
} from "../widget.js";
const e = /\/([a-z]{2}-[a-z]{2})(\/|$)/i,
    y = () => {
        var o, r;
        if ((r = (o = window.Shopify) == null ? void 0 : o.routes) != null && r.root) return window.Shopify.routes.root;
        const t = window.location.pathname.match(e);
        return t ? `/${t[1]}/` : "/"
    },
    w = (n, t) => {
        const o = n.match(e);
        return o ? n.replace(o[0], t) : n
    },
    S = () => {
        const n = document.querySelectorAll("script");
        for (const o of n) {
            const r = o.src;
            if (o.innerHTML.includes("shopify") || r.includes("shopify")) return !0
        }
        const t = document.querySelectorAll("link");
        for (const o of t) {
            const r = o.href;
            if (o.innerHTML.includes("shopify") || r.includes("shopify")) return !0
        }
        return !1
    },
    i = (n, t) => {
        if (!t) return n;
        const o = n.includes("?") ? "&" : "?";
        return `${n}${o}variant=${t}`
    },
    $ = ({
        appUrl: n = (r => (r = window.location) == null ? void 0 : r.host)(),
        handle: t
    }, o) => {
        var c;
        if (d(t)) {
            const h = window.location.pathname.match(e);
            if (h) {
                const f = `/${h[1]}/`,
                    p = w(t, f);
                return i(p, o)
            }
            return i(t, o)
        }
        const l = y();
        let s = n;
        (c = window == null ? void 0 : window.location) != null && c.host && n !== window.location.host && (s = m() || S() ? window.location.host : n);
        const u = `https://${s}${l}products/${t}`;
        return i(u, o)
    };
class M {
    constructor(t, o = {}) {
        this.props = t, this.children = [], this.key = o.key
    }
    onMount() {
        this.children.forEach(t => t.onMount())
    }
    onUnmount() {
        this.children.forEach(t => t.onUnmount())
    }
    unmountChild(t) {
        const o = this.children.find(r => r.key === t);
        o && o.onUnmount(), this.children = this.children.filter(r => r.key !== t)
    }
    toString() {
        var t;
        return ((t = this == null ? void 0 : this.render()) == null ? void 0 : t.outerHTML) || super.toString()
    }
    push(t) {
        return this.children.push(t), t
    }
    removeChild(t) {
        this.children = this.children.filter(o => o.key !== t)
    }
}
const U = (...n) => n.flat().filter(t => typeof t == "string").join(" ").trim();
export {
    M as C, U as c, $ as g
};