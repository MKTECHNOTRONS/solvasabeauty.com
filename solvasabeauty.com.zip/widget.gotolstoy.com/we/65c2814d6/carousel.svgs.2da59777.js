import {
    ck as T,
    b1 as V
} from "../widget.js";
const s = "_carouselContainer_1ktjo_1",
    l = "_carouselVideosContainer_1ktjo_10",
    _ = "_controlsContainer_1ktjo_15",
    c = "_variantContainer_1ktjo_23",
    u = "_variantContentContainer_1ktjo_28",
    C = "_variantColor_1ktjo_48",
    d = "_squareVariantColor_1ktjo_57",
    v = "_variantTitle_1ktjo_61",
    k = "_controlButton_1ktjo_74",
    h = "_playIcon_1ktjo_106",
    x = "_pauseIcon_1ktjo_110",
    g = "_videoContainer_1ktjo_114",
    p = "_isPlaying_1ktjo_114",
    r = "_handleContainer_1ktjo_124",
    m = "_handleLink_1ktjo_134",
    w = "_centerTile_1ktjo_143",
    f = "_video_1ktjo_114",
    B = "_arrow_1ktjo_155",
    S = "_watermark_1ktjo_172",
    I = {
        carouselContainer: s,
        carouselVideosContainer: l,
        controlsContainer: _,
        variantContainer: c,
        variantContentContainer: u,
        variantColor: C,
        squareVariantColor: d,
        variantTitle: v,
        controlButton: k,
        playIcon: h,
        pauseIcon: x,
        videoContainer: g,
        isPlaying: p,
        handleContainer: r,
        handleLink: m,
        centerTile: w,
        video: f,
        arrow: B,
        watermark: S
    },
    P = Object.freeze(Object.defineProperty({
        __proto__: null,
        arrow: B,
        carouselContainer: s,
        carouselVideosContainer: l,
        centerTile: w,
        controlButton: k,
        controlsContainer: _,
        default: I,
        handleContainer: r,
        handleLink: m,
        isPlaying: p,
        pauseIcon: x,
        playIcon: h,
        squareVariantColor: d,
        variantColor: C,
        variantContainer: c,
        variantContentContainer: u,
        variantTitle: v,
        video: f,
        videoContainer: g,
        watermark: S
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    b = (n, t = "tiktok") => {
        if (t === "tiktok") return `https://www.tiktok.com/${n}/`;
        if (t === "instagram") return `https://www.instagram.com/${n}/`
    };

function i(n) {
    return n ? n[0] === "@" ? n : "@" + n : ""
}
const N = (n, t, a, e) => a ? `<a
      target="_blank"
      rel="noopener noreferrer"
      href="${t}"
      class="${e.handleLink}"
      aria-label="View creator profile"
    >
      ${i(n)}
    </a>` : `<span class="${e.handleLink}">
    ${i(n)}
  </span>`,
    A = ({
        step: n,
        showCreatorProfileLink: t,
        openCreatorProfileLink: a,
        carouselCreatorProfileLinkPosition: e,
        shouldShowWatermark: y
    }) => {
        try {
            const {
                handle: o,
                provider: j
            } = (n == null ? void 0 : n.externalProviderData) || {};
            if (!(t && o)) return "";
            const L = () => e === T.TOP ? "top: 4px" : y ? "bottom: 47px" : "bottom: 16px",
                $ = b(o, j);
            return `
      <div
        class="${r}"
        style="${L()}"
      >
      ${N(o,$,a,P)}
      </div>
    `
        } catch (o) {
            V(o)
        }
    },
    R = "_carouselContainer_1x0nl_1",
    q = "_titleContainer_1x0nl_10",
    E = "_carouselVideoContainer_1x0nl_16",
    D = "_previousButtonContainer_1x0nl_23",
    W = "_nextButtonContainer_1x0nl_41",
    z = "_videosContainer_1x0nl_49",
    F = "_videosContainerSafariWorkaround_1x0nl_61",
    K = "_videoContainer_1x0nl_61",
    U = "_videosContainerSkeleton_1x0nl_65",
    G = "_video_1x0nl_49",
    J = "_playButtonContainer_1x0nl_115",
    Q = "_playButtonSkeleton_1x0nl_137",
    X = "_skeleton_1x0nl_143",
    Y = "_dotsContainer_1x0nl_159",
    nn = "_dot_1x0nl_159",
    tn = "_playInTileControlsContainer_1x0nl_192",
    on = "_controlButton_1x0nl_202",
    en = "_spotlightVideosContainer_1x0nl_224",
    O = "_muteSvg_1x0nl_224",
    H = "_unmuteSvg_1x0nl_234",
    an = "_tileContainer_1x0nl_244",
    rn = "_tileNameContainer_1x0nl_258",
    sn = "_tileNameText_1x0nl_269",
    ln = "_arrowButtonContainer_1x0nl_283",
    _n = "_arrowButton_1x0nl_283",
    cn = "_tileNameHeightPlaceholder_1x0nl_294";
const un = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Open Tolstoy widget"><path d="M.047.352A.663.663 0 0 0 0 .562v3.375c0 .329.258.563.563.563a.542.542 0 0 0 .562-.563V1.922l3.164 3.164c.234.234.586.234.797 0 .234-.211.234-.563 0-.797L1.922 1.125h2.016A.542.542 0 0 0 4.5.562.555.555 0 0 0 3.937 0H.563a.657.657 0 0 0-.211.047.641.641 0 0 0-.305.305Zm11.93 11.32c.023-.07.023-.14.023-.235v-3.35c0-.328-.234-.586-.563-.586a.57.57 0 0 0-.562.563v2.039L7.711 6.937a.513.513 0 0 0-.774 0 .513.513 0 0 0 0 .774l3.165 3.164h-2.04a.57.57 0 0 0-.562.563c0 .328.258.562.563.562h3.374c.094 0 .165 0 .235-.023a.763.763 0 0 0 .305-.305Z" fill="#fff"/></svg>',
    Cn = `<svg class="${O}" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Mute tolstoy video"><path d="M6.266 1.551a0.667 0.667 0 0 1 0.382 0.583v7.714c0 0.261 -0.161 0.482 -0.381 0.602a0.651 0.651 0 0 1 -0.703 -0.12L2.85 7.918h-1.346a1.269 1.269 0 0 1 -1.286 -1.286v-1.286c0 -0.703 0.562 -1.286 1.286 -1.286h1.346L5.563 1.671a0.651 0.651 0 0 1 0.703 -0.12Zm2.492 2.651 1.105 1.106 1.105 -1.106c0.18 -0.18 0.483 -0.18 0.663 0 0.201 0.201 0.201 0.502 0 0.683L10.526 5.991l1.106 1.104c0.201 0.201 0.201 0.502 0 0.683a0.44 0.44 0 0 1 -0.663 0l-1.106 -1.105 -1.104 1.106c-0.201 0.201 -0.502 0.201 -0.683 0 -0.201 -0.182 -0.201 -0.483 0 -0.684l1.105 -1.105L8.073 4.886c-0.2 -0.18 -0.2 -0.482 0 -0.683 0.182 -0.18 0.483 -0.18 0.684 0Z" fill="#fff"/></svg>`,
    dn = `<svg class="${H}" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Unmute tolstoy video"><path d="M6.627 1.55c.238.101.411.342.411.583v7.714c0 .261-.173.482-.411.603a.742.742 0 0 1-.757-.121l-2.921-2.41H1.5c-.779 0-1.385-.563-1.385-1.286V5.347c0-.703.606-1.286 1.385-1.286h1.449l2.921-2.39a.742.742 0 0 1 .757-.121Zm3.721 1.447c.931.723 1.537 1.788 1.537 2.993 0 1.225-.606 2.29-1.537 2.993a.542.542 0 0 1-.735-.06c-.195-.201-.152-.502.065-.683.714-.522 1.168-1.326 1.168-2.25 0-.904-.454-1.708-1.168-2.23a.475.475 0 0 1-.065-.683.565.565 0 0 1 .735-.08ZM9.029 4.503c.476.362.779.884.779 1.487 0 .623-.303 1.145-.779 1.507a.55.55 0 0 1-.736-.081.454.454 0 0 1 .087-.663.966.966 0 0 0 .389-.763.928.928 0 0 0-.389-.743.475.475 0 0 1-.087-.683.57.57 0 0 1 .736-.061Z" fill="#fff"/></svg>`;
export {
    sn as A, B, w as C, p as D, r as E, d as F, g as G, S as H, f as I, _ as J, k as K, h as L, x as M, C as N, u as O, v as P, c as Q, l as R, en as S, E as a, z as b, R as c, nn as d, U as e, cn as f, ln as g, _n as h, Y as i, G as j, on as k, A as l, Cn as m, W as n, K as o, D as p, tn as q, un as r, X as s, q as t, dn as u, F as v, an as w, rn as x, J as y, Q as z
};