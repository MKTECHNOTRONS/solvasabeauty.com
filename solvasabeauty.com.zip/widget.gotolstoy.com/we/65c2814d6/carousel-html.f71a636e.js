import {
    bo as o,
    f as u,
    bV as S,
    bW as h,
    i as it,
    bx as dt,
    F as ct,
    n as ut,
    o as mt,
    s as pt,
    j as F,
    bm as yt,
    bX as M,
    r as Ct,
    m as $t
} from "../widget.js";
import {
    i as vt,
    b as Et,
    g as gt
} from "./assets.utils.6157eb1e.js";
import {
    c as Tt,
    a as Nt,
    t as Bt,
    b as bt,
    v as Lt,
    e as xt,
    f as ft,
    g as St,
    h as At,
    p as Ht,
    n as kt,
    i as Pt,
    j as U,
    k as O,
    u as wt,
    m as Mt,
    l as Ot,
    o as _t,
    s as ht,
    q as Ft,
    r as Ut,
    w as zt,
    x as It,
    y as Wt,
    z as Rt,
    A as Vt
} from "./carousel.svgs.2da59777.js";
import {
    g as Gt
} from "./color.e07a28b3.js";
let z = !1;
const I = a => {
        z && (a.style.fontFamily = `'tolstoy-custom-font-family', ${ct}`)
    },
    Dt = ({
        carouselFontSize: a,
        carouselFontColor: t,
        carouselTitleEnabled: s,
        carouselTitleText: e,
        carouselTitleFontWeight: i
    }, d) => {
        if (!e || !s) return "";
        const l = typeof e == "string" ? e : e.textContent,
            n = document.createElement("div");
        return n.classList.add(Bt, o.title), n.dataset.tolstoyElement = u(o.title, d), n.setAttribute("role", "heading"), n.setAttribute("aria-level", "2"), n.setAttribute("aria-label", `Tolstoy carousel header: ${l.replace(/\s+/g," ")}`), n.style.fontSize = `${a}px`, n.style.fontWeight = i, n.style.color = t, I(n), n.append(e), n
    },
    jt = ({
        text: a,
        carouselTileNameTextColor: t,
        carouselTileNameTextSize: s
    }) => {
        const e = document.createElement("div");
        return e.classList.add(Vt, o.tileNameText), e.style.color = t, e.style.fontSize = `${s}px`, e.style.lineHeight = `${s*1.2}px`, I(e), e.append(a), e
    },
    Xt = ({
        text: a = "",
        carouselTileNameEnabled: t,
        carouselTileNameTextSize: s,
        carouselTileNameTextColor: e,
        carouselTileNameBackgroundEnabled: i,
        carouselTileNameBackgroundColor: d,
        carouselTileNameBackgroundTransparancy: l,
        carouselBorderRadius: n,
        isOver: y
    }) => {
        if (!t || !a) return;
        const c = document.createElement("div");
        return c.classList.add(It, o.tileNameContainer), c.style.height = `${h}px`, c.style.borderRadius = `0 0 ${n}px ${n}px`, y && i && (c.style.background = Gt(d, l / 100)), c.append(jt({
            text: a,
            carouselTileNameTextColor: e,
            carouselTileNameTextSize: s
        })), c
    },
    qt = ({
        partName: a,
        videoUrl: t,
        carouselShape: s,
        videoRadius: e,
        posterImage: i,
        publishId: d,
        step: l,
        featureSettings: n
    }) => {
        var C, $;
        const y = [U, o.video],
            c = {
                playsinline: "",
                muted: "",
                "aria-label": a,
                "data-tolstoy-element": u(o.video, d),
                "data-tolstoy-is-sound-allowed": l.isSoundAllowed,
                "data-tolstoy-video-id": l.videoId,
                poster: i
            };
        (C = n == null ? void 0 : n[M]) != null && C.preload && (c.preload = ($ = n[M]) == null ? void 0 : $.preload);
        const r = {
            "z-index": 1,
            "aspect-ratio": s,
            "border-radius": `${e}px`,
            "aria-hidden": !0,
            muted: ""
        };
        return F({
            tagName: "video",
            classNames: y,
            attributes: c,
            src: t,
            style: r
        }).outerHTML
    },
    Kt = ({
        carouselEmbed: a,
        publishId: t,
        index: s,
        featureSettings: e,
        showCreatorProfileLink: i,
        openCreatorProfileLink: d,
        carouselCreatorProfileLinkPosition: l
    }) => {
        const {
            carouselSteps: n,
            carouselBorderColor: y,
            carouselBorderWidth: c,
            carouselBorder: r,
            carouselBorderRadius: m,
            carouselPlayButtonBackground: C = !0,
            carouselPlayButtonBackgroundColor: $ = "#000",
            carouselPlayButtonBorder: g = !1,
            carouselPlayButtonBorderColor: v = "#fff",
            carouselPlayButtonOpacity: T,
            carouselShape: N,
            carouselMotion: B,
            carouselTileNameEnabled: b = !1,
            carouselTileNameLocation: L = S.under,
            carouselTileNameTextSize: x = 16,
            carouselTileNameTextColor: W = "black",
            carouselTileNameBackgroundEnabled: R = !1,
            carouselTileNameBackgroundColor: V = "black",
            carouselTileNameBackgroundTransparancy: G = 50,
            skeleton: H = !1,
            loadAll: D = !1,
            carouselPlayInTileFirst: j
        } = a, p = n[s], E = document.createElement("div"), X = e == null ? void 0 : e["widget-poster-settings"], f = vt(p), k = Et(p), q = f || k ? "" : ut({
            step: p,
            embedMotion: B,
            loadAll: D,
            isCarouselPlayInTileFirst: j
        }), K = p.partName || `Carousel video ${s+1} preview`, Y = f ? gt(p) : mt({
            step: p,
            extension: Ct,
            posterSettings: X,
            size: pt["480x480"]
        }), Z = `
    opacity:${T};
    background: ${C?$:"transparent"};
    border: ${g?2:0}px solid ${v};
  `, P = r ? c : 0, A = r && y, J = r ? `border: ${P}px solid ${A}` : "", Q = A ? `background:${A}` : "", tt = m - P, et = $t(g ? v : void 0), ot = qt({
            partName: K,
            videoUrl: q,
            carouselShape: N,
            videoRadius: tt,
            posterImage: Y,
            publishId: t,
            step: p,
            featureSettings: e
        }), at = F({
            tagName: "div",
            classNames: [U],
            styleString: "background:transparent;display:flex;width:fit-content;z-index:2;"
        }), nt = f || k ? "" : `
    <button
      aria-label="Open Tolstoy widget"
      type="button"
      class="
        ${Wt}
        ${H?Rt:""}
        ${o.playButtonContainer}
      "
      data-tolstoy-element="${u(o.playButtonContainer,t)}"
      style="${Z}"
    >
      ${et}
    </button>
  `, st = f ? "" : `
    <button
      role="button"
      aria-label="Mute/unmute video sound"
      type="button"
      class="${O}"
      data-tolstoy-element="${u(o.muteButton,t)}"
      data-tolstoy-video-id="${p.videoId}"
    >
      ${wt}
      ${Mt}
    </button>
  `, lt = Ot({
            step: p,
            showCreatorProfileLink: i,
            openCreatorProfileLink: d,
            carouselCreatorProfileLinkPosition: l
        });
        E.innerHTML = `
    <div
      style="border-radius: ${m}px;${J};${Q}"
      class="${_t} ${o.videoContainer}"
      ${H?ht:""}
      data-tolstoy-element="${u(o.videoContainer,t)}"
      aria-label="Play video - ${p.partName}"
    >
      ${ot}
      ${at.outerHTML}
      ${nt}
      ${lt}

      <div
        class="${Ft} ${o.controlsContainer}"
        data-tolstoy-element="${u(o.controlsContainer,t)}"
      >
        <button
          class="${O}"
          data-tolstoy-element="${u(o.expandButton,t)}"
          aria-label="Open Tolstoy widget"
          type="button"
        >
          ${Ut}
        </button>

        ${st}
      </div>
    </div>
  `;
        const rt = L === S.over;
        E.classList.add(zt, o.tileContainer), E.dataset.tolstoyElement = u(o.tileContainer, t);
        const w = Xt({
            text: p.partName,
            carouselTileNameEnabled: b,
            carouselTileNameTextSize: x,
            carouselTileNameTextColor: W,
            carouselTileNameBackgroundEnabled: R,
            carouselTileNameBackgroundColor: V,
            carouselTileNameBackgroundTransparancy: G,
            carouselBorderRadius: m,
            isOver: rt
        });
        return w && E.append(w), E
    },
    Yt = ({
        carouselEmbed: a,
        publishId: t,
        featureSettings: s,
        showCreatorProfileLink: e,
        openCreatorProfileLink: i,
        carouselCreatorProfileLinkPosition: d
    }) => {
        const {
            carouselSteps: l,
            carouselSpacingHorizontal: n = yt,
            carouselTileNameLocation: y = S.under,
            skeleton: c = !1
        } = a, r = document.createElement("div");
        r.classList.add(bt, o.videosContainer), window != null && window.safari && r.classList.add(Lt), c && r.classList.add(xt), r.dataset.tolstoyElement = u(o.videosContainer, t), r.style.gap = `${n}px`, r.style.gridTemplateColumns = `repeat(${l.length}, calc(25% - ${n}px))`, r.id = u(o.videosContainer, t), r.role = "group", r.ariaLabel = "Tolstoy Carousel", r.dataset.carouselMuted = !1, r.dataset.carouselTileNameLocation = y;
        for (let m = 0; m < l.length; m++) {
            const C = Kt({
                carouselEmbed: a,
                publishId: t,
                index: m,
                featureSettings: s,
                showCreatorProfileLink: e,
                openCreatorProfileLink: i,
                carouselCreatorProfileLinkPosition: d
            });
            r.append(C)
        }
        return r
    },
    Zt = ({
        carouselTileNameEnabled: a,
        carouselTileNameLocation: t,
        carouselSteps: s
    }) => {
        if (!a || t !== S.under || s.every(d => !d.partName)) return;
        const i = document.createElement("div");
        return i.classList.add(ft, o.tileNameHeightPlaceholder), i.style.height = `${h}px`, i
    },
    _ = (a, t, s) => {
        const e = document.createElement("div");
        e.classList.add(St, o.arrowButtonContainer);
        const i = document.createElement("div");
        i.classList.add(At, o.arrowButton);
        const d = a ? o.nextButton : o.previousButton,
            l = document.createElement("button");
        return l.type = "button", l.dataset.tolstoyElement = u(d, s), l.classList.add(d, Ht), a ? (l.classList.add(kt), l.setAttribute("aria-label", "Tolstoy carousel: next button")) : l.setAttribute("aria-label", "Tolstoy carousel: previous button"), l.innerHTML = it, i.append(l), e.append(i), t && e.append(t), e
    },
    Jt = (a, t) => {
        if (!(a != null && a[dt])) return "";
        const s = document.createElement("div");
        return s.classList.add(Pt, o.dotsContainer), s.dataset.tolstoyElement = u(o.dotsContainer, t), s
    },
    ne = ({
        carouselEmbed: a,
        publishId: t,
        featureSettings: s,
        design: e,
        showCreatorProfileLink: i,
        openCreatorProfileLink: d,
        carouselCreatorProfileLinkPosition: l
    }) => {
        var v, T, N, B, b, L, x;
        const {
            carouselPaddingHorizontal: n = 0,
            carouselPaddingVertical: y = 0
        } = a;
        z = !!((N = (T = (v = e == null ? void 0 : e.branding) == null ? void 0 : v.typography) == null ? void 0 : T.font) != null && N.family);
        const c = ((B = Dt(a, t)) == null ? void 0 : B.outerHTML) || "",
            r = ((b = Yt({
                carouselEmbed: a,
                publishId: t,
                featureSettings: s,
                showCreatorProfileLink: i,
                openCreatorProfileLink: d,
                carouselCreatorProfileLinkPosition: l
            })) == null ? void 0 : b.outerHTML) || "",
            m = Zt(a),
            C = ((L = _(!1, m, t)) == null ? void 0 : L.outerHTML) || "",
            $ = ((x = _(!0, m, t)) == null ? void 0 : x.outerHTML) || "",
            g = Jt(s, t).outerHTML || "";
        return `
    <div
      v-pre
      class="${Tt} ${o.carouselContainer}"
      data-tolstoy-element="${u(o.carouselContainer,t)}"
      style="padding: ${y}px ${n}px;"
    >
      ${c}
      <div
        class="${Nt} ${o.videoCarouselContainer}"
        data-tolstoy-element="${u(o.videoCarouselContainer,t)}"
      >
        ${C}
        ${r}
        ${$}
      </div>
      ${g}
    </div>`
    };
export {
    ne as g
};