"use strict";
(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [5912], {
        82146: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return m
                }
            });
            var n = r(87100);
            var i = e => (0, n.Z)(`https://fast.a.klaviyo.com/custom-fonts/api/v1/company-fonts/onsite?company_id=${e}`).then((e => e.json())).catch((e => (console.error(e), Promise.resolve({}))));
            const o = "kl-custom-fonts";
            var s = () => !!document.getElementById(o);
            r(19986), r(26650);
            const a = {
                    100: "0,100",
                    "100italic": "1,100",
                    200: "0,200",
                    "200italic": "1,200",
                    300: "0,300",
                    "300italic": "1,300",
                    regular: "0,400",
                    italic: "1,400",
                    500: "0,500",
                    "500italic": "1,500",
                    600: "0,600",
                    "600italic": "1,600",
                    700: "0,700",
                    "700italic": "1,700",
                    800: "0,800",
                    "800italic": "1,800",
                    900: "0,900",
                    "900italic": "1,900"
                },
                l = e => `@import '${e}';`,
                c = e => {
                    const t = e.family.replace(/ /g, "+"),
                        r = (e => {
                            const t = [];
                            for (const r in e)
                                if (e.hasOwnProperty(r)) {
                                    const n = e[r];
                                    t.push(a[n.variant_value])
                                }
                            return t.sort(), t.join(";")
                        })(e.variants);
                    return 0 === r.length ? "" : `family=${t}:ital,wght@${r}&`
                },
                u = e => `${e}00`;
            var d = e => {
                if (!(e.google && 0 !== e.google.length || e.typekit && 0 !== e.typekit.length || e.custom && 0 !== e.custom.length)) return;
                const {
                    googleImport: t = ""
                } = e.google.length > 0 ? (e => {
                    let t = "https://fonts.googleapis.com/css2?";
                    for (const r in e)
                        if (e.hasOwnProperty(r)) {
                            const n = e[r];
                            t += c(n)
                        }
                    return t += "display=swap", {
                        googleImport: l(t)
                    }
                })(e.google) : {}, {
                    typekitImport: r = ""
                } = e.typekit.length > 0 ? (e => {
                    const t = {};
                    for (const r in e)
                        if (e.hasOwnProperty(r)) {
                            const n = e[r].typekit_url,
                                i = n.slice(n.length - 4);
                            t[l(".css" === i ? n : `${n}.css`)] = !0
                        }
                    let r = "";
                    for (const e in t) t.hasOwnProperty(e) && (r += `${e}\n`);
                    return {
                        typekitImport: r
                    }
                })(e.typekit) : {}, {
                    customImport: n = ""
                } = e.custom.length > 0 ? (e => {
                    let t = "";
                    for (const r in e)
                        if (e.hasOwnProperty(r)) {
                            const n = e[r],
                                {
                                    family: i
                                } = n;
                            for (const e in n.variants)
                                if (n.variants.hasOwnProperty(e)) {
                                    const r = n.variants[e],
                                        o = "i" === r.variant_value[0] ? "italic" : "normal",
                                        s = u(r.variant_value[1]);
                                    t += `@font-face {\n        font-family: '${i}'; \n        src: url(${r.url});\n        font-weight: ${s};\n        font-style: ${o};\n        font-display: swap;\n      }\n`
                                }
                        }
                    return {
                        customImport: t
                    }
                })(e.custom) : {}, i = `\n${t}\n${r}\n${n}`, s = document.head || document.getElementsByTagName("head")[0], a = document.createElement("style");
                a.id = o, a.appendChild(document.createTextNode(i)), s.appendChild(a)
            };
            var m = e => s() ? Promise.resolve() : i(e).then((e => d(e))).catch((e => console.error(e)))
        },
        77585: function(e, t, r) {
            r.d(t, {
                Ax: function() {
                    return s
                },
                VE: function() {
                    return l
                },
                dG: function() {
                    return a
                },
                m$: function() {
                    return i
                },
                qu: function() {
                    return o
                }
            });
            const n = {
                    STARS: !1,
                    REVIEWS: !1,
                    FEATURED: !1
                },
                i = () => n.STARS || n.REVIEWS || n.FEATURED,
                o = () => {
                    n.STARS = !0, n.REVIEWS = !0, n.FEATURED = !0
                },
                s = () => {
                    n.STARS = !1
                },
                a = () => {
                    n.REVIEWS = !1
                },
                l = () => {
                    n.FEATURED = !1
                }
        },
        51363: function(e, t, r) {
            r.d(t, {
                getCustomerSettings: function() {
                    return n
                }
            });
            const n = async (e, t, r) => e.getCustomerSettings(t, r)
        },
        2537: function(e, t, r) {
            r.d(t, {
                $x: function() {
                    return l
                },
                CF: function() {
                    return c
                },
                HE: function() {
                    return i
                },
                I_: function() {
                    return f
                },
                O: function() {
                    return v
                },
                Qh: function() {
                    return a
                },
                VL: function() {
                    return o
                },
                X5: function() {
                    return w
                },
                Z: function() {
                    return d
                },
                ak: function() {
                    return m
                },
                mP: function() {
                    return p
                },
                vD: function() {
                    return s
                },
                yZ: function() {
                    return n
                }
            });
            const n = "https://reviews-media.services.klaviyo.com/abc/width:260/height:260/resizing_type:fill/plain/https://klaviyo.s3.amazonaws.com/reviews/images/",
                i = "https://reviews-media.services.klaviyo.com/abc/width:300/height:300/plain/https://klaviyo.s3.amazonaws.com/reviews/images/",
                o = "https://reviews-media.services.klaviyo.com/abc/width:640/plain/https://klaviyo.s3.amazonaws.com/reviews/images/",
                s = ["fulfilled-reviews-all", "klaviyo-reviews-all", "fulfilled-reviews-summary", "klaviyo-reviews-summary", "fulfilled-reviews-list", "klaviyo-reviews-list"],
                a = ["fulfilled-star-rating-widget", "klaviyo-star-rating-widget"],
                l = ["fulfilled-featured-reviews-carousel", "klaviyo-featured-reviews-carousel"],
                c = `${[...s.map((e=>`#${e}`)),...l.map((e=>`#${e}`)),...a.map((e=>`.${e}`))].join(", ")}:empty`,
                u = {
                    white: "white",
                    lightest: "#EEE",
                    lighter: "rgba(0, 0, 0, 0.05)",
                    light: "rgb(237, 231, 226)",
                    medium: "rgba(0, 0, 0, 0.1)",
                    mediumDark: "rgba(0, 0, 0, 0.15)",
                    dark: "black",
                    starYellow: "#F8BE00",
                    emptyStarGray: "#E5E5E5",
                    accentBlue: "#1C65AD",
                    hoverGray: "#606A72",
                    secondaryFontGray: "#606A72",
                    fontBlack: "#202223",
                    fontGray: "#606A72",
                    filterGray: "rgba( 32, 34, 35, 0.1)"
                },
                d = {
                    starColor: u.starYellow,
                    accentColor: u.accentBlue,
                    primaryFontColor: u.fontBlack,
                    secondaryFontColor: u.fontGray,
                    widgetMargin: {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0
                    },
                    emptyStarColor: u.emptyStarGray,
                    starBorder: void 0,
                    starShape: "star_standard",
                    starSize: "medium",
                    starSpacing: 0,
                    primaryFont: {
                        font_family: "inherit",
                        font_weight: 400
                    },
                    secondaryFont: {
                        font_family: "inherit",
                        font_weight: 400
                    },
                    primaryBackgroundColor: "unset",
                    secondaryBackgroundColor: void 0,
                    cornerRadius: 8,
                    divisionLines: void 0,
                    buttonColor: void 0,
                    buttonCornerRadius: 8,
                    buttonBorder: void 0,
                    buttonHoverColor: u.hoverGray,
                    buttonInnerPadding: {
                        top: 8,
                        right: 8,
                        bottom: 8,
                        left: 8
                    },
                    buttonFont: {
                        font_family: "inherit",
                        font_weight: 400
                    },
                    buttonFontColor: u.white,
                    filterCornerRadius: 24,
                    filterBackgroundColor: u.filterGray,
                    filterShowSearchIcon: !0,
                    filterPlaceholderTextColor: u.fontGray,
                    summaryImagesCornerRadius: 0,
                    reviewImagesCornerRadius: 0,
                    reviewImagesSize: "medium",
                    featuredReviewsPerPage: 3,
                    featuredTextLimit: 3,
                    featuredImageSize: "large",
                    summaryStarSize: "medium",
                    reviewStarSize: "medium",
                    filterButtonBorderWidth: 1,
                    filterButtonLetterSpacing: 0,
                    filterButtonBackgroundColor: void 0,
                    filterButtonBorderColor: void 0,
                    filterButtonFont: void 0,
                    filterButtonCornerRadius: void 0,
                    filterButtonFontColor: void 0,
                    pageSize: 5,
                    displayWithZeroStars: !0,
                    buttonBackgroundColor: u.dark,
                    buttonTextColor: u.white,
                    buttonBorderColor: u.mediumDark,
                    badgeBackgroundColor: u.light,
                    badgeTextColor: u.dark,
                    badgeBorderColor: u.medium,
                    mentionedTitle: "Customers Mentioned",
                    brandResponseTitle: "Store replied",
                    featuredReviewsTitle: "Featured Reviews",
                    writeReviewButtonTitle: "Write a review",
                    askQuestionButtonTitle: "Ask a question",
                    reviewsTabTitle: "Reviews",
                    questionsTabTitle: "Questions",
                    hasSummaryTotalEnabled: !0,
                    hasSummaryMentionedEnabled: !0,
                    hasQuestionsEnabled: !0,
                    showWriteReviewButton: !0,
                    reviewBody: !0,
                    reviewMedia: !0,
                    reviewStars: !0,
                    reviewStoreReply: !0,
                    reviewTitle: !0,
                    reviewAuthor: !0,
                    reviewTimestamp: !0,
                    reviewVerified: !0,
                    reviewIncentivized: !0,
                    reviewQuestions: !0,
                    reviewCustomQuestions: !0,
                    reviewVariant: !1,
                    summaryAverageStars: !0,
                    summaryHistogram: !0,
                    summaryCustomQuestions: !0,
                    summaryReviewImages: !1,
                    showSearchBar: !0,
                    showMediaFilter: !0,
                    showSorting: !0,
                    showRatingFilter: !0,
                    showCustomQuestionsFilters: !0,
                    showVariantFilter: !1,
                    defaultSort: 3,
                    textAlignment: "1",
                    contentAlignment: "1",
                    showFeaturedCarouselHeadline: !1,
                    featuredCarouselHeadline: "",
                    featuredCarouselHeadlineGap: 12,
                    featuredCarouselHeadlineAlignment: "2",
                    displayCarouselImage: "true",
                    showFeaturedCarouselDate: !0,
                    showFeaturedCarouselUsername: !0,
                    showFeaturedCarouselVerifiedBadge: !0,
                    headlinePrimaryFont: {
                        font_family: "inherit",
                        font_weight: 600,
                        font_size: "28px"
                    },
                    headlineFontColor: u.fontBlack,
                    cardColor: u.white,
                    cardShadow: !0,
                    cardBorderColor: "unset",
                    cardBorderWidth: 1,
                    carouselBackgroundColor: "unset",
                    featuredImageFit: "cover",
                    reviewTitleFont: {
                        font_family: "inherit",
                        font_weight: 600
                    },
                    reviewTitleFontColor: u.fontBlack,
                    showStoreReviews: !0,
                    displayStoreReviewsTab: !1,
                    onsiteOverlayColor: "rgba(20, 20, 20, 100)",
                    cardDropShadow: !1,
                    cardDropShadowColor: "rgba(20, 20, 20, 100)",
                    locale: "en_US",
                    i18n: {}
                };
            let m = function(e) {
                    return e[e.SMALL = 16] = "SMALL", e[e.MEDIUM = 20] = "MEDIUM", e[e.LARGE = 24] = "LARGE", e
                }({}),
                v = function(e) {
                    return e[e.SMALL = 12] = "SMALL", e[e.MEDIUM = 16] = "MEDIUM", e[e.LARGE = 20] = "LARGE", e
                }({});
            const p = e => ({
                    free_product: null == e ? void 0 : e.i18n.freeProductIncentiveToolTip,
                    coupon_or_discount: null == e ? void 0 : e.i18n.couponIncentiveToolTip,
                    loyalty_points: null == e ? void 0 : e.i18n.loyaltyPointsIncentiveToolTip,
                    sweepstakes_entry: null == e ? void 0 : e.i18n.sweepstakesIncentiveToolTip,
                    employee_review: null == e ? void 0 : e.i18n.employeeReviewIncentiveToolTip,
                    paid_promotion: null == e ? void 0 : e.i18n.paidPromotionIncentiveToolTip,
                    other: null == e ? void 0 : e.i18n.otherIncentiveToolTip
                }),
                w = "Default Title",
                f = "shop_app"
        },
        23216: function(e, t, r) {
            r.d(t, {
                b: function() {
                    return d
                },
                o: function() {
                    return u
                }
            });
            var n = r(76223),
                i = r(12958);
            r(92461), r(44159);
            const o = (e, t) => {
                    const r = !1 === t,
                        {
                            observerOptions: i = {},
                            duration: o,
                            resetOnLeave: s
                        } = t || {},
                        {
                            threshold: a,
                            root: l,
                            rootMargin: c
                        } = i,
                        u = (0, n.useRef)(null),
                        [d, m] = (0, n.useState)(!1);
                    return (0, n.useEffect)((() => {
                        if (r) return () => {};
                        let t;
                        const n = new IntersectionObserver((r => {
                            r.forEach((r => {
                                r.isIntersecting ? t || (t = window.setTimeout((() => {
                                    !d && e && e(), m(!0)
                                }), o)) : (t && (clearTimeout(t), t = void 0), s && m(!1))
                            }))
                        }), {
                            threshold: a,
                            root: l,
                            rootMargin: c
                        });
                        u.current && n.observe(u.current);
                        const i = u.current;
                        return () => {
                            i && n.disconnect(), clearTimeout(t)
                        }
                    }), [o, s, l, c, a, d, r, e]), u
                },
                s = (e, t) => {
                    const r = !1 === t,
                        {
                            onlyFirst: i = !1
                        } = t || {},
                        o = (0, n.useRef)(null),
                        [s, a] = (0, n.useState)(!1);
                    return (0, n.useEffect)((() => {
                        if (r || s && i) return () => {};
                        const t = o.current,
                            n = t => {
                                e(t), a(!0)
                            };
                        return null == t || t.addEventListener("click", n), () => {
                            null == t || t.removeEventListener("click", n)
                        }
                    }), [r, i, e, s]), o
                };
            var a = r(22580);

            function l(e) {
                return e ? e.classList.length > 0 ? e.classList.toString() : l(e.parentElement) : null
            }
            const c = (0, r(58175).hY)({}).uniqueProps,
                u = () => {
                    const e = (0, a.gY)(),
                        t = (0, a.J9)(),
                        r = (0, a.CB)();
                    return (0, n.useCallback)((async (n, i = {}, {
                        uniqueUserProp: o,
                        uniqueSessionProp: s,
                        uniquePageviewProp: a
                    } = (null != c ? c : {})) => {
                        const l = {
                                metric: n,
                                payload: i
                            },
                            u = {};
                        return e.add(n), t.add(n), r.add(n), o && (u[o] = await e.add(l)), s && (u[s] = await t.add(l)), a && (u[a] = await r.add(l)), u
                    }), [e, t, r])
                },
                d = (e, t) => (r, a) => {
                    var c;
                    const {
                        uniqueProps: d,
                        impression: m = !1,
                        interaction: v = !1
                    } = null != (c = t[r]) ? c : {}, p = u(), w = e(), f = (0, n.useCallback)((async e => {
                        const t = Object.assign({}, a, {
                            eventDetails: Object.assign({}, null == a ? void 0 : a.eventDetails)
                        });
                        "object" == typeof v && v.targetClassProp && (null == e ? void 0 : e.target) instanceof HTMLElement && (t.eventDetails[v.targetClassProp] = l(e.target));
                        const n = await p(r, t, d);
                        Object.assign(t.eventDetails, n), w(r, t)
                    }), [a, v, r, w, d, p]), g = o(f, (0, n.useMemo)((() => !0 === m ? void 0 : m), [m])), y = s(f, (0, n.useMemo)((() => !0 === v ? void 0 : v), [v]));
                    return (0, i.q)(y, g)
                }
        },
        22580: function(e, t, r) {
            r.d(t, {
                gY: function() {
                    return g
                },
                CB: function() {
                    return h
                },
                J9: function() {
                    return y
                }
            });
            r(19986), r(60873);
            var n = r(76223),
                i = r(88187),
                o = r.n(i),
                s = r(20746),
                a = r.n(s),
                l = (r(81383), r(88267), r(31818), r(26266), r(23751), r(42008).lW);

            function c(e) {
                var t, r, n, i = 2;
                for ("undefined" != typeof Symbol && (r = Symbol.asyncIterator, n = Symbol.iterator); i--;) {
                    if (r && null != (t = e[r])) return t.call(e);
                    if (n && null != (t = e[n])) return new u(t.call(e));
                    r = "@@asyncIterator", n = "@@iterator"
                }
                throw new TypeError("Object is not async iterable")
            }

            function u(e) {
                function t(e) {
                    if (Object(e) !== e) return Promise.reject(new TypeError(e + " is not an object."));
                    var t = e.done;
                    return Promise.resolve(e.value).then((function(e) {
                        return {
                            value: e,
                            done: t
                        }
                    }))
                }
                return u = function(e) {
                    this.s = e, this.n = e.next
                }, u.prototype = {
                    s: null,
                    n: null,
                    next: function() {
                        return t(this.n.apply(this.s, arguments))
                    },
                    return: function(e) {
                        var r = this.s.return;
                        return void 0 === r ? Promise.resolve({
                            value: e,
                            done: !0
                        }) : t(r.apply(this.s, arguments))
                    },
                    throw: function(e) {
                        var r = this.s.return;
                        return void 0 === r ? Promise.reject(e) : t(r.apply(this.s, arguments))
                    }
                }, new u(e)
            }
            class d {
                constructor({
                    size: e,
                    numHashes: t,
                    bitArray: r
                }) {
                    this.size = void 0, this.numHashes = void 0, this.bitArray = void 0, this.size = e, this.numHashes = t, this.bitArray = null != r ? r : new Uint8Array(Math.ceil(e / 8))
                }
                async hash(e, t) {
                    var r;
                    const n = (new TextEncoder).encode(`${e}${t}`),
                        i = null != (r = window.crypto) && null != (r = r.subtle) && r.digest ? await window.crypto.subtle.digest("SHA-256", n) : new ArrayBuffer(4);
                    return new DataView(i, 0, 4).getUint32(0) % this.size
                }
                bitIterator(e) {
                    var t = this;
                    return a()((function*() {
                        const r = new Array(t.numHashes).fill(0).map(((r, n) => t.hash(e, n)));
                        var n, i = !1,
                            s = !1;
                        try {
                            for (var a, l = c(r); i = !(a = yield o()(l.next())).done; i = !1) {
                                const e = a.value; {
                                    const r = Math.floor(e / 8),
                                        n = e % 8,
                                        i = t.bitArray[r];
                                    if (void 0 === i) throw new Error("Undefined byte");
                                    const o = i & 1 << n;
                                    yield {
                                        isSet: !!o,
                                        byteIndex: r,
                                        bitIndex: n
                                    }
                                }
                            }
                        } catch (e) {
                            s = !0, n = e
                        } finally {
                            try {
                                i && null != l.return && (yield o()(l.return()))
                            } finally {
                                if (s) throw n
                            }
                        }
                    }))()
                }
                static
                import (e) {
                    const {
                        size: t,
                        numHashes: r,
                        base64BitArray: n
                    } = e, i = new Uint8Array(l.from(n, "base64"));
                    return new d({
                        size: t,
                        numHashes: r,
                        bitArray: i
                    })
                }
                export () {
                    return {
                        size: this.size,
                        numHashes: this.numHashes,
                        base64BitArray: l.from(this.bitArray).toString("base64")
                    }
                }
                async add(e) {
                    let t = !0;
                    var r, n = !1,
                        i = !1;
                    try {
                        for (var o, s = c(this.bitIterator(e)); n = !(o = await s.next()).done; n = !1) {
                            const {
                                bitIndex: e,
                                byteIndex: r,
                                isSet: n
                            } = o.value;
                            if (t = t && n, void 0 === this.bitArray[r]) throw new Error("Undefined byte");
                            this.bitArray[r] |= 1 << e
                        }
                    } catch (e) {
                        i = !0, r = e
                    } finally {
                        try {
                            n && null != s.return && await s.return()
                        } finally {
                            if (i) throw r
                        }
                    }
                    return !t
                }
                async maybeHas(e) {
                    var t, r = !1,
                        n = !1;
                    try {
                        for (var i, o = c(this.bitIterator(e)); r = !(i = await o.next()).done; r = !1) {
                            const {
                                isSet: e
                            } = i.value;
                            if (!e) return !1
                        }
                    } catch (e) {
                        n = !0, t = e
                    } finally {
                        try {
                            r && null != o.return && await o.return()
                        } finally {
                            if (n) throw t
                        }
                    }
                    return !0
                }
            }
            const m = 143776,
                v = 10,
                p = e => {
                    if (!e || "object" != typeof e) return JSON.stringify(e);
                    return Object.entries(e).sort((([e], [t]) => e.localeCompare(t))).map((([e, t]) => `${e}#(${p(t)})`)).join("|")
                },
                w = new Map,
                f = (e, t, r) => {
                    const {
                        size: i = m,
                        numHashes: o = v,
                        bitArray: s
                    } = null != t ? t : {}, a = (0, n.useMemo)((() => {
                        const t = w.get(e);
                        if (t) return t;
                        const n = null == r ? void 0 : r.getItem(e);
                        if (n) try {
                            const t = d.import(JSON.parse(n));
                            return w.set(e, t), t
                        } catch (e) {}
                        const a = new d({
                            size: i,
                            numHashes: o,
                            bitArray: s
                        });
                        return w.set(e, a), a
                    }), [e, r, i, o, s]);
                    return (0, n.useMemo)((() => ({
                        add: t => {
                            const n = a.add(p(t));
                            return null == r || r.setItem(e, JSON.stringify(a.export())), n
                        },
                        maybeHas: e => a.maybeHas(p(e))
                    })), [e, a, r])
                },
                g = (e, t) => f(null != e ? e : "kl-bloom-local", t, window.localStorage),
                y = (e, t) => f(null != e ? e : "kl-bloom-session", t, window.sessionStorage),
                h = (e, t) => {
                    const r = null != e ? e : "kl-bloom-memory",
                        i = (0, n.useMemo)((() => {
                            const e = new Map;
                            return {
                                getItem: t => {
                                    var r;
                                    return null != (r = e.get(t)) ? r : null
                                },
                                setItem: (t, r) => e.set(t, r)
                            }
                        }), []);
                    return f(r, t, i)
                }
        },
        45768: function(e, t, r) {
            r.d(t, {
                Y: function() {
                    return i
                }
            });
            var n = r(76223);
            const i = (e, t) => {
                (0, n.useEffect)((() => {
                    if (null === t) return () => {};
                    const r = setInterval(e, t);
                    return () => {
                        clearInterval(r)
                    }
                }), [e, t])
            }
        },
        12958: function(e, t, r) {
            r.d(t, {
                q: function() {
                    return n
                }
            });
            const n = (...e) => t => {
                for (let r = 0; r < e.length; r += 1) {
                    const n = e[r];
                    n && ("function" == typeof n ? n(t) : "string" != typeof n && (n.current = t))
                }
            }
        },
        76236: function(e, t, r) {
            r.d(t, {
                m: function() {
                    return i
                }
            });
            var n = r(76223);
            const i = (e, t, r) => {
                (0, n.useEffect)((() => (window.addEventListener(e, t, r), () => {
                    window.removeEventListener(e, t, r)
                })), [e, t, r])
            }
        },
        68568: function(e, t, r) {
            r.d(t, {
                LV: function() {
                    return c
                },
                W5: function() {
                    return o
                },
                ed: function() {
                    return s
                },
                l$: function() {
                    return a
                },
                rJ: function() {
                    return i
                },
                u3: function() {
                    return d
                },
                uZ: function() {
                    return u
                },
                wO: function() {
                    return l
                }
            });
            r(26650), r(92461), r(70818), r(39265), r(60873), r(70917), r(93677), r(84304), r(75723), r(20696), r(38528), r(72418), r(60624), r(75479);
            var n = r(2537);
            const i = () => {
                    const e = document.querySelectorAll(n.vD.map((e => `#${e}`)).join(", ")),
                        t = Array.from(e).filter((e => 0 === e.childElementCount)),
                        r = new Set(t.map((e => e.getAttribute("data-id"))));
                    return Array.from(r).filter((e => !!e))
                },
                o = () => {
                    const e = document.querySelectorAll(n.Qh.map((e => `.${e}`)).join(", ")),
                        t = Array.from(e).filter((e => 0 === e.childElementCount)),
                        r = new Set(t.map((e => e.getAttribute("data-id"))));
                    return Array.from(r).filter((e => !!e))
                },
                s = () => {
                    const e = document.querySelector(n.$x.map((e => `#${e}`)).join(", "));
                    return null !== e && 0 === e.childElementCount
                };

            function a(e, t, r, n, i) {
                return (e - t) * (i - n) / (r - t) + n
            }
            const l = () => {
                    const e = new URLSearchParams(window.location.search),
                        t = null == e ? void 0 : e.get("kl_review_uuid");
                    return encodeURI(null != t ? t : "")
                },
                c = () => o().length > 0 || i().length > 0 || s(),
                u = e => {
                    if (!e) return !0;
                    const t = Object.values(e);
                    return 0 === t.length || 0 === t.filter((e => void 0 !== e)).length
                },
                d = () => {
                    var e;
                    const t = document.querySelectorAll(n.CF),
                        r = Array.from(t).find((e => !!e.getAttribute("lang")));
                    return null != (e = null == r ? void 0 : r.getAttribute("lang")) ? e : void 0
                }
        },
        58175: function(e, t, r) {
            r.d(t, {
                __: function() {
                    return y
                },
                ar: function() {
                    return g
                },
                C7: function() {
                    return E
                },
                Fv: function() {
                    return S
                },
                jy: function() {
                    return C
                },
                m: function() {
                    return I
                },
                hY: function() {
                    return b
                }
            });
            r(22923), r(60873);
            var n = r(60093),
                i = r(5832),
                o = r(23216),
                s = r(76223),
                a = r.n(s),
                l = r(76236),
                c = r(45768);

            function u(e, t) {
                switch (t.type) {
                    case "add":
                        return [...e, t.payload];
                    case "reset":
                        return [];
                    default:
                        throw new Error(`Invalid action: ${t}`)
                }
            }
            const d = (0, s.createContext)([]),
                m = (0, s.createContext)((() => {}));
            r(26650);
            const v = e => "string" == typeof e && /^[\da-f]{8}-([\da-f]{4}-){3}[\da-f]{12}$/.test(e),
                p = "kl-uid",
                w = () => {
                    const e = localStorage.getItem(p);
                    if (v(e)) return e;
                    const t = "randomUUID" in window.crypto ? window.crypto.randomUUID() : (() => {
                        const e = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (e => {
                            const t = Math.floor(16 * Math.random());
                            return ("x" === e ? t : t % 4 + 8).toString(16)
                        }));
                        return v(e) ? e : "00000000-0000-4000-8000-000000000000"
                    })();
                    return localStorage.setItem(p, t), t
                },
                f = "reviews-onsite",
                g = {
                    IMPRESSION_STARS: "impression.starsWidget",
                    IMPRESSION_REVIEWS: "impression.reviewsWidget",
                    IMPRESSION_CAROUSEL: "impression.carouselWidget",
                    IMPRESSION_REVIEW: "impression.review",
                    IMPRESSION_CAROUSEL_REVIEW: "impression.carouselReview",
                    IMPRESSION_REVIEW_IMAGE: "impression.reviewImage",
                    IMPRESSION_REVIEWS_PANEL: "impression.reviewsPanel",
                    IMPRESSION_QUESTIONS_PANEL: "impression.questionsPanel",
                    IMPRESSION_QUESTION: "impression.question",
                    IMPRESSION_STORE_REVIEWS_PANEL: "impression.storeReviewsPanel",
                    CLICK_STARS: "click.starsWidget",
                    CLICK_CAROUSEL: "click.carouselWidget",
                    CLICK_REVIEW: "click.review",
                    CLICK_CAROUSEL_REVIEW: "click.carouselReview",
                    CLICK_WRITE_REVIEW: "click.writeReview",
                    CLICK_ASK_QUESTION: "click.askQuestion",
                    CLICK_REVIEWS_TAB: "click.reviewsTab",
                    CLICK_QUESTIONS_TAB: "click.questionsTab",
                    CLICK_QUESTIONS_MORE: "click.questionsMore",
                    CLICK_REVIEWS_MORE: "click.reviewsMore",
                    CLICK_REVIEWS_SORT: "click.reviewsSortFilter",
                    CLICK_QUESTIONS_SORT: "click.questionsSortFilter",
                    CLICK_REVIEWS_RATING_FILTER: "click.reviewsRatingFilter",
                    CLICK_REVIEWS_MEDIA_FILTER: "click.reviewsMediaFilter",
                    CLICK_REVIEWS_VARIANT_FILTER: "click.reviewsVariantFilter",
                    CLICK_REVIEWS_SEARCH: "click.reviewsSearchFilter",
                    CLICK_QUESTIONS_SEARCH: "click.questionsSearchFilter",
                    CLICK_REVIEW_IMAGE: "click.reviewImage",
                    CLICK_SHOPIFY_INSTALL_NOW: "click.shopifyInstallNow",
                    CLICK_STORE_REVIEWS_TAB: "click.storeReviewsTab",
                    PAGEVIEW_STARS: "pageview.starsWidget",
                    PAGEVIEW_REVIEWS: "pageview.reviewsWidget",
                    PAGEVIEW_CAROUSEL: "pageview.carouselWidget",
                    ADD_TO_CART: "external.addedToCart"
                },
                y = Object.assign({}, {
                    HYDRATE_STARS: "hydrate.stars",
                    HYDRATE_REVIEWS: "hydrate.reviews",
                    HYDRATED_FEATURED: "hydrate.featured"
                }, g),
                h = () => ({
                    logToStatsd: !0,
                    logToS3: !0,
                    eventDetails: {
                        device_type: (0, n.Z)() ? "MOBILE" : "DESKTOP",
                        hostname: window.location.hostname,
                        href: window.location.href,
                        page_url: `${window.location.origin}${window.location.pathname}`,
                        uid: w()
                    }
                }),
                S = e => {
                    var t;
                    if (null != (t = window.klaviyoModulesObject) && t.companyId) {
                        const t = h();
                        (0, i.Z)({
                            companyId: window.klaviyoModulesObject.companyId,
                            metricGroup: f,
                            events: [Object.assign({}, t, {
                                metric: e
                            })]
                        })
                    }
                },
                [E, I] = (e => {
                    var t;
                    const {
                        metrics: r,
                        metricGroup: n,
                        sample: o = 1,
                        companyId: v = ("undefined" != typeof window ? null == (t = window.klaviyoModulesObject) ? void 0 : t.companyId : void 0)
                    } = e;
                    return [e => {
                        const {
                            children: t,
                            batchSize: r = 100,
                            frequency: p = 1e4
                        } = e, [w, f] = (0, s.useReducer)(u, []), g = (0, s.useCallback)((() => {
                            v && 0 !== w.length && ((0, i.Z)({
                                companyId: v,
                                events: w,
                                metricGroup: n,
                                sample: o
                            }), f({
                                type: "reset"
                            }))
                        }), [w]);
                        return (0, l.m)("beforeunload", g), (0, c.Y)(g, p), (0, s.useEffect)((() => {
                            w.length >= r && g()
                        }), [w, r, p, g]), a().createElement(d.Provider, {
                            value: w
                        }, a().createElement(m.Provider, {
                            value: f
                        }, t))
                    }, () => {
                        const e = (0, s.useContext)(m);
                        return (0, s.useCallback)(((t, n) => {
                            const i = r[t];
                            if (!i) throw new Error(`Metric not found: ${t.toString()}`);
                            const o = "function" == typeof i ? i() : i,
                                s = t.toString();
                            e({
                                type: "add",
                                payload: Object.assign({}, o, n, {
                                    eventDetails: Object.assign({}, o.eventDetails, null == n ? void 0 : n.eventDetails),
                                    metric: s
                                })
                            })
                        }), [e])
                    }]
                })({
                    metricGroup: f,
                    metrics: (() => {
                        const e = Object.fromEntries(Object.values(g).map((e => [e, () => Object.assign({}, h(), {
                            logToMetricsService: !0,
                            metricServiceEventName: e
                        })])));
                        return e
                    })()
                });

            function b(e) {
                return Object.assign({
                    uniqueProps: {
                        uniqueUserProp: "uniqueUser",
                        uniqueSessionProp: "uniqueSession",
                        uniquePageviewProp: "uniquePageview"
                    }
                }, e)
            }
            const C = (0, o.b)(I, {
                "impression.reviewsWidget": b({
                    impression: {
                        duration: 3e3,
                        observerOptions: {
                            rootMargin: "-200px"
                        },
                        resetOnLeave: !0
                    }
                }),
                "impression.starsWidget": b({
                    impression: {
                        duration: 2e3,
                        observerOptions: {
                            threshold: 1
                        },
                        resetOnLeave: !0
                    }
                }),
                "impression.carouselWidget": b({
                    impression: {
                        duration: 3e3,
                        observerOptions: {
                            rootMargin: "-100px"
                        },
                        resetOnLeave: !0
                    }
                }),
                "impression.review": b({
                    impression: {
                        duration: 3e3,
                        observerOptions: {
                            threshold: .5
                        },
                        resetOnLeave: !0
                    }
                }),
                "impression.carouselReview": b({
                    impression: {
                        duration: 3e3,
                        observerOptions: {
                            rootMargin: "-100px"
                        },
                        resetOnLeave: !0
                    }
                }),
                "impression.reviewImage": b({
                    impression: {
                        duration: 2e3,
                        observerOptions: {
                            threshold: .2
                        },
                        resetOnLeave: !0
                    }
                }),
                "impression.reviewsPanel": b({
                    impression: {
                        duration: 3e3,
                        observerOptions: {
                            rootMargin: "-200px"
                        },
                        resetOnLeave: !0
                    }
                }),
                "impression.questionsPanel": b({
                    impression: {
                        duration: 3e3,
                        observerOptions: {
                            rootMargin: "-200px"
                        },
                        resetOnLeave: !0
                    }
                }),
                "impression.storeReviewsPanel": b({
                    impression: {
                        duration: 3e3,
                        observerOptions: {
                            rootMargin: "-200px"
                        },
                        resetOnLeave: !0
                    }
                }),
                "impression.question": b({
                    impression: {
                        duration: 3e3,
                        observerOptions: {
                            threshold: .5
                        },
                        resetOnLeave: !0
                    }
                }),
                "click.starsWidget": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.carouselWidget": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.review": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.carouselReview": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.writeReview": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.askQuestion": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.reviewsTab": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.questionsTab": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.storeReviewsTab": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.questionsMore": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.reviewsMore": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.reviewsSortFilter": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.reviewsMediaFilter": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.reviewsRatingFilter": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.questionsSortFilter": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.questionsSearchFilter": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.reviewsSearchFilter": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.reviewsVariantFilter": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.reviewImage": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                }),
                "click.shopifyInstallNow": b({
                    interaction: {
                        targetClassProp: "className"
                    }
                })
            })
        },
        23105: function(e, t, r) {
            t.Z = ({
                tracking: e
            }) => {
                var t;
                const n = e ? "https://static-tracking.klaviyo.com/onsite/js/" : "https://static.klaviyo.com/onsite/js/",
                    i = null == (t = window.klaviyoModulesObject) ? void 0 : t.assetSource;
                r.p = i ? `${n}${i}` : n
            }
        },
        18603: function(e, t, r) {
            var n = r(23105),
                i = r(82146),
                o = r(2537),
                s = (r(92461), r(70818), r(44159), r(68568));
            r(60624), r(75479);
            const a = () => window.location.href,
                l = (e, t, r = a) => {
                    const n = r().split("?")[0] || "";
                    if (!n) return null;
                    if (t) {
                        const t = new URL(n).pathname.split("/").filter(Boolean).pop(),
                            r = ((e, t) => {
                                const r = document.querySelectorAll('script[type="application/ld+json"]');
                                for (const n of r) try {
                                    if (n && n.textContent) {
                                        const r = JSON.parse(n.textContent),
                                            i = r["@id"],
                                            o = r["@type"];
                                        if ("ProductGroup" === o && e && e === r.productGroupId) return {
                                            id: i,
                                            type: o
                                        };
                                        if (i && t && i.includes(t)) return {
                                            id: i,
                                            type: o
                                        }
                                    }
                                } catch (e) {
                                    return null
                                }
                                return null
                            })(e.external_id, t || void 0);
                        if (r) return {
                            "@context": "https://schema.org",
                            "@type": r.type,
                            aggregateRating: {
                                "@type": "AggregateRating",
                                ratingValue: `${e.star_rating}`,
                                reviewCount: e.review_count
                            },
                            "@id": r.id
                        }
                    }
                    return {
                        "@context": "https://schema.org",
                        "@type": "Product",
                        aggregateRating: {
                            "@type": "AggregateRating",
                            ratingValue: `${e.star_rating}`,
                            reviewCount: e.review_count
                        },
                        "@id": n,
                        name: e.name
                    }
                };
            var c = r(77585),
                u = r(51363);
            r(39265);
            const d = (e, t) => {
                    if ("all" !== t) return null;
                    const {
                        widgets: r
                    } = e, n = r.find((e => "REVIEWS" === e.widget_type)), i = JSON.parse((null == n ? void 0 : n.json_data) || "{}");
                    return i.show_store_reviews && i.display_store_reviews_tab ? "store" : i.show_store_reviews && !i.display_store_reviews_tab ? "all" : null
                },
                m = async () => {
                    var e;
                    if (null != (e = window) && null != (e = e.klaviyoModulesObject) && e.companyId && (window.klReviewsObject || Object.defineProperty(window, "klReviewsObject", {
                            value: {
                                renderWidgets: m
                            },
                            enumerable: !1
                        }), (0, s.LV)())) {
                        if ((0, c.m$)()) return;
                        (0, c.qu)();
                        const e = (0, s.u3)(),
                            t = (0, s.W5)(),
                            n = (0, s.rJ)(),
                            i = (0, s.ed)(),
                            {
                                onsiteReviewsApi: o
                            } = await Promise.all([r.e(2462), r.e(3867)]).then(r.bind(r, 26320));
                        (0, u.getCustomerSettings)(o, window.klaviyoModulesObject.companyId, e).then((e => {
                            var a, u;
                            t.length > 0 ? o.getReviews({
                                productIds: t,
                                companyId: null != (a = null == (u = window.klaviyoModulesObject) ? void 0 : u.companyId) ? a : ""
                            }).then((({
                                products: t
                            }) => {
                                Promise.all([r.e(2462), r.e(532), r.e(2765), r.e(1094)]).then(r.bind(r, 79769)).then((({
                                    renderStarWidgets: r
                                }) => {
                                    r({
                                        products: t,
                                        settings: e
                                    })
                                }))
                            })) : (0, c.Ax)();
                            const m = Array.from(n).filter((e => !!e));
                            var v, p;
                            (m.length > 0 ? m.forEach(((t, n) => {
                                var i, a, c;
                                const u = (0, s.wO)(),
                                    m = null == (i = window.Shopify) ? void 0 : i.country;
                                o.getReviewsForProduct({
                                    productId: t,
                                    reviewUuid: u,
                                    companyId: null != (a = null == (c = window.klaviyoModulesObject) ? void 0 : c.companyId) ? a : "",
                                    subtype: d(e, t),
                                    limit: 5,
                                    preferredCountry: m
                                }).then((({
                                    product: i,
                                    summary: o,
                                    reviews: s,
                                    shop: a,
                                    has_more: c,
                                    variant_counts: u
                                }) => {
                                    Promise.all([r.e(2462), r.e(532), r.e(2765), r.e(1094)]).then(r.bind(r, 79769)).then((({
                                        renderReviewsWidgets: r
                                    }) => {
                                        r({
                                            product: i,
                                            summary: o,
                                            reviews: s,
                                            settings: e,
                                            hasMore: c,
                                            dataId: t,
                                            shop: a,
                                            variant_counts: u
                                        }), 0 === n && !document.getElementById("kl_reviews_rich_snippet") && a.rich_snippets_enabled && i && i.review_count > 0 && ((e, t) => {
                                            const r = document.createElement("script"),
                                                n = l(e, t);
                                            if (!n) return;
                                            r.setAttribute("id", "kl_reviews_rich_snippet"), r.setAttribute("type", "application/ld+json"), r.textContent = JSON.stringify(n, null, "    ");
                                            const i = document.getElementsByTagName("head")[0];
                                            i && i.appendChild(r)
                                        })(i, "shopify" === a.integration_service_key)
                                    }))
                                }))
                            })) : (0, c.dG)(), i) ? o.getFeaturedReviews({
                                companyId: null != (v = null == (p = window.klaviyoModulesObject) ? void 0 : p.companyId) ? v : ""
                            }).then((({
                                reviews: t
                            }) => {
                                Promise.all([r.e(2462), r.e(532), r.e(2765), r.e(1094)]).then(r.bind(r, 79769)).then((({
                                    renderFeaturedReviewsWidget: r
                                }) => {
                                    r({
                                        reviews: t,
                                        settings: e
                                    })
                                }))
                            })): (0, c.VE)()
                        }))
                    }
                };
            var v = m,
                p = r(76223),
                w = r.n(p),
                f = r(14324),
                g = r(58175);
            var y = async () => {
                if (window.klaviyoReviewsProductDesignMode && !document.querySelector(o.CF)) {
                    var e;
                    const {
                        ShopifyAddWidgetModal: t
                    } = await Promise.all([r.e(2462), r.e(532), r.e(1817)]).then(r.bind(r, 31817)), {
                        onsiteReviewsApi: n
                    } = await Promise.all([r.e(2462), r.e(3867)]).then(r.bind(r, 26320)), {
                        getCustomerSettings: i
                    } = await Promise.resolve().then(r.bind(r, 51363));
                    null != (e = window.klaviyoModulesObject) && e.companyId && i(n, window.klaviyoModulesObject.companyId).then((e => {
                        (0, f.render)(w().createElement(g.C7, null, w().createElement(t, {
                            settings: e
                        })), document.body)
                    }))
                }
            };
            var h = () => {
                Promise.all([r.e(2462), r.e(8689), r.e(4573), r.e(4928)]).then(r.bind(r, 6451)).then((e => {
                    e.evaluateTriggerDefinition({
                        triggers: {
                            triggers: {
                                ELEMENT_EXISTS: {
                                    value: o.CF
                                },
                                DELAY: {
                                    value: 5
                                }
                            }
                        },
                        compoundTriggers: [{
                            triggers: [{
                                triggerType: "ELEMENT_EXISTS",
                                expectedToPass: !0,
                                continuousTrigger: !0
                            }],
                            callback: v
                        }, {
                            triggers: [{
                                triggerType: "DELAY",
                                expectedToPass: !0,
                                continuousTrigger: !1
                            }],
                            callback: y
                        }]
                    })
                }))
            };
            (0, n.Z)({
                tracking: !1
            });
            (() => {
                const e = window.__klKey;
                (0, i.Z)(e), h()
            })()
        }
    },
    function(e) {
        e.O(0, [2462, 4606, 7419], (function() {
            return t = 18603, e(e.s = t);
            var t
        }));
        e.O()
    }
]);