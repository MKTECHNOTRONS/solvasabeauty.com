var __defProp = Object.defineProperty,
    __defProps = Object.defineProperties,
    __getOwnPropDescs = Object.getOwnPropertyDescriptors,
    __getOwnPropSymbols = Object.getOwnPropertySymbols,
    __hasOwnProp = Object.prototype.hasOwnProperty,
    __propIsEnum = Object.prototype.propertyIsEnumerable,
    __defNormalProp = (e, t, r) => t in e ? __defProp(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : e[t] = r,
    __spreadValues = (e, t) => {
        for (var r in t || (t = {})) __hasOwnProp.call(t, r) && __defNormalProp(e, r, t[r]);
        if (__getOwnPropSymbols)
            for (var r of __getOwnPropSymbols(t)) __propIsEnum.call(t, r) && __defNormalProp(e, r, t[r]);
        return e
    },
    __spreadProps = (e, t) => __defProps(e, __getOwnPropDescs(t));
! function(e, t, r, n) {
    "use strict";
    const o = "object" == typeof global && global && global.Object === Object && global;
    var i = "object" == typeof self && self && self.Object === Object && self;
    const d = o || i || Function("return this")();
    const a = d.Symbol;
    var s = Object.prototype,
        u = s.hasOwnProperty,
        l = s.toString,
        c = a ? a.toStringTag : void 0;
    var f = Object.prototype.toString;
    var $ = a ? a.toStringTag : void 0;

    function p(e) {
        return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : $ && $ in Object(e) ? function(e) {
            var t = u.call(e, c),
                r = e[c];
            try {
                e[c] = void 0;
                var n = !0
            } catch (Ln) {}
            var o = l.call(e);
            return n && (t ? e[c] = r : delete e[c]), o
        }(e) : function(e) {
            return f.call(e)
        }(e)
    }

    function h(e) {
        return null != e && "object" == typeof e
    }

    function m(e) {
        return "symbol" == typeof e || h(e) && "[object Symbol]" == p(e)
    }

    function _(e, t) {
        for (var r = -1, n = null == e ? 0 : e.length, o = Array(n); ++r < n;) o[r] = t(e[r], r, e);
        return o
    }
    const y = Array.isArray;
    var v = a ? a.prototype : void 0,
        g = v ? v.toString : void 0;

    function b(e) {
        if ("string" == typeof e) return e;
        if (y(e)) return _(e, b) + "";
        if (m(e)) return g ? g.call(e) : "";
        var t = e + "";
        return "0" == t && 1 / e == -1 / 0 ? "-0" : t
    }
    var w = /\s/;

    function C(e) {
        for (var t = e.length; t-- && w.test(e.charAt(t)););
        return t
    }
    var S = /^\s+/;

    function P(e) {
        return e ? e.slice(0, C(e) + 1).replace(S, "") : e
    }

    function O(e) {
        var t = typeof e;
        return null != e && ("object" == t || "function" == t)
    }
    var x = /^[-+]0x[0-9a-f]+$/i,
        E = /^0b[01]+$/i,
        M = /^0o[0-7]+$/i,
        D = parseInt;
    var N = 1 / 0;

    function I(e) {
        return e ? (e = function(e) {
            if ("number" == typeof e) return e;
            if (m(e)) return NaN;
            if (O(e)) {
                var t = "function" == typeof e.valueOf ? e.valueOf() : e;
                e = O(t) ? t + "" : t
            }
            if ("string" != typeof e) return 0 === e ? e : +e;
            e = P(e);
            var r = E.test(e);
            return r || M.test(e) ? D(e.slice(2), r ? 2 : 8) : x.test(e) ? NaN : +e
        }(e)) === N || e === -1 / 0 ? 17976931348623157e292 * (e < 0 ? -1 : 1) : e == e ? e : 0 : 0 === e ? e : 0
    }

    function k(e) {
        var t = I(e),
            r = t % 1;
        return t == t ? r ? t - r : t : 0
    }

    function T(e) {
        return e
    }

    function A(e) {
        if (!O(e)) return !1;
        var t = p(e);
        return "[object Function]" == t || "[object GeneratorFunction]" == t || "[object AsyncFunction]" == t || "[object Proxy]" == t
    }
    const j = d["__core-js_shared__"];
    var R, L = (R = /[^.]+$/.exec(j && j.keys && j.keys.IE_PROTO || "")) ? "Symbol(src)_1." + R : "";
    var F = Function.prototype.toString;

    function B(e) {
        if (null != e) {
            try {
                return F.call(e)
            } catch (Ln) {}
            try {
                return e + ""
            } catch (Ln) {}
        }
        return ""
    }
    var Y = /^\[object .+?Constructor\]$/,
        U = Function.prototype,
        z = Object.prototype,
        W = U.toString,
        G = z.hasOwnProperty,
        H = RegExp("^" + W.call(G).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");

    function V(e) {
        return !(!O(e) || (t = e, L && L in t)) && (A(e) ? H : Y).test(B(e));
        var t
    }

    function q(e, t) {
        var r = function(e, t) {
            return null == e ? void 0 : e[t]
        }(e, t);
        return V(r) ? r : void 0
    }
    const K = q(d, "WeakMap");
    var Z = Object.create;
    const J = function() {
        function e() {}
        return function(t) {
            if (!O(t)) return {};
            if (Z) return Z(t);
            e.prototype = t;
            var r = new e;
            return e.prototype = void 0, r
        }
    }();
    var X = Date.now;
    var Q = function() {
        try {
            var e = q(Object, "defineProperty");
            return e({}, "", {}), e
        } catch (Ln) {}
    }();
    const ee = Q;
    var te = ee ? function(e, t) {
        return ee(e, "toString", {
            configurable: !0,
            enumerable: !1,
            value: (r = t, function() {
                return r
            }),
            writable: !0
        });
        var r
    } : T;
    var re, ne, oe, ie = (re = te, ne = 0, oe = 0, function() {
        var e = X(),
            t = 16 - (e - oe);
        if (oe = e, t > 0) {
            if (++ne >= 800) return arguments[0]
        } else ne = 0;
        return re.apply(void 0, arguments)
    });
    const de = ie;

    function ae(e) {
        return e != e
    }

    function se(e, t, r) {
        return t == t ? function(e, t, r) {
            for (var n = r - 1, o = e.length; ++n < o;)
                if (e[n] === t) return n;
            return -1
        }(e, t, r) : function(e, t, r, n) {
            for (var o = e.length, i = r + (n ? 1 : -1); n ? i-- : ++i < o;)
                if (t(e[i], i, e)) return i;
            return -1
        }(e, ae, r)
    }
    var ue = /^(?:0|[1-9]\d*)$/;

    function le(e, t) {
        var r = typeof e;
        return !!(t = null == t ? 9007199254740991 : t) && ("number" == r || "symbol" != r && ue.test(e)) && e > -1 && e % 1 == 0 && e < t
    }

    function ce(e, t, r) {
        "__proto__" == t && ee ? ee(e, t, {
            configurable: !0,
            enumerable: !0,
            value: r,
            writable: !0
        }) : e[t] = r
    }

    function fe(e, t) {
        return e === t || e != e && t != t
    }
    var $e = Object.prototype.hasOwnProperty;

    function pe(e, t, r) {
        var n = e[t];
        $e.call(e, t) && fe(n, r) && (void 0 !== r || t in e) || ce(e, t, r)
    }
    var he = Math.max;

    function me(e, t) {
        return de(function(e, t, r) {
            return t = he(void 0 === t ? e.length - 1 : t, 0),
                function() {
                    for (var n = arguments, o = -1, i = he(n.length - t, 0), d = Array(i); ++o < i;) d[o] = n[t + o];
                    o = -1;
                    for (var a = Array(t + 1); ++o < t;) a[o] = n[o];
                    return a[t] = r(d),
                        function(e, t, r) {
                            switch (r.length) {
                                case 0:
                                    return e.call(t);
                                case 1:
                                    return e.call(t, r[0]);
                                case 2:
                                    return e.call(t, r[0], r[1]);
                                case 3:
                                    return e.call(t, r[0], r[1], r[2])
                            }
                            return e.apply(t, r)
                        }(e, this, a)
                }
        }(e, t, T), e + "")
    }

    function _e(e) {
        return "number" == typeof e && e > -1 && e % 1 == 0 && e <= 9007199254740991
    }

    function ye(e) {
        return null != e && _e(e.length) && !A(e)
    }

    function ve(e, t, r) {
        if (!O(r)) return !1;
        var n = typeof t;
        return !!("number" == n ? ye(r) && le(t, r.length) : "string" == n && t in r) && fe(r[t], e)
    }
    var ge = Object.prototype;

    function be(e) {
        var t = e && e.constructor;
        return e === ("function" == typeof t && t.prototype || ge)
    }

    function we(e) {
        return h(e) && "[object Arguments]" == p(e)
    }
    var Ce = Object.prototype,
        Se = Ce.hasOwnProperty,
        Pe = Ce.propertyIsEnumerable,
        Oe = we(function() {
            return arguments
        }()) ? we : function(e) {
            return h(e) && Se.call(e, "callee") && !Pe.call(e, "callee")
        };
    const xe = Oe;
    var Ee = "object" == typeof exports && exports && !exports.nodeType && exports,
        Me = Ee && "object" == typeof module && module && !module.nodeType && module,
        De = Me && Me.exports === Ee ? d.Buffer : void 0;
    const Ne = (De ? De.isBuffer : void 0) || function() {
        return !1
    };
    var Ie = {};

    function ke(e) {
        return function(t) {
            return e(t)
        }
    }
    Ie["[object Float32Array]"] = Ie["[object Float64Array]"] = Ie["[object Int8Array]"] = Ie["[object Int16Array]"] = Ie["[object Int32Array]"] = Ie["[object Uint8Array]"] = Ie["[object Uint8ClampedArray]"] = Ie["[object Uint16Array]"] = Ie["[object Uint32Array]"] = !0, Ie["[object Arguments]"] = Ie["[object Array]"] = Ie["[object ArrayBuffer]"] = Ie["[object Boolean]"] = Ie["[object DataView]"] = Ie["[object Date]"] = Ie["[object Error]"] = Ie["[object Function]"] = Ie["[object Map]"] = Ie["[object Number]"] = Ie["[object Object]"] = Ie["[object RegExp]"] = Ie["[object Set]"] = Ie["[object String]"] = Ie["[object WeakMap]"] = !1;
    var Te = "object" == typeof exports && exports && !exports.nodeType && exports,
        Ae = Te && "object" == typeof module && module && !module.nodeType && module,
        je = Ae && Ae.exports === Te && o.process;
    const Re = function() {
        try {
            var e = Ae && Ae.require && Ae.require("util").types;
            return e || je && je.binding && je.binding("util")
        } catch (Ln) {}
    }();
    var Le = Re && Re.isTypedArray;
    const Fe = Le ? ke(Le) : function(e) {
        return h(e) && _e(e.length) && !!Ie[p(e)]
    };
    var Be = Object.prototype.hasOwnProperty;

    function Ye(e, t) {
        var r = y(e),
            n = !r && xe(e),
            o = !r && !n && Ne(e),
            i = !r && !n && !o && Fe(e),
            d = r || n || o || i,
            a = d ? function(e, t) {
                for (var r = -1, n = Array(e); ++r < e;) n[r] = t(r);
                return n
            }(e.length, String) : [],
            s = a.length;
        for (var u in e) !t && !Be.call(e, u) || d && ("length" == u || o && ("offset" == u || "parent" == u) || i && ("buffer" == u || "byteLength" == u || "byteOffset" == u) || le(u, s)) || a.push(u);
        return a
    }

    function Ue(e, t) {
        return function(r) {
            return e(t(r))
        }
    }
    const ze = Ue(Object.keys, Object);
    var We = Object.prototype.hasOwnProperty;

    function Ge(e) {
        if (!be(e)) return ze(e);
        var t = [];
        for (var r in Object(e)) We.call(e, r) && "constructor" != r && t.push(r);
        return t
    }

    function He(e) {
        return ye(e) ? Ye(e) : Ge(e)
    }
    var Ve = Object.prototype.hasOwnProperty;

    function qe(e) {
        if (!O(e)) return function(e) {
            var t = [];
            if (null != e)
                for (var r in Object(e)) t.push(r);
            return t
        }(e);
        var t = be(e),
            r = [];
        for (var n in e)("constructor" != n || !t && Ve.call(e, n)) && r.push(n);
        return r
    }

    function Ke(e) {
        return ye(e) ? Ye(e, !0) : qe(e)
    }
    var Ze = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
        Je = /^\w*$/;

    function Xe(e, t) {
        if (y(e)) return !1;
        var r = typeof e;
        return !("number" != r && "symbol" != r && "boolean" != r && null != e && !m(e)) || (Je.test(e) || !Ze.test(e) || null != t && e in Object(t))
    }
    const Qe = q(Object, "create");
    var et = Object.prototype.hasOwnProperty;
    var tt = Object.prototype.hasOwnProperty;

    function rt(e) {
        var t = -1,
            r = null == e ? 0 : e.length;
        for (this.clear(); ++t < r;) {
            var n = e[t];
            this.set(n[0], n[1])
        }
    }

    function nt(e, t) {
        for (var r = e.length; r--;)
            if (fe(e[r][0], t)) return r;
        return -1
    }
    rt.prototype.clear = function() {
        this.__data__ = Qe ? Qe(null) : {}, this.size = 0
    }, rt.prototype.delete = function(e) {
        var t = this.has(e) && delete this.__data__[e];
        return this.size -= t ? 1 : 0, t
    }, rt.prototype.get = function(e) {
        var t = this.__data__;
        if (Qe) {
            var r = t[e];
            return "__lodash_hash_undefined__" === r ? void 0 : r
        }
        return et.call(t, e) ? t[e] : void 0
    }, rt.prototype.has = function(e) {
        var t = this.__data__;
        return Qe ? void 0 !== t[e] : tt.call(t, e)
    }, rt.prototype.set = function(e, t) {
        var r = this.__data__;
        return this.size += this.has(e) ? 0 : 1, r[e] = Qe && void 0 === t ? "__lodash_hash_undefined__" : t, this
    };
    var ot = Array.prototype.splice;

    function it(e) {
        var t = -1,
            r = null == e ? 0 : e.length;
        for (this.clear(); ++t < r;) {
            var n = e[t];
            this.set(n[0], n[1])
        }
    }
    it.prototype.clear = function() {
        this.__data__ = [], this.size = 0
    }, it.prototype.delete = function(e) {
        var t = this.__data__,
            r = nt(t, e);
        return !(r < 0) && (r == t.length - 1 ? t.pop() : ot.call(t, r, 1), --this.size, !0)
    }, it.prototype.get = function(e) {
        var t = this.__data__,
            r = nt(t, e);
        return r < 0 ? void 0 : t[r][1]
    }, it.prototype.has = function(e) {
        return nt(this.__data__, e) > -1
    }, it.prototype.set = function(e, t) {
        var r = this.__data__,
            n = nt(r, e);
        return n < 0 ? (++this.size, r.push([e, t])) : r[n][1] = t, this
    };
    const dt = q(d, "Map");

    function at(e, t) {
        var r, n, o = e.__data__;
        return ("string" == (n = typeof(r = t)) || "number" == n || "symbol" == n || "boolean" == n ? "__proto__" !== r : null === r) ? o["string" == typeof t ? "string" : "hash"] : o.map
    }

    function st(e) {
        var t = -1,
            r = null == e ? 0 : e.length;
        for (this.clear(); ++t < r;) {
            var n = e[t];
            this.set(n[0], n[1])
        }
    }
    st.prototype.clear = function() {
        this.size = 0, this.__data__ = {
            hash: new rt,
            map: new(dt || it),
            string: new rt
        }
    }, st.prototype.delete = function(e) {
        var t = at(this, e).delete(e);
        return this.size -= t ? 1 : 0, t
    }, st.prototype.get = function(e) {
        return at(this, e).get(e)
    }, st.prototype.has = function(e) {
        return at(this, e).has(e)
    }, st.prototype.set = function(e, t) {
        var r = at(this, e),
            n = r.size;
        return r.set(e, t), this.size += r.size == n ? 0 : 1, this
    };

    function ut(e, t) {
        if ("function" != typeof e || null != t && "function" != typeof t) throw new TypeError("Expected a function");
        var r = function() {
            var n = arguments,
                o = t ? t.apply(this, n) : n[0],
                i = r.cache;
            if (i.has(o)) return i.get(o);
            var d = e.apply(this, n);
            return r.cache = i.set(o, d) || i, d
        };
        return r.cache = new(ut.Cache || st), r
    }
    ut.Cache = st;
    var lt = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
        ct = /\\(\\)?/g,
        ft = function(e) {
            var t = ut(e, (function(e) {
                    return 500 === r.size && r.clear(), e
                })),
                r = t.cache;
            return t
        }((function(e) {
            var t = [];
            return 46 === e.charCodeAt(0) && t.push(""), e.replace(lt, (function(e, r, n, o) {
                t.push(n ? o.replace(ct, "$1") : r || e)
            })), t
        }));
    const $t = ft;

    function pt(e) {
        return null == e ? "" : b(e)
    }

    function ht(e, t) {
        return y(e) ? e : Xe(e, t) ? [e] : $t(pt(e))
    }

    function mt(e) {
        if ("string" == typeof e || m(e)) return e;
        var t = e + "";
        return "0" == t && 1 / e == -1 / 0 ? "-0" : t
    }

    function _t(e, t) {
        for (var r = 0, n = (t = ht(t, e)).length; null != e && r < n;) e = e[mt(t[r++])];
        return r && r == n ? e : void 0
    }

    function yt(e, t, r) {
        var n = null == e ? void 0 : _t(e, t);
        return void 0 === n ? r : n
    }
    const vt = Ue(Object.getPrototypeOf, Object);
    var gt = Function.prototype,
        bt = Object.prototype,
        wt = gt.toString,
        Ct = bt.hasOwnProperty,
        St = wt.call(Object);

    function Pt(e, t, r) {
        var n = e.length;
        return r = void 0 === r ? n : r, !t && r >= n ? e : function(e, t, r) {
            var n = -1,
                o = e.length;
            t < 0 && (t = -t > o ? 0 : o + t), (r = r > o ? o : r) < 0 && (r += o), o = t > r ? 0 : r - t >>> 0, t >>>= 0;
            for (var i = Array(o); ++n < o;) i[n] = e[n + t];
            return i
        }(e, t, r)
    }
    var Ot = RegExp("[\\u200d\\ud800-\\udfff\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff\\ufe0e\\ufe0f]");

    function xt(e) {
        return Ot.test(e)
    }
    var Et = "\\ud800-\\udfff",
        Mt = "[" + Et + "]",
        Dt = "[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]",
        Nt = "\\ud83c[\\udffb-\\udfff]",
        It = "[^" + Et + "]",
        kt = "(?:\\ud83c[\\udde6-\\uddff]){2}",
        Tt = "[\\ud800-\\udbff][\\udc00-\\udfff]",
        At = "(?:" + Dt + "|" + Nt + ")" + "?",
        jt = "[\\ufe0e\\ufe0f]?",
        Rt = jt + At + ("(?:\\u200d(?:" + [It, kt, Tt].join("|") + ")" + jt + At + ")*"),
        Lt = "(?:" + [It + Dt + "?", Dt, kt, Tt, Mt].join("|") + ")",
        Ft = RegExp(Nt + "(?=" + Nt + ")|" + Lt + Rt, "g");

    function Bt(e) {
        return xt(e) ? function(e) {
            return e.match(Ft) || []
        }(e) : function(e) {
            return e.split("")
        }(e)
    }

    function Yt(e) {
        var t = this.__data__ = new it(e);
        this.size = t.size
    }
    Yt.prototype.clear = function() {
        this.__data__ = new it, this.size = 0
    }, Yt.prototype.delete = function(e) {
        var t = this.__data__,
            r = t.delete(e);
        return this.size = t.size, r
    }, Yt.prototype.get = function(e) {
        return this.__data__.get(e)
    }, Yt.prototype.has = function(e) {
        return this.__data__.has(e)
    }, Yt.prototype.set = function(e, t) {
        var r = this.__data__;
        if (r instanceof it) {
            var n = r.__data__;
            if (!dt || n.length < 199) return n.push([e, t]), this.size = ++r.size, this;
            r = this.__data__ = new st(n)
        }
        return r.set(e, t), this.size = r.size, this
    };
    var Ut = "object" == typeof exports && exports && !exports.nodeType && exports,
        zt = Ut && "object" == typeof module && module && !module.nodeType && module,
        Wt = zt && zt.exports === Ut ? d.Buffer : void 0,
        Gt = Wt ? Wt.allocUnsafe : void 0;
    var Ht = Object.prototype.propertyIsEnumerable,
        Vt = Object.getOwnPropertySymbols;
    const qt = Vt ? function(e) {
        return null == e ? [] : (e = Object(e), function(e, t) {
            for (var r = -1, n = null == e ? 0 : e.length, o = 0, i = []; ++r < n;) {
                var d = e[r];
                t(d, r, e) && (i[o++] = d)
            }
            return i
        }(Vt(e), (function(t) {
            return Ht.call(e, t)
        })))
    } : function() {
        return []
    };

    function Kt(e) {
        return function(e, t, r) {
            var n = t(e);
            return y(e) ? n : function(e, t) {
                for (var r = -1, n = t.length, o = e.length; ++r < n;) e[o + r] = t[r];
                return e
            }(n, r(e))
        }(e, He, qt)
    }
    const Zt = q(d, "DataView");
    const Jt = q(d, "Promise");
    const Xt = q(d, "Set");
    var Qt = "[object Map]",
        er = "[object Promise]",
        tr = "[object Set]",
        rr = "[object WeakMap]",
        nr = "[object DataView]",
        or = B(Zt),
        ir = B(dt),
        dr = B(Jt),
        ar = B(Xt),
        sr = B(K),
        ur = p;
    (Zt && ur(new Zt(new ArrayBuffer(1))) != nr || dt && ur(new dt) != Qt || Jt && ur(Jt.resolve()) != er || Xt && ur(new Xt) != tr || K && ur(new K) != rr) && (ur = function(e) {
        var t = p(e),
            r = "[object Object]" == t ? e.constructor : void 0,
            n = r ? B(r) : "";
        if (n) switch (n) {
            case or:
                return nr;
            case ir:
                return Qt;
            case dr:
                return er;
            case ar:
                return tr;
            case sr:
                return rr
        }
        return t
    });
    const lr = ur;
    const cr = d.Uint8Array;

    function fr(e, t) {
        var r, n, o = t ? (r = e.buffer, n = new r.constructor(r.byteLength), new cr(n).set(new cr(r)), n) : e.buffer;
        return new e.constructor(o, e.byteOffset, e.length)
    }

    function $r(e) {
        var t = -1,
            r = null == e ? 0 : e.length;
        for (this.__data__ = new st; ++t < r;) this.add(e[t])
    }

    function pr(e, t) {
        for (var r = -1, n = null == e ? 0 : e.length; ++r < n;)
            if (t(e[r], r, e)) return !0;
        return !1
    }
    $r.prototype.add = $r.prototype.push = function(e) {
        return this.__data__.set(e, "__lodash_hash_undefined__"), this
    }, $r.prototype.has = function(e) {
        return this.__data__.has(e)
    };

    function hr(e, t, r, n, o, i) {
        var d = 1 & r,
            a = e.length,
            s = t.length;
        if (a != s && !(d && s > a)) return !1;
        var u = i.get(e),
            l = i.get(t);
        if (u && l) return u == t && l == e;
        var c = -1,
            f = !0,
            $ = 2 & r ? new $r : void 0;
        for (i.set(e, t), i.set(t, e); ++c < a;) {
            var p = e[c],
                h = t[c];
            if (n) var m = d ? n(h, p, c, t, e, i) : n(p, h, c, e, t, i);
            if (void 0 !== m) {
                if (m) continue;
                f = !1;
                break
            }
            if ($) {
                if (!pr(t, (function(e, t) {
                        if (d = t, !$.has(d) && (p === e || o(p, e, r, n, i))) return $.push(t);
                        var d
                    }))) {
                    f = !1;
                    break
                }
            } else if (p !== h && !o(p, h, r, n, i)) {
                f = !1;
                break
            }
        }
        return i.delete(e), i.delete(t), f
    }

    function mr(e) {
        var t = -1,
            r = Array(e.size);
        return e.forEach((function(e, n) {
            r[++t] = [n, e]
        })), r
    }

    function _r(e) {
        var t = -1,
            r = Array(e.size);
        return e.forEach((function(e) {
            r[++t] = e
        })), r
    }
    var yr = a ? a.prototype : void 0,
        vr = yr ? yr.valueOf : void 0;
    var gr = Object.prototype.hasOwnProperty;
    var br = "[object Arguments]",
        wr = "[object Array]",
        Cr = "[object Object]",
        Sr = Object.prototype.hasOwnProperty;

    function Pr(e, t, r, n, o, i) {
        var d = y(e),
            a = y(t),
            s = d ? wr : lr(e),
            u = a ? wr : lr(t),
            l = (s = s == br ? Cr : s) == Cr,
            c = (u = u == br ? Cr : u) == Cr,
            f = s == u;
        if (f && Ne(e)) {
            if (!Ne(t)) return !1;
            d = !0, l = !1
        }
        if (f && !l) return i || (i = new Yt), d || Fe(e) ? hr(e, t, r, n, o, i) : function(e, t, r, n, o, i, d) {
            switch (r) {
                case "[object DataView]":
                    if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
                    e = e.buffer, t = t.buffer;
                case "[object ArrayBuffer]":
                    return !(e.byteLength != t.byteLength || !i(new cr(e), new cr(t)));
                case "[object Boolean]":
                case "[object Date]":
                case "[object Number]":
                    return fe(+e, +t);
                case "[object Error]":
                    return e.name == t.name && e.message == t.message;
                case "[object RegExp]":
                case "[object String]":
                    return e == t + "";
                case "[object Map]":
                    var a = mr;
                case "[object Set]":
                    var s = 1 & n;
                    if (a || (a = _r), e.size != t.size && !s) return !1;
                    var u = d.get(e);
                    if (u) return u == t;
                    n |= 2, d.set(e, t);
                    var l = hr(a(e), a(t), n, o, i, d);
                    return d.delete(e), l;
                case "[object Symbol]":
                    if (vr) return vr.call(e) == vr.call(t)
            }
            return !1
        }(e, t, s, r, n, o, i);
        if (!(1 & r)) {
            var $ = l && Sr.call(e, "__wrapped__"),
                p = c && Sr.call(t, "__wrapped__");
            if ($ || p) {
                var h = $ ? e.value() : e,
                    m = p ? t.value() : t;
                return i || (i = new Yt), o(h, m, r, n, i)
            }
        }
        return !!f && (i || (i = new Yt), function(e, t, r, n, o, i) {
            var d = 1 & r,
                a = Kt(e),
                s = a.length;
            if (s != Kt(t).length && !d) return !1;
            for (var u = s; u--;) {
                var l = a[u];
                if (!(d ? l in t : gr.call(t, l))) return !1
            }
            var c = i.get(e),
                f = i.get(t);
            if (c && f) return c == t && f == e;
            var $ = !0;
            i.set(e, t), i.set(t, e);
            for (var p = d; ++u < s;) {
                var h = e[l = a[u]],
                    m = t[l];
                if (n) var _ = d ? n(m, h, l, t, e, i) : n(h, m, l, e, t, i);
                if (!(void 0 === _ ? h === m || o(h, m, r, n, i) : _)) {
                    $ = !1;
                    break
                }
                p || (p = "constructor" == l)
            }
            if ($ && !p) {
                var y = e.constructor,
                    v = t.constructor;
                y == v || !("constructor" in e) || !("constructor" in t) || "function" == typeof y && y instanceof y && "function" == typeof v && v instanceof v || ($ = !1)
            }
            return i.delete(e), i.delete(t), $
        }(e, t, r, n, o, i))
    }

    function Or(e, t, r, n, o) {
        return e === t || (null == e || null == t || !h(e) && !h(t) ? e != e && t != t : Pr(e, t, r, n, Or, o))
    }

    function xr(e) {
        return e == e && !O(e)
    }

    function Er(e, t) {
        return function(r) {
            return null != r && (r[e] === t && (void 0 !== t || e in Object(r)))
        }
    }

    function Mr(e) {
        var t = function(e) {
            for (var t = He(e), r = t.length; r--;) {
                var n = t[r],
                    o = e[n];
                t[r] = [n, o, xr(o)]
            }
            return t
        }(e);
        return 1 == t.length && t[0][2] ? Er(t[0][0], t[0][1]) : function(r) {
            return r === e || function(e, t, r, n) {
                var o = r.length,
                    i = o,
                    d = !n;
                if (null == e) return !i;
                for (e = Object(e); o--;) {
                    var a = r[o];
                    if (d && a[2] ? a[1] !== e[a[0]] : !(a[0] in e)) return !1
                }
                for (; ++o < i;) {
                    var s = (a = r[o])[0],
                        u = e[s],
                        l = a[1];
                    if (d && a[2]) {
                        if (void 0 === u && !(s in e)) return !1
                    } else {
                        var c = new Yt;
                        if (n) var f = n(u, l, s, e, t, c);
                        if (!(void 0 === f ? Or(l, u, 3, n, c) : f)) return !1
                    }
                }
                return !0
            }(r, e, t)
        }
    }

    function Dr(e, t) {
        return null != e && t in Object(e)
    }

    function Nr(e, t) {
        return null != e && function(e, t, r) {
            for (var n = -1, o = (t = ht(t, e)).length, i = !1; ++n < o;) {
                var d = mt(t[n]);
                if (!(i = null != e && r(e, d))) break;
                e = e[d]
            }
            return i || ++n != o ? i : !!(o = null == e ? 0 : e.length) && _e(o) && le(d, o) && (y(e) || xe(e))
        }(e, t, Dr)
    }
    var Ir;

    function kr(e) {
        return Xe(e) ? (t = mt(e), function(e) {
            return null == e ? void 0 : e[t]
        }) : function(e) {
            return function(t) {
                return _t(t, e)
            }
        }(e);
        var t
    }

    function Tr(e) {
        return "function" == typeof e ? e : null == e ? T : "object" == typeof e ? y(e) ? (t = e[0], r = e[1], Xe(t) && xr(r) ? Er(mt(t), r) : function(e) {
            var n = yt(e, t);
            return void 0 === n && n === r ? Nr(e, t) : Or(r, n, 3)
        }) : Mr(e) : kr(e);
        var t, r
    }
    const Ar = function(e, t, r) {
        for (var n = -1, o = Object(e), i = r(e), d = i.length; d--;) {
            var a = i[Ir ? d : ++n];
            if (!1 === t(o[a], a, o)) break
        }
        return e
    };
    var jr = function(e, t) {
        return function(r, n) {
            if (null == r) return r;
            if (!ye(r)) return e(r, n);
            for (var o = r.length, i = t ? o : -1, d = Object(r);
                (t ? i-- : ++i < o) && !1 !== n(d[i], i, d););
            return r
        }
    }((function(e, t) {
        return e && Ar(e, t, He)
    }));
    const Rr = jr;

    function Lr(e, t, r) {
        (void 0 !== r && !fe(e[t], r) || void 0 === r && !(t in e)) && ce(e, t, r)
    }

    function Fr(e, t) {
        if (("constructor" !== t || "function" != typeof e[t]) && "__proto__" != t) return e[t]
    }

    function Br(e) {
        return function(e, t, r, n) {
            var o = !r;
            r || (r = {});
            for (var i = -1, d = t.length; ++i < d;) {
                var a = t[i],
                    s = n ? n(r[a], e[a], a, r, e) : void 0;
                void 0 === s && (s = e[a]), o ? ce(r, a, s) : pe(r, a, s)
            }
            return r
        }(e, Ke(e))
    }

    function Yr(e, t, r, n, o, i, d) {
        var a = Fr(e, r),
            s = Fr(t, r),
            u = d.get(s);
        if (u) Lr(e, r, u);
        else {
            var l, c = i ? i(a, s, r + "", e, t, d) : void 0,
                f = void 0 === c;
            if (f) {
                var $ = y(s),
                    m = !$ && Ne(s),
                    _ = !$ && !m && Fe(s);
                c = s, $ || m || _ ? y(a) ? c = a : h(l = a) && ye(l) ? c = function(e, t) {
                    var r = -1,
                        n = e.length;
                    for (t || (t = Array(n)); ++r < n;) t[r] = e[r];
                    return t
                }(a) : m ? (f = !1, c = function(e, t) {
                    if (t) return e.slice();
                    var r = e.length,
                        n = Gt ? Gt(r) : new e.constructor(r);
                    return e.copy(n), n
                }(s, !0)) : _ ? (f = !1, c = fr(s, !0)) : c = [] : function(e) {
                    if (!h(e) || "[object Object]" != p(e)) return !1;
                    var t = vt(e);
                    if (null === t) return !0;
                    var r = Ct.call(t, "constructor") && t.constructor;
                    return "function" == typeof r && r instanceof r && wt.call(r) == St
                }(s) || xe(s) ? (c = a, xe(a) ? c = Br(a) : O(a) && !A(a) || (c = function(e) {
                    return "function" != typeof e.constructor || be(e) ? {} : J(vt(e))
                }(s))) : f = !1
            }
            f && (d.set(s, c), o(c, s, n, i, d), d.delete(s)), Lr(e, r, c)
        }
    }

    function Ur(e, t, r, n, o) {
        e !== t && Ar(t, (function(i, d) {
            if (o || (o = new Yt), O(i)) Yr(e, t, d, r, Ur, n, o);
            else {
                var a = n ? n(Fr(e, d), i, d + "", e, t, o) : void 0;
                void 0 === a && (a = i), Lr(e, d, a)
            }
        }), Ke)
    }

    function zr(e, t) {
        for (var r = -1, n = null == e ? 0 : e.length; ++r < n;)
            if (!t(e[r], r, e)) return !1;
        return !0
    }

    function Wr(e, t) {
        var r = !0;
        return Rr(e, (function(e, n, o) {
            return r = !!t(e, n, o)
        })), r
    }

    function Gr(e) {
        return null == e ? [] : function(e, t) {
            return _(t, (function(t) {
                return e[t]
            }))
        }(e, He(e))
    }
    var Hr = Math.max;

    function Vr(e, t, r, n) {
        e = ye(e) ? e : Gr(e), r = r && !n ? k(r) : 0;
        var o = e.length;
        return r < 0 && (r = Hr(o + r, 0)),
            function(e) {
                return "string" == typeof e || !y(e) && h(e) && "[object String]" == p(e)
            }(e) ? r <= o && e.indexOf(t, r) > -1 : !!o && se(e, t, r) > -1
    }
    var qr = Object.prototype.hasOwnProperty;

    function Kr(e) {
        if (null == e) return !0;
        if (ye(e) && (y(e) || "string" == typeof e || "function" == typeof e.splice || Ne(e) || Fe(e) || xe(e))) return !e.length;
        var t = lr(e);
        if ("[object Map]" == t || "[object Set]" == t) return !e.size;
        if (be(e)) return !Ge(e).length;
        for (var r in e)
            if (qr.call(e, r)) return !1;
        return !0
    }

    function Zr(e) {
        return null == e
    }
    var Jr = Re && Re.isRegExp;
    const Xr = Jr ? ke(Jr) : function(e) {
        return h(e) && "[object RegExp]" == p(e)
    };
    var Qr;
    const en = (Qr = function(e, t, r) {
        Ur(e, t, r)
    }, me((function(e, t) {
        var r = -1,
            n = t.length,
            o = n > 1 ? t[n - 1] : void 0,
            i = n > 2 ? t[2] : void 0;
        for (o = Qr.length > 3 && "function" == typeof o ? (n--, o) : void 0, i && ve(t[0], t[1], i) && (o = n < 3 ? void 0 : o, n = 1), e = Object(e); ++r < n;) {
            var d = t[r];
            d && Qr(e, d, r, o)
        }
        return e
    })));

    function tn(e, t, r) {
        return null == e ? e : function(e, t, r, n) {
            if (!O(e)) return e;
            for (var o = -1, i = (t = ht(t, e)).length, d = i - 1, a = e; null != a && ++o < i;) {
                var s = mt(t[o]),
                    u = r;
                if ("__proto__" === s || "constructor" === s || "prototype" === s) return e;
                if (o != d) {
                    var l = a[s];
                    void 0 === (u = n ? n(l, s, a) : void 0) && (u = O(l) ? l : le(t[o + 1]) ? [] : {})
                }
                pe(a, s, u), a = a[s]
            }
            return e
        }(e, t, r)
    }

    function rn(e, t) {
        var r;
        return Rr(e, (function(e, n, o) {
            return !(r = t(e, n, o))
        })), !!r
    }

    function nn(e, t, r) {
        return r && "number" != typeof r && ve(e, t, r) && (t = r = void 0), (r = void 0 === r ? 4294967295 : r >>> 0) ? (e = pt(e)) && ("string" == typeof t || null != t && !Xr(t)) && !(t = b(t)) && xt(e) ? Pt(Bt(e), 0, r) : e.split(t, r) : []
    }

    function on(e, t) {
        for (var r = e.length; r-- && se(t, e[r], 0) > -1;);
        return r
    }

    function dn(e, t, r) {
        if ((e = pt(e)) && (r || void 0 === t)) return P(e);
        if (!e || !(t = b(t))) return e;
        var n = Bt(e),
            o = Bt(t),
            i = function(e, t) {
                for (var r = -1, n = e.length; ++r < n && se(t, e[r], 0) > -1;);
                return r
            }(n, o);
        return Pt(n, i, on(n, o) + 1).join("")
    }

    function an(e, t, r) {
        if ((e = pt(e)) && (r || void 0 === t)) return e.slice(0, C(e) + 1);
        if (!e || !(t = b(t))) return e;
        var n = Bt(e);
        return Pt(n, 0, on(n, Bt(t)) + 1).join("")
    }
    const sn = {
            VITE_APP_ENV: "production",
            VITE_API_URL: "https://api.ecomsend.com",
            VITE_API_URL_GO: "https://ecomsend-go.ecomsend.com",
            VITE_DEFAULT_LANG: "en",
            VITE_COOKIE_NAME_PREFIX: "ecomsend_",
            VITE_SHOPIFY_API_KEY: "bda73e80e3a30463cb353d7ee7aa3edc",
            VITE_EXTENSION_UUID: "a5670cf8-5705-4b01-ad9e-447033feae26",
            VITE_CHANNELWILL_PAGE_URL: "https://aio-apps.channelwill.com",
            BASE_URL: "/",
            MODE: "production",
            DEV: !1,
            PROD: !0,
            SSR: !1
        },
        un = {
            get env() {
                return sn.VITE_APP_ENV
            },
            get mode() {
                return sn.MODE
            },
            get isDev() {
                return sn.DEV
            },
            get isProd() {
                return sn.PROD
            },
            get mockLoginUid() {
                return Number(sn.VITE_MOCK_LOGIN_UID)
            },
            get apiURL() {
                return sn.VITE_API_URL
            },
            get apiURLGo() {
                return sn.VITE_API_URL_GO
            },
            get shopifyApiKey() {
                return sn.VITE_SHOPIFY_API_KEY
            },
            get defaultLang() {
                return sn.VITE_DEFAULT_LANG
            },
            get enableHttpReplaceHttps() {
                return "true" === sn.VITE_ENABLE_HTTP_REPLACE_HTTPS
            },
            get extensionUUID() {
                return sn.VITE_EXTENSION_UUID
            },
            get i18nDebug() {
                return "true" === sn.VITE_I18N_DEBUG
            },
            get cookieNamePrefix() {
                return sn.VITE_COOKIE_NAME_PREFIX
            },
            get pluginIsPreview() {
                return "true" === sn.VITE_PLUGIN_IS_PREVIEW
            },
            get pluginBuildTime() {
                return sn.VITE_PLUGIN_BUILD_TIME
            }
        },
        ln = new URLSearchParams(window.location.search),
        cn = yt(window, "EcomSendApps.common.shop.id", ln.get("shop-id")),
        fn = `${un.apiURL}/v2/store-frontend/${cn}/popups`,
        $n = {
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json"
        },
        pn = {
            getConfig: async e => new Promise(((t, r) => {
                (async (e = "", t = {}, r = "GET") => {
                    let n = {
                        method: r,
                        headers: {
                            "Access-Control-Allow-Origin": "*",
                            "Content-Type": "application/json"
                        }
                    };
                    if ("GET" == (r = r.toUpperCase())) {
                        let r = "";
                        Object.keys(t).forEach((e => {
                            r += e + "=" + t[e] + "&"
                        })), "" !== r && (r = r.substr(0, r.lastIndexOf("&")), e = e + "?" + r)
                    }
                    "POST" == r && Object.defineProperty(n, "body", {
                        value: JSON.stringify(t)
                    });
                    try {
                        const t = await fetch(e, n);
                        return await t.json()
                    } catch (o) {
                        throw new Error(o)
                    }
                })(`${fn}/${e||""}`).then((e => {
                    t(e)
                })).catch((e => {
                    r(e)
                }))
            })),
            async subscribed(e) {
                const {
                    popupId: t,
                    email: r,
                    first_name: n,
                    last_name: o,
                    phone: i,
                    birthday: d,
                    gdpr: a,
                    tcpa: s,
                    year: u,
                    month: l,
                    day: c
                } = e, f = {
                    email: r,
                    first_name: n,
                    last_name: o,
                    phone: i || void 0,
                    gdpr: a,
                    tcpa: s,
                    birthday: d,
                    locale: window.shopLocale,
                    referrer: window.location.href
                }, $ = await fetch(`${fn}/${t}/draw`, {
                    body: JSON.stringify(f),
                    headers: $n,
                    cache: "no-cache",
                    method: "POST"
                });
                return {
                    data: await $.json(),
                    status: $.status
                }
            },
            sendReport(e, t) {
                const r = {
                    popup_id: e
                };
                fetch(`${fn}/${e}/hello`, {
                    body: JSON.stringify(r),
                    cache: "no-cache",
                    headers: $n,
                    method: "POST"
                }).then((e => null))
            }
        };
    var hn = (e => (e[e.ANY = 0] = "ANY", e[e.IN = 1] = "IN", e[e.NOTIN = 2] = "NOTIN", e))(hn || {}),
        mn = (e => (e[e.ALL = 0] = "ALL", e[e.PERIOD = 1] = "PERIOD", e))(mn || {}),
        _n = (e => (e.PercentageOff = "0", e.FixedAmount = "1", e.FreeShipping = "2", e))(_n || {}),
        yn = (e => (e.LEFT = "left", e.RIGHT = "right", e))(yn || {}),
        vn = (e => (e[e.AFTER_POPUP_IS_CLOSED = 0] = "AFTER_POPUP_IS_CLOSED", e[e.BEFORE_DISPLAYING_POPUP = 2] = "BEFORE_DISPLAYING_POPUP", e[e.AFTER_POPUP_IS_CLOSED_AND_BEFORE_DISPLAYING_POPUP = 4] = "AFTER_POPUP_IS_CLOSED_AND_BEFORE_DISPLAYING_POPUP", e))(vn || {}),
        gn = (e => (e[e.Timer = 0] = "Timer", e[e.ExitingPage = 1] = "ExitingPage", e[e.ScrollingPage = 2] = "ScrollingPage", e))(gn || {}),
        bn = (e => (e[e.EveryTime = 0] = "EveryTime", e[e.Limit = 1] = "Limit", e))(bn || {}),
        wn = (e => (e.Minute = "minute", e.Hour = "hour", e.Day = "day", e.Week = "week", e.Month = "month", e.Year = "year", e))(wn || {}),
        Cn = (e => (e.All = "all", e.Desktop = "desktop", e.Mobile = "mobile", e))(Cn || {}),
        Sn = (e => (e[e.AnyPage = 0] = "AnyPage", e[e.SpecificPage = 1] = "SpecificPage", e))(Sn || {}),
        Pn = (e => (e.Equals = "0", e.DoesNotEqual = "1", e.Contains = "2", e.DoesNotContain = "3", e.IsHomepage = "4", e.IsNotHomepage = "5", e))(Pn || {}),
        On = (e => (e[e.OR = 0] = "OR", e[e.AND = 1] = "AND", e))(On || {}),
        xn = (e => (e.NAME = "name", e.EMAIL = "email", e.PHONE = "phone", e.GDPR = "gdpr", e.TCPA = "tcpa", e.BIRTHDAY = "birthday", e))(xn || {}),
        En = (e => (e.BOTH = "both", e.FIRST = "first_name", e.LAST = "last_name", e))(En || {}),
        Mn = (e => (e.SUBMIT = "submit", e.CLOSE = "close", e.LINK = "url", e))(Mn || {}),
        Dn = (e => (e.MMDDYYYY = "MM/DD/YYYY", e.DDMMYYYY = "DD/MM/YYYY", e.YYYYMMDD = "YYYY/MM/DD", e))(Dn || {}),
        Nn = (e => (e[e.Close = 0] = "Close", e[e.OpenSpecificPage = 1] = "OpenSpecificPage", e))(Nn || {}),
        In = (e => (e.SpinWheel = "spin-wheel", e.OptIn = "opt-in", e))(In || {});
    const kn = {
        rules: {
            rewards: [{
                label: "10% OFF",
                chance: 40,
                discount_coupon: {
                    value: "discount_code",
                    discount_code: {
                        ttl: 1,
                        type: "1",
                        value: 100,
                        has_ttl: !1
                    },
                    manually_code: ""
                }
            }, {
                label: "No luck",
                chance: 0,
                discount_coupon: {
                    value: "no_discount",
                    discount_code: {
                        ttl: 1,
                        type: "0",
                        value: 0,
                        has_ttl: !1
                    },
                    manually_code: ""
                }
            }, {
                label: "15% OFF",
                chance: 30,
                discount_coupon: {
                    value: "discount_code",
                    discount_code: {
                        ttl: 1,
                        type: "0",
                        value: 15,
                        has_ttl: !1
                    },
                    manually_code: ""
                }
            }, {
                label: "Sorry...",
                chance: 0,
                discount_coupon: {
                    value: "no_discount",
                    discount_code: {
                        ttl: 1,
                        type: "0",
                        value: 0,
                        has_ttl: !1
                    },
                    manually_code: ""
                }
            }, {
                label: "Free shipping",
                chance: 30,
                discount_coupon: {
                    value: "discount_code",
                    discount_code: {
                        ttl: 1,
                        type: "2",
                        value: 0,
                        has_ttl: !1
                    },
                    manually_code: ""
                }
            }, {
                label: "Almost",
                chance: 0,
                discount_coupon: {
                    value: "no_discount",
                    discount_code: {
                        ttl: 1,
                        type: "0",
                        value: 0,
                        has_ttl: !1
                    },
                    manually_code: ""
                }
            }],
            discount_coupon: {
                discount_code: {
                    has_ttl: !0,
                    ttl: 1,
                    type: _n.PercentageOff,
                    value: 10
                },
                manually_code: "",
                value: "discount_code"
            },
            marketing_branding: {
                remove_powered_by: !1
            },
            location: { in: [],
                type: 0,
                not_in: []
            },
            schedule: {
                type: 0,
                end_unix: -1,
                start_unix: -1,
                has_end_unix: !1
            },
            page_display_rules: {
                match_mode: On.OR,
                specific_page: [{
                    operator: Pn.Equals,
                    type: "url",
                    value: ""
                }],
                type: Sn.AnyPage
            },
            sidebar_widget: {
                show: !1,
                show_position: yn.LEFT
            },
            sticky_discount_bar: !1,
            trigger: {
                devices: Cn.All,
                frequency: {
                    limit: {
                        per: wn.Day,
                        value: 2
                    },
                    type: bn.EveryTime
                },
                when: {
                    scroll_offset: 50,
                    timeout: 0,
                    type: gn.Timer
                }
            }
        },
        style: {
            colors: {
                checkbox: "#454545",
                input: "#121212",
                error_color: "#D72C0D",
                footer_text_color: "#6D7175",
                popup_background_color: "#FFFFFF",
                primary_button_background_color: "#202223",
                primary_button_text_color: "#FFFFFF",
                secondary_button: "#202223",
                sidebar_widget_background_color: "#202223",
                sidebar_widget_text_color: "#FFFFFF",
                sticky_discount_bar_background_color: "#121127",
                sticky_discount_bar_text_color: "#FFFFFF",
                text_description_color: "#6D7175",
                text_heading_color: "#202223",
                wheel: {}
            },
            css: "body{color:red}",
            display: {
                align: "center",
                corner_radius: "standard",
                size: "standard"
            },
            layout: {
                image_position: "none",
                image_mobile_position: "none",
                image_url: "",
                hide_on_mobile: !1
            },
            logo: {
                url: "",
                width: 65
            }
        },
        text: {
            error_text: {
                already_subscribed: "You have already subscribed",
                first_name: "Please enter your first name",
                invalid_email: "Please enter valid email address!",
                last_name: "Please enter your last name",
                submit_error: "Sorry, please try again later",
                phone_number: "Please enter valid phone number",
                policy_not_checked: "Please check the policy"
            },
            sidebar_widget: {
                button_text: "Get 10% OFF"
            },
            start_status: {
                heading: "Get 10% OFF your order",
                description: "Sign up and unlock your instant discount.",
                footer_text: "You are signing up to receive communication via email and can unsubscribe at any time.",
                actions: {
                    primary_btn: {
                        link: "",
                        text: "Claim discount",
                        action: Mn.SUBMIT,
                        enabled: !0,
                        new_context: !0
                    },
                    secondary_btn: {
                        link: "",
                        text: "No, thanks",
                        action: Mn.CLOSE,
                        enabled: !0,
                        new_context: !0
                    }
                },
                forms: {
                    email: {
                        enabled: !0,
                        required: !0,
                        placeholder: "Email address"
                    },
                    gdpr: {
                        content: "<p>I agree to receive marketing emails</p>",
                        enabled: !1
                    },
                    name: {
                        layout: "vertical",
                        enabled: !1,
                        field_type: En.BOTH,
                        first_name: {
                            required: !0,
                            placeholder: "First name"
                        },
                        last_name: {
                            required: !0,
                            placeholder: "Last name"
                        }
                    },
                    phone: {
                        country: "US",
                        enabled: !1,
                        required: !0,
                        placeholder: "Phone number"
                    },
                    tcpa: {
                        content: "<p>By signing up, you agree to receive recurring automated marketing messages at the phone number provided. Consent is not a condition of purchase. Reply STOP to unsubscribe. Msg frequency varies. Msg & data rates may apply. View Privacy Policy & Terms.</p>",
                        enabled: !1
                    },
                    birthday: {
                        day: {
                            placeholder: "DD"
                        },
                        enabled: !1,
                        format: "MM/DD/YYYY",
                        month: {
                            placeholder: "MM"
                        },
                        label: "Birthday",
                        required: !0,
                        year: {
                            placeholder: "YYYY"
                        }
                    }
                },
                forms_index: [xn.EMAIL]
            },
            sticky_discount_bar: {
                description: "Don't forget to use your discount code"
            },
            success_status: {
                button_action: {
                    enabled: !0,
                    open_specific_page: "",
                    open_specific_page_new_window: !1,
                    type: Nn.Close
                },
                button_text: "Shop now",
                description: "Thanks for subscribing. Copy your discount code and apply to your next order.",
                heading: "Discount unlocked 🎉"
            }
        },
        template: {
            id: 1,
            slug: 'opt-in__1"',
            type: In.OptIn
        }
    };
    var Tn, An;
    let jn = (Tn = e.action.bound, Rn = (An = class {
        constructor() {
            this.template = kn.template, this.rules = kn.rules, this.text = kn.text, this.style = kn.style, this.discount_code = void 0, this.id = 0, e.makeAutoObservable(this)
        }
        setStoreConfig(e) {
            this.id = e.id, this.rules = e.rules, this.text = e.text, this.style = e.style, e.template && (this.template = e.template)
        }
        setConfig(e, t) {
            tn(this, e, t)
        }
    }).prototype, Ln = "setStoreConfig", Fn = [Tn], Bn = Object.getOwnPropertyDescriptor(An.prototype, "setStoreConfig"), Yn = An.prototype, Un = {}, Object.keys(Bn).forEach((function(e) {
        Un[e] = Bn[e]
    })), Un.enumerable = !!Un.enumerable, Un.configurable = !!Un.configurable, ("value" in Un || Un.initializer) && (Un.writable = !0), Un = Fn.slice().reverse().reduce((function(e, t) {
        return t(Rn, Ln, e) || e
    }), Un), Yn && void 0 !== Un.initializer && (Un.value = Un.initializer ? Un.initializer.call(Yn) : void 0, Un.initializer = void 0), void 0 === Un.initializer && Object.defineProperty(Rn, Ln, Un), An);
    var Rn, Ln, Fn, Bn, Yn, Un, zn = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

    function Wn(e) {
        return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
    }
    var Gn = {
        exports: {}
    };
    Gn.exports = function() {
        var e = 1e3,
            t = 6e4,
            r = 36e5,
            n = "millisecond",
            o = "second",
            i = "minute",
            d = "hour",
            a = "day",
            s = "week",
            u = "month",
            l = "quarter",
            c = "year",
            f = "date",
            $ = "Invalid Date",
            p = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,
            h = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,
            m = {
                name: "en",
                weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
                months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
                ordinal: function(e) {
                    var t = ["th", "st", "nd", "rd"],
                        r = e % 100;
                    return "[" + e + (t[(r - 20) % 10] || t[r] || t[0]) + "]"
                }
            },
            _ = function(e, t, r) {
                var n = String(e);
                return !n || n.length >= t ? e : "" + Array(t + 1 - n.length).join(r) + e
            },
            y = {
                s: _,
                z: function(e) {
                    var t = -e.utcOffset(),
                        r = Math.abs(t),
                        n = Math.floor(r / 60),
                        o = r % 60;
                    return (t <= 0 ? "+" : "-") + _(n, 2, "0") + ":" + _(o, 2, "0")
                },
                m: function e(t, r) {
                    if (t.date() < r.date()) return -e(r, t);
                    var n = 12 * (r.year() - t.year()) + (r.month() - t.month()),
                        o = t.clone().add(n, u),
                        i = r - o < 0,
                        d = t.clone().add(n + (i ? -1 : 1), u);
                    return +(-(n + (r - o) / (i ? o - d : d - o)) || 0)
                },
                a: function(e) {
                    return e < 0 ? Math.ceil(e) || 0 : Math.floor(e)
                },
                p: function(e) {
                    return {
                        M: u,
                        y: c,
                        w: s,
                        d: a,
                        D: f,
                        h: d,
                        m: i,
                        s: o,
                        ms: n,
                        Q: l
                    }[e] || String(e || "").toLowerCase().replace(/s$/, "")
                },
                u: function(e) {
                    return void 0 === e
                }
            },
            v = "en",
            g = {};
        g[v] = m;
        var b = "$isDayjsObject",
            w = function(e) {
                return e instanceof O || !(!e || !e[b])
            },
            C = function e(t, r, n) {
                var o;
                if (!t) return v;
                if ("string" == typeof t) {
                    var i = t.toLowerCase();
                    g[i] && (o = i), r && (g[i] = r, o = i);
                    var d = t.split("-");
                    if (!o && d.length > 1) return e(d[0])
                } else {
                    var a = t.name;
                    g[a] = t, o = a
                }
                return !n && o && (v = o), o || !n && v
            },
            S = function(e, t) {
                if (w(e)) return e.clone();
                var r = "object" == typeof t ? t : {};
                return r.date = e, r.args = arguments, new O(r)
            },
            P = y;
        P.l = C, P.i = w, P.w = function(e, t) {
            return S(e, {
                locale: t.$L,
                utc: t.$u,
                x: t.$x,
                $offset: t.$offset
            })
        };
        var O = function() {
                function m(e) {
                    this.$L = C(e.locale, null, !0), this.parse(e), this.$x = this.$x || e.x || {}, this[b] = !0
                }
                var _ = m.prototype;
                return _.parse = function(e) {
                    this.$d = function(e) {
                        var t = e.date,
                            r = e.utc;
                        if (null === t) return new Date(NaN);
                        if (P.u(t)) return new Date;
                        if (t instanceof Date) return new Date(t);
                        if ("string" == typeof t && !/Z$/i.test(t)) {
                            var n = t.match(p);
                            if (n) {
                                var o = n[2] - 1 || 0,
                                    i = (n[7] || "0").substring(0, 3);
                                return r ? new Date(Date.UTC(n[1], o, n[3] || 1, n[4] || 0, n[5] || 0, n[6] || 0, i)) : new Date(n[1], o, n[3] || 1, n[4] || 0, n[5] || 0, n[6] || 0, i)
                            }
                        }
                        return new Date(t)
                    }(e), this.init()
                }, _.init = function() {
                    var e = this.$d;
                    this.$y = e.getFullYear(), this.$M = e.getMonth(), this.$D = e.getDate(), this.$W = e.getDay(), this.$H = e.getHours(), this.$m = e.getMinutes(), this.$s = e.getSeconds(), this.$ms = e.getMilliseconds()
                }, _.$utils = function() {
                    return P
                }, _.isValid = function() {
                    return !(this.$d.toString() === $)
                }, _.isSame = function(e, t) {
                    var r = S(e);
                    return this.startOf(t) <= r && r <= this.endOf(t)
                }, _.isAfter = function(e, t) {
                    return S(e) < this.startOf(t)
                }, _.isBefore = function(e, t) {
                    return this.endOf(t) < S(e)
                }, _.$g = function(e, t, r) {
                    return P.u(e) ? this[t] : this.set(r, e)
                }, _.unix = function() {
                    return Math.floor(this.valueOf() / 1e3)
                }, _.valueOf = function() {
                    return this.$d.getTime()
                }, _.startOf = function(e, t) {
                    var r = this,
                        n = !!P.u(t) || t,
                        l = P.p(e),
                        $ = function(e, t) {
                            var o = P.w(r.$u ? Date.UTC(r.$y, t, e) : new Date(r.$y, t, e), r);
                            return n ? o : o.endOf(a)
                        },
                        p = function(e, t) {
                            return P.w(r.toDate()[e].apply(r.toDate("s"), (n ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(t)), r)
                        },
                        h = this.$W,
                        m = this.$M,
                        _ = this.$D,
                        y = "set" + (this.$u ? "UTC" : "");
                    switch (l) {
                        case c:
                            return n ? $(1, 0) : $(31, 11);
                        case u:
                            return n ? $(1, m) : $(0, m + 1);
                        case s:
                            var v = this.$locale().weekStart || 0,
                                g = (h < v ? h + 7 : h) - v;
                            return $(n ? _ - g : _ + (6 - g), m);
                        case a:
                        case f:
                            return p(y + "Hours", 0);
                        case d:
                            return p(y + "Minutes", 1);
                        case i:
                            return p(y + "Seconds", 2);
                        case o:
                            return p(y + "Milliseconds", 3);
                        default:
                            return this.clone()
                    }
                }, _.endOf = function(e) {
                    return this.startOf(e, !1)
                }, _.$set = function(e, t) {
                    var r, s = P.p(e),
                        l = "set" + (this.$u ? "UTC" : ""),
                        $ = (r = {}, r[a] = l + "Date", r[f] = l + "Date", r[u] = l + "Month", r[c] = l + "FullYear", r[d] = l + "Hours", r[i] = l + "Minutes", r[o] = l + "Seconds", r[n] = l + "Milliseconds", r)[s],
                        p = s === a ? this.$D + (t - this.$W) : t;
                    if (s === u || s === c) {
                        var h = this.clone().set(f, 1);
                        h.$d[$](p), h.init(), this.$d = h.set(f, Math.min(this.$D, h.daysInMonth())).$d
                    } else $ && this.$d[$](p);
                    return this.init(), this
                }, _.set = function(e, t) {
                    return this.clone().$set(e, t)
                }, _.get = function(e) {
                    return this[P.p(e)]()
                }, _.add = function(n, l) {
                    var f, $ = this;
                    n = Number(n);
                    var p = P.p(l),
                        h = function(e) {
                            var t = S($);
                            return P.w(t.date(t.date() + Math.round(e * n)), $)
                        };
                    if (p === u) return this.set(u, this.$M + n);
                    if (p === c) return this.set(c, this.$y + n);
                    if (p === a) return h(1);
                    if (p === s) return h(7);
                    var m = (f = {}, f[i] = t, f[d] = r, f[o] = e, f)[p] || 1,
                        _ = this.$d.getTime() + n * m;
                    return P.w(_, this)
                }, _.subtract = function(e, t) {
                    return this.add(-1 * e, t)
                }, _.format = function(e) {
                    var t = this,
                        r = this.$locale();
                    if (!this.isValid()) return r.invalidDate || $;
                    var n = e || "YYYY-MM-DDTHH:mm:ssZ",
                        o = P.z(this),
                        i = this.$H,
                        d = this.$m,
                        a = this.$M,
                        s = r.weekdays,
                        u = r.months,
                        l = r.meridiem,
                        c = function(e, r, o, i) {
                            return e && (e[r] || e(t, n)) || o[r].slice(0, i)
                        },
                        f = function(e) {
                            return P.s(i % 12 || 12, e, "0")
                        },
                        p = l || function(e, t, r) {
                            var n = e < 12 ? "AM" : "PM";
                            return r ? n.toLowerCase() : n
                        };
                    return n.replace(h, (function(e, n) {
                        return n || function(e) {
                            switch (e) {
                                case "YY":
                                    return String(t.$y).slice(-2);
                                case "YYYY":
                                    return P.s(t.$y, 4, "0");
                                case "M":
                                    return a + 1;
                                case "MM":
                                    return P.s(a + 1, 2, "0");
                                case "MMM":
                                    return c(r.monthsShort, a, u, 3);
                                case "MMMM":
                                    return c(u, a);
                                case "D":
                                    return t.$D;
                                case "DD":
                                    return P.s(t.$D, 2, "0");
                                case "d":
                                    return String(t.$W);
                                case "dd":
                                    return c(r.weekdaysMin, t.$W, s, 2);
                                case "ddd":
                                    return c(r.weekdaysShort, t.$W, s, 3);
                                case "dddd":
                                    return s[t.$W];
                                case "H":
                                    return String(i);
                                case "HH":
                                    return P.s(i, 2, "0");
                                case "h":
                                    return f(1);
                                case "hh":
                                    return f(2);
                                case "a":
                                    return p(i, d, !0);
                                case "A":
                                    return p(i, d, !1);
                                case "m":
                                    return String(d);
                                case "mm":
                                    return P.s(d, 2, "0");
                                case "s":
                                    return String(t.$s);
                                case "ss":
                                    return P.s(t.$s, 2, "0");
                                case "SSS":
                                    return P.s(t.$ms, 3, "0");
                                case "Z":
                                    return o
                            }
                            return null
                        }(e) || o.replace(":", "")
                    }))
                }, _.utcOffset = function() {
                    return 15 * -Math.round(this.$d.getTimezoneOffset() / 15)
                }, _.diff = function(n, f, $) {
                    var p, h = this,
                        m = P.p(f),
                        _ = S(n),
                        y = (_.utcOffset() - this.utcOffset()) * t,
                        v = this - _,
                        g = function() {
                            return P.m(h, _)
                        };
                    switch (m) {
                        case c:
                            p = g() / 12;
                            break;
                        case u:
                            p = g();
                            break;
                        case l:
                            p = g() / 3;
                            break;
                        case s:
                            p = (v - y) / 6048e5;
                            break;
                        case a:
                            p = (v - y) / 864e5;
                            break;
                        case d:
                            p = v / r;
                            break;
                        case i:
                            p = v / t;
                            break;
                        case o:
                            p = v / e;
                            break;
                        default:
                            p = v
                    }
                    return $ ? p : P.a(p)
                }, _.daysInMonth = function() {
                    return this.endOf(u).$D
                }, _.$locale = function() {
                    return g[this.$L]
                }, _.locale = function(e, t) {
                    if (!e) return this.$L;
                    var r = this.clone(),
                        n = C(e, t, !0);
                    return n && (r.$L = n), r
                }, _.clone = function() {
                    return P.w(this.$d, this)
                }, _.toDate = function() {
                    return new Date(this.valueOf())
                }, _.toJSON = function() {
                    return this.isValid() ? this.toISOString() : null
                }, _.toISOString = function() {
                    return this.$d.toISOString()
                }, _.toString = function() {
                    return this.$d.toUTCString()
                }, m
            }(),
            x = O.prototype;
        return S.prototype = x, [
            ["$ms", n],
            ["$s", o],
            ["$m", i],
            ["$H", d],
            ["$W", a],
            ["$M", u],
            ["$y", c],
            ["$D", f]
        ].forEach((function(e) {
            x[e[1]] = function(t) {
                return this.$g(t, e[0], e[1])
            }
        })), S.extend = function(e, t) {
            return e.$i || (e(t, O, S), e.$i = !0), S
        }, S.locale = C, S.isDayjs = w, S.unix = function(e) {
            return S(1e3 * e)
        }, S.en = g[v], S.Ls = g, S.p = {}, S
    }();
    const Hn = Wn(Gn.exports);
    /*! js-cookie v3.0.5 | MIT */
    function Vn(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = arguments[t];
            for (var n in r) e[n] = r[n]
        }
        return e
    }
    var qn = function e(t, r) {
        function n(e, n, o) {
            if ("undefined" != typeof document) {
                "number" == typeof(o = Vn({}, r, o)).expires && (o.expires = new Date(Date.now() + 864e5 * o.expires)), o.expires && (o.expires = o.expires.toUTCString()), e = encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
                var i = "";
                for (var d in o) o[d] && (i += "; " + d, !0 !== o[d] && (i += "=" + o[d].split(";")[0]));
                return document.cookie = e + "=" + t.write(n, e) + i
            }
        }
        return Object.create({
            set: n,
            get: function(e) {
                if ("undefined" != typeof document && (!arguments.length || e)) {
                    for (var r = document.cookie ? document.cookie.split("; ") : [], n = {}, o = 0; o < r.length; o++) {
                        var i = r[o].split("="),
                            d = i.slice(1).join("=");
                        try {
                            var a = decodeURIComponent(i[0]);
                            if (n[a] = t.read(d, a), e === a) break
                        } catch (Ln) {}
                    }
                    return e ? n[e] : n
                }
            },
            remove: function(e, t) {
                n(e, "", Vn({}, t, {
                    expires: -1
                }))
            },
            withAttributes: function(t) {
                return e(this.converter, Vn({}, this.attributes, t))
            },
            withConverter: function(t) {
                return e(Vn({}, this.converter, t), this.attributes)
            }
        }, {
            attributes: {
                value: Object.freeze(r)
            },
            converter: {
                value: Object.freeze(t)
            }
        })
    }({
        read: function(e) {
            return '"' === e[0] && (e = e.slice(1, -1)), e.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
        },
        write: function(e) {
            return encodeURIComponent(e).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent)
        }
    }, {
        path: "/"
    });
    const Kn = new class {
            get env() {
                return un.env
            }
            get cookieNamePrefix() {
                return un.cookieNamePrefix
            }
        },
        Zn = function(e) {
            return function(e, t) {
                var r;
                if ("function" != typeof t) throw new TypeError("Expected a function");
                return e = k(e),
                    function() {
                        return --e > 0 && (r = t.apply(this, arguments)), e <= 1 && (t = void 0), r
                    }
            }(2, e)
        }((() => {}));

    function Jn() {
        if (fe(io.getSessionStorage("is_preview", "false"), "true")) return Zn(), !0;
        const e = "true" === yt(window, "EcomSendApps.searchParams.popup-preview", "false");
        if (e) {
            io.setSessionStorage("is_preview", "true");
            let e = yt(window, "EcomSendApps.searchParams.popup-id");
            e && io.setSessionStorage("popup_id", e)
        }
        return e || un.pluginIsPreview
    }

    function Xn() {
        return "none" !== yt(window, "EcomSendApps.searchParams.user-select", "false")
    }

    function Qn() {
        const e = /iPad|iPhone|iPod/.test(navigator.userAgent),
            t = navigator.userAgent.includes("Macintosh"),
            r = navigator.maxTouchPoints >= 1;
        return e || t && (r || function() {
            const e = new Audio;
            return e.volume = .5, 1 === e.volume
        }())
    }
    tn(window, "EcomSendApps.isPreviewMode", Jn);
    const eo = function() {
        try {
            const e = "__test__";
            return sessionStorage.setItem(e, e), sessionStorage.removeItem(e), !0
        } catch (Ln) {
            return !1
        }
    }();
    const to = eo ? sessionStorage : new class {
            constructor() {
                this.data = {}, this.length = this.data.length
            }
            setItem(e, t) {
                this.data[e] = t
            }
            getItem(e) {
                return this.data[e]
            }
            removeItem(e) {
                delete this.data[e]
            }
            clear() {
                this.data = {}
            }
            key(e) {
                return Object.values(this.data)[e]
            }
        },
        {
            get: ro,
            set: no,
            remove: oo
        } = qn;
    const io = new class {
        setSessionStorage(e, t) {
            to.setItem(Kn.cookieNamePrefix + e, t)
        }
        getSessionStorage(e, t = "") {
            const r = to.getItem(Kn.cookieNamePrefix + e);
            return Zr(r) ? t : r
        }
        getCookie(e, t) {
            const r = ro(Kn.cookieNamePrefix + e);
            return void 0 === r ? t : r
        }
        getCookies() {
            return ro()
        }
        removeCookie(e, t) {
            oo(Kn.cookieNamePrefix + e, t)
        }
        removeCookieNoPrefix(e) {
            oo(e)
        }
        setCookie(e, t, r) {
            no(Kn.cookieNamePrefix + e, t, r)
        }
        getLocalStorage(e, t = "") {
            const r = localStorage.getItem(Kn.cookieNamePrefix + e);
            return Zr(r) ? t : r
        }
        setLocalStorage(e, t) {
            localStorage.setItem(Kn.cookieNamePrefix + e, t)
        }
        setExpires(e, t) {
            this.setLocalStorage(e, t)
        }
        getExpires(e) {
            return Hn.unix(Number(this.getLocalStorage(e)))
        }
        hasLocalStorage(e) {
            return Zr(localStorage.getItem(Kn.cookieNamePrefix + e))
        }
        removeLocalStorage(e) {
            localStorage.removeItem(Kn.cookieNamePrefix + e)
        }
        setDiscountCode(e, t, r) {
            this.setCookie(`discount_code${r}`, e, {
                expires: t.toDate()
            })
        }
        getDiscountCode(e) {
            return this.getCookie(`discount_code${e}`, void 0) || void 0
        }
        setPreviewDiscountCode(e, t, r) {
            this.setCookie(`preview_discount_code${r}`, e, {
                expires: t.toDate()
            })
        }
        getPreviewDiscountCode(e) {
            return this.getCookie(`preview_discount_code${e}`, void 0) || void 0
        }
        setRemoveModal(e) {
            this.setCookie("remove_modal", String(e.unix()), {
                expires: e.toDate()
            })
        }
        setForeverRemoveModal() {
            this.setLocalStorage("forever_remove", "true")
        }
        getForeverRemoveModal() {
            return Boolean(this.getLocalStorage("forever_remove"))
        }
        getRemoveModal() {
            return this.getCookie("remove_modal", void 0) || void 0
        }
        setSubscribedStatus(e, t) {
            this.setCookie("is_subscribed", e, {
                expires: t.toDate()
            })
        }
        incrementModalShowCount(e, t) {
            const r = this.getModalShowCount(t),
                n = function(e) {
                    return Hn().add(1, e)
                }(e);
            if (0 === r) this.setCookie(Jn() ? `preview_modal_limit${t}` : `modal_limit${t}`, String(2), {
                expires: n.toDate()
            }), this.setExpires(Jn() ? `preview_expires_time${t}` : `expires_time${t}`, String(n.unix()));
            else {
                const e = this.getExpires(Jn() ? `preview_expires_time${t}` : `expires_time${t}`).toDate() || n.toDate();
                this.setCookie(Jn() ? `preview_modal_limit${t}` : `modal_limit${t}`, String(r + 1), {
                    expires: e
                })
            }
        }
        clearModalShowCount() {}
        getModalShowCount(e) {
            return Number(this.getCookie(Jn() ? `preview_modal_limit${e}` : `modal_limit${e}`, "0") || "0")
        }
    };
    const ao = {
        ConfigStore: new jn,
        IntentionsStore: new class {
            constructor() {
                this.modal_success_status = !1, this.modal_success_status_list = {}, this.show_modal = !1, this.show_modal_by_id = void 0, this.show_widget_modal_list = [], this.show_widget_modal = !1, this.show_sticky_bar_list = [], this.show_sticky_bar = !1, this.is_subscribed_list = [], this.is_subscribed = !1, e.makeAutoObservable(this)
            }
            setConfig(e, t) {
                tn(this, e, t)
            }
            setModalSuccessStatus(e, t) {
                this.modal_success_status_list[e] = t
            }
            showWidgetModal(e) {
                "true" === io.getSessionStorage(`close_widget_modal${e}`) || this.show_widget_modal_list.includes(e) || this.setConfig("show_widget_modal_list", [...this.show_widget_modal_list, e])
            }
            hideWidgetModal(e) {
                let t = this.show_widget_modal_list.indexOf(e); - 1 !== t && this.show_widget_modal_list.splice(t, 1)
            }
            showStickyBar(e) {
                this.show_sticky_bar_list.includes(e) || this.setConfig("show_sticky_bar_list", [...this.show_sticky_bar_list, e])
            }
            hideStickyBar(e) {
                let t = this.show_sticky_bar_list.indexOf(e); - 1 !== t && this.show_sticky_bar_list.splice(t, 1)
            }
            showModalById(e) {
                this.show_modal_by_id = e
            }
        },
        PopupsStore: new class {
            constructor() {
                this.popups = [], e.makeAutoObservable(this)
            }
            setConfig(e, t) {
                tn(this, e, t)
            }
        }
    };

    function so(e = !1, t) {
        const r = Array.from(document.getElementsByTagName("html"));
        r[0].addEventListener("mouseleave", (function n() {
            const {
                IntentionsStore: o,
                PopupsStore: i
            } = ao;
            o.show_modal || (po.showModal(!1, e, t), r[0].removeEventListener("mouseleave", n))
        }))
    }
    const uo = {
        [Pn.Equals]: (e, t) => fe(e || "/", `/${dn(nn(t,"?")[0],"/")}`),
        [Pn.DoesNotEqual]: (e, t) => !fe(e, `/${dn(nn(t,"?")[0],"/")}`),
        [Pn.Contains]: (e, t) => Vr(e, t),
        [Pn.DoesNotContain]: (e, t) => !Vr(e, t),
        [Pn.IsHomepage]() {
            var e;
            return "index" === (null == (e = window.EcomSendApps.common) ? void 0 : e.template)
        },
        [Pn.IsNotHomepage]() {
            var e;
            return "index" !== (null == (e = window.EcomSendApps.common) ? void 0 : e.template)
        }
    };

    function lo(e, t, r = !1) {
        return r ? function(e, t, r) {
            var n = y(e) ? pr : rn;
            return r && ve(e, t, r) && (t = void 0), n(e, Tr(t))
        }(e, (e => uo[e.operator](t, e.value))) : function(e, t, r) {
            var n = y(e) ? zr : Wr;
            return r && ve(e, t, r) && (t = void 0), n(e, Tr(t))
        }(e, (e => uo[e.operator](t, e.value)))
    }
    const co = () => {
        let e = navigator.userAgent,
            t = ["Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"],
            r = !1;
        for (let i = 0; i < t.length; i++)
            if (e.indexOf(t[i]) > 0) {
                r = !0;
                break
            }
        let n = window.screen.width,
            o = window.screen.height;
        return n > 325 && o < 750 && (r = !0), r
    };
    const {
        IntentionsStore: fo,
        PopupsStore: $o
    } = ao, po = {
        initQueueMap: {},
        clean() {
            Object.keys(io.getCookies()).forEach((e => {
                var t, r, n, o, i, d;
                t = e, r = un.cookieNamePrefix, t = pt(t), n = null == n ? 0 : (o = k(n), i = 0, d = t.length, o == o && (void 0 !== d && (o = o <= d ? o : d), void 0 !== i && (o = o >= i ? o : i)), o), r = b(r), t.slice(n, n + r.length) == r && io.removeCookieNoPrefix(e)
            })), localStorage.clear(), to.clear()
        },
        closeOtherComponent(e, t) {
            switch (e) {
                case "show_modal":
                    fo.hideWidgetModal(t), fo.hideStickyBar(t);
                    break;
                case "show_sticky_bar":
                    fo.hideWidgetModal(t), fo.setModalSuccessStatus(t, !1);
                    break;
                case "show_widget_modal":
                    fo.hideStickyBar(t), fo.setModalSuccessStatus(t, !1)
            }
        },
        getTargetPopupConfig: e => $o.popups.find((t => t.id === e)),
        isImmediateShow: e => e.rules.trigger.when.type === gn.ExitingPage || (Jn() ? !Zr(io.getCookie(`preview_discount_code${e.id}`)) : !Zr(io.getCookie(`discount_code${e.id}`))) || "true" === io.getSessionStorage(`pp_already_show${e.id}`) || Jn() && !Xn(),
        initPopup(e) {
            let t = this.getTargetPopupConfig(e);
            if (Jn()) {
                if (this.isSetExitPage(t) && Xn() ? so(Jn(), e) : !fo.show_modal && this.showModal(!1, !0, e), !Xn()) return;
                return this.showStickyBar(e), void this.showWidget(e)
            }
            this.isPassword() || (Jn() || t.status) && "true" !== io.getCookie(Jn() ? `pp_preview_forever_remove${e}` : `pp_forever_remove${e}`) && (this.showWidget(e), this.isSetExitPage(t) ? so(Jn(), e) : !fo.show_modal && this.showModal(!1, !1, e), this.showStickyBar(e))
        },
        init(e, t = !1) {
            let r = this.getTargetPopupConfig(e),
                {
                    timeout: n,
                    type: o
                } = r.rules.trigger.when;
            const i = "true" == io.getSessionStorage(`pp_already_show${e}`);
            if ((o !== gn.Timer || this.isImmediateShow(r)) && (n = 0), t) {
                const {
                    show_display: t
                } = r.rules.sidebar_widget, o = i && t !== vn.BEFORE_DISPLAYING_POPUP;
                (t === vn.BEFORE_DISPLAYING_POPUP || t === vn.AFTER_POPUP_IS_CLOSED_AND_BEFORE_DISPLAYING_POPUP || o) && this.showWidget(e), this.initQueueMap[e] = !0;
                let d = setTimeout((() => {
                    i ? this.showStickyBar(e) : this.initPopup(e), clearTimeout(d), this.initQueueMap[e] = !1
                }), 1e3 * n)
            } else !this.initQueueMap[e] && this.initPopup(e)
        },
        isPassword: () => "password" === window.EcomSendApps.common.template,
        isSetExitPage: e => e.rules.trigger.when.type === gn.ExitingPage,
        removeModal(e, t) {
            let r = this.getTargetPopupConfig(t);
            switch (e) {
                case "normal":
                    io.setSessionStorage(`pp_window_normal${t}`, "true"), io.setSessionStorage(`pp_already_show${t}`, "true"), fo.setConfig("show_modal", !1);
                    const {
                        sidebar_widget: e
                    } = r.rules, n = e.show_display === vn.AFTER_POPUP_IS_CLOSED || e.show_display === vn.AFTER_POPUP_IS_CLOSED_AND_BEFORE_DISPLAYING_POPUP;
                    e.show && n && fo.showWidgetModal(t);
                    break;
                case "success_subscriber":
                    io.setSessionStorage(`pp_window_normal${t}`, "true"), io.setSessionStorage(`pp_already_show${t}`, "true"), fo.setConfig("show_modal", !1), r.rules.sticky_discount_bar && this.showStickyBar(t);
                    break;
                case "forever":
                    let o = Hn().add(365, "day");
                    io.setCookie(Jn() ? `pp_preview_forever_remove${t}` : `pp_forever_remove${t}`, "true", {
                        expires: o.toDate()
                    }), fo.setConfig("show_modal", !1), fo.hideStickyBar(t), fo.hideWidgetModal(t)
            }
        },
        sendModalReport(e) {
            if (!Jn()) {
                if (Zr(e)) throw new Error("popupId is empty");
                const t = yt(window, "EcomSendApps.common.customer.id", "");
                pn.sendReport(e, t)
            }
        },
        setDiscountCode(e, t = !1, r) {
            t ? io.setPreviewDiscountCode(e, Hn().add(365, "day"), r) : io.setDiscountCode(e, Hn().add(365, "day"), r)
        },
        setSubscribedStatus() {
            io.setSubscribedStatus("1", Hn().add(100, "days"))
        },
        showModal(e = !1, t = !1, r, n = !1) {
            let o = this.getTargetPopupConfig(r);
            e && (this.closeOtherComponent("show_modal", r), fo.showModalById(r), fo.setConfig("show_modal", !0), this.sendModalReport(r), fo.hideWidgetModal(r));
            let i = (document.body.scrollHeight || document.documentElement.scrollHeight) - (window.innerHeight || document.documentElement.clientHeight),
                d = ((document.body.scrollTop || document.documentElement.scrollTop) / i * 100).toFixed(2);
            if ("NaN" === d && (d = "0"), Xn() && o.rules.trigger.when.type === gn.ScrollingPage && Number(d) < o.rules.trigger.when.scroll_offset && !n) {
                let n = !1;
                window.addEventListener("scroll", function(e, t) {
                    let r = !0;
                    return function() {
                        if (!r) return;
                        const n = this,
                            o = [...arguments];
                        r = !1, setTimeout((() => {
                            e.apply(n, o), r = !0
                        }), t)
                    }
                }((() => {
                    let d = ((document.body.scrollTop || document.documentElement.scrollTop) / i * 100).toFixed(2);
                    const a = o.rules.sidebar_widget.show_display === vn.AFTER_POPUP_IS_CLOSED;
                    if (Number(d) >= o.rules.trigger.when.scroll_offset && (!a || a && !fo.show_widget_modal_list.includes(r)) && !n && !fo.show_modal) {
                        n = !0;
                        "true" == io.getSessionStorage(`pp_already_show${r}`) || this.showModal(e, t, r, !0)
                    }
                }), 200))
            } else {
                if (t && "true" !== io.getSessionStorage("not_ft")) {
                    let e = io.getSessionStorage("popup_id"),
                        t = window.atob(e),
                        r = io.getSessionStorage("is_preview");
                    const n = io.getSessionStorage(`close_widget_modal${t}`);
                    to.clear(), n && io.setSessionStorage(`close_widget_modal${t}`, n), io.setSessionStorage("popup_id", e), io.setSessionStorage("is_preview", r), io.setSessionStorage("not_ft", "true"), io.removeCookie(`preview_discount_code${t}`), io.removeCookie(`pp_preview_success_subscribed${t}`), io.removeCookie(`preview_modal_limit${t}`)
                }
                if ((Jn() ? Zr(io.getPreviewDiscountCode(r)) : Zr(io.getDiscountCode(r))) && "true" !== io.getCookie(Jn() ? `pp_preview_success_subscribed${r}` : `pp_success_subscribed${r}`)) {
                    if ("true" === io.getSessionStorage(`pp_window_normal${r}`)) return "session_false";
                    if (this.isOverLimit(o) && Xn()) this.removeModal("normal", r);
                    else switch (o.rules.page_display_rules.type) {
                        case Sn.SpecificPage:
                            Xn() && !lo(o.rules.page_display_rules.specific_page, an(window.location.pathname, "/"), o.rules.page_display_rules.match_mode === On.OR) || (this.closeOtherComponent("show_modal", r), fo.showModalById(r), fo.setConfig("show_modal", !0), fo.hideWidgetModal(r), this.sendModalReport(r), Xn() && io.incrementModalShowCount(o.rules.trigger.frequency.limit.per, r));
                            break;
                        case Sn.AnyPage:
                            this.closeOtherComponent("show_modal", r), fo.showModalById(r), fo.setConfig("show_modal", !0), this.sendModalReport(r), fo.hideWidgetModal(r), Xn() && io.incrementModalShowCount(o.rules.trigger.frequency.limit.per, r);
                            break;
                        default:
                            fo.setConfig("show_modal", !1)
                    }
                }
            }
        },
        showStickyBar(e) {
            if (Jn() && "true" !== io.getSessionStorage("not_ft")) return;
            let t = this.getTargetPopupConfig(e);
            fo.show_widget_modal_list.includes(e) || "true" !== io.getCookie(Jn() ? `pp_preview_forever_remove${e}` : `pp_forever_remove${e}`) && ((Jn() ? Kr(io.getPreviewDiscountCode(e)) : Kr(io.getDiscountCode(e))) || !t.rules.sticky_discount_bar || (fo.show_modal_by_id === e && fo.setConfig("show_modal", !1), fo.showStickyBar(e), fo.hideWidgetModal(e)))
        },
        showWidget(e) {
            const t = "true" == io.getSessionStorage(`pp_already_show${e}`),
                r = this.getTargetPopupConfig(e),
                n = r.rules.sidebar_widget.show_display === vn.AFTER_POPUP_IS_CLOSED,
                o = r.rules.sidebar_widget.show_display === vn.BEFORE_DISPLAYING_POPUP;
            if ((!Jn() || "true" === io.getSessionStorage("not_ft") || !n) && "true" !== io.getCookie(Jn() ? `pp_preview_success_subscribed${e}` : `pp_success_subscribed${e}`) && "true" !== io.getSessionStorage(`close_widget_modal${e}`) && (!n || t) && (Jn() ? Kr(io.getPreviewDiscountCode(e)) : Kr(io.getDiscountCode(e)) || !r.rules.sticky_discount_bar))
                if (r.rules.sidebar_widget.show) {
                    if (t && o) return;
                    !(!t && o) && o || fo.show_modal_by_id || fo.showWidgetModal(e)
                } else fo.hideWidgetModal(e)
        },
        isOverLimit(e) {
            const t = io.getModalShowCount(e.id),
                {
                    type: r,
                    limit: n
                } = e.rules.trigger.frequency;
            return r === bn.Limit && n.value < t
        }
    };
    tn(window, "EcomSendApps.actions", po);
    const ho = ["Googlebot-Image", "Googlebot-News", "Googlebot", "Storebot-Google", "Google-InspectionTool", "GoogleOther", "AdsBot-Google-Mobile", "AdsBot-Google", "APIs-Google", "Mediapartners-Google", "FeedFetcher-Google", "GoogleProducer", "Google-Read-Aloud", "bingbot", "AdIdxBot", "BingPreview", "MicrosoftPreview"];
    var mo = vo;

    function _o(e) {
        return e && e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
    }

    function yo(e) {
        return e
    }

    function vo(e, t) {
        const r = (t = t || {}).delimiter || ".",
            n = t.maxDepth,
            o = t.transformKey || yo,
            i = {};
        return function e(d, a, s) {
            s = s || 1, Object.keys(d).forEach((function(u) {
                const l = d[u],
                    c = t.safe && Array.isArray(l),
                    f = Object.prototype.toString.call(l),
                    $ = _o(l),
                    p = "[object Object]" === f || "[object Array]" === f,
                    h = a ? a + r + o(u) : o(u);
                if (!c && !$ && p && Object.keys(l).length && (!t.maxDepth || s < n)) return e(l, h, s + 1);
                i[h] = l
            }))
        }(e), i
    }
    if (vo.flatten = vo, vo.unflatten = function e(t, r) {
            const n = (r = r || {}).delimiter || ".",
                o = r.overwrite || !1,
                i = r.transformKey || yo,
                d = {};
            if (_o(t) || "[object Object]" !== Object.prototype.toString.call(t)) return t;

            function a(e) {
                const t = Number(e);
                return isNaN(t) || -1 !== e.indexOf(".") || r.object ? e : t
            }
            return t = Object.keys(t).reduce((function(e, o) {
                const i = Object.prototype.toString.call(t[o]);
                return !("[object Object]" === i || "[object Array]" === i) || function(e) {
                    const t = Object.prototype.toString.call(e),
                        r = "[object Array]" === t,
                        n = "[object Object]" === t;
                    if (!e) return !0;
                    if (r) return !e.length;
                    if (n) return !Object.keys(e).length
                }(t[o]) ? (e[o] = t[o], e) : (d = o, a = e, s = vo(t[o], r), Object.keys(s).reduce((function(e, t) {
                    return e[d + n + t] = s[t], e
                }), a));
                var d, a, s
            }), {}), Object.keys(t).forEach((function(s) {
                const u = s.split(n).map(i);
                let l = a(u.shift()),
                    c = a(u[0]),
                    f = d;
                for (; void 0 !== c;) {
                    if ("__proto__" === l) return;
                    const e = Object.prototype.toString.call(f[l]),
                        t = "[object Object]" === e || "[object Array]" === e;
                    if (!o && !t && void 0 !== f[l]) return;
                    (o && !t || !o && null == f[l]) && (f[l] = "number" != typeof c || r.object ? {} : []), f = f[l], u.length > 0 && (l = a(u.shift()), c = a(u[0]))
                }
                f[l] = e(t[s], r)
            })), d
        }, !t.useState) throw new Error("mobx-react-lite requires React with Hooks support");
    if (!e.makeObservable) throw new Error("mobx-react-lite@3 requires mobx at least version 6 to be available");

    function go(e) {
        e()
    }

    function bo(t) {
        return e.getDependencyTree(t)
    }
    var wo = function() {
            function e(e) {
                var t = this;
                Object.defineProperty(this, "finalize", {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: e
                }), Object.defineProperty(this, "registrations", {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: new Map
                }), Object.defineProperty(this, "sweepTimeout", {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: void 0
                }), Object.defineProperty(this, "sweep", {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: function(e) {
                        void 0 === e && (e = 1e4), clearTimeout(t.sweepTimeout), t.sweepTimeout = void 0;
                        var r = Date.now();
                        t.registrations.forEach((function(n, o) {
                            r - n.registeredAt >= e && (t.finalize(n.value), t.registrations.delete(o))
                        })), t.registrations.size > 0 && t.scheduleSweep()
                    }
                }), Object.defineProperty(this, "finalizeAllImmediately", {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: function() {
                        t.sweep(0)
                    }
                })
            }
            return Object.defineProperty(e.prototype, "register", {
                enumerable: !1,
                configurable: !0,
                writable: !0,
                value: function(e, t, r) {
                    this.registrations.set(r, {
                        value: t,
                        registeredAt: Date.now()
                    }), this.scheduleSweep()
                }
            }), Object.defineProperty(e.prototype, "unregister", {
                enumerable: !1,
                configurable: !0,
                writable: !0,
                value: function(e) {
                    this.registrations.delete(e)
                }
            }), Object.defineProperty(e.prototype, "scheduleSweep", {
                enumerable: !1,
                configurable: !0,
                writable: !0,
                value: function() {
                    void 0 === this.sweepTimeout && (this.sweepTimeout = setTimeout(this.sweep, 1e4))
                }
            }), e
        }(),
        Co = new("undefined" != typeof FinalizationRegistry ? FinalizationRegistry : wo)((function(e) {
            var t;
            null === (t = e.reaction) || void 0 === t || t.dispose(), e.reaction = null
        })),
        So = globalThis && globalThis.__read || function(e, t) {
            var r = "function" == typeof Symbol && e[Symbol.iterator];
            if (!r) return e;
            var n, o, i = r.call(e),
                d = [];
            try {
                for (;
                    (void 0 === t || t-- > 0) && !(n = i.next()).done;) d.push(n.value)
            } catch (a) {
                o = {
                    error: a
                }
            } finally {
                try {
                    n && !n.done && (r = i.return) && r.call(i)
                } finally {
                    if (o) throw o.error
                }
            }
            return d
        };

    function Po(e) {
        return "observer".concat(e)
    }
    var Oo = function() {};

    function xo() {
        return new Oo
    }
    var Eo, Mo = "function" == typeof Symbol && Symbol.for;

    function Do(r) {
        var n = r.children,
            o = r.render,
            i = n || o;
        return "function" != typeof i ? null : function(r, n) {
            void 0 === n && (n = "observed");
            var o = So(t.useState(xo), 1)[0],
                i = So(t.useState(), 2)[1],
                d = function() {
                    return i([])
                },
                a = t.useRef(null);
            a.current || (a.current = {
                reaction: null,
                mounted: !1,
                changedBeforeMount: !1
            });
            var s, u, l = a.current;
            if (l.reaction || (l.reaction = new e.Reaction(Po(n), (function() {
                    l.mounted ? d() : l.changedBeforeMount = !0
                })), Co.register(o, l, l)), t.useDebugValue(l.reaction, bo), t.useEffect((function() {
                    return Co.unregister(l), l.mounted = !0, l.reaction ? l.changedBeforeMount && (l.changedBeforeMount = !1, d()) : (l.reaction = new e.Reaction(Po(n), (function() {
                            d()
                        })), d()),
                        function() {
                            l.reaction.dispose(), l.reaction = null, l.mounted = !1, l.changedBeforeMount = !1
                        }
                }), []), l.reaction.track((function() {
                    try {
                        s = r()
                    } catch (Ln) {
                        u = Ln
                    }
                })), u) throw u;
            return s
        }(i)
    }
    Mo ? Symbol.for("react.forward_ref") : "function" == typeof t.forwardRef && t.forwardRef((function(e) {
        return null
    })).$$typeof, Mo ? Symbol.for("react.memo") : "function" == typeof t.memo && t.memo((function(e) {
        return null
    })).$$typeof, Do.displayName = "Observer", globalThis && globalThis.__read, (Eo = r.unstable_batchedUpdates) || (Eo = go), e.configure({
        reactionScheduler: Eo
    }), Co.finalizeAllImmediately;
    var No, Io = {
            exports: {}
        },
        ko = {};
    Io.exports = function() {
        if (No) return ko;
        No = 1;
        var e = t,
            r = Symbol.for("react.element"),
            n = Symbol.for("react.fragment"),
            o = Object.prototype.hasOwnProperty,
            i = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
            d = {
                key: !0,
                ref: !0,
                __self: !0,
                __source: !0
            };

        function a(e, t, n) {
            var a, s = {},
                u = null,
                l = null;
            for (a in void 0 !== n && (u = "" + n), void 0 !== t.key && (u = "" + t.key), void 0 !== t.ref && (l = t.ref), t) o.call(t, a) && !d.hasOwnProperty(a) && (s[a] = t[a]);
            if (e && e.defaultProps)
                for (a in t = e.defaultProps) void 0 === s[a] && (s[a] = t[a]);
            return {
                $$typeof: r,
                type: e,
                key: u,
                ref: l,
                props: s,
                _owner: i.current
            }
        }
        return ko.Fragment = n, ko.jsx = a, ko.jsxs = a, ko
    }();
    var To = Io.exports;
    const Ao = To.jsx,
        jo = To.jsxs,
        Ro = To.Fragment;

    function Lo() {
        return Lo = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }, Lo.apply(this, arguments)
    }
    var Fo = ["children"],
        Bo = t.createContext({});

    function Yo(e) {
        var r = e.children,
            n = function(e, t) {
                if (null == e) return {};
                var r, n, o = {},
                    i = Object.keys(e);
                for (n = 0; n < i.length; n++) r = i[n], t.indexOf(r) >= 0 || (o[r] = e[r]);
                return o
            }(e, Fo),
            o = t.useContext(Bo),
            i = t.useRef(Lo({}, o, n)).current;
        return Ao(Bo.Provider, {
            value: i,
            children: r
        })
    }
    if (Yo.displayName = "MobXProvider", !t.Component) throw new Error("mobx-react requires React to be available");
    if (!e.observable) throw new Error("mobx-react requires mobx to be available");
    var Uo = {},
        zo = r;
    Uo.createRoot = zo.createRoot, Uo.hydrateRoot = zo.hydrateRoot;
    var Wo = {
        exports: {}
    };
    /*!
      	Copyright (c) 2018 Jed Watson.
      	Licensed under the MIT License (MIT), see
      	http://jedwatson.github.io/classnames
      */
    ! function(e) {
        ! function() {
            var t = {}.hasOwnProperty;

            function r() {
                for (var e = "", t = 0; t < arguments.length; t++) {
                    var r = arguments[t];
                    r && (e = o(e, n(r)))
                }
                return e
            }

            function n(e) {
                if ("string" == typeof e || "number" == typeof e) return e;
                if ("object" != typeof e) return "";
                if (Array.isArray(e)) return r.apply(null, e);
                if (e.toString !== Object.prototype.toString && !e.toString.toString().includes("[native code]")) return e.toString();
                var n = "";
                for (var i in e) t.call(e, i) && e[i] && (n = o(n, i));
                return n
            }

            function o(e, t) {
                return t ? e ? e + " " + t : e + t : e
            }
            e.exports ? (r.default = r, e.exports = r) : window.classNames = r
        }()
    }(Wo);
    const Go = Wn(Wo.exports);
    var Ho = !1;
    if ("undefined" != typeof window) {
        var Vo = {
            get passive() {
                Ho = !0
            }
        };
        window.addEventListener("testPassive", null, Vo), window.removeEventListener("testPassive", null, Vo)
    }
    var qo = "undefined" != typeof window && window.navigator && window.navigator.platform && (/iP(ad|hone|od)/.test(window.navigator.platform) || "MacIntel" === window.navigator.platform && window.navigator.maxTouchPoints > 1),
        Ko = [],
        Zo = !1,
        Jo = -1,
        Xo = void 0,
        Qo = void 0,
        ei = function(e) {
            return Ko.some((function(t) {
                return !(!t.options.allowTouchMove || !t.options.allowTouchMove(e))
            }))
        },
        ti = function(e) {
            var t = e || window.event;
            return !!ei(t.target) || (t.touches.length > 1 || (t.preventDefault && t.preventDefault(), !1))
        },
        ri = function(e, t) {
            if (e && !Ko.some((function(t) {
                    return t.targetElement === e
                }))) {
                var r = {
                    targetElement: e,
                    options: t || {}
                };
                Ko = [].concat(function(e) {
                    if (Array.isArray(e)) {
                        for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
                        return r
                    }
                    return Array.from(e)
                }(Ko), [r]), qo ? (e.ontouchstart = function(e) {
                    1 === e.targetTouches.length && (Jo = e.targetTouches[0].clientY)
                }, e.ontouchmove = function(t) {
                    1 === t.targetTouches.length && function(e, t) {
                        var r = e.targetTouches[0].clientY - Jo;
                        !ei(e.target) && (t && 0 === t.scrollTop && r > 0 || function(e) {
                            return !!e && e.scrollHeight - e.scrollTop <= e.clientHeight
                        }(t) && r < 0 ? ti(e) : e.stopPropagation())
                    }(t, e)
                }, Zo || (document.addEventListener("touchmove", ti, Ho ? {
                    passive: !1
                } : void 0), Zo = !0)) : function(e) {
                    if (void 0 === Qo) {
                        var t = !!e && !0 === e.reserveScrollBarGap,
                            r = window.innerWidth - document.documentElement.clientWidth;
                        t && r > 0 && (Qo = document.body.style.paddingRight, document.body.style.paddingRight = r + "px")
                    }
                    void 0 === Xo && (Xo = document.body.style.overflow, document.body.style.overflow = "hidden")
                }(t)
            }
        },
        ni = function(e) {
            e && (Ko = Ko.filter((function(t) {
                return t.targetElement !== e
            })), qo ? (e.ontouchstart = null, e.ontouchmove = null, Zo && 0 === Ko.length && (document.removeEventListener("touchmove", ti, Ho ? {
                passive: !1
            } : void 0), Zo = !1)) : Ko.length || (void 0 !== Qo && (document.body.style.paddingRight = Qo, Qo = void 0), void 0 !== Xo && (document.body.style.overflow = Xo, Xo = void 0)))
        };

    function oi(e, r = {
        isStateful: !0
    }) {
        const n = function(e = null) {
                let [r, n] = t.useState(e);
                const {
                    current: o
                } = t.useRef({
                    current: r
                });
                return Object.defineProperty(o, "current", {
                    get: () => r,
                    set: e => {
                        Object.is(r, e) || (r = e, n(e))
                    }
                }), o
            }(null),
            o = t.useRef(null),
            i = r.isStateful ? n : o;
        return t.useEffect((() => {
            !e || ("function" == typeof e ? e(i.current) : e.current = i.current)
        })), i
    }

    function ii() {
        return ii = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }, ii.apply(this, arguments)
    }
    var di = function(e) {
            var t = e.classes,
                r = e.classNames,
                n = e.styles,
                o = e.id,
                i = e.closeIcon,
                d = e.onClick;
            return Ao("button", {
                id: o,
                className: Go(t.closeButton, null == r ? void 0 : r.closeButton),
                style: null == n ? void 0 : n.closeButton,
                onClick: d,
                "data-testid": "close-button",
                children: i || Ao("svg", {
                    className: null == r ? void 0 : r.closeIcon,
                    style: null == n ? void 0 : n.closeIcon,
                    width: 28,
                    height: 28,
                    viewBox: "0 0 36 36",
                    "data-testid": "close-icon",
                    children: Ao("path", {
                        d: "M28.5 9.62L26.38 7.5 18 15.88 9.62 7.5 7.5 9.62 15.88 18 7.5 26.38l2.12 2.12L18 20.12l8.38 8.38 2.12-2.12L20.12 18z"
                    })
                })
            })
        },
        ai = "undefined" != typeof window,
        si = ["input", "select", "textarea", "a[href]", "button", "[tabindex]", "audio[controls]", "video[controls]", '[contenteditable]:not([contenteditable="false"])'];

    function ui(e) {
        return null === e.offsetParent || "hidden" === getComputedStyle(e).visibility
    }

    function li(e) {
        if ("INPUT" !== e.tagName || "radio" !== e.type || !e.name) return !0;
        var t = (e.form || e.ownerDocument).querySelectorAll('input[type="radio"][name="' + e.name + '"]'),
            r = function(e, t) {
                for (var r = 0; r < e.length; r++)
                    if (e[r].checked && e[r].form === t) return e[r]
            }(t, e.form);
        return r === e || void 0 === r && t[0] === e
    }

    function ci(e) {
        for (var t = document.activeElement, r = e.querySelectorAll(si.join(",")), n = [], o = 0; o < r.length; o++) {
            var i = r[o];
            (t === i || !i.disabled && fi(i) > -1 && !ui(i) && li(i)) && n.push(i)
        }
        return n
    }

    function fi(e) {
        var t = parseInt(e.getAttribute("tabindex"), 10);
        return isNaN(t) ? function(e) {
            return e.getAttribute("contentEditable")
        }(e) ? 0 : e.tabIndex : t
    }
    var $i = function(e) {
            var r = e.container,
                n = e.initialFocusRef,
                o = t.useRef();
            return t.useEffect((function() {
                var e = function(e) {
                    (null == r ? void 0 : r.current) && function(e, t) {
                        if (e && "Tab" === e.key) {
                            if (!t || !t.contains) return process, !1;
                            if (!t.contains(e.target)) return !1;
                            var r = ci(t),
                                n = r[0],
                                o = r[r.length - 1];
                            e.shiftKey && e.target === n ? (o.focus(), e.preventDefault()) : !e.shiftKey && e.target === o && (n.focus(), e.preventDefault())
                        }
                    }(e, r.current)
                };
                if (ai && document.addEventListener("keydown", e), ai && (null == r ? void 0 : r.current)) {
                    var t = function() {
                        -1 !== si.findIndex((function(e) {
                            var t;
                            return null == (t = document.activeElement) ? void 0 : t.matches(e)
                        })) && (o.current = document.activeElement)
                    };
                    if (n) t(), requestAnimationFrame((function() {
                        var e;
                        null == (e = n.current) || e.focus()
                    }));
                    else {
                        var i = ci(r.current);
                        i[0] && (t(), i[0].focus())
                    }
                }
                return function() {
                    var t;
                    ai && (document.removeEventListener("keydown", e), null == (t = o.current) || t.focus())
                }
            }), [r, n]), null
        },
        pi = [],
        hi = function(e) {
            pi.push(e)
        },
        mi = function(e) {
            pi = pi.filter((function(t) {
                return t !== e
            }))
        },
        _i = function(e) {
            return !!pi.length && pi[pi.length - 1] === e
        };
    var yi = {
            root: "react-responsive-modal-root",
            overlay: "react-responsive-modal-overlay",
            overlayAnimationIn: "react-responsive-modal-overlay-in",
            overlayAnimationOut: "react-responsive-modal-overlay-out",
            modalContainer: "react-responsive-modal-container",
            modalContainerCenter: "react-responsive-modal-containerCenter",
            modal: "react-responsive-modal-modal",
            modalAnimationIn: "react-responsive-modal-modal-in",
            modalAnimationOut: "react-responsive-modal-modal-out",
            closeButton: "react-responsive-modal-closeButton"
        },
        vi = t.forwardRef((function(e, n) {
            var o, i, d, a, s = e.open,
                u = e.center,
                l = e.blockScroll,
                c = void 0 === l || l,
                f = e.closeOnEsc,
                $ = void 0 === f || f,
                p = e.closeOnOverlayClick,
                h = void 0 === p || p,
                m = e.container,
                _ = e.showCloseIcon,
                y = void 0 === _ || _,
                v = e.closeIconId,
                g = e.closeIcon,
                b = e.focusTrapped,
                w = void 0 === b || b,
                C = e.initialFocusRef,
                S = void 0 === C ? void 0 : C,
                P = e.animationDuration,
                O = void 0 === P ? 300 : P,
                x = e.classNames,
                E = e.styles,
                M = e.role,
                D = void 0 === M ? "dialog" : M,
                N = e.ariaDescribedby,
                I = e.ariaLabelledby,
                k = e.containerId,
                T = e.modalId,
                A = e.onClose,
                j = e.onEscKeyDown,
                R = e.onOverlayClick,
                L = e.onAnimationEnd,
                F = e.children,
                B = e.reserveScrollBarGap,
                Y = oi(n),
                U = t.useRef(null),
                z = t.useRef(null),
                W = t.useRef(null);
            null === W.current && ai && (W.current = document.createElement("div"));
            var G = t.useState(!1),
                H = G[0],
                V = G[1];
            ! function(e, r) {
                t.useEffect((function() {
                    return r && hi(e),
                        function() {
                            mi(e)
                        }
                }), [r, e])
            }(U, s),
            function(e, r, n, o, i) {
                var d = t.useRef(null);
                t.useEffect((function() {
                    return r && e.current && o && (d.current = e.current, ri(e.current, {
                            reserveScrollBarGap: i
                        })),
                        function() {
                            d.current && (ni(d.current), d.current = null)
                        }
                }), [r, n, e, o, i])
            }(U, s, H, c, B);
            var q = function(e) {
                27 === e.keyCode && _i(U) && (null == j || j(e), $ && A())
            };
            t.useEffect((function() {
                return function() {
                    H && (W.current && !m && document.body.contains(W.current) && document.body.removeChild(W.current), document.removeEventListener("keydown", q))
                }
            }), [H]), t.useEffect((function() {
                s && !H && (V(!0), !W.current || m || document.body.contains(W.current) || document.body.appendChild(W.current), document.addEventListener("keydown", q))
            }), [s]);
            var K = function() {
                    z.current = !1
                },
                Z = m || W.current,
                J = s ? null != (o = null == x ? void 0 : x.overlayAnimationIn) ? o : yi.overlayAnimationIn : null != (i = null == x ? void 0 : x.overlayAnimationOut) ? i : yi.overlayAnimationOut,
                X = s ? null != (d = null == x ? void 0 : x.modalAnimationIn) ? d : yi.modalAnimationIn : null != (a = null == x ? void 0 : x.modalAnimationOut) ? a : yi.modalAnimationOut;
            return H && Z ? r.createPortal(jo("div", {
                className: Go(yi.root, null == x ? void 0 : x.root),
                style: null == E ? void 0 : E.root,
                "data-testid": "root",
                children: [Ao("div", {
                    className: Go(yi.overlay, null == x ? void 0 : x.overlay),
                    "data-testid": "overlay",
                    "aria-hidden": !0,
                    style: ii({
                        animation: J + " " + O + "ms"
                    }, null == E ? void 0 : E.overlay)
                }), Ao("div", {
                    ref: U,
                    id: k,
                    className: Go(yi.modalContainer, u && yi.modalContainerCenter, null == x ? void 0 : x.modalContainer),
                    style: null == E ? void 0 : E.modalContainer,
                    "data-testid": "modal-container",
                    onClick: function(e) {
                        null === z.current && (z.current = !0), z.current ? (null == R || R(e), h && A(), z.current = null) : z.current = null
                    },
                    children: jo("div", {
                        ref: Y,
                        className: Go(yi.modal, null == x ? void 0 : x.modal),
                        style: ii({
                            animation: X + " " + O + "ms"
                        }, null == E ? void 0 : E.modal),
                        onMouseDown: K,
                        onMouseUp: K,
                        onClick: K,
                        onAnimationEnd: function() {
                            s || V(!1), null == L || L()
                        },
                        id: T,
                        role: D,
                        "aria-modal": "true",
                        "aria-labelledby": I,
                        "aria-describedby": N,
                        "data-testid": "modal",
                        tabIndex: -1,
                        children: [w && Ao($i, {
                            container: Y,
                            initialFocusRef: S
                        }), F, y && Ao(di, {
                            classes: yi,
                            classNames: x,
                            styles: E,
                            closeIcon: g,
                            onClick: A,
                            id: v
                        })]
                    })
                })]
            }), Z) : null
        }));

    function gi(e, t = "ecomsend") {
        return `${t}__${e}`
    }

    function bi(e, t = "ecomsend") {
        return `${t}-SpinWheel__${e}`
    }
    var wi = (e => (e[e.OK = 200] = "OK", e[e.ACCEPTED = 201] = "ACCEPTED", e[e.REDIRECT = 302] = "REDIRECT", e[e.PARAM_ERROR = 400] = "PARAM_ERROR", e[e.NOT_LOGIN = 401] = "NOT_LOGIN", e[e.NOT_AUTH = 403] = "NOT_AUTH", e[e.NOT_FOUND = 404] = "NOT_FOUND", e[e.CONFLICT = 409] = "CONFLICT", e[e.SERVER_ERROR = 500] = "SERVER_ERROR", e[e.NOT_IMPLEMENTED = 501] = "NOT_IMPLEMENTED", e[e.SERVICE_UNAVAILABLE = 503] = "SERVICE_UNAVAILABLE", e))(wi || {});
    const Ci = e => Ao("svg", __spreadProps(__spreadValues({
            width: 16,
            height: 16,
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        }, e), {
            style: {
                width: "16px",
                height: "16px"
            },
            children: Ao("path", {
                d: "m9.414 8 6.293-6.293A1 1 0 0 0 14.293.293L8 6.586 1.707.293A1 1 0 1 0 .293 1.707L6.586 8 .293 14.293a1 1 0 1 0 1.414 1.414L8 9.414l6.293 6.293a.997.997 0 0 0 1.631-.324 1 1 0 0 0-.217-1.09L9.414 8Z",
                fill: "#6C6B80"
            })
        })),
        Si = () => jo("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 32 32",
            children: [Ao("circle", {
                transform: "translate(8 0)",
                cx: "0",
                cy: "16",
                r: "0",
                children: Ao("animate", {
                    attributeName: "r",
                    values: "0; 4; 0; 0",
                    dur: "1.2s",
                    repeatCount: "indefinite",
                    begin: "0",
                    keyTimes: "0;0.2;0.7;1",
                    keySplines: "0.2 0.2 0.4 0.8;0.2 0.6 0.4 0.8;0.2 0.6 0.4 0.8",
                    calcMode: "spline"
                })
            }), Ao("circle", {
                transform: "translate(16 0)",
                cx: "0",
                cy: "16",
                r: "0",
                children: Ao("animate", {
                    attributeName: "r",
                    values: "0; 4; 0; 0",
                    dur: "1.2s",
                    repeatCount: "indefinite",
                    begin: "0.3",
                    keyTimes: "0;0.2;0.7;1",
                    keySplines: "0.2 0.2 0.4 0.8;0.2 0.6 0.4 0.8;0.2 0.6 0.4 0.8",
                    calcMode: "spline"
                })
            }), Ao("circle", {
                transform: "translate(24 0)",
                cx: "0",
                cy: "16",
                r: "0",
                children: Ao("animate", {
                    attributeName: "r",
                    values: "0; 4; 0; 0",
                    dur: "1.2s",
                    repeatCount: "indefinite",
                    begin: "0.6",
                    keyTimes: "0;0.2;0.7;1",
                    keySplines: "0.2 0.2 0.4 0.8;0.2 0.6 0.4 0.8;0.2 0.6 0.4 0.8",
                    calcMode: "spline"
                })
            })]
        }),
        Pi = {
            xButton: "_xButton_1vm0o_2",
            loadingBox: "_loadingBox_1vm0o_24",
            text: "_text_1vm0o_33",
            mobile: "_mobile_1vm0o_38",
            disabled: "_disabled_1vm0o_41",
            "btn-radius-standard": "_btn-radius-standard_1vm0o_44",
            "btn-radius-none": "_btn-radius-none_1vm0o_47",
            "btn-radius-large": "_btn-radius-large_1vm0o_50",
            block: "_block_1vm0o_53",
            small: "_small_1vm0o_60"
        };

    function Oi({
        buttonTextConfig: e,
        size: t,
        shape: r,
        colors: n,
        action: o,
        loading: i,
        block: d,
        isMobile: a,
        onClick: s,
        classNames: u
    }) {
        return Ao(Ro, {
            children: !Kr(e) && Ao("div", {
                className: Go(gi("Button"), Pi.xButton, Pi[`btn-radius-${r}`], Pi[t || ""], d && Pi.block, o && Pi.disabled, a && Pi.mobile, u),
                style: {
                    "--bg-color": `${n.primary_button_background_color}`,
                    background: `${n.primary_button_background_color}`,
                    color: `${n.primary_button_text_color}`
                },
                onClick: () => "function" == typeof s && s(),
                children: Ao("div", i ? {
                    className: Pi.loadingBox,
                    children: Ao(Si, {})
                } : {
                    className: Pi.text,
                    children: e
                })
            })
        })
    }
    var xi = {},
        Ei = function(e) {
            if (navigator.clipboard) return navigator.clipboard.writeText(e).catch((function(e) {
                throw void 0 !== e ? e : new DOMException("The request is not allowed", "NotAllowedError")
            }));
            var t = document.createElement("span");
            t.textContent = e, t.style.whiteSpace = "pre", t.style.webkitUserSelect = "auto", t.style.userSelect = "all", document.body.appendChild(t);
            var r = window.getSelection(),
                n = window.document.createRange();
            r.removeAllRanges(), n.selectNode(t), r.addRange(n);
            var o = !1;
            try {
                o = window.document.execCommand("copy")
            } catch (i) {}
            return r.removeAllRanges(), window.document.body.removeChild(t), o ? Promise.resolve() : Promise.reject(new DOMException("The request is not allowed", "NotAllowedError"))
        };
    /*! clipboard-copy. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
    var Mi = {};
    Object.defineProperty(Mi, "__esModule", {
        value: !0
    }), Mi.useTimedToggle = void 0;
    var Di = t;
    Mi.useTimedToggle = function(e) {
        var t = Di.useState(!1),
            r = t[0],
            n = t[1],
            o = Di.useRef(),
            i = Di.useRef(e);
        return Di.useEffect((function() {
            return function() {
                return clearTimeout(o.current)
            }
        }), []), [r, function(e) {
            clearTimeout(o.current), n(!i.current), o.current = window.setTimeout((function() {
                return n(i.current)
            }), e)
        }]
    };
    var Ni = zn && zn.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    };
    Object.defineProperty(xi, "__esModule", {
        value: !0
    });
    var Ii = xi.useClipboard = void 0,
        ki = Ni(Ei),
        Ti = t,
        Ai = Mi;

    function ji(e) {
        return e && ("TEXTAREA" === e.nodeName || "INPUT" === e.nodeName)
    }
    Ii = xi.useClipboard = function(e) {
        void 0 === e && (e = {});
        var t = Ai.useTimedToggle(!1),
            r = t[0],
            n = t[1],
            o = Ti.useRef(null),
            i = Ti.useRef(e);
        return i.current = e, {
            copied: r,
            copy: Ti.useCallback((function(e) {
                var t = i.current,
                    r = o.current;

                function d() {
                    t.onSuccess && t.onSuccess(), t.copiedTimeout && n(t.copiedTimeout), t.selectOnCopy && ji(r) && r.select()
                }

                function a() {
                    t.onError && t.onError(), !1 !== t.selectOnError && ji(r) && r.select()
                }

                function s(e) {
                    ki.default(e).then(d).catch(a)
                }
                "string" == typeof e ? s(e) : r && s(r.value)
            }), []),
            isSupported: function() {
                return !!navigator.clipboard || "function" == typeof document.execCommand && "function" == typeof document.queryCommandSupported && document.queryCommandSupported("copy")
            },
            target: o
        }
    };
    const Ri = e => jo("svg", __spreadProps(__spreadValues({
            width: 28,
            height: 28,
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        }, e), {
            children: [Ao("mask", {
                id: "copy_svg__a",
                style: {
                    maskType: "alpha"
                },
                maskUnits: "userSpaceOnUse",
                x: 8,
                y: 3,
                width: 17,
                height: 17,
                children: Ao("path", {
                    d: "M24.5 3.5v16.334h-2.178V5.678H8.167V3.5H24.5Z",
                    fill: "#fff"
                })
            }), Ao("g", {
                mask: "url(#copy_svg__a)",
                children: Ao("rect", {
                    x: 23.333,
                    y: 18.667,
                    width: 14,
                    height: 14,
                    rx: 1.167,
                    transform: "rotate(-180 23.333 18.667)",
                    stroke: "#6C6B80",
                    strokeWidth: 2.333
                })
            }), Ao("path", {
                d: "M18.667 22.167c0 .644-.523 1.166-1.167 1.166H5.833a1.167 1.167 0 0 1-1.166-1.166V10.5c0-.644.522-1.167 1.166-1.167H17.5c.644 0 1.167.523 1.167 1.167v11.667Z",
                stroke: "#6C6B80",
                strokeWidth: 2.333
            })]
        })),
        Li = e => Ao("svg", __spreadProps(__spreadValues({
            viewBox: "0 0 20 20",
            xmlns: "http://www.w3.org/2000/svg"
        }, e), {
            children: Ao("path", {
                d: "m7.293 14.707-3-3a.999.999 0 1 1 1.414-1.414l2.236 2.236 6.298-7.18a.999.999 0 1 1 1.518 1.3l-7 8a1 1 0 0 1-.72.35 1.017 1.017 0 0 1-.746-.292z",
                fill: "#5C5F62"
            })
        })),
        Fi = {
            myCustomInputContent: "_myCustomInputContent_1n64r_2",
            small: "_small_1n64r_7",
            stickyMobileStyle: "_stickyMobileStyle_1n64r_10",
            mobile: "_mobile_1n64r_13",
            block: "_block_1n64r_17",
            myCustomInput: "_myCustomInput_1n64r_2",
            stickyBarCustomStyle: "_stickyBarCustomStyle_1n64r_46",
            copyBtn: "_copyBtn_1n64r_49",
            discountCodeInput: "_discountCodeInput_1n64r_54",
            large: "_large_1n64r_60",
            standard: "_standard_1n64r_63",
            "input-radius-standard": "_input-radius-standard_1n64r_69",
            "input-radius-none": "_input-radius-none_1n64r_72",
            "input-radius-large": "_input-radius-large_1n64r_75",
            "input-radius-small": "_input-radius-small_1n64r_78"
        };

    function Bi({
        size: e,
        shape: t,
        color: r,
        value: n,
        placeholder: o,
        stickyBarCustomStyle: i,
        block: d,
        isSuccess: a,
        isMobile: s,
        fromSticky: u,
        isManuallyCode: l,
        manuallyCode: c,
        className: f,
        id: $,
        onChange: p,
        type: h,
        style: m,
        autoComplete: _,
        onBlur: y
    }) {
        const v = Ii({
            copiedTimeout: 2e3,
            onSuccess() {
                v.target.current.select()
            }
        });
        return jo("div", {
            className: Go(gi("Input__Wrap"), Fi.myCustomInputContent, d && Fi.block, s && Fi.mobile, u && Fi.stickyMobileStyle, Fi[e], f),
            children: [Ao("input", {
                className: Go(gi("Input__Input"), Fi.myCustomInput, Fi[e], Fi[`input-radius-${t}`], i && Fi.stickyBarCustomStyle, a && Fi.discountCodeInput),
                style: __spreadValues({
                    "--color": `${r}`
                }, m),
                value: l && a && c ? c : n,
                readOnly: a,
                id: $,
                placeholder: o,
                type: h || (a ? "" : "email"),
                ref: v.target,
                autoComplete: _,
                onChange: p,
                onBlur: () => y && y()
            }), a && Ao("div", {
                className: Go(gi("Input_CopyBtn"), Fi.copyBtn),
                onClick: v.copy,
                children: v.copied ? Ao(Li, {}) : Ao(Ri, {})
            })]
        })
    }
    const Yi = {
            modalContainer: "_modalContainer_rds7d_2",
            modalContent: "_modalContent_rds7d_22",
            myCustomDialogWrapper: "_myCustomDialogWrapper_rds7d_29",
            "size-standard": "_size-standard_rds7d_34",
            myCustomDialog: "_myCustomDialog_rds7d_29",
            titleText: "_titleText_rds7d_37",
            titleHelpText: "_titleHelpText_rds7d_40",
            "size-large": "_size-large_rds7d_43",
            "size-small": "_size-small_rds7d_52",
            left: "_left_rds7d_61",
            right: "_right_rds7d_61",
            "cornerRadius-standard": "_cornerRadius-standard_rds7d_64",
            "cornerRadius-none": "_cornerRadius-none_rds7d_67",
            "cornerRadius-large": "_cornerRadius-large_rds7d_70",
            customPic: "_customPic_rds7d_79",
            errContent: "_errContent_rds7d_88",
            errIcon: "_errIcon_rds7d_94",
            errText: "_errText_rds7d_106",
            myLogoImg: "_myLogoImg_rds7d_112",
            center: "_center_rds7d_116",
            closeText: "_closeText_rds7d_174",
            small: "_small_rds7d_191",
            descriptionText: "_descriptionText_rds7d_195",
            closeBtn: "_closeBtn_rds7d_236",
            mobilePosition: "_mobilePosition_rds7d_250",
            adminModalContainer: "_adminModalContainer_rds7d_255",
            bottomLayout: "_bottomLayout_rds7d_286",
            greySign: "_greySign_rds7d_362",
            blueText: "_blueText_rds7d_373"
        },
        Ui = "_errContent_1dz3r_2",
        zi = "_embed_1dz3r_8",
        Wi = "_errIcon_1dz3r_12",
        Gi = "_errText_1dz3r_24",
        Hi = e => Ao("svg", __spreadProps(__spreadValues({
            viewBox: "0 0 20 20",
            xmlns: "http://www.w3.org/2000/svg"
        }, e), {
            children: Ao("path", {
                d: "M10 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16zM9 9a1 1 0 0 0 2 0V7a1 1 0 1 0-2 0v2zm0 4a1 1 0 1 0 2 0 1 1 0 0 0-2 0z",
                fill: "#5C5F62"
            })
        })),
        Vi = ({
            colors: e,
            errText: t,
            embed: r
        }) => jo("div", {
            className: Go(bi("Modal__ErrTextMarkup"), Ui, r ? zi : null),
            style: {
                color: `${e.error_color}`,
                fill: `${e.error_color}`
            },
            children: [Ao("div", {
                className: Wi,
                children: Ao(Hi, {})
            }), Ao("span", {
                className: Gi,
                children: t
            })]
        });
    var qi = {
            exports: {}
        },
        Ki = {
            exports: {}
        };
    ! function(e, t) {
        function r(e) {
            return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e
            } : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            })(e)
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = function(e) {
            if (!("string" == typeof e || e instanceof String)) {
                var t = r(e);
                throw null === e ? t = "null" : "object" === t && (t = e.constructor.name), new TypeError("Expected a string but received a ".concat(t))
            }
        }, e.exports = t.default, e.exports.default = t.default
    }(Ki, Ki.exports);
    var Zi = Ki.exports,
        Ji = {
            exports: {}
        };
    ! function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                t = arguments.length > 1 ? arguments[1] : void 0;
            for (var r in t) void 0 === e[r] && (e[r] = t[r]);
            return e
        }, e.exports = t.default, e.exports.default = t.default
    }(Ji, Ji.exports);
    var Xi = Ji.exports;
    ! function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = function(e, t) {
            return (0, r.default)(e), 0 === ((t = (0, n.default)(t, i)).ignore_whitespace ? e.trim().length : e.length)
        };
        var r = o(Zi),
            n = o(Xi);

        function o(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var i = {
            ignore_whitespace: !1
        };
        e.exports = t.default, e.exports.default = t.default
    }(qi, qi.exports);
    const Qi = Wn(qi.exports);
    var ed = {
            exports: {}
        },
        td = {
            exports: {}
        };
    ! function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = function(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                if (e === n || (o = n, "[object RegExp]" === Object.prototype.toString.call(o) && n.test(e))) return !0
            }
            var o;
            return !1
        }, e.exports = t.default, e.exports.default = t.default
    }(td, td.exports);
    var rd = td.exports,
        nd = {
            exports: {}
        };
    ! function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = function(e, t) {
            var o, i;
            (0, r.default)(e), "object" === n(t) ? (o = t.min || 0, i = t.max) : (o = arguments[1], i = arguments[2]);
            var d = encodeURI(e).split(/%..|./).length - 1;
            return d >= o && (void 0 === i || d <= i)
        };
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }(Zi);

        function n(e) {
            return (n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e
            } : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            })(e)
        }
        e.exports = t.default, e.exports.default = t.default
    }(nd, nd.exports);
    var od = nd.exports,
        id = {
            exports: {}
        };
    ! function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = function(e, t) {
            (0, r.default)(e), (t = (0, n.default)(t, i)).allow_trailing_dot && "." === e[e.length - 1] && (e = e.substring(0, e.length - 1));
            !0 === t.allow_wildcard && 0 === e.indexOf("*.") && (e = e.substring(2));
            var o = e.split("."),
                d = o[o.length - 1];
            if (t.require_tld) {
                if (o.length < 2) return !1;
                if (!t.allow_numeric_tld && !/^([a-z\u00A1-\u00A8\u00AA-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]{2,}|xn[a-z0-9-]{2,})$/i.test(d)) return !1;
                if (/\s/.test(d)) return !1
            }
            if (!t.allow_numeric_tld && /^\d+$/.test(d)) return !1;
            return o.every((function(e) {
                return !(e.length > 63 && !t.ignore_max_length) && (!!/^[a-z_\u00a1-\uffff0-9-]+$/i.test(e) && (!/[\uff01-\uff5e]/.test(e) && (!/^-|-$/.test(e) && !(!t.allow_underscores && /_/.test(e)))))
            }))
        };
        var r = o(Zi),
            n = o(Xi);

        function o(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var i = {
            require_tld: !0,
            allow_underscores: !1,
            allow_trailing_dot: !1,
            allow_numeric_tld: !1,
            allow_wildcard: !1,
            ignore_max_length: !1
        };
        e.exports = t.default, e.exports.default = t.default
    }(id, id.exports);
    var dd = id.exports,
        ad = {
            exports: {}
        };
    ! function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = function e(t) {
            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
            if ((0, r.default)(t), !(n = String(n))) return e(t, 4) || e(t, 6);
            if ("4" === n) return i.test(t);
            if ("6" === n) return a.test(t);
            return !1
        };
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }(Zi);
        var n = "(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])",
            o = "(".concat(n, "[.]){3}").concat(n),
            i = new RegExp("^".concat(o, "$")),
            d = "(?:[0-9a-fA-F]{1,4})",
            a = new RegExp("^(" + "(?:".concat(d, ":){7}(?:").concat(d, "|:)|") + "(?:".concat(d, ":){6}(?:").concat(o, "|:").concat(d, "|:)|") + "(?:".concat(d, ":){5}(?::").concat(o, "|(:").concat(d, "){1,2}|:)|") + "(?:".concat(d, ":){4}(?:(:").concat(d, "){0,1}:").concat(o, "|(:").concat(d, "){1,3}|:)|") + "(?:".concat(d, ":){3}(?:(:").concat(d, "){0,2}:").concat(o, "|(:").concat(d, "){1,4}|:)|") + "(?:".concat(d, ":){2}(?:(:").concat(d, "){0,3}:").concat(o, "|(:").concat(d, "){1,5}|:)|") + "(?:".concat(d, ":){1}(?:(:").concat(d, "){0,4}:").concat(o, "|(:").concat(d, "){1,6}|:)|") + "(?::((?::".concat(d, "){0,5}:").concat(o, "|(?::").concat(d, "){1,7}|:))") + ")(%[0-9a-zA-Z-.:]{1,})?$");
        e.exports = t.default, e.exports.default = t.default
    }(ad, ad.exports);
    var sd = ad.exports;
    ! function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = function(e, t) {
            if ((0, r.default)(e), (t = (0, a.default)(t, u)).require_display_name || t.allow_display_name) {
                var s = e.match(l);
                if (s) {
                    var _ = s[1];
                    if (e = e.replace(_, "").replace(/(^<|>$)/g, ""), _.endsWith(" ") && (_ = _.slice(0, -1)), ! function(e) {
                            var t = e.replace(/^"(.+)"$/, "$1");
                            if (!t.trim()) return !1;
                            if (/[\.";<>]/.test(t)) {
                                if (t === e) return !1;
                                if (!(t.split('"').length === t.split('\\"').length)) return !1
                            }
                            return !0
                        }(_)) return !1
                } else if (t.require_display_name) return !1
            }
            if (!t.ignore_max_length && e.length > m) return !1;
            var y = e.split("@"),
                v = y.pop(),
                g = v.toLowerCase();
            if (t.host_blacklist.length > 0 && (0, n.default)(g, t.host_blacklist)) return !1;
            if (t.host_whitelist.length > 0 && !(0, n.default)(g, t.host_whitelist)) return !1;
            var b = y.join("@");
            if (t.domain_specific_validation && ("gmail.com" === g || "googlemail.com" === g)) {
                var w = (b = b.toLowerCase()).split("+")[0];
                if (!(0, o.default)(w.replace(/\./g, ""), {
                        min: 6,
                        max: 30
                    })) return !1;
                for (var C = w.split("."), S = 0; S < C.length; S++)
                    if (!f.test(C[S])) return !1
            }
            if (!(!1 !== t.ignore_max_length || (0, o.default)(b, {
                    max: 64
                }) && (0, o.default)(v, {
                    max: 254
                }))) return !1;
            if (!(0, i.default)(v, {
                    require_tld: t.require_tld,
                    ignore_max_length: t.ignore_max_length,
                    allow_underscores: t.allow_underscores
                })) {
                if (!t.allow_ip_domain) return !1;
                if (!(0, d.default)(v)) {
                    if (!v.startsWith("[") || !v.endsWith("]")) return !1;
                    var P = v.slice(1, -1);
                    if (0 === P.length || !(0, d.default)(P)) return !1
                }
            }
            if (t.blacklisted_chars && -1 !== b.search(new RegExp("[".concat(t.blacklisted_chars, "]+"), "g"))) return !1;
            if ('"' === b[0] && '"' === b[b.length - 1]) return b = b.slice(1, b.length - 1), t.allow_utf8_local_part ? h.test(b) : $.test(b);
            for (var O = t.allow_utf8_local_part ? p : c, x = b.split("."), E = 0; E < x.length; E++)
                if (!O.test(x[E])) return !1;
            return !0
        };
        var r = s(Zi),
            n = s(rd),
            o = s(od),
            i = s(dd),
            d = s(sd),
            a = s(Xi);

        function s(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var u = {
                allow_display_name: !1,
                allow_underscores: !1,
                require_display_name: !1,
                allow_utf8_local_part: !0,
                require_tld: !0,
                blacklisted_chars: "",
                ignore_max_length: !1,
                host_blacklist: [],
                host_whitelist: []
            },
            l = /^([^\x00-\x1F\x7F-\x9F\cX]+)</i,
            c = /^[a-z\d!#\$%&'\*\+\-\/=\?\^_`{\|}~]+$/i,
            f = /^[a-z\d]+$/,
            $ = /^([\s\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e]|(\\[\x01-\x09\x0b\x0c\x0d-\x7f]))*$/i,
            p = /^[a-z\d!#\$%&'\*\+\-\/=\?\^_`{\|}~\u00A1-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+$/i,
            h = /^([\s\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|(\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*$/i,
            m = 254;
        e.exports = t.default, e.exports.default = t.default
    }(ed, ed.exports);
    const ud = Wn(ed.exports),
        ld = {
            version: 4,
            country_calling_codes: {
                1: ["US", "AG", "AI", "AS", "BB", "BM", "BS", "CA", "DM", "DO", "GD", "GU", "JM", "KN", "KY", "LC", "MP", "MS", "PR", "SX", "TC", "TT", "VC", "VG", "VI"],
                7: ["RU", "KZ"],
                20: ["EG"],
                27: ["ZA"],
                30: ["GR"],
                31: ["NL"],
                32: ["BE"],
                33: ["FR"],
                34: ["ES"],
                36: ["HU"],
                39: ["IT", "VA"],
                40: ["RO"],
                41: ["CH"],
                43: ["AT"],
                44: ["GB", "GG", "IM", "JE"],
                45: ["DK"],
                46: ["SE"],
                47: ["NO", "SJ"],
                48: ["PL"],
                49: ["DE"],
                51: ["PE"],
                52: ["MX"],
                53: ["CU"],
                54: ["AR"],
                55: ["BR"],
                56: ["CL"],
                57: ["CO"],
                58: ["VE"],
                60: ["MY"],
                61: ["AU", "CC", "CX"],
                62: ["ID"],
                63: ["PH"],
                64: ["NZ"],
                65: ["SG"],
                66: ["TH"],
                81: ["JP"],
                82: ["KR"],
                84: ["VN"],
                86: ["CN"],
                90: ["TR"],
                91: ["IN"],
                92: ["PK"],
                93: ["AF"],
                94: ["LK"],
                95: ["MM"],
                98: ["IR"],
                211: ["SS"],
                212: ["MA", "EH"],
                213: ["DZ"],
                216: ["TN"],
                218: ["LY"],
                220: ["GM"],
                221: ["SN"],
                222: ["MR"],
                223: ["ML"],
                224: ["GN"],
                225: ["CI"],
                226: ["BF"],
                227: ["NE"],
                228: ["TG"],
                229: ["BJ"],
                230: ["MU"],
                231: ["LR"],
                232: ["SL"],
                233: ["GH"],
                234: ["NG"],
                235: ["TD"],
                236: ["CF"],
                237: ["CM"],
                238: ["CV"],
                239: ["ST"],
                240: ["GQ"],
                241: ["GA"],
                242: ["CG"],
                243: ["CD"],
                244: ["AO"],
                245: ["GW"],
                246: ["IO"],
                247: ["AC"],
                248: ["SC"],
                249: ["SD"],
                250: ["RW"],
                251: ["ET"],
                252: ["SO"],
                253: ["DJ"],
                254: ["KE"],
                255: ["TZ"],
                256: ["UG"],
                257: ["BI"],
                258: ["MZ"],
                260: ["ZM"],
                261: ["MG"],
                262: ["RE", "YT"],
                263: ["ZW"],
                264: ["NA"],
                265: ["MW"],
                266: ["LS"],
                267: ["BW"],
                268: ["SZ"],
                269: ["KM"],
                290: ["SH", "TA"],
                291: ["ER"],
                297: ["AW"],
                298: ["FO"],
                299: ["GL"],
                350: ["GI"],
                351: ["PT"],
                352: ["LU"],
                353: ["IE"],
                354: ["IS"],
                355: ["AL"],
                356: ["MT"],
                357: ["CY"],
                358: ["FI", "AX"],
                359: ["BG"],
                370: ["LT"],
                371: ["LV"],
                372: ["EE"],
                373: ["MD"],
                374: ["AM"],
                375: ["BY"],
                376: ["AD"],
                377: ["MC"],
                378: ["SM"],
                380: ["UA"],
                381: ["RS"],
                382: ["ME"],
                383: ["XK"],
                385: ["HR"],
                386: ["SI"],
                387: ["BA"],
                389: ["MK"],
                420: ["CZ"],
                421: ["SK"],
                423: ["LI"],
                500: ["FK"],
                501: ["BZ"],
                502: ["GT"],
                503: ["SV"],
                504: ["HN"],
                505: ["NI"],
                506: ["CR"],
                507: ["PA"],
                508: ["PM"],
                509: ["HT"],
                590: ["GP", "BL", "MF"],
                591: ["BO"],
                592: ["GY"],
                593: ["EC"],
                594: ["GF"],
                595: ["PY"],
                596: ["MQ"],
                597: ["SR"],
                598: ["UY"],
                599: ["CW", "BQ"],
                670: ["TL"],
                672: ["NF"],
                673: ["BN"],
                674: ["NR"],
                675: ["PG"],
                676: ["TO"],
                677: ["SB"],
                678: ["VU"],
                679: ["FJ"],
                680: ["PW"],
                681: ["WF"],
                682: ["CK"],
                683: ["NU"],
                685: ["WS"],
                686: ["KI"],
                687: ["NC"],
                688: ["TV"],
                689: ["PF"],
                690: ["TK"],
                691: ["FM"],
                692: ["MH"],
                850: ["KP"],
                852: ["HK"],
                853: ["MO"],
                855: ["KH"],
                856: ["LA"],
                880: ["BD"],
                886: ["TW"],
                960: ["MV"],
                961: ["LB"],
                962: ["JO"],
                963: ["SY"],
                964: ["IQ"],
                965: ["KW"],
                966: ["SA"],
                967: ["YE"],
                968: ["OM"],
                970: ["PS"],
                971: ["AE"],
                972: ["IL"],
                973: ["BH"],
                974: ["QA"],
                975: ["BT"],
                976: ["MN"],
                977: ["NP"],
                992: ["TJ"],
                993: ["TM"],
                994: ["AZ"],
                995: ["GE"],
                996: ["KG"],
                998: ["UZ"]
            },
            countries: {
                AC: ["247", "00", "(?:[01589]\\d|[46])\\d{4}", [5, 6]],
                AD: ["376", "00", "(?:1|6\\d)\\d{7}|[135-9]\\d{5}", [6, 8, 9],
                    [
                        ["(\\d{3})(\\d{3})", "$1 $2", ["[135-9]"]],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["1"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["6"]]
                    ]
                ],
                AE: ["971", "00", "(?:[4-7]\\d|9[0-689])\\d{7}|800\\d{2,9}|[2-4679]\\d{7}", [5, 6, 7, 8, 9, 10, 11, 12],
                    [
                        ["(\\d{3})(\\d{2,9})", "$1 $2", ["60|8"]],
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["[236]|[479][2-8]"], "0$1"],
                        ["(\\d{3})(\\d)(\\d{5})", "$1 $2 $3", ["[479]"]],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["5"], "0$1"]
                    ], "0"
                ],
                AF: ["93", "00", "[2-7]\\d{8}", [9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[2-7]"], "0$1"]
                    ], "0"
                ],
                AG: ["1", "011", "(?:268|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([457]\\d{6})$|1", "268$1", 0, "268"],
                AI: ["1", "011", "(?:264|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2457]\\d{6})$|1", "264$1", 0, "264"],
                AL: ["355", "00", "(?:700\\d\\d|900)\\d{3}|8\\d{5,7}|(?:[2-5]|6\\d)\\d{7}", [6, 7, 8, 9],
                    [
                        ["(\\d{3})(\\d{3,4})", "$1 $2", ["80|9"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["4[2-6]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2358][2-5]|4"], "0$1"],
                        ["(\\d{3})(\\d{5})", "$1 $2", ["[23578]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["6"], "0$1"]
                    ], "0"
                ],
                AM: ["374", "00", "(?:[1-489]\\d|55|60|77)\\d{6}", [8],
                    [
                        ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["[89]0"], "0 $1"],
                        ["(\\d{3})(\\d{5})", "$1 $2", ["2|3[12]"], "(0$1)"],
                        ["(\\d{2})(\\d{6})", "$1 $2", ["1|47"], "(0$1)"],
                        ["(\\d{2})(\\d{6})", "$1 $2", ["[3-9]"], "0$1"]
                    ], "0"
                ],
                AO: ["244", "00", "[29]\\d{8}", [9],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[29]"]]
                    ]
                ],
                AR: ["54", "00", "(?:11|[89]\\d\\d)\\d{8}|[2368]\\d{9}", [10, 11],
                    [
                        ["(\\d{4})(\\d{2})(\\d{4})", "$1 $2-$3", ["2(?:2[024-9]|3[0-59]|47|6[245]|9[02-8])|3(?:3[28]|4[03-9]|5[2-46-8]|7[1-578]|8[2-9])", "2(?:[23]02|6(?:[25]|4[6-8])|9(?:[02356]|4[02568]|72|8[23]))|3(?:3[28]|4(?:[04679]|3[5-8]|5[4-68]|8[2379])|5(?:[2467]|3[237]|8[2-5])|7[1-578]|8(?:[2469]|3[2578]|5[4-8]|7[36-8]|8[5-8]))|2(?:2[24-9]|3[1-59]|47)", "2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3[78]|5(?:4[46]|8)|8[2379])|5(?:[2467]|3[237]|8[23])|7[1-578]|8(?:[2469]|3[278]|5[56][46]|86[3-6]))|2(?:2[24-9]|3[1-59]|47)|38(?:[58][78]|7[378])|3(?:4[35][56]|58[45]|8(?:[38]5|54|76))[4-6]", "2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3(?:5(?:4[0-25689]|[56])|[78])|58|8[2379])|5(?:[2467]|3[237]|8(?:[23]|4(?:[45]|60)|5(?:4[0-39]|5|64)))|7[1-578]|8(?:[2469]|3[278]|54(?:4|5[13-7]|6[89])|86[3-6]))|2(?:2[24-9]|3[1-59]|47)|38(?:[58][78]|7[378])|3(?:454|85[56])[46]|3(?:4(?:36|5[56])|8(?:[38]5|76))[4-6]"], "0$1", 1],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2-$3", ["1"], "0$1", 1],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1-$2-$3", ["[68]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2-$3", ["[23]"], "0$1", 1],
                        ["(\\d)(\\d{4})(\\d{2})(\\d{4})", "$2 15-$3-$4", ["9(?:2[2-469]|3[3-578])", "9(?:2(?:2[024-9]|3[0-59]|47|6[245]|9[02-8])|3(?:3[28]|4[03-9]|5[2-46-8]|7[1-578]|8[2-9]))", "9(?:2(?:[23]02|6(?:[25]|4[6-8])|9(?:[02356]|4[02568]|72|8[23]))|3(?:3[28]|4(?:[04679]|3[5-8]|5[4-68]|8[2379])|5(?:[2467]|3[237]|8[2-5])|7[1-578]|8(?:[2469]|3[2578]|5[4-8]|7[36-8]|8[5-8])))|92(?:2[24-9]|3[1-59]|47)", "9(?:2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3[78]|5(?:4[46]|8)|8[2379])|5(?:[2467]|3[237]|8[23])|7[1-578]|8(?:[2469]|3[278]|5(?:[56][46]|[78])|7[378]|8(?:6[3-6]|[78]))))|92(?:2[24-9]|3[1-59]|47)|93(?:4[35][56]|58[45]|8(?:[38]5|54|76))[4-6]", "9(?:2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3(?:5(?:4[0-25689]|[56])|[78])|5(?:4[46]|8)|8[2379])|5(?:[2467]|3[237]|8(?:[23]|4(?:[45]|60)|5(?:4[0-39]|5|64)))|7[1-578]|8(?:[2469]|3[278]|5(?:4(?:4|5[13-7]|6[89])|[56][46]|[78])|7[378]|8(?:6[3-6]|[78]))))|92(?:2[24-9]|3[1-59]|47)|93(?:4(?:36|5[56])|8(?:[38]5|76))[4-6]"], "0$1", 0, "$1 $2 $3-$4"],
                        ["(\\d)(\\d{2})(\\d{4})(\\d{4})", "$2 15-$3-$4", ["91"], "0$1", 0, "$1 $2 $3-$4"],
                        ["(\\d{3})(\\d{3})(\\d{5})", "$1-$2-$3", ["8"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{3})(\\d{4})", "$2 15-$3-$4", ["9"], "0$1", 0, "$1 $2 $3-$4"]
                    ], "0", 0, "0?(?:(11|2(?:2(?:02?|[13]|2[13-79]|4[1-6]|5[2457]|6[124-8]|7[1-4]|8[13-6]|9[1267])|3(?:02?|1[467]|2[03-6]|3[13-8]|[49][2-6]|5[2-8]|[67])|4(?:7[3-578]|9)|6(?:[0136]|2[24-6]|4[6-8]?|5[15-8])|80|9(?:0[1-3]|[19]|2\\d|3[1-6]|4[02568]?|5[2-4]|6[2-46]|72?|8[23]?))|3(?:3(?:2[79]|6|8[2578])|4(?:0[0-24-9]|[12]|3[5-8]?|4[24-7]|5[4-68]?|6[02-9]|7[126]|8[2379]?|9[1-36-8])|5(?:1|2[1245]|3[237]?|4[1-46-9]|6[2-4]|7[1-6]|8[2-5]?)|6[24]|7(?:[069]|1[1568]|2[15]|3[145]|4[13]|5[14-8]|7[2-57]|8[126])|8(?:[01]|2[15-7]|3[2578]?|4[13-6]|5[4-8]?|6[1-357-9]|7[36-8]?|8[5-8]?|9[124])))15)?", "9$1"
                ],
                AS: ["1", "011", "(?:[58]\\d\\d|684|900)\\d{7}", [10], 0, "1", 0, "([267]\\d{6})$|1", "684$1", 0, "684"],
                AT: ["43", "00", "1\\d{3,12}|2\\d{6,12}|43(?:(?:0\\d|5[02-9])\\d{3,9}|2\\d{4,5}|[3467]\\d{4}|8\\d{4,6}|9\\d{4,7})|5\\d{4,12}|8\\d{7,12}|9\\d{8,12}|(?:[367]\\d|4[0-24-9])\\d{4,11}", [4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
                    [
                        ["(\\d)(\\d{3,12})", "$1 $2", ["1(?:11|[2-9])"], "0$1"],
                        ["(\\d{3})(\\d{2})", "$1 $2", ["517"], "0$1"],
                        ["(\\d{2})(\\d{3,5})", "$1 $2", ["5[079]"], "0$1"],
                        ["(\\d{3})(\\d{3,10})", "$1 $2", ["(?:31|4)6|51|6(?:5[0-3579]|[6-9])|7(?:20|32|8)|[89]"], "0$1"],
                        ["(\\d{4})(\\d{3,9})", "$1 $2", ["[2-467]|5[2-6]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["5"], "0$1"],
                        ["(\\d{2})(\\d{4})(\\d{4,7})", "$1 $2 $3", ["5"], "0$1"]
                    ], "0"
                ],
                AU: ["61", "001[14-689]|14(?:1[14]|34|4[17]|[56]6|7[47]|88)0011", "1(?:[0-79]\\d{7}(?:\\d(?:\\d{2})?)?|8[0-24-9]\\d{7})|[2-478]\\d{8}|1\\d{4,7}", [5, 6, 7, 8, 9, 10, 12],
                    [
                        ["(\\d{2})(\\d{3,4})", "$1 $2", ["16"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{2,4})", "$1 $2 $3", ["16"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["14|4"], "0$1"],
                        ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["[2378]"], "(0$1)"],
                        ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1(?:30|[89])"]]
                    ], "0", 0, "(183[12])|0", 0, 0, 0, [
                        ["(?:(?:(?:2(?:[0-26-9]\\d|3[0-8]|4[02-9]|5[0135-9])|7(?:[013-57-9]\\d|2[0-8]))\\d|3(?:(?:[0-3589]\\d|6[1-9]|7[0-35-9])\\d|4(?:[0-578]\\d|90)))\\d\\d|8(?:51(?:0(?:0[03-9]|[12479]\\d|3[2-9]|5[0-8]|6[1-9]|8[0-7])|1(?:[0235689]\\d|1[0-69]|4[0-589]|7[0-47-9])|2(?:0[0-79]|[18][13579]|2[14-9]|3[0-46-9]|[4-6]\\d|7[89]|9[0-4])|3\\d\\d)|(?:6[0-8]|[78]\\d)\\d{3}|9(?:[02-9]\\d{3}|1(?:(?:[0-58]\\d|6[0135-9])\\d|7(?:0[0-24-9]|[1-9]\\d)|9(?:[0-46-9]\\d|5[0-79])))))\\d{3}", [9]],
                        ["4(?:79[01]|83[0-389]|94[0-4])\\d{5}|4(?:[0-36]\\d|4[047-9]|5[0-25-9]|7[02-8]|8[0-24-9]|9[0-37-9])\\d{6}", [9]],
                        ["180(?:0\\d{3}|2)\\d{3}", [7, 10]],
                        ["190[0-26]\\d{6}", [10]], 0, 0, 0, ["163\\d{2,6}", [5, 6, 7, 8, 9]],
                        ["14(?:5(?:1[0458]|[23][458])|71\\d)\\d{4}", [9]],
                        ["13(?:00\\d{6}(?:\\d{2})?|45[0-4]\\d{3})|13\\d{4}", [6, 8, 10, 12]]
                    ], "0011"
                ],
                AW: ["297", "00", "(?:[25-79]\\d\\d|800)\\d{4}", [7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[25-9]"]]
                    ]
                ],
                AX: ["358", "00|99(?:[01469]|5(?:[14]1|3[23]|5[59]|77|88|9[09]))", "2\\d{4,9}|35\\d{4,5}|(?:60\\d\\d|800)\\d{4,6}|7\\d{5,11}|(?:[14]\\d|3[0-46-9]|50)\\d{4,8}", [5, 6, 7, 8, 9, 10, 11, 12], 0, "0", 0, 0, 0, 0, "18", 0, "00"],
                AZ: ["994", "00", "365\\d{6}|(?:[124579]\\d|60|88)\\d{7}", [9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["90"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["1[28]|2|365|46", "1[28]|2|365[45]|46", "1[28]|2|365(?:4|5[02])|46"], "(0$1)"],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[13-9]"], "0$1"]
                    ], "0"
                ],
                BA: ["387", "00", "6\\d{8}|(?:[35689]\\d|49|70)\\d{6}", [8, 9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["6[1-3]|[7-9]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2-$3", ["[3-5]|6[56]"], "0$1"],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3 $4", ["6"], "0$1"]
                    ], "0"
                ],
                BB: ["1", "011", "(?:246|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "246$1", 0, "246"],
                BD: ["880", "00", "[1-469]\\d{9}|8[0-79]\\d{7,8}|[2-79]\\d{8}|[2-9]\\d{7}|[3-9]\\d{6}|[57-9]\\d{5}", [6, 7, 8, 9, 10],
                    [
                        ["(\\d{2})(\\d{4,6})", "$1-$2", ["31[5-8]|[459]1"], "0$1"],
                        ["(\\d{3})(\\d{3,7})", "$1-$2", ["3(?:[67]|8[013-9])|4(?:6[168]|7|[89][18])|5(?:6[128]|9)|6(?:[15]|28|4[14])|7[2-589]|8(?:0[014-9]|[12])|9[358]|(?:3[2-5]|4[235]|5[2-578]|6[0389]|76|8[3-7]|9[24])1|(?:44|66)[01346-9]"], "0$1"],
                        ["(\\d{4})(\\d{3,6})", "$1-$2", ["[13-9]|2[23]"], "0$1"],
                        ["(\\d)(\\d{7,8})", "$1-$2", ["2"], "0$1"]
                    ], "0"
                ],
                BE: ["32", "00", "4\\d{8}|[1-9]\\d{7}", [8, 9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["(?:80|9)0"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[239]|4[23]"], "0$1"],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[15-8]"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["4"], "0$1"]
                    ], "0"
                ],
                BF: ["226", "00", "[025-7]\\d{7}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[025-7]"]]
                    ]
                ],
                BG: ["359", "00", "00800\\d{7}|[2-7]\\d{6,7}|[89]\\d{6,8}|2\\d{5}", [6, 7, 8, 9, 12],
                    [
                        ["(\\d)(\\d)(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["2"], "0$1"],
                        ["(\\d{3})(\\d{4})", "$1 $2", ["43[1-6]|70[1-9]"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{3,4})", "$1 $2 $3", ["2"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{2,3})", "$1 $2 $3", ["[356]|4[124-7]|7[1-9]|8[1-6]|9[1-7]"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["(?:70|8)0"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{2})", "$1 $2 $3", ["43[1-7]|7"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[48]|9[08]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["9"], "0$1"]
                    ], "0"
                ],
                BH: ["973", "00", "[136-9]\\d{7}", [8],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[13679]|8[02-4679]"]]
                    ]
                ],
                BI: ["257", "00", "(?:[267]\\d|31)\\d{6}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2367]"]]
                    ]
                ],
                BJ: ["229", "00", "(?:01\\d|[24-689])\\d{7}", [8, 10],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[24-689]"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["0"]]
                    ]
                ],
                BL: ["590", "00", "(?:590\\d|7090)\\d{5}|(?:69|80|9\\d)\\d{7}", [9], 0, "0", 0, 0, 0, 0, 0, [
                    ["590(?:2[7-9]|3[3-7]|5[12]|87)\\d{4}"],
                    ["(?:69(?:0\\d\\d|1(?:2[2-9]|3[0-5])|4(?:0[89]|1[2-6]|9\\d)|6(?:1[016-9]|5[0-4]|[67]\\d))|7090[0-4])\\d{4}"],
                    ["80[0-5]\\d{6}"], 0, 0, 0, 0, 0, ["9(?:(?:39[5-7]|76[018])\\d|475[0-6])\\d{4}"]
                ]],
                BM: ["1", "011", "(?:441|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "441$1", 0, "441"],
                BN: ["673", "00", "[2-578]\\d{6}", [7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[2-578]"]]
                    ]
                ],
                BO: ["591", "00(?:1\\d)?", "8001\\d{5}|(?:[2-467]\\d|50)\\d{6}", [8, 9],
                    [
                        ["(\\d)(\\d{7})", "$1 $2", ["[235]|4[46]"]],
                        ["(\\d{8})", "$1", ["[67]"]],
                        ["(\\d{3})(\\d{2})(\\d{4})", "$1 $2 $3", ["8"]]
                    ], "0", 0, "0(1\\d)?"
                ],
                BQ: ["599", "00", "(?:[34]1|7\\d)\\d{5}", [7], 0, 0, 0, 0, 0, 0, "[347]"],
                BR: ["55", "00(?:1[245]|2[1-35]|31|4[13]|[56]5|99)", "(?:[1-46-9]\\d\\d|5(?:[0-46-9]\\d|5[0-46-9]))\\d{8}|[1-9]\\d{9}|[3589]\\d{8}|[34]\\d{7}", [8, 9, 10, 11],
                    [
                        ["(\\d{4})(\\d{4})", "$1-$2", ["300|4(?:0[02]|37)", "4(?:02|37)0|[34]00"]],
                        ["(\\d{3})(\\d{2,3})(\\d{4})", "$1 $2 $3", ["(?:[358]|90)0"], "0$1"],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2-$3", ["(?:[14689][1-9]|2[12478]|3[1-578]|5[13-5]|7[13-579])[2-57]"], "($1)"],
                        ["(\\d{2})(\\d{5})(\\d{4})", "$1 $2-$3", ["[16][1-9]|[2-57-9]"], "($1)"]
                    ], "0", 0, "(?:0|90)(?:(1[245]|2[1-35]|31|4[13]|[56]5|99)(\\d{10,11}))?", "$2"
                ],
                BS: ["1", "011", "(?:242|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([3-8]\\d{6})$|1", "242$1", 0, "242"],
                BT: ["975", "00", "[17]\\d{7}|[2-8]\\d{6}", [7, 8],
                    [
                        ["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["[2-68]|7[246]"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["1[67]|7"]]
                    ]
                ],
                BW: ["267", "00", "(?:0800|(?:[37]|800)\\d)\\d{6}|(?:[2-6]\\d|90)\\d{5}", [7, 8, 10],
                    [
                        ["(\\d{2})(\\d{5})", "$1 $2", ["90"]],
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[24-6]|3[15-9]"]],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[37]"]],
                        ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["0"]],
                        ["(\\d{3})(\\d{4})(\\d{3})", "$1 $2 $3", ["8"]]
                    ]
                ],
                BY: ["375", "810", "(?:[12]\\d|33|44|902)\\d{7}|8(?:0[0-79]\\d{5,7}|[1-7]\\d{9})|8(?:1[0-489]|[5-79]\\d)\\d{7}|8[1-79]\\d{6,7}|8[0-79]\\d{5}|8\\d{5}", [6, 7, 8, 9, 10, 11],
                    [
                        ["(\\d{3})(\\d{3})", "$1 $2", ["800"], "8 $1"],
                        ["(\\d{3})(\\d{2})(\\d{2,4})", "$1 $2 $3", ["800"], "8 $1"],
                        ["(\\d{4})(\\d{2})(\\d{3})", "$1 $2-$3", ["1(?:5[169]|6[3-5]|7[179])|2(?:1[35]|2[34]|3[3-5])", "1(?:5[169]|6(?:3[1-3]|4|5[125])|7(?:1[3-9]|7[0-24-6]|9[2-7]))|2(?:1[35]|2[34]|3[3-5])"], "8 0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["1(?:[56]|7[467])|2[1-3]"], "8 0$1"],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["[1-4]"], "8 0$1"],
                        ["(\\d{3})(\\d{3,4})(\\d{4})", "$1 $2 $3", ["[89]"], "8 $1"]
                    ], "8", 0, "0|80?", 0, 0, 0, 0, "8~10"
                ],
                BZ: ["501", "00", "(?:0800\\d|[2-8])\\d{6}", [7, 11],
                    [
                        ["(\\d{3})(\\d{4})", "$1-$2", ["[2-8]"]],
                        ["(\\d)(\\d{3})(\\d{4})(\\d{3})", "$1-$2-$3-$4", ["0"]]
                    ]
                ],
                CA: ["1", "011", "[2-9]\\d{9}|3\\d{6}", [7, 10], 0, "1", 0, 0, 0, 0, 0, [
                    ["(?:2(?:04|[23]6|[48]9|50|63)|3(?:06|43|54|6[578]|82)|4(?:03|1[68]|[26]8|3[178]|50|74)|5(?:06|1[49]|48|79|8[147])|6(?:04|[18]3|39|47|72)|7(?:0[59]|42|53|78|8[02])|8(?:[06]7|19|25|7[39])|9(?:0[25]|42))[2-9]\\d{6}", [10]],
                    ["", [10]],
                    ["8(?:00|33|44|55|66|77|88)[2-9]\\d{6}", [10]],
                    ["900[2-9]\\d{6}", [10]],
                    ["52(?:3(?:[2-46-9][02-9]\\d|5(?:[02-46-9]\\d|5[0-46-9]))|4(?:[2-478][02-9]\\d|5(?:[034]\\d|2[024-9]|5[0-46-9])|6(?:0[1-9]|[2-9]\\d)|9(?:[05-9]\\d|2[0-5]|49)))\\d{4}|52[34][2-9]1[02-9]\\d{4}|(?:5(?:2[125-9]|33|44|66|77|88)|6(?:22|33))[2-9]\\d{6}", [10]], 0, ["310\\d{4}", [7]], 0, ["600[2-9]\\d{6}", [10]]
                ]],
                CC: ["61", "001[14-689]|14(?:1[14]|34|4[17]|[56]6|7[47]|88)0011", "1(?:[0-79]\\d{8}(?:\\d{2})?|8[0-24-9]\\d{7})|[148]\\d{8}|1\\d{5,7}", [6, 7, 8, 9, 10, 12], 0, "0", 0, "([59]\\d{7})$|0", "8$1", 0, 0, [
                    ["8(?:51(?:0(?:02|31|60|89)|1(?:18|76)|223)|91(?:0(?:1[0-2]|29)|1(?:[28]2|50|79)|2(?:10|64)|3(?:[06]8|22)|4[29]8|62\\d|70[23]|959))\\d{3}", [9]],
                    ["4(?:79[01]|83[0-389]|94[0-4])\\d{5}|4(?:[0-36]\\d|4[047-9]|5[0-25-9]|7[02-8]|8[0-24-9]|9[0-37-9])\\d{6}", [9]],
                    ["180(?:0\\d{3}|2)\\d{3}", [7, 10]],
                    ["190[0-26]\\d{6}", [10]], 0, 0, 0, 0, ["14(?:5(?:1[0458]|[23][458])|71\\d)\\d{4}", [9]],
                    ["13(?:00\\d{6}(?:\\d{2})?|45[0-4]\\d{3})|13\\d{4}", [6, 8, 10, 12]]
                ], "0011"],
                CD: ["243", "00", "(?:(?:[189]|5\\d)\\d|2)\\d{7}|[1-68]\\d{6}", [7, 8, 9, 10],
                    [
                        ["(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3", ["88"], "0$1"],
                        ["(\\d{2})(\\d{5})", "$1 $2", ["[1-6]"], "0$1"],
                        ["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["2"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[89]"], "0$1"],
                        ["(\\d{2})(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["5"], "0$1"]
                    ], "0"
                ],
                CF: ["236", "00", "(?:[27]\\d{3}|8776)\\d{4}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[278]"]]
                    ]
                ],
                CG: ["242", "00", "222\\d{6}|(?:0\\d|80)\\d{7}", [9],
                    [
                        ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["8"]],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[02]"]]
                    ]
                ],
                CH: ["41", "00", "8\\d{11}|[2-9]\\d{8}", [9, 12],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["8[047]|90"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2-79]|81"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["8"], "0$1"]
                    ], "0"
                ],
                CI: ["225", "00", "[02]\\d{9}", [10],
                    [
                        ["(\\d{2})(\\d{2})(\\d)(\\d{5})", "$1 $2 $3 $4", ["2"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3 $4", ["0"]]
                    ]
                ],
                CK: ["682", "00", "[2-578]\\d{4}", [5],
                    [
                        ["(\\d{2})(\\d{3})", "$1 $2", ["[2-578]"]]
                    ]
                ],
                CL: ["56", "(?:0|1(?:1[0-69]|2[02-5]|5[13-58]|69|7[0167]|8[018]))0", "12300\\d{6}|6\\d{9,10}|[2-9]\\d{8}", [9, 10, 11],
                    [
                        ["(\\d{5})(\\d{4})", "$1 $2", ["219", "2196"], "($1)"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["44"]],
                        ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["2[1-36]"], "($1)"],
                        ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["9[2-9]"]],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["3[2-5]|[47]|5[1-3578]|6[13-57]|8(?:0[1-9]|[1-9])"], "($1)"],
                        ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["60|8"]],
                        ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"]],
                        ["(\\d{3})(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3 $4", ["60"]]
                    ]
                ],
                CM: ["237", "00", "[26]\\d{8}|88\\d{6,7}", [8, 9],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["88"]],
                        ["(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["[26]|88"]]
                    ]
                ],
                CN: ["86", "00|1(?:[12]\\d|79)\\d\\d00", "(?:(?:1[03-689]|2\\d)\\d\\d|6)\\d{8}|1\\d{10}|[126]\\d{6}(?:\\d(?:\\d{2})?)?|86\\d{5,6}|(?:[3-579]\\d|8[0-57-9])\\d{5,9}", [7, 8, 9, 10, 11, 12],
                    [
                        ["(\\d{2})(\\d{5,6})", "$1 $2", ["(?:10|2[0-57-9])[19]|3(?:[157]|35|49|9[1-68])|4(?:1[124-9]|2[179]|6[47-9]|7|8[23])|5(?:[1357]|2[37]|4[36]|6[1-46]|80)|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:07|1[236-8]|2[5-7]|[37]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3|4[13]|5[1-5]|7[0-79]|9[0-35-9])|(?:4[35]|59|85)[1-9]", "(?:10|2[0-57-9])(?:1[02]|9[56])|8078|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))1", "10(?:1(?:0|23)|9[56])|2[0-57-9](?:1(?:00|23)|9[56])|80781|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))12", "10(?:1(?:0|23)|9[56])|2[0-57-9](?:1(?:00|23)|9[56])|807812|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))123", "10(?:1(?:0|23)|9[56])|2[0-57-9](?:1(?:00|23)|9[56])|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:078|1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))123"], "0$1"],
                        ["(\\d{3})(\\d{5,6})", "$1 $2", ["3(?:[157]|35|49|9[1-68])|4(?:[17]|2[179]|6[47-9]|8[23])|5(?:[1357]|2[37]|4[36]|6[1-46]|80)|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]|4[13]|5[1-5])|(?:4[35]|59|85)[1-9]", "(?:3(?:[157]\\d|35|49|9[1-68])|4(?:[17]\\d|2[179]|[35][1-9]|6[47-9]|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]\\d|4[13]|5[1-5]))[19]", "85[23](?:10|95)|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:[17]\\d|2[179]|[35][1-9]|6[47-9]|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[14-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]\\d|4[13]|5[1-5]))(?:10|9[56])", "85[23](?:100|95)|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:[17]\\d|2[179]|[35][1-9]|6[47-9]|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[14-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]\\d|4[13]|5[1-5]))(?:100|9[56])"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["(?:4|80)0"]],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["10|2(?:[02-57-9]|1[1-9])", "10|2(?:[02-57-9]|1[1-9])", "10[0-79]|2(?:[02-57-9]|1[1-79])|(?:10|21)8(?:0[1-9]|[1-9])"], "0$1", 1],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["3(?:[3-59]|7[02-68])|4(?:[26-8]|3[3-9]|5[2-9])|5(?:3[03-9]|[468]|7[028]|9[2-46-9])|6|7(?:[0-247]|3[04-9]|5[0-4689]|6[2368])|8(?:[1-358]|9[1-7])|9(?:[013479]|5[1-5])|(?:[34]1|55|79|87)[02-9]"], "0$1", 1],
                        ["(\\d{3})(\\d{7,8})", "$1 $2", ["9"]],
                        ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["80"], "0$1", 1],
                        ["(\\d{3})(\\d{4})(\\d{4})", "$1 $2 $3", ["[3-578]"], "0$1", 1],
                        ["(\\d{3})(\\d{4})(\\d{4})", "$1 $2 $3", ["1[3-9]"]],
                        ["(\\d{2})(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3 $4", ["[12]"], "0$1", 1]
                    ], "0", 0, "(1(?:[12]\\d|79)\\d\\d)|0", 0, 0, 0, 0, "00"
                ],
                CO: ["57", "00(?:4(?:[14]4|56)|[579])", "(?:46|60\\d\\d)\\d{6}|(?:1\\d|[39])\\d{9}", [8, 10, 11],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["46"]],
                        ["(\\d{3})(\\d{7})", "$1 $2", ["6|90"], "($1)"],
                        ["(\\d{3})(\\d{7})", "$1 $2", ["3[0-357]|91"]],
                        ["(\\d)(\\d{3})(\\d{7})", "$1-$2-$3", ["1"], "0$1", 0, "$1 $2 $3"]
                    ], "0", 0, "0([3579]|4(?:[14]4|56))?"
                ],
                CR: ["506", "00", "(?:8\\d|90)\\d{8}|(?:[24-8]\\d{3}|3005)\\d{4}", [8, 10],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[2-7]|8[3-9]"]],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1-$2-$3", ["[89]"]]
                    ], 0, 0, "(19(?:0[0-2468]|1[09]|20|66|77|99))"
                ],
                CU: ["53", "119", "(?:[2-7]|8\\d\\d)\\d{7}|[2-47]\\d{6}|[34]\\d{5}", [6, 7, 8, 10],
                    [
                        ["(\\d{2})(\\d{4,6})", "$1 $2", ["2[1-4]|[34]"], "(0$1)"],
                        ["(\\d)(\\d{6,7})", "$1 $2", ["7"], "(0$1)"],
                        ["(\\d)(\\d{7})", "$1 $2", ["[56]"], "0$1"],
                        ["(\\d{3})(\\d{7})", "$1 $2", ["8"], "0$1"]
                    ], "0"
                ],
                CV: ["238", "0", "(?:[2-59]\\d\\d|800)\\d{4}", [7],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3", ["[2-589]"]]
                    ]
                ],
                CW: ["599", "00", "(?:[34]1|60|(?:7|9\\d)\\d)\\d{5}", [7, 8],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[3467]"]],
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["9[4-8]"]]
                    ], 0, 0, 0, 0, 0, "[69]"
                ],
                CX: ["61", "001[14-689]|14(?:1[14]|34|4[17]|[56]6|7[47]|88)0011", "1(?:[0-79]\\d{8}(?:\\d{2})?|8[0-24-9]\\d{7})|[148]\\d{8}|1\\d{5,7}", [6, 7, 8, 9, 10, 12], 0, "0", 0, "([59]\\d{7})$|0", "8$1", 0, 0, [
                    ["8(?:51(?:0(?:01|30|59|88)|1(?:17|46|75)|2(?:22|35))|91(?:00[6-9]|1(?:[28]1|49|78)|2(?:09|63)|3(?:12|26|75)|4(?:56|97)|64\\d|7(?:0[01]|1[0-2])|958))\\d{3}", [9]],
                    ["4(?:79[01]|83[0-389]|94[0-4])\\d{5}|4(?:[0-36]\\d|4[047-9]|5[0-25-9]|7[02-8]|8[0-24-9]|9[0-37-9])\\d{6}", [9]],
                    ["180(?:0\\d{3}|2)\\d{3}", [7, 10]],
                    ["190[0-26]\\d{6}", [10]], 0, 0, 0, 0, ["14(?:5(?:1[0458]|[23][458])|71\\d)\\d{4}", [9]],
                    ["13(?:00\\d{6}(?:\\d{2})?|45[0-4]\\d{3})|13\\d{4}", [6, 8, 10, 12]]
                ], "0011"],
                CY: ["357", "00", "(?:[279]\\d|[58]0)\\d{6}", [8],
                    [
                        ["(\\d{2})(\\d{6})", "$1 $2", ["[257-9]"]]
                    ]
                ],
                CZ: ["420", "00", "(?:[2-578]\\d|60)\\d{7}|9\\d{8,11}", [9, 10, 11, 12],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2-8]|9[015-7]"]],
                        ["(\\d{2})(\\d{3})(\\d{3})(\\d{2})", "$1 $2 $3 $4", ["96"]],
                        ["(\\d{2})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["9"]],
                        ["(\\d{3})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["9"]]
                    ]
                ],
                DE: ["49", "00", "[2579]\\d{5,14}|49(?:[34]0|69|8\\d)\\d\\d?|49(?:37|49|60|7[089]|9\\d)\\d{1,3}|49(?:2[024-9]|3[2-689]|7[1-7])\\d{1,8}|(?:1|[368]\\d|4[0-8])\\d{3,13}|49(?:[015]\\d|2[13]|31|[46][1-8])\\d{1,9}", [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
                    [
                        ["(\\d{2})(\\d{3,13})", "$1 $2", ["3[02]|40|[68]9"], "0$1"],
                        ["(\\d{3})(\\d{3,12})", "$1 $2", ["2(?:0[1-389]|1[124]|2[18]|3[14])|3(?:[35-9][15]|4[015])|906|(?:2[4-9]|4[2-9]|[579][1-9]|[68][1-8])1", "2(?:0[1-389]|12[0-8])|3(?:[35-9][15]|4[015])|906|2(?:[13][14]|2[18])|(?:2[4-9]|4[2-9]|[579][1-9]|[68][1-8])1"], "0$1"],
                        ["(\\d{4})(\\d{2,11})", "$1 $2", ["[24-6]|3(?:[3569][02-46-9]|4[2-4679]|7[2-467]|8[2-46-8])|70[2-8]|8(?:0[2-9]|[1-8])|90[7-9]|[79][1-9]", "[24-6]|3(?:3(?:0[1-467]|2[127-9]|3[124578]|7[1257-9]|8[1256]|9[145])|4(?:2[135]|4[13578]|9[1346])|5(?:0[14]|2[1-3589]|6[1-4]|7[13468]|8[13568])|6(?:2[1-489]|3[124-6]|6[13]|7[12579]|8[1-356]|9[135])|7(?:2[1-7]|4[145]|6[1-5]|7[1-4])|8(?:21|3[1468]|6|7[1467]|8[136])|9(?:0[12479]|2[1358]|4[134679]|6[1-9]|7[136]|8[147]|9[1468]))|70[2-8]|8(?:0[2-9]|[1-8])|90[7-9]|[79][1-9]|3[68]4[1347]|3(?:47|60)[1356]|3(?:3[46]|46|5[49])[1246]|3[4579]3[1357]"], "0$1"],
                        ["(\\d{3})(\\d{4})", "$1 $2", ["138"], "0$1"],
                        ["(\\d{5})(\\d{2,10})", "$1 $2", ["3"], "0$1"],
                        ["(\\d{3})(\\d{5,11})", "$1 $2", ["181"], "0$1"],
                        ["(\\d{3})(\\d)(\\d{4,10})", "$1 $2 $3", ["1(?:3|80)|9"], "0$1"],
                        ["(\\d{3})(\\d{7,8})", "$1 $2", ["1[67]"], "0$1"],
                        ["(\\d{3})(\\d{7,12})", "$1 $2", ["8"], "0$1"],
                        ["(\\d{5})(\\d{6})", "$1 $2", ["185", "1850", "18500"], "0$1"],
                        ["(\\d{3})(\\d{4})(\\d{4})", "$1 $2 $3", ["7"], "0$1"],
                        ["(\\d{4})(\\d{7})", "$1 $2", ["18[68]"], "0$1"],
                        ["(\\d{4})(\\d{7})", "$1 $2", ["15[1279]"], "0$1"],
                        ["(\\d{5})(\\d{6})", "$1 $2", ["15[03568]", "15(?:[0568]|31)"], "0$1"],
                        ["(\\d{3})(\\d{8})", "$1 $2", ["18"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{7,8})", "$1 $2 $3", ["1(?:6[023]|7)"], "0$1"],
                        ["(\\d{4})(\\d{2})(\\d{7})", "$1 $2 $3", ["15[279]"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{8})", "$1 $2 $3", ["15"], "0$1"]
                    ], "0"
                ],
                DJ: ["253", "00", "(?:2\\d|77)\\d{6}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[27]"]]
                    ]
                ],
                DK: ["45", "00", "[2-9]\\d{7}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2-9]"]]
                    ]
                ],
                DM: ["1", "011", "(?:[58]\\d\\d|767|900)\\d{7}", [10], 0, "1", 0, "([2-7]\\d{6})$|1", "767$1", 0, "767"],
                DO: ["1", "011", "(?:[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, 0, 0, 0, "8001|8[024]9"],
                DZ: ["213", "00", "(?:[1-4]|[5-79]\\d|80)\\d{7}", [8, 9],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[1-4]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["9"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-8]"], "0$1"]
                    ], "0"
                ],
                EC: ["593", "00", "1\\d{9,10}|(?:[2-7]|9\\d)\\d{7}", [8, 9, 10, 11],
                    [
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2-$3", ["[2-7]"], "(0$1)", 0, "$1-$2-$3"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["9"], "0$1"],
                        ["(\\d{4})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["1"]]
                    ], "0"
                ],
                EE: ["372", "00", "8\\d{9}|[4578]\\d{7}|(?:[3-8]\\d|90)\\d{5}", [7, 8, 10],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[369]|4[3-8]|5(?:[0-2]|5[0-478]|6[45])|7[1-9]|88", "[369]|4[3-8]|5(?:[02]|1(?:[0-8]|95)|5[0-478]|6(?:4[0-4]|5[1-589]))|7[1-9]|88"]],
                        ["(\\d{4})(\\d{3,4})", "$1 $2", ["[45]|8(?:00|[1-49])", "[45]|8(?:00[1-9]|[1-49])"]],
                        ["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["7"]],
                        ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"]]
                    ]
                ],
                EG: ["20", "00", "[189]\\d{8,9}|[24-6]\\d{8}|[135]\\d{7}", [8, 9, 10],
                    [
                        ["(\\d)(\\d{7,8})", "$1 $2", ["[23]"], "0$1"],
                        ["(\\d{2})(\\d{6,7})", "$1 $2", ["1[35]|[4-6]|8[2468]|9[235-7]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[89]"], "0$1"],
                        ["(\\d{2})(\\d{8})", "$1 $2", ["1"], "0$1"]
                    ], "0"
                ],
                EH: ["212", "00", "[5-8]\\d{8}", [9], 0, "0", 0, 0, 0, 0, "528[89]"],
                ER: ["291", "00", "[178]\\d{6}", [7],
                    [
                        ["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["[178]"], "0$1"]
                    ], "0"
                ],
                ES: ["34", "00", "[5-9]\\d{8}", [9],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[89]00"]],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-9]"]]
                    ]
                ],
                ET: ["251", "00", "(?:11|[2-579]\\d)\\d{7}", [9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[1-579]"], "0$1"]
                    ], "0"
                ],
                FI: ["358", "00|99(?:[01469]|5(?:[14]1|3[23]|5[59]|77|88|9[09]))", "[1-35689]\\d{4}|7\\d{10,11}|(?:[124-7]\\d|3[0-46-9])\\d{8}|[1-9]\\d{5,8}", [5, 6, 7, 8, 9, 10, 11, 12],
                    [
                        ["(\\d{5})", "$1", ["20[2-59]"], "0$1"],
                        ["(\\d{3})(\\d{3,7})", "$1 $2", ["(?:[1-3]0|[68])0|70[07-9]"], "0$1"],
                        ["(\\d{2})(\\d{4,8})", "$1 $2", ["[14]|2[09]|50|7[135]"], "0$1"],
                        ["(\\d{2})(\\d{6,10})", "$1 $2", ["7"], "0$1"],
                        ["(\\d)(\\d{4,9})", "$1 $2", ["(?:19|[2568])[1-8]|3(?:0[1-9]|[1-9])|9"], "0$1"]
                    ], "0", 0, 0, 0, 0, "1[03-79]|[2-9]", 0, "00"
                ],
                FJ: ["679", "0(?:0|52)", "45\\d{5}|(?:0800\\d|[235-9])\\d{6}", [7, 11],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[235-9]|45"]],
                        ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["0"]]
                    ], 0, 0, 0, 0, 0, 0, 0, "00"
                ],
                FK: ["500", "00", "[2-7]\\d{4}", [5]],
                FM: ["691", "00", "(?:[39]\\d\\d|820)\\d{4}", [7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[389]"]]
                    ]
                ],
                FO: ["298", "00", "[2-9]\\d{5}", [6],
                    [
                        ["(\\d{6})", "$1", ["[2-9]"]]
                    ], 0, 0, "(10(?:01|[12]0|88))"
                ],
                FR: ["33", "00", "[1-9]\\d{8}", [9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"], "0 $1"],
                        ["(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["[1-79]"], "0$1"]
                    ], "0"
                ],
                GA: ["241", "00", "(?:[067]\\d|11)\\d{6}|[2-7]\\d{6}", [7, 8],
                    [
                        ["(\\d)(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2-7]"], "0$1"],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["0"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["11|[67]"], "0$1"]
                    ], 0, 0, "0(11\\d{6}|60\\d{6}|61\\d{6}|6[256]\\d{6}|7[467]\\d{6})", "$1"
                ],
                GB: ["44", "00", "[1-357-9]\\d{9}|[18]\\d{8}|8\\d{6}", [7, 9, 10],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["800", "8001", "80011", "800111", "8001111"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3", ["845", "8454", "84546", "845464"], "0$1"],
                        ["(\\d{3})(\\d{6})", "$1 $2", ["800"], "0$1"],
                        ["(\\d{5})(\\d{4,5})", "$1 $2", ["1(?:38|5[23]|69|76|94)", "1(?:(?:38|69)7|5(?:24|39)|768|946)", "1(?:3873|5(?:242|39[4-6])|(?:697|768)[347]|9467)"], "0$1"],
                        ["(\\d{4})(\\d{5,6})", "$1 $2", ["1(?:[2-69][02-9]|[78])"], "0$1"],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["[25]|7(?:0|6[02-9])", "[25]|7(?:0|6(?:[03-9]|2[356]))"], "0$1"],
                        ["(\\d{4})(\\d{6})", "$1 $2", ["7"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[1389]"], "0$1"]
                    ], "0", 0, 0, 0, 0, 0, [
                        ["(?:1(?:1(?:3(?:[0-58]\\d\\d|73[0-35])|4(?:(?:[0-5]\\d|70)\\d|69[7-9])|(?:(?:5[0-26-9]|[78][0-49])\\d|6(?:[0-4]\\d|50))\\d)|(?:2(?:(?:0[024-9]|2[3-9]|3[3-79]|4[1-689]|[58][02-9]|6[0-47-9]|7[013-9]|9\\d)\\d|1(?:[0-7]\\d|8[0-3]))|(?:3(?:0\\d|1[0-8]|[25][02-9]|3[02-579]|[468][0-46-9]|7[1-35-79]|9[2-578])|4(?:0[03-9]|[137]\\d|[28][02-57-9]|4[02-69]|5[0-8]|[69][0-79])|5(?:0[1-35-9]|[16]\\d|2[024-9]|3[015689]|4[02-9]|5[03-9]|7[0-35-9]|8[0-468]|9[0-57-9])|6(?:0[034689]|1\\d|2[0-35689]|[38][013-9]|4[1-467]|5[0-69]|6[13-9]|7[0-8]|9[0-24578])|7(?:0[0246-9]|2\\d|3[0236-8]|4[03-9]|5[0-46-9]|6[013-9]|7[0-35-9]|8[024-9]|9[02-9])|8(?:0[35-9]|2[1-57-9]|3[02-578]|4[0-578]|5[124-9]|6[2-69]|7\\d|8[02-9]|9[02569])|9(?:0[02-589]|[18]\\d|2[02-689]|3[1-57-9]|4[2-9]|5[0-579]|6[2-47-9]|7[0-24578]|9[2-57]))\\d)\\d)|2(?:0[013478]|3[0189]|4[017]|8[0-46-9]|9[0-2])\\d{3})\\d{4}|1(?:2(?:0(?:46[1-4]|87[2-9])|545[1-79]|76(?:2\\d|3[1-8]|6[1-6])|9(?:7(?:2[0-4]|3[2-5])|8(?:2[2-8]|7[0-47-9]|8[3-5])))|3(?:6(?:38[2-5]|47[23])|8(?:47[04-9]|64[0157-9]))|4(?:044[1-7]|20(?:2[23]|8\\d)|6(?:0(?:30|5[2-57]|6[1-8]|7[2-8])|140)|8(?:052|87[1-3]))|5(?:2(?:4(?:3[2-79]|6\\d)|76\\d)|6(?:26[06-9]|686))|6(?:06(?:4\\d|7[4-79])|295[5-7]|35[34]\\d|47(?:24|61)|59(?:5[08]|6[67]|74)|9(?:55[0-4]|77[23]))|7(?:26(?:6[13-9]|7[0-7])|(?:442|688)\\d|50(?:2[0-3]|[3-68]2|76))|8(?:27[56]\\d|37(?:5[2-5]|8[239])|843[2-58])|9(?:0(?:0(?:6[1-8]|85)|52\\d)|3583|4(?:66[1-8]|9(?:2[01]|81))|63(?:23|3[1-4])|9561))\\d{3}", [9, 10]],
                        ["7(?:457[0-57-9]|700[01]|911[028])\\d{5}|7(?:[1-3]\\d\\d|4(?:[0-46-9]\\d|5[0-689])|5(?:0[0-8]|[13-9]\\d|2[0-35-9])|7(?:0[1-9]|[1-7]\\d|8[02-9]|9[0-689])|8(?:[014-9]\\d|[23][0-8])|9(?:[024-9]\\d|1[02-9]|3[0-689]))\\d{6}", [10]],
                        ["80[08]\\d{7}|800\\d{6}|8001111"],
                        ["(?:8(?:4[2-5]|7[0-3])|9(?:[01]\\d|8[2-49]))\\d{7}|845464\\d", [7, 10]],
                        ["70\\d{8}", [10]], 0, ["(?:3[0347]|55)\\d{8}", [10]],
                        ["76(?:464|652)\\d{5}|76(?:0[0-28]|2[356]|34|4[01347]|5[49]|6[0-369]|77|8[14]|9[139])\\d{6}", [10]],
                        ["56\\d{8}", [10]]
                    ], 0, " x"
                ],
                GD: ["1", "011", "(?:473|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "473$1", 0, "473"],
                GE: ["995", "00", "(?:[3-57]\\d\\d|800)\\d{6}", [9],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["70"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["32"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[57]"]],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[348]"], "0$1"]
                    ], "0"
                ],
                GF: ["594", "00", "(?:[56]94\\d|7093)\\d{5}|(?:80|9\\d)\\d{7}", [9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-7]|9[47]"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[89]"], "0$1"]
                    ], "0"
                ],
                GG: ["44", "00", "(?:1481|[357-9]\\d{3})\\d{6}|8\\d{6}(?:\\d{2})?", [7, 9, 10], 0, "0", 0, "([25-9]\\d{5})$|0", "1481$1", 0, 0, [
                    ["1481[25-9]\\d{5}", [10]],
                    ["7(?:(?:781|839)\\d|911[17])\\d{5}", [10]],
                    ["80[08]\\d{7}|800\\d{6}|8001111"],
                    ["(?:8(?:4[2-5]|7[0-3])|9(?:[01]\\d|8[0-3]))\\d{7}|845464\\d", [7, 10]],
                    ["70\\d{8}", [10]], 0, ["(?:3[0347]|55)\\d{8}", [10]],
                    ["76(?:464|652)\\d{5}|76(?:0[0-28]|2[356]|34|4[01347]|5[49]|6[0-369]|77|8[14]|9[139])\\d{6}", [10]],
                    ["56\\d{8}", [10]]
                ]],
                GH: ["233", "00", "(?:[235]\\d{3}|800)\\d{5}", [8, 9],
                    [
                        ["(\\d{3})(\\d{5})", "$1 $2", ["8"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[235]"], "0$1"]
                    ], "0"
                ],
                GI: ["350", "00", "(?:[25]\\d|60)\\d{6}", [8],
                    [
                        ["(\\d{3})(\\d{5})", "$1 $2", ["2"]]
                    ]
                ],
                GL: ["299", "00", "(?:19|[2-689]\\d|70)\\d{4}", [6],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["19|[2-9]"]]
                    ]
                ],
                GM: ["220", "00", "[2-9]\\d{6}", [7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[2-9]"]]
                    ]
                ],
                GN: ["224", "00", "722\\d{6}|(?:3|6\\d)\\d{7}", [8, 9],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["3"]],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[67]"]]
                    ]
                ],
                GP: ["590", "00", "(?:590\\d|7090)\\d{5}|(?:69|80|9\\d)\\d{7}", [9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-79]"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"], "0$1"]
                    ], "0", 0, 0, 0, 0, 0, [
                        ["590(?:0[1-68]|[14][0-24-9]|2[0-68]|3[1-9]|5[3-579]|[68][0-689]|7[08]|9\\d)\\d{4}"],
                        ["(?:69(?:0\\d\\d|1(?:2[2-9]|3[0-5])|4(?:0[89]|1[2-6]|9\\d)|6(?:1[016-9]|5[0-4]|[67]\\d))|7090[0-4])\\d{4}"],
                        ["80[0-5]\\d{6}"], 0, 0, 0, 0, 0, ["9(?:(?:39[5-7]|76[018])\\d|475[0-6])\\d{4}"]
                    ]
                ],
                GQ: ["240", "00", "222\\d{6}|(?:3\\d|55|[89]0)\\d{7}", [9],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[235]"]],
                        ["(\\d{3})(\\d{6})", "$1 $2", ["[89]"]]
                    ]
                ],
                GR: ["30", "00", "5005000\\d{3}|8\\d{9,11}|(?:[269]\\d|70)\\d{8}", [10, 11, 12],
                    [
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["21|7"]],
                        ["(\\d{4})(\\d{6})", "$1 $2", ["2(?:2|3[2-57-9]|4[2-469]|5[2-59]|6[2-9]|7[2-69]|8[2-49])|5"]],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[2689]"]],
                        ["(\\d{3})(\\d{3,4})(\\d{5})", "$1 $2 $3", ["8"]]
                    ]
                ],
                GT: ["502", "00", "80\\d{6}|(?:1\\d{3}|[2-7])\\d{7}", [8, 11],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[2-8]"]],
                        ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"]]
                    ]
                ],
                GU: ["1", "011", "(?:[58]\\d\\d|671|900)\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "671$1", 0, "671"],
                GW: ["245", "00", "[49]\\d{8}|4\\d{6}", [7, 9],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["40"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[49]"]]
                    ]
                ],
                GY: ["592", "001", "(?:[2-8]\\d{3}|9008)\\d{3}", [7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[2-9]"]]
                    ]
                ],
                HK: ["852", "00(?:30|5[09]|[126-9]?)", "8[0-46-9]\\d{6,7}|9\\d{4,7}|(?:[2-7]|9\\d{3})\\d{7}", [5, 6, 7, 8, 9, 11],
                    [
                        ["(\\d{3})(\\d{2,5})", "$1 $2", ["900", "9003"]],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[2-7]|8[1-4]|9(?:0[1-9]|[1-8])"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"]],
                        ["(\\d{3})(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["9"]]
                    ], 0, 0, 0, 0, 0, 0, 0, "00"
                ],
                HN: ["504", "00", "8\\d{10}|[237-9]\\d{7}", [8, 11],
                    [
                        ["(\\d{4})(\\d{4})", "$1-$2", ["[237-9]"]]
                    ]
                ],
                HR: ["385", "00", "(?:[24-69]\\d|3[0-79])\\d{7}|80\\d{5,7}|[1-79]\\d{7}|6\\d{5,6}", [6, 7, 8, 9],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2,3})", "$1 $2 $3", ["6[01]"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2,3})", "$1 $2 $3", ["8"], "0$1"],
                        ["(\\d)(\\d{4})(\\d{3})", "$1 $2 $3", ["1"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["6|7[245]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["9"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[2-57]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"], "0$1"]
                    ], "0"
                ],
                HT: ["509", "00", "(?:[2-489]\\d|55)\\d{6}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["[2-589]"]]
                    ]
                ],
                HU: ["36", "00", "[235-7]\\d{8}|[1-9]\\d{7}", [8, 9],
                    [
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["1"], "(06 $1)"],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[27][2-9]|3[2-7]|4[24-9]|5[2-79]|6|8[2-57-9]|9[2-69]"], "(06 $1)"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[2-9]"], "06 $1"]
                    ], "06"
                ],
                ID: ["62", "00[89]", "00[1-9]\\d{9,14}|(?:[1-36]|8\\d{5})\\d{6}|00\\d{9}|[1-9]\\d{8,10}|[2-9]\\d{7}", [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
                    [
                        ["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["15"]],
                        ["(\\d{2})(\\d{5,9})", "$1 $2", ["2[124]|[36]1"], "(0$1)"],
                        ["(\\d{3})(\\d{5,7})", "$1 $2", ["800"], "0$1"],
                        ["(\\d{3})(\\d{5,8})", "$1 $2", ["[2-79]"], "(0$1)"],
                        ["(\\d{3})(\\d{3,4})(\\d{3})", "$1-$2-$3", ["8[1-35-9]"], "0$1"],
                        ["(\\d{3})(\\d{6,8})", "$1 $2", ["1"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["804"], "0$1"],
                        ["(\\d{3})(\\d)(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["80"], "0$1"],
                        ["(\\d{3})(\\d{4})(\\d{4,5})", "$1-$2-$3", ["8"], "0$1"]
                    ], "0"
                ],
                IE: ["353", "00", "(?:1\\d|[2569])\\d{6,8}|4\\d{6,9}|7\\d{8}|8\\d{8,9}", [7, 8, 9, 10],
                    [
                        ["(\\d{2})(\\d{5})", "$1 $2", ["2[24-9]|47|58|6[237-9]|9[35-9]"], "(0$1)"],
                        ["(\\d{3})(\\d{5})", "$1 $2", ["[45]0"], "(0$1)"],
                        ["(\\d)(\\d{3,4})(\\d{4})", "$1 $2 $3", ["1"], "(0$1)"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[2569]|4[1-69]|7[14]"], "(0$1)"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["70"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["81"], "(0$1)"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[78]"], "0$1"],
                        ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1"]],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["4"], "(0$1)"],
                        ["(\\d{2})(\\d)(\\d{3})(\\d{4})", "$1 $2 $3 $4", ["8"], "0$1"]
                    ], "0"
                ],
                IL: ["972", "0(?:0|1[2-9])", "1\\d{6}(?:\\d{3,5})?|[57]\\d{8}|[1-489]\\d{7}", [7, 8, 9, 10, 11, 12],
                    [
                        ["(\\d{4})(\\d{3})", "$1-$2", ["125"]],
                        ["(\\d{4})(\\d{2})(\\d{2})", "$1-$2-$3", ["121"]],
                        ["(\\d)(\\d{3})(\\d{4})", "$1-$2-$3", ["[2-489]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1-$2-$3", ["[57]"], "0$1"],
                        ["(\\d{4})(\\d{3})(\\d{3})", "$1-$2-$3", ["12"]],
                        ["(\\d{4})(\\d{6})", "$1-$2", ["159"]],
                        ["(\\d)(\\d{3})(\\d{3})(\\d{3})", "$1-$2-$3-$4", ["1[7-9]"]],
                        ["(\\d{3})(\\d{1,2})(\\d{3})(\\d{4})", "$1-$2 $3-$4", ["15"]]
                    ], "0"
                ],
                IM: ["44", "00", "1624\\d{6}|(?:[3578]\\d|90)\\d{8}", [10], 0, "0", 0, "([25-8]\\d{5})$|0", "1624$1", 0, "74576|(?:16|7[56])24"],
                IN: ["91", "00", "(?:000800|[2-9]\\d\\d)\\d{7}|1\\d{7,12}", [8, 9, 10, 11, 12, 13],
                    [
                        ["(\\d{8})", "$1", ["5(?:0|2[23]|3[03]|[67]1|88)", "5(?:0|2(?:21|3)|3(?:0|3[23])|616|717|888)", "5(?:0|2(?:21|3)|3(?:0|3[23])|616|717|8888)"], 0, 1],
                        ["(\\d{4})(\\d{4,5})", "$1 $2", ["180", "1800"], 0, 1],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["140"], 0, 1],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["11|2[02]|33|4[04]|79[1-7]|80[2-46]", "11|2[02]|33|4[04]|79(?:[1-6]|7[19])|80(?:[2-4]|6[0-589])", "11|2[02]|33|4[04]|79(?:[124-6]|3(?:[02-9]|1[0-24-9])|7(?:1|9[1-6]))|80(?:[2-4]|6[0-589])"], "0$1", 1],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["1(?:2[0-249]|3[0-25]|4[145]|[68]|7[1257])|2(?:1[257]|3[013]|4[01]|5[0137]|6[0158]|78|8[1568])|3(?:26|4[1-3]|5[34]|6[01489]|7[02-46]|8[159])|4(?:1[36]|2[1-47]|5[12]|6[0-26-9]|7[0-24-9]|8[013-57]|9[014-7])|5(?:1[025]|22|[36][25]|4[28]|5[12]|[78]1)|6(?:12|[2-4]1|5[17]|6[13]|80)|7(?:12|3[134]|4[47]|61|88)|8(?:16|2[014]|3[126]|6[136]|7[078]|8[34]|91)|(?:43|59|75)[15]|(?:1[59]|29|67|72)[14]", "1(?:2[0-24]|3[0-25]|4[145]|[59][14]|6[1-9]|7[1257]|8[1-57-9])|2(?:1[257]|3[013]|4[01]|5[0137]|6[058]|78|8[1568]|9[14])|3(?:26|4[1-3]|5[34]|6[01489]|7[02-46]|8[159])|4(?:1[36]|2[1-47]|3[15]|5[12]|6[0-26-9]|7[0-24-9]|8[013-57]|9[014-7])|5(?:1[025]|22|[36][25]|4[28]|[578]1|9[15])|674|7(?:(?:2[14]|3[34]|5[15])[2-6]|61[346]|88[0-8])|8(?:70[2-6]|84[235-7]|91[3-7])|(?:1(?:29|60|8[06])|261|552|6(?:12|[2-47]1|5[17]|6[13]|80)|7(?:12|31|4[47])|8(?:16|2[014]|3[126]|6[136]|7[78]|83))[2-7]", "1(?:2[0-24]|3[0-25]|4[145]|[59][14]|6[1-9]|7[1257]|8[1-57-9])|2(?:1[257]|3[013]|4[01]|5[0137]|6[058]|78|8[1568]|9[14])|3(?:26|4[1-3]|5[34]|6[01489]|7[02-46]|8[159])|4(?:1[36]|2[1-47]|3[15]|5[12]|6[0-26-9]|7[0-24-9]|8[013-57]|9[014-7])|5(?:1[025]|22|[36][25]|4[28]|[578]1|9[15])|6(?:12(?:[2-6]|7[0-8])|74[2-7])|7(?:(?:2[14]|5[15])[2-6]|3171|61[346]|88(?:[2-7]|82))|8(?:70[2-6]|84(?:[2356]|7[19])|91(?:[3-6]|7[19]))|73[134][2-6]|(?:74[47]|8(?:16|2[014]|3[126]|6[136]|7[78]|83))(?:[2-6]|7[19])|(?:1(?:29|60|8[06])|261|552|6(?:[2-4]1|5[17]|6[13]|7(?:1|4[0189])|80)|7(?:12|88[01]))[2-7]"], "0$1", 1],
                        ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1(?:[2-479]|5[0235-9])|[2-5]|6(?:1[1358]|2[2457-9]|3[2-5]|4[235-7]|5[2-689]|6[24578]|7[235689]|8[1-6])|7(?:1[013-9]|28|3[129]|4[1-35689]|5[29]|6[02-5]|70)|807", "1(?:[2-479]|5[0235-9])|[2-5]|6(?:1[1358]|2(?:[2457]|84|95)|3(?:[2-4]|55)|4[235-7]|5[2-689]|6[24578]|7[235689]|8[1-6])|7(?:1(?:[013-8]|9[6-9])|28[6-8]|3(?:17|2[0-49]|9[2-57])|4(?:1[2-4]|[29][0-7]|3[0-8]|[56]|8[0-24-7])|5(?:2[1-3]|9[0-6])|6(?:0[5689]|2[5-9]|3[02-8]|4|5[0-367])|70[13-7])|807[19]", "1(?:[2-479]|5(?:[0236-9]|5[013-9]))|[2-5]|6(?:2(?:84|95)|355|83)|73179|807(?:1|9[1-3])|(?:1552|6(?:1[1358]|2[2457]|3[2-4]|4[235-7]|5[2-689]|6[24578]|7[235689]|8[124-6])\\d|7(?:1(?:[013-8]\\d|9[6-9])|28[6-8]|3(?:2[0-49]|9[2-57])|4(?:1[2-4]|[29][0-7]|3[0-8]|[56]\\d|8[0-24-7])|5(?:2[1-3]|9[0-6])|6(?:0[5689]|2[5-9]|3[02-8]|4\\d|5[0-367])|70[13-7]))[2-7]"], "0$1", 1],
                        ["(\\d{5})(\\d{5})", "$1 $2", ["[6-9]"], "0$1", 1],
                        ["(\\d{4})(\\d{2,4})(\\d{4})", "$1 $2 $3", ["1(?:6|8[06])", "1(?:6|8[06]0)"], 0, 1],
                        ["(\\d{4})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["18"], 0, 1]
                    ], "0"
                ],
                IO: ["246", "00", "3\\d{6}", [7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["3"]]
                    ]
                ],
                IQ: ["964", "00", "(?:1|7\\d\\d)\\d{7}|[2-6]\\d{7,8}", [8, 9, 10],
                    [
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["1"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[2-6]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["7"], "0$1"]
                    ], "0"
                ],
                IR: ["98", "00", "[1-9]\\d{9}|(?:[1-8]\\d\\d|9)\\d{3,4}", [4, 5, 6, 7, 10],
                    [
                        ["(\\d{4,5})", "$1", ["96"], "0$1"],
                        ["(\\d{2})(\\d{4,5})", "$1 $2", ["(?:1[137]|2[13-68]|3[1458]|4[145]|5[1468]|6[16]|7[1467]|8[13467])[12689]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["9"], "0$1"],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["[1-8]"], "0$1"]
                    ], "0"
                ],
                IS: ["354", "00|1(?:0(?:01|[12]0)|100)", "(?:38\\d|[4-9])\\d{6}", [7, 9],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[4-9]"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["3"]]
                    ], 0, 0, 0, 0, 0, 0, 0, "00"
                ],
                IT: ["39", "00", "0\\d{5,10}|1\\d{8,10}|3(?:[0-8]\\d{7,10}|9\\d{7,8})|(?:43|55|70)\\d{8}|8\\d{5}(?:\\d{2,4})?", [6, 7, 8, 9, 10, 11, 12],
                    [
                        ["(\\d{2})(\\d{4,6})", "$1 $2", ["0[26]"]],
                        ["(\\d{3})(\\d{3,6})", "$1 $2", ["0[13-57-9][0159]|8(?:03|4[17]|9[2-5])", "0[13-57-9][0159]|8(?:03|4[17]|9(?:2|3[04]|[45][0-4]))"]],
                        ["(\\d{4})(\\d{2,6})", "$1 $2", ["0(?:[13-579][2-46-8]|8[236-8])"]],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["894"]],
                        ["(\\d{2})(\\d{3,4})(\\d{4})", "$1 $2 $3", ["0[26]|5"]],
                        ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["1(?:44|[679])|[378]|43"]],
                        ["(\\d{3})(\\d{3,4})(\\d{4})", "$1 $2 $3", ["0[13-57-9][0159]|14"]],
                        ["(\\d{2})(\\d{4})(\\d{5})", "$1 $2 $3", ["0[26]"]],
                        ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["0"]],
                        ["(\\d{3})(\\d{4})(\\d{4,5})", "$1 $2 $3", ["3"]]
                    ], 0, 0, 0, 0, 0, 0, [
                        ["0669[0-79]\\d{1,6}|0(?:1(?:[0159]\\d|[27][1-5]|31|4[1-4]|6[1356]|8[2-57])|2\\d\\d|3(?:[0159]\\d|2[1-4]|3[12]|[48][1-6]|6[2-59]|7[1-7])|4(?:[0159]\\d|[23][1-9]|4[245]|6[1-5]|7[1-4]|81)|5(?:[0159]\\d|2[1-5]|3[2-6]|4[1-79]|6[4-6]|7[1-578]|8[3-8])|6(?:[0-57-9]\\d|6[0-8])|7(?:[0159]\\d|2[12]|3[1-7]|4[2-46]|6[13569]|7[13-6]|8[1-59])|8(?:[0159]\\d|2[3-578]|3[1-356]|[6-8][1-5])|9(?:[0159]\\d|[238][1-5]|4[12]|6[1-8]|7[1-6]))\\d{2,7}", [6, 7, 8, 9, 10, 11]],
                        ["3[2-9]\\d{7,8}|(?:31|43)\\d{8}", [9, 10]],
                        ["80(?:0\\d{3}|3)\\d{3}", [6, 9]],
                        ["(?:0878\\d{3}|89(?:2\\d|3[04]|4(?:[0-4]|[5-9]\\d\\d)|5[0-4]))\\d\\d|(?:1(?:44|6[346])|89(?:38|5[5-9]|9))\\d{6}", [6, 8, 9, 10]],
                        ["1(?:78\\d|99)\\d{6}", [9, 10]],
                        ["3[2-8]\\d{9,10}", [11, 12]], 0, 0, ["55\\d{8}", [10]],
                        ["84(?:[08]\\d{3}|[17])\\d{3}", [6, 9]]
                    ]
                ],
                JE: ["44", "00", "1534\\d{6}|(?:[3578]\\d|90)\\d{8}", [10], 0, "0", 0, "([0-24-8]\\d{5})$|0", "1534$1", 0, 0, [
                    ["1534[0-24-8]\\d{5}"],
                    ["7(?:(?:(?:50|82)9|937)\\d|7(?:00[378]|97\\d))\\d{5}"],
                    ["80(?:07(?:35|81)|8901)\\d{4}"],
                    ["(?:8(?:4(?:4(?:4(?:05|42|69)|703)|5(?:041|800))|7(?:0002|1206))|90(?:066[59]|1810|71(?:07|55)))\\d{4}"],
                    ["701511\\d{4}"], 0, ["(?:3(?:0(?:07(?:35|81)|8901)|3\\d{4}|4(?:4(?:4(?:05|42|69)|703)|5(?:041|800))|7(?:0002|1206))|55\\d{4})\\d{4}"],
                    ["76(?:464|652)\\d{5}|76(?:0[0-28]|2[356]|34|4[01347]|5[49]|6[0-369]|77|8[14]|9[139])\\d{6}"],
                    ["56\\d{8}"]
                ]],
                JM: ["1", "011", "(?:[58]\\d\\d|658|900)\\d{7}", [10], 0, "1", 0, 0, 0, 0, "658|876"],
                JO: ["962", "00", "(?:(?:[2689]|7\\d)\\d|32|53)\\d{6}", [8, 9],
                    [
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["[2356]|87"], "(0$1)"],
                        ["(\\d{3})(\\d{5,6})", "$1 $2", ["[89]"], "0$1"],
                        ["(\\d{2})(\\d{7})", "$1 $2", ["70"], "0$1"],
                        ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["7"], "0$1"]
                    ], "0"
                ],
                JP: ["81", "010", "00[1-9]\\d{6,14}|[257-9]\\d{9}|(?:00|[1-9]\\d\\d)\\d{6}", [8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1-$2-$3", ["(?:12|57|99)0"], "0$1"],
                        ["(\\d{4})(\\d)(\\d{4})", "$1-$2-$3", ["1(?:26|3[79]|4[56]|5[4-68]|6[3-5])|499|5(?:76|97)|746|8(?:3[89]|47|51)|9(?:80|9[16])", "1(?:267|3(?:7[247]|9[278])|466|5(?:47|58|64)|6(?:3[245]|48|5[4-68]))|499[2468]|5(?:76|97)9|7468|8(?:3(?:8[7-9]|96)|477|51[2-9])|9(?:802|9(?:1[23]|69))|1(?:45|58)[67]", "1(?:267|3(?:7[247]|9[278])|466|5(?:47|58|64)|6(?:3[245]|48|5[4-68]))|499[2468]|5(?:769|979[2-69])|7468|8(?:3(?:8[7-9]|96[2457-9])|477|51[2-9])|9(?:802|9(?:1[23]|69))|1(?:45|58)[67]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1-$2-$3", ["60"], "0$1"],
                        ["(\\d)(\\d{4})(\\d{4})", "$1-$2-$3", ["[36]|4(?:2[09]|7[01])", "[36]|4(?:2(?:0|9[02-69])|7(?:0[019]|1))"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1-$2-$3", ["1(?:1|5[45]|77|88|9[69])|2(?:2[1-37]|3[0-269]|4[59]|5|6[24]|7[1-358]|8[1369]|9[0-38])|4(?:[28][1-9]|3[0-57]|[45]|6[248]|7[2-579]|9[29])|5(?:2|3[0459]|4[0-369]|5[29]|8[02389]|9[0-389])|7(?:2[02-46-9]|34|[58]|6[0249]|7[57]|9[2-6])|8(?:2[124589]|3[26-9]|49|51|6|7[0-468]|8[68]|9[019])|9(?:[23][1-9]|4[15]|5[138]|6[1-3]|7[156]|8[189]|9[1-489])", "1(?:1|5(?:4[018]|5[017])|77|88|9[69])|2(?:2(?:[127]|3[014-9])|3[0-269]|4[59]|5(?:[1-3]|5[0-69]|9[19])|62|7(?:[1-35]|8[0189])|8(?:[16]|3[0134]|9[0-5])|9(?:[028]|17))|4(?:2(?:[13-79]|8[014-6])|3[0-57]|[45]|6[248]|7[2-47]|8[1-9]|9[29])|5(?:2|3(?:[045]|9[0-8])|4[0-369]|5[29]|8[02389]|9[0-3])|7(?:2[02-46-9]|34|[58]|6[0249]|7[57]|9(?:[23]|4[0-59]|5[01569]|6[0167]))|8(?:2(?:[1258]|4[0-39]|9[0-2469])|3(?:[29]|60)|49|51|6(?:[0-24]|36|5[0-3589]|7[23]|9[01459])|7[0-468]|8[68])|9(?:[23][1-9]|4[15]|5[138]|6[1-3]|7[156]|8[189]|9(?:[1289]|3[34]|4[0178]))|(?:264|837)[016-9]|2(?:57|93)[015-9]|(?:25[0468]|422|838)[01]|(?:47[59]|59[89]|8(?:6[68]|9))[019]", "1(?:1|5(?:4[018]|5[017])|77|88|9[69])|2(?:2[127]|3[0-269]|4[59]|5(?:[1-3]|5[0-69]|9(?:17|99))|6(?:2|4[016-9])|7(?:[1-35]|8[0189])|8(?:[16]|3[0134]|9[0-5])|9(?:[028]|17))|4(?:2(?:[13-79]|8[014-6])|3[0-57]|[45]|6[248]|7[2-47]|9[29])|5(?:2|3(?:[045]|9(?:[0-58]|6[4-9]|7[0-35689]))|4[0-369]|5[29]|8[02389]|9[0-3])|7(?:2[02-46-9]|34|[58]|6[0249]|7[57]|9(?:[23]|4[0-59]|5[01569]|6[0167]))|8(?:2(?:[1258]|4[0-39]|9[0169])|3(?:[29]|60|7(?:[017-9]|6[6-8]))|49|51|6(?:[0-24]|36[2-57-9]|5(?:[0-389]|5[23])|6(?:[01]|9[178])|7(?:2[2-468]|3[78])|9[0145])|7[0-468]|8[68])|9(?:4[15]|5[138]|7[156]|8[189]|9(?:[1289]|3(?:31|4[357])|4[0178]))|(?:8294|96)[1-3]|2(?:57|93)[015-9]|(?:223|8699)[014-9]|(?:25[0468]|422|838)[01]|(?:48|8292|9[23])[1-9]|(?:47[59]|59[89]|8(?:68|9))[019]"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{4})", "$1-$2-$3", ["[14]|[289][2-9]|5[3-9]|7[2-4679]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1-$2-$3", ["800"], "0$1"],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1-$2-$3", ["[257-9]"], "0$1"]
                    ], "0", 0, "(000[259]\\d{6})$|(?:(?:003768)0?)|0", "$1"
                ],
                KE: ["254", "000", "(?:[17]\\d\\d|900)\\d{6}|(?:2|80)0\\d{6,7}|[4-6]\\d{6,8}", [7, 8, 9, 10],
                    [
                        ["(\\d{2})(\\d{5,7})", "$1 $2", ["[24-6]"], "0$1"],
                        ["(\\d{3})(\\d{6})", "$1 $2", ["[17]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[89]"], "0$1"]
                    ], "0"
                ],
                KG: ["996", "00", "8\\d{9}|[235-9]\\d{8}", [9, 10],
                    [
                        ["(\\d{4})(\\d{5})", "$1 $2", ["3(?:1[346]|[24-79])"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[235-79]|88"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d)(\\d{2,3})", "$1 $2 $3 $4", ["8"], "0$1"]
                    ], "0"
                ],
                KH: ["855", "00[14-9]", "1\\d{9}|[1-9]\\d{7,8}", [8, 9, 10],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[1-9]"], "0$1"],
                        ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1"]]
                    ], "0"
                ],
                KI: ["686", "00", "(?:[37]\\d|6[0-79])\\d{6}|(?:[2-48]\\d|50)\\d{3}", [5, 8], 0, "0"],
                KM: ["269", "00", "[3478]\\d{6}", [7],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3", ["[3478]"]]
                    ]
                ],
                KN: ["1", "011", "(?:[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-7]\\d{6})$|1", "869$1", 0, "869"],
                KP: ["850", "00|99", "85\\d{6}|(?:19\\d|[2-7])\\d{7}", [8, 10],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["[2-7]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"], "0$1"]
                    ], "0"
                ],
                KR: ["82", "00(?:[125689]|3(?:[46]5|91)|7(?:00|27|3|55|6[126]))", "00[1-9]\\d{8,11}|(?:[12]|5\\d{3})\\d{7}|[13-6]\\d{9}|(?:[1-6]\\d|80)\\d{7}|[3-6]\\d{4,5}|(?:00|7)0\\d{8}", [5, 6, 8, 9, 10, 11, 12, 13, 14],
                    [
                        ["(\\d{2})(\\d{3,4})", "$1-$2", ["(?:3[1-3]|[46][1-4]|5[1-5])1"], "0$1"],
                        ["(\\d{4})(\\d{4})", "$1-$2", ["1"]],
                        ["(\\d)(\\d{3,4})(\\d{4})", "$1-$2-$3", ["2"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1-$2-$3", ["[36]0|8"], "0$1"],
                        ["(\\d{2})(\\d{3,4})(\\d{4})", "$1-$2-$3", ["[1346]|5[1-5]"], "0$1"],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1-$2-$3", ["[57]"], "0$1"],
                        ["(\\d{2})(\\d{5})(\\d{4})", "$1-$2-$3", ["5"], "0$1"]
                    ], "0", 0, "0(8(?:[1-46-8]|5\\d\\d))?"
                ],
                KW: ["965", "00", "18\\d{5}|(?:[2569]\\d|41)\\d{6}", [7, 8],
                    [
                        ["(\\d{4})(\\d{3,4})", "$1 $2", ["[169]|2(?:[235]|4[1-35-9])|52"]],
                        ["(\\d{3})(\\d{5})", "$1 $2", ["[245]"]]
                    ]
                ],
                KY: ["1", "011", "(?:345|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "345$1", 0, "345"],
                KZ: ["7", "810", "(?:33622|8\\d{8})\\d{5}|[78]\\d{9}", [10, 14], 0, "8", 0, 0, 0, 0, "33|7", 0, "8~10"],
                LA: ["856", "00", "[23]\\d{9}|3\\d{8}|(?:[235-8]\\d|41)\\d{6}", [8, 9, 10],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["2[13]|3[14]|[4-8]"], "0$1"],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3 $4", ["30[0135-9]"], "0$1"],
                        ["(\\d{2})(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["[23]"], "0$1"]
                    ], "0"
                ],
                LB: ["961", "00", "[27-9]\\d{7}|[13-9]\\d{6}", [7, 8],
                    [
                        ["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["[13-69]|7(?:[2-57]|62|8[0-7]|9[04-9])|8[02-9]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[27-9]"]]
                    ], "0"
                ],
                LC: ["1", "011", "(?:[58]\\d\\d|758|900)\\d{7}", [10], 0, "1", 0, "([2-8]\\d{6})$|1", "758$1", 0, "758"],
                LI: ["423", "00", "[68]\\d{8}|(?:[2378]\\d|90)\\d{5}", [7, 9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3", ["[2379]|8(?:0[09]|7)", "[2379]|8(?:0(?:02|9)|7)"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"]],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["69"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["6"]]
                    ], "0", 0, "(1001)|0"
                ],
                LK: ["94", "00", "[1-9]\\d{8}", [9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["7"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[1-689]"], "0$1"]
                    ], "0"
                ],
                LR: ["231", "00", "(?:[245]\\d|33|77|88)\\d{7}|(?:2\\d|[4-6])\\d{6}", [7, 8, 9],
                    [
                        ["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["4[67]|[56]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["2"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[2-578]"], "0$1"]
                    ], "0"
                ],
                LS: ["266", "00", "(?:[256]\\d\\d|800)\\d{5}", [8],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[2568]"]]
                    ]
                ],
                LT: ["370", "00", "(?:[3469]\\d|52|[78]0)\\d{6}", [8],
                    [
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["52[0-7]"], "(0-$1)", 1],
                        ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["[7-9]"], "0 $1", 1],
                        ["(\\d{2})(\\d{6})", "$1 $2", ["37|4(?:[15]|6[1-8])"], "(0-$1)", 1],
                        ["(\\d{3})(\\d{5})", "$1 $2", ["[3-6]"], "(0-$1)", 1]
                    ], "0", 0, "[08]"
                ],
                LU: ["352", "00", "35[013-9]\\d{4,8}|6\\d{8}|35\\d{2,4}|(?:[2457-9]\\d|3[0-46-9])\\d{2,9}", [4, 5, 6, 7, 8, 9, 10, 11],
                    [
                        ["(\\d{2})(\\d{3})", "$1 $2", ["2(?:0[2-689]|[2-9])|[3-57]|8(?:0[2-9]|[13-9])|9(?:0[89]|[2-579])"]],
                        ["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["2(?:0[2-689]|[2-9])|[3-57]|8(?:0[2-9]|[13-9])|9(?:0[89]|[2-579])"]],
                        ["(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3", ["20[2-689]"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{1,2})", "$1 $2 $3 $4", ["2(?:[0367]|4[3-8])"]],
                        ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["80[01]|90[015]"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3 $4", ["20"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["6"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{1,2})", "$1 $2 $3 $4 $5", ["2(?:[0367]|4[3-8])"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{1,5})", "$1 $2 $3 $4", ["[3-57]|8[13-9]|9(?:0[89]|[2-579])|(?:2|80)[2-9]"]]
                    ], 0, 0, "(15(?:0[06]|1[12]|[35]5|4[04]|6[26]|77|88|99)\\d)"
                ],
                LV: ["371", "00", "(?:[268]\\d|90)\\d{6}", [8],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[269]|8[01]"]]
                    ]
                ],
                LY: ["218", "00", "[2-9]\\d{8}", [9],
                    [
                        ["(\\d{2})(\\d{7})", "$1-$2", ["[2-9]"], "0$1"]
                    ], "0"
                ],
                MA: ["212", "00", "[5-8]\\d{8}", [9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["5[45]"], "0$1"],
                        ["(\\d{4})(\\d{5})", "$1-$2", ["5(?:2[2-46-9]|3[3-9]|9)|8(?:0[89]|92)"], "0$1"],
                        ["(\\d{2})(\\d{7})", "$1-$2", ["8"], "0$1"],
                        ["(\\d{3})(\\d{6})", "$1-$2", ["[5-7]"], "0$1"]
                    ], "0", 0, 0, 0, 0, 0, [
                        ["5(?:2(?:[0-25-79]\\d|3[1-578]|4[02-46-8]|8[0235-7])|3(?:[0-47]\\d|5[02-9]|6[02-8]|8[014-9]|9[3-9])|(?:4[067]|5[03])\\d)\\d{5}"],
                        ["(?:6(?:[0-79]\\d|8[0-247-9])|7(?:[0167]\\d|2[0-467]|5[0-3]|8[0-5]))\\d{6}"],
                        ["80[0-7]\\d{6}"],
                        ["89\\d{7}"], 0, 0, 0, 0, ["(?:592(?:4[0-2]|93)|80[89]\\d\\d)\\d{4}"]
                    ]
                ],
                MC: ["377", "00", "(?:[3489]|6\\d)\\d{7}", [8, 9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["4"], "0$1"],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[389]"]],
                        ["(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["6"], "0$1"]
                    ], "0"
                ],
                MD: ["373", "00", "(?:[235-7]\\d|[89]0)\\d{6}", [8],
                    [
                        ["(\\d{3})(\\d{5})", "$1 $2", ["[89]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["22|3"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["[25-7]"], "0$1"]
                    ], "0"
                ],
                ME: ["382", "00", "(?:20|[3-79]\\d)\\d{6}|80\\d{6,7}", [8, 9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[2-9]"], "0$1"]
                    ], "0"
                ],
                MF: ["590", "00", "(?:590\\d|7090)\\d{5}|(?:69|80|9\\d)\\d{7}", [9], 0, "0", 0, 0, 0, 0, 0, [
                    ["590(?:0[079]|[14]3|[27][79]|3[03-7]|5[0-268]|87)\\d{4}"],
                    ["(?:69(?:0\\d\\d|1(?:2[2-9]|3[0-5])|4(?:0[89]|1[2-6]|9\\d)|6(?:1[016-9]|5[0-4]|[67]\\d))|7090[0-4])\\d{4}"],
                    ["80[0-5]\\d{6}"], 0, 0, 0, 0, 0, ["9(?:(?:39[5-7]|76[018])\\d|475[0-6])\\d{4}"]
                ]],
                MG: ["261", "00", "[23]\\d{8}", [9],
                    [
                        ["(\\d{2})(\\d{2})(\\d{3})(\\d{2})", "$1 $2 $3 $4", ["[23]"], "0$1"]
                    ], "0", 0, "([24-9]\\d{6})$|0", "20$1"
                ],
                MH: ["692", "011", "329\\d{4}|(?:[256]\\d|45)\\d{5}", [7],
                    [
                        ["(\\d{3})(\\d{4})", "$1-$2", ["[2-6]"]]
                    ], "1"
                ],
                MK: ["389", "00", "[2-578]\\d{7}", [8],
                    [
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["2|34[47]|4(?:[37]7|5[47]|64)"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[347]"], "0$1"],
                        ["(\\d{3})(\\d)(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[58]"], "0$1"]
                    ], "0"
                ],
                ML: ["223", "00", "[24-9]\\d{7}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[24-9]"]]
                    ]
                ],
                MM: ["95", "00", "1\\d{5,7}|95\\d{6}|(?:[4-7]|9[0-46-9])\\d{6,8}|(?:2|8\\d)\\d{5,8}", [6, 7, 8, 9, 10],
                    [
                        ["(\\d)(\\d{2})(\\d{3})", "$1 $2 $3", ["16|2"], "0$1"],
                        ["(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3", ["4(?:[2-46]|5[3-5])|5|6(?:[1-689]|7[235-7])|7(?:[0-4]|5[2-7])|8[1-5]|(?:60|86)[23]"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[12]|452|678|86", "[12]|452|6788|86"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[4-7]|8[1-35]"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{4,6})", "$1 $2 $3", ["9(?:2[0-4]|[35-9]|4[137-9])"], "0$1"],
                        ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["2"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["92"], "0$1"],
                        ["(\\d)(\\d{5})(\\d{4})", "$1 $2 $3", ["9"], "0$1"]
                    ], "0"
                ],
                MN: ["976", "001", "[12]\\d{7,9}|[5-9]\\d{7}", [8, 9, 10],
                    [
                        ["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["[12]1"], "0$1"],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[5-9]"]],
                        ["(\\d{3})(\\d{5,6})", "$1 $2", ["[12]2[1-3]"], "0$1"],
                        ["(\\d{4})(\\d{5,6})", "$1 $2", ["[12](?:27|3[2-8]|4[2-68]|5[1-4689])", "[12](?:27|3[2-8]|4[2-68]|5[1-4689])[0-3]"], "0$1"],
                        ["(\\d{5})(\\d{4,5})", "$1 $2", ["[12]"], "0$1"]
                    ], "0"
                ],
                MO: ["853", "00", "0800\\d{3}|(?:28|[68]\\d)\\d{6}", [7, 8],
                    [
                        ["(\\d{4})(\\d{3})", "$1 $2", ["0"]],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[268]"]]
                    ]
                ],
                MP: ["1", "011", "[58]\\d{9}|(?:67|90)0\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "670$1", 0, "670"],
                MQ: ["596", "00", "(?:596\\d|7091)\\d{5}|(?:69|[89]\\d)\\d{7}", [9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-79]|8(?:0[6-9]|[36])"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"], "0$1"]
                    ], "0"
                ],
                MR: ["222", "00", "(?:[2-4]\\d\\d|800)\\d{5}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2-48]"]]
                    ]
                ],
                MS: ["1", "011", "(?:[58]\\d\\d|664|900)\\d{7}", [10], 0, "1", 0, "([34]\\d{6})$|1", "664$1", 0, "664"],
                MT: ["356", "00", "3550\\d{4}|(?:[2579]\\d\\d|800)\\d{5}", [8],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[2357-9]"]]
                    ]
                ],
                MU: ["230", "0(?:0|[24-7]0|3[03])", "(?:[57]|8\\d\\d)\\d{7}|[2-468]\\d{6}", [7, 8, 10],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[2-46]|8[013]"]],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[57]"]],
                        ["(\\d{5})(\\d{5})", "$1 $2", ["8"]]
                    ], 0, 0, 0, 0, 0, 0, 0, "020"
                ],
                MV: ["960", "0(?:0|19)", "(?:800|9[0-57-9]\\d)\\d{7}|[34679]\\d{6}", [7, 10],
                    [
                        ["(\\d{3})(\\d{4})", "$1-$2", ["[34679]"]],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[89]"]]
                    ], 0, 0, 0, 0, 0, 0, 0, "00"
                ],
                MW: ["265", "00", "(?:[1289]\\d|31|77)\\d{7}|1\\d{6}", [7, 9],
                    [
                        ["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["1[2-9]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["2"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[137-9]"], "0$1"]
                    ], "0"
                ],
                MX: ["52", "0[09]", "[2-9]\\d{9}", [10],
                    [
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["33|5[56]|81"]],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[2-9]"]]
                    ], 0, 0, 0, 0, 0, 0, 0, "00"
                ],
                MY: ["60", "00", "1\\d{8,9}|(?:3\\d|[4-9])\\d{7}", [8, 9, 10],
                    [
                        ["(\\d)(\\d{3})(\\d{4})", "$1-$2 $3", ["[4-79]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1-$2 $3", ["1(?:[02469]|[378][1-9]|53)|8", "1(?:[02469]|[37][1-9]|53|8(?:[1-46-9]|5[7-9]))|8"], "0$1"],
                        ["(\\d)(\\d{4})(\\d{4})", "$1-$2 $3", ["3"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{2})(\\d{4})", "$1-$2-$3-$4", ["1(?:[367]|80)"]],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1-$2 $3", ["15"], "0$1"],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1-$2 $3", ["1"], "0$1"]
                    ], "0"
                ],
                MZ: ["258", "00", "(?:2|8\\d)\\d{7}", [8, 9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["2|8[2-79]"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"]]
                    ]
                ],
                NA: ["264", "00", "[68]\\d{7,8}", [8, 9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["88"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["6"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["87"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"], "0$1"]
                    ], "0"
                ],
                NC: ["687", "00", "(?:050|[2-57-9]\\d\\d)\\d{3}", [6],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})", "$1.$2.$3", ["[02-57-9]"]]
                    ]
                ],
                NE: ["227", "00", "[027-9]\\d{7}", [8],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["08"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[089]|2[013]|7[0467]"]]
                    ]
                ],
                NF: ["672", "00", "[13]\\d{5}", [6],
                    [
                        ["(\\d{2})(\\d{4})", "$1 $2", ["1[0-3]"]],
                        ["(\\d)(\\d{5})", "$1 $2", ["[13]"]]
                    ], 0, 0, "([0-258]\\d{4})$", "3$1"
                ],
                NG: ["234", "009", "38\\d{6}|[78]\\d{9,13}|(?:20|9\\d)\\d{8}", [8, 10, 11, 12, 13, 14],
                    [
                        ["(\\d{2})(\\d{3})(\\d{2,3})", "$1 $2 $3", ["3"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[7-9]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["20[129]"], "0$1"],
                        ["(\\d{4})(\\d{2})(\\d{4})", "$1 $2 $3", ["2"], "0$1"],
                        ["(\\d{3})(\\d{4})(\\d{4,5})", "$1 $2 $3", ["[78]"], "0$1"],
                        ["(\\d{3})(\\d{5})(\\d{5,6})", "$1 $2 $3", ["[78]"], "0$1"]
                    ], "0"
                ],
                NI: ["505", "00", "(?:1800|[25-8]\\d{3})\\d{4}", [8],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[125-8]"]]
                    ]
                ],
                NL: ["31", "00", "(?:[124-7]\\d\\d|3(?:[02-9]\\d|1[0-8]))\\d{6}|8\\d{6,9}|9\\d{6,10}|1\\d{4,5}", [5, 6, 7, 8, 9, 10, 11],
                    [
                        ["(\\d{3})(\\d{4,7})", "$1 $2", ["[89]0"], "0$1"],
                        ["(\\d{2})(\\d{7})", "$1 $2", ["66"], "0$1"],
                        ["(\\d)(\\d{8})", "$1 $2", ["6"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["1[16-8]|2[259]|3[124]|4[17-9]|5[124679]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[1-578]|91"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{5})", "$1 $2 $3", ["9"], "0$1"]
                    ], "0"
                ],
                NO: ["47", "00", "(?:0|[2-9]\\d{3})\\d{4}", [5, 8],
                    [
                        ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["8"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2-79]"]]
                    ], 0, 0, 0, 0, 0, "[02-689]|7[0-8]"
                ],
                NP: ["977", "00", "(?:1\\d|9)\\d{9}|[1-9]\\d{7}", [8, 10, 11],
                    [
                        ["(\\d)(\\d{7})", "$1-$2", ["1[2-6]"], "0$1"],
                        ["(\\d{2})(\\d{6})", "$1-$2", ["1[01]|[2-8]|9(?:[1-59]|[67][2-6])"], "0$1"],
                        ["(\\d{3})(\\d{7})", "$1-$2", ["9"]]
                    ], "0"
                ],
                NR: ["674", "00", "(?:444|(?:55|8\\d)\\d|666)\\d{4}", [7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[4-68]"]]
                    ]
                ],
                NU: ["683", "00", "(?:[4-7]|888\\d)\\d{3}", [4, 7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["8"]]
                    ]
                ],
                NZ: ["64", "0(?:0|161)", "[1289]\\d{9}|50\\d{5}(?:\\d{2,3})?|[27-9]\\d{7,8}|(?:[34]\\d|6[0-35-9])\\d{6}|8\\d{4,6}", [5, 6, 7, 8, 9, 10],
                    [
                        ["(\\d{2})(\\d{3,8})", "$1 $2", ["8[1-79]"], "0$1"],
                        ["(\\d{3})(\\d{2})(\\d{2,3})", "$1 $2 $3", ["50[036-8]|8|90", "50(?:[0367]|88)|8|90"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["24|[346]|7[2-57-9]|9[2-9]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["2(?:10|74)|[589]"], "0$1"],
                        ["(\\d{2})(\\d{3,4})(\\d{4})", "$1 $2 $3", ["1|2[028]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,5})", "$1 $2 $3", ["2(?:[169]|7[0-35-9])|7"], "0$1"]
                    ], "0", 0, 0, 0, 0, 0, 0, "00"
                ],
                OM: ["968", "00", "(?:1505|[279]\\d{3}|500)\\d{4}|800\\d{5,6}", [7, 8, 9],
                    [
                        ["(\\d{3})(\\d{4,6})", "$1 $2", ["[58]"]],
                        ["(\\d{2})(\\d{6})", "$1 $2", ["2"]],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[179]"]]
                    ]
                ],
                PA: ["507", "00", "(?:00800|8\\d{3})\\d{6}|[68]\\d{7}|[1-57-9]\\d{6}", [7, 8, 10, 11],
                    [
                        ["(\\d{3})(\\d{4})", "$1-$2", ["[1-57-9]"]],
                        ["(\\d{4})(\\d{4})", "$1-$2", ["[68]"]],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"]]
                    ]
                ],
                PE: ["51", "00|19(?:1[124]|77|90)00", "(?:[14-8]|9\\d)\\d{7}", [8, 9],
                    [
                        ["(\\d{3})(\\d{5})", "$1 $2", ["80"], "(0$1)"],
                        ["(\\d)(\\d{7})", "$1 $2", ["1"], "(0$1)"],
                        ["(\\d{2})(\\d{6})", "$1 $2", ["[4-8]"], "(0$1)"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["9"]]
                    ], "0", 0, 0, 0, 0, 0, 0, "00", " Anexo "
                ],
                PF: ["689", "00", "4\\d{5}(?:\\d{2})?|8\\d{7,8}", [6, 8, 9],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["44"]],
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["4|8[7-9]"]],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"]]
                    ]
                ],
                PG: ["675", "00|140[1-3]", "(?:180|[78]\\d{3})\\d{4}|(?:[2-589]\\d|64)\\d{5}", [7, 8],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["18|[2-69]|85"]],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[78]"]]
                    ], 0, 0, 0, 0, 0, 0, 0, "00"
                ],
                PH: ["63", "00", "(?:[2-7]|9\\d)\\d{8}|2\\d{5}|(?:1800|8)\\d{7,9}", [6, 8, 9, 10, 11, 12, 13],
                    [
                        ["(\\d)(\\d{5})", "$1 $2", ["2"], "(0$1)"],
                        ["(\\d{4})(\\d{4,6})", "$1 $2", ["3(?:23|39|46)|4(?:2[3-6]|[35]9|4[26]|76)|544|88[245]|(?:52|64|86)2", "3(?:230|397|461)|4(?:2(?:35|[46]4|51)|396|4(?:22|63)|59[347]|76[15])|5(?:221|446)|642[23]|8(?:622|8(?:[24]2|5[13]))"], "(0$1)"],
                        ["(\\d{5})(\\d{4})", "$1 $2", ["346|4(?:27|9[35])|883", "3469|4(?:279|9(?:30|56))|8834"], "(0$1)"],
                        ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["2"], "(0$1)"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[3-7]|8[2-8]"], "(0$1)"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[89]"], "0$1"],
                        ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"]],
                        ["(\\d{4})(\\d{1,2})(\\d{3})(\\d{4})", "$1 $2 $3 $4", ["1"]]
                    ], "0"
                ],
                PK: ["92", "00", "122\\d{6}|[24-8]\\d{10,11}|9(?:[013-9]\\d{8,10}|2(?:[01]\\d\\d|2(?:[06-8]\\d|1[01]))\\d{7})|(?:[2-8]\\d{3}|92(?:[0-7]\\d|8[1-9]))\\d{6}|[24-9]\\d{8}|[89]\\d{7}", [8, 9, 10, 11, 12],
                    [
                        ["(\\d{3})(\\d{3})(\\d{2,7})", "$1 $2 $3", ["[89]0"], "0$1"],
                        ["(\\d{4})(\\d{5})", "$1 $2", ["1"]],
                        ["(\\d{3})(\\d{6,7})", "$1 $2", ["2(?:3[2358]|4[2-4]|9[2-8])|45[3479]|54[2-467]|60[468]|72[236]|8(?:2[2-689]|3[23578]|4[3478]|5[2356])|9(?:2[2-8]|3[27-9]|4[2-6]|6[3569]|9[25-8])", "9(?:2[3-8]|98)|(?:2(?:3[2358]|4[2-4]|9[2-8])|45[3479]|54[2-467]|60[468]|72[236]|8(?:2[2-689]|3[23578]|4[3478]|5[2356])|9(?:22|3[27-9]|4[2-6]|6[3569]|9[25-7]))[2-9]"], "(0$1)"],
                        ["(\\d{2})(\\d{7,8})", "$1 $2", ["(?:2[125]|4[0-246-9]|5[1-35-7]|6[1-8]|7[14]|8[16]|91)[2-9]"], "(0$1)"],
                        ["(\\d{5})(\\d{5})", "$1 $2", ["58"], "(0$1)"],
                        ["(\\d{3})(\\d{7})", "$1 $2", ["3"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["2[125]|4[0-246-9]|5[1-35-7]|6[1-8]|7[14]|8[16]|91"], "(0$1)"],
                        ["(\\d{3})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["[24-9]"], "(0$1)"]
                    ], "0"
                ],
                PL: ["48", "00", "(?:6|8\\d\\d)\\d{7}|[1-9]\\d{6}(?:\\d{2})?|[26]\\d{5}", [6, 7, 8, 9, 10],
                    [
                        ["(\\d{5})", "$1", ["19"]],
                        ["(\\d{3})(\\d{3})", "$1 $2", ["11|20|64"]],
                        ["(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3", ["(?:1[2-8]|2[2-69]|3[2-4]|4[1-468]|5[24-689]|6[1-3578]|7[14-7]|8[1-79]|9[145])1", "(?:1[2-8]|2[2-69]|3[2-4]|4[1-468]|5[24-689]|6[1-3578]|7[14-7]|8[1-79]|9[145])19"]],
                        ["(\\d{3})(\\d{2})(\\d{2,3})", "$1 $2 $3", ["64"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["21|39|45|5[0137]|6[0469]|7[02389]|8(?:0[14]|8)"]],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["1[2-8]|[2-7]|8[1-79]|9[145]"]],
                        ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["8"]]
                    ]
                ],
                PM: ["508", "00", "[45]\\d{5}|(?:708|8\\d\\d)\\d{6}", [6, 9],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["[45]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["7"]],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"], "0$1"]
                    ], "0"
                ],
                PR: ["1", "011", "(?:[589]\\d\\d|787)\\d{7}", [10], 0, "1", 0, 0, 0, 0, "787|939"],
                PS: ["970", "00", "[2489]2\\d{6}|(?:1\\d|5)\\d{8}", [8, 9, 10],
                    [
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["[2489]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["5"], "0$1"],
                        ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1"]]
                    ], "0"
                ],
                PT: ["351", "00", "1693\\d{5}|(?:[26-9]\\d|30)\\d{7}", [9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["2[12]"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["16|[236-9]"]]
                    ]
                ],
                PW: ["680", "01[12]", "(?:[24-8]\\d\\d|345|900)\\d{4}", [7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[2-9]"]]
                    ]
                ],
                PY: ["595", "00", "59\\d{4,6}|9\\d{5,10}|(?:[2-46-8]\\d|5[0-8])\\d{4,7}", [6, 7, 8, 9, 10, 11],
                    [
                        ["(\\d{3})(\\d{3,6})", "$1 $2", ["[2-9]0"], "0$1"],
                        ["(\\d{2})(\\d{5})", "$1 $2", ["[26]1|3[289]|4[1246-8]|7[1-3]|8[1-36]"], "(0$1)"],
                        ["(\\d{3})(\\d{4,5})", "$1 $2", ["2[279]|3[13-5]|4[359]|5|6(?:[34]|7[1-46-8])|7[46-8]|85"], "(0$1)"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["2[14-68]|3[26-9]|4[1246-8]|6(?:1|75)|7[1-35]|8[1-36]"], "(0$1)"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["87"]],
                        ["(\\d{3})(\\d{6})", "$1 $2", ["9(?:[5-79]|8[1-7])"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2-8]"], "0$1"],
                        ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["9"]]
                    ], "0"
                ],
                QA: ["974", "00", "800\\d{4}|(?:2|800)\\d{6}|(?:0080|[3-7])\\d{7}", [7, 8, 9, 11],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["2[16]|8"]],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[3-7]"]]
                    ]
                ],
                RE: ["262", "00", "709\\d{6}|(?:26|[689]\\d)\\d{7}", [9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[26-9]"], "0$1"]
                    ], "0", 0, 0, 0, 0, 0, [
                        ["26(?:2\\d\\d|3(?:0\\d|1[0-6]))\\d{4}"],
                        ["(?:69(?:2\\d\\d|3(?:[06][0-6]|1[013]|2[0-2]|3[0-39]|4\\d|5[0-5]|7[0-37]|8[0-8]|9[0-479]))|7092[0-3])\\d{4}"],
                        ["80\\d{7}"],
                        ["89[1-37-9]\\d{6}"], 0, 0, 0, 0, ["9(?:399[0-3]|479[0-6]|76(?:2[278]|3[0-37]))\\d{4}"],
                        ["8(?:1[019]|2[0156]|84|90)\\d{6}"]
                    ]
                ],
                RO: ["40", "00", "(?:[236-8]\\d|90)\\d{7}|[23]\\d{5}", [6, 9],
                    [
                        ["(\\d{3})(\\d{3})", "$1 $2", ["2[3-6]", "2[3-6]\\d9"], "0$1"],
                        ["(\\d{2})(\\d{4})", "$1 $2", ["219|31"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[23]1"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[236-9]"], "0$1"]
                    ], "0", 0, 0, 0, 0, 0, 0, 0, " int "
                ],
                RS: ["381", "00", "38[02-9]\\d{6,9}|6\\d{7,9}|90\\d{4,8}|38\\d{5,6}|(?:7\\d\\d|800)\\d{3,9}|(?:[12]\\d|3[0-79])\\d{5,10}", [6, 7, 8, 9, 10, 11, 12],
                    [
                        ["(\\d{3})(\\d{3,9})", "$1 $2", ["(?:2[389]|39)0|[7-9]"], "0$1"],
                        ["(\\d{2})(\\d{5,10})", "$1 $2", ["[1-36]"], "0$1"]
                    ], "0"
                ],
                RU: ["7", "810", "8\\d{13}|[347-9]\\d{9}", [10, 14],
                    [
                        ["(\\d{4})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["7(?:1[0-8]|2[1-9])", "7(?:1(?:[0-356]2|4[29]|7|8[27])|2(?:1[23]|[2-9]2))", "7(?:1(?:[0-356]2|4[29]|7|8[27])|2(?:13[03-69]|62[013-9]))|72[1-57-9]2"], "8 ($1)", 1],
                        ["(\\d{5})(\\d)(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["7(?:1[0-68]|2[1-9])", "7(?:1(?:[06][3-6]|[18]|2[35]|[3-5][3-5])|2(?:[13][3-5]|[24-689]|7[457]))", "7(?:1(?:0(?:[356]|4[023])|[18]|2(?:3[013-9]|5)|3[45]|43[013-79]|5(?:3[1-8]|4[1-7]|5)|6(?:3[0-35-9]|[4-6]))|2(?:1(?:3[178]|[45])|[24-689]|3[35]|7[457]))|7(?:14|23)4[0-8]|71(?:33|45)[1-79]"], "8 ($1)", 1],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["7"], "8 ($1)", 1],
                        ["(\\d{3})(\\d{3})(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["[349]|8(?:[02-7]|1[1-8])"], "8 ($1)", 1],
                        ["(\\d{4})(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["8"], "8 ($1)"]
                    ], "8", 0, 0, 0, 0, "3[04-689]|[489]", 0, "8~10"
                ],
                RW: ["250", "00", "(?:06|[27]\\d\\d|[89]00)\\d{6}", [8, 9],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["0"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["2"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[7-9]"], "0$1"]
                    ], "0"
                ],
                SA: ["966", "00", "92\\d{7}|(?:[15]|8\\d)\\d{8}", [9, 10],
                    [
                        ["(\\d{4})(\\d{5})", "$1 $2", ["9"]],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["5"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["81"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"]]
                    ], "0"
                ],
                SB: ["677", "0[01]", "[6-9]\\d{6}|[1-6]\\d{4}", [5, 7],
                    [
                        ["(\\d{2})(\\d{5})", "$1 $2", ["6[89]|7|8[4-9]|9(?:[1-8]|9[0-8])"]]
                    ]
                ],
                SC: ["248", "010|0[0-2]", "(?:[2489]\\d|64)\\d{5}", [7],
                    [
                        ["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["[246]|9[57]"]]
                    ], 0, 0, 0, 0, 0, 0, 0, "00"
                ],
                SD: ["249", "00", "[19]\\d{8}", [9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[19]"], "0$1"]
                    ], "0"
                ],
                SE: ["46", "00", "(?:[26]\\d\\d|9)\\d{9}|[1-9]\\d{8}|[1-689]\\d{7}|[1-4689]\\d{6}|2\\d{5}", [6, 7, 8, 9, 10, 12],
                    [
                        ["(\\d{2})(\\d{2,3})(\\d{2})", "$1-$2 $3", ["20"], "0$1", 0, "$1 $2 $3"],
                        ["(\\d{3})(\\d{4})", "$1-$2", ["9(?:00|39|44|9)"], "0$1", 0, "$1 $2"],
                        ["(\\d{2})(\\d{3})(\\d{2})", "$1-$2 $3", ["[12][136]|3[356]|4[0246]|6[03]|90[1-9]"], "0$1", 0, "$1 $2 $3"],
                        ["(\\d)(\\d{2,3})(\\d{2})(\\d{2})", "$1-$2 $3 $4", ["8"], "0$1", 0, "$1 $2 $3 $4"],
                        ["(\\d{3})(\\d{2,3})(\\d{2})", "$1-$2 $3", ["1[2457]|2(?:[247-9]|5[0138])|3[0247-9]|4[1357-9]|5[0-35-9]|6(?:[125689]|4[02-57]|7[0-2])|9(?:[125-8]|3[02-5]|4[0-3])"], "0$1", 0, "$1 $2 $3"],
                        ["(\\d{3})(\\d{2,3})(\\d{3})", "$1-$2 $3", ["9(?:00|39|44)"], "0$1", 0, "$1 $2 $3"],
                        ["(\\d{2})(\\d{2,3})(\\d{2})(\\d{2})", "$1-$2 $3 $4", ["1[13689]|2[0136]|3[1356]|4[0246]|54|6[03]|90[1-9]"], "0$1", 0, "$1 $2 $3 $4"],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1-$2 $3 $4", ["10|7"], "0$1", 0, "$1 $2 $3 $4"],
                        ["(\\d)(\\d{3})(\\d{3})(\\d{2})", "$1-$2 $3 $4", ["8"], "0$1", 0, "$1 $2 $3 $4"],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1-$2 $3 $4", ["[13-5]|2(?:[247-9]|5[0138])|6(?:[124-689]|7[0-2])|9(?:[125-8]|3[02-5]|4[0-3])"], "0$1", 0, "$1 $2 $3 $4"],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{3})", "$1-$2 $3 $4", ["9"], "0$1", 0, "$1 $2 $3 $4"],
                        ["(\\d{3})(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1-$2 $3 $4 $5", ["[26]"], "0$1", 0, "$1 $2 $3 $4 $5"]
                    ], "0"
                ],
                SG: ["65", "0[0-3]\\d", "(?:(?:1\\d|8)\\d\\d|7000)\\d{7}|[3689]\\d{7}", [8, 10, 11],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[369]|8(?:0[1-9]|[1-9])"]],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"]],
                        ["(\\d{4})(\\d{4})(\\d{3})", "$1 $2 $3", ["7"]],
                        ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"]]
                    ]
                ],
                SH: ["290", "00", "(?:[256]\\d|8)\\d{3}", [4, 5], 0, 0, 0, 0, 0, 0, "[256]"],
                SI: ["386", "00|10(?:22|66|88|99)", "[1-7]\\d{7}|8\\d{4,7}|90\\d{4,6}", [5, 6, 7, 8],
                    [
                        ["(\\d{2})(\\d{3,6})", "$1 $2", ["8[09]|9"], "0$1"],
                        ["(\\d{3})(\\d{5})", "$1 $2", ["59|8"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[37][01]|4[0139]|51|6"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[1-57]"], "(0$1)"]
                    ], "0", 0, 0, 0, 0, 0, 0, "00"
                ],
                SJ: ["47", "00", "0\\d{4}|(?:[489]\\d|79)\\d{6}", [5, 8], 0, 0, 0, 0, 0, 0, "79"],
                SK: ["421", "00", "[2-689]\\d{8}|[2-59]\\d{6}|[2-5]\\d{5}", [6, 7, 9],
                    [
                        ["(\\d)(\\d{2})(\\d{3,4})", "$1 $2 $3", ["21"], "0$1"],
                        ["(\\d{2})(\\d{2})(\\d{2,3})", "$1 $2 $3", ["[3-5][1-8]1", "[3-5][1-8]1[67]"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{3})(\\d{2})", "$1/$2 $3 $4", ["2"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[689]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1/$2 $3 $4", ["[3-5]"], "0$1"]
                    ], "0"
                ],
                SL: ["232", "00", "(?:[237-9]\\d|66)\\d{6}", [8],
                    [
                        ["(\\d{2})(\\d{6})", "$1 $2", ["[236-9]"], "(0$1)"]
                    ], "0"
                ],
                SM: ["378", "00", "(?:0549|[5-7]\\d)\\d{6}", [8, 10],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-7]"]],
                        ["(\\d{4})(\\d{6})", "$1 $2", ["0"]]
                    ], 0, 0, "([89]\\d{5})$", "0549$1"
                ],
                SN: ["221", "00", "(?:[378]\\d|93)\\d{7}", [9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"]],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[379]"]]
                    ]
                ],
                SO: ["252", "00", "[346-9]\\d{8}|[12679]\\d{7}|[1-5]\\d{6}|[1348]\\d{5}", [6, 7, 8, 9],
                    [
                        ["(\\d{2})(\\d{4})", "$1 $2", ["8[125]"]],
                        ["(\\d{6})", "$1", ["[134]"]],
                        ["(\\d)(\\d{6})", "$1 $2", ["[15]|2[0-79]|3[0-46-8]|4[0-7]"]],
                        ["(\\d)(\\d{7})", "$1 $2", ["(?:2|90)4|[67]"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[348]|64|79|90"]],
                        ["(\\d{2})(\\d{5,7})", "$1 $2", ["1|28|6[0-35-9]|7[67]|9[2-9]"]]
                    ], "0"
                ],
                SR: ["597", "00", "(?:[2-5]|68|[78]\\d)\\d{5}", [6, 7],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})", "$1-$2-$3", ["56"]],
                        ["(\\d{3})(\\d{3})", "$1-$2", ["[2-5]"]],
                        ["(\\d{3})(\\d{4})", "$1-$2", ["[6-8]"]]
                    ]
                ],
                SS: ["211", "00", "[19]\\d{8}", [9],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[19]"], "0$1"]
                    ], "0"
                ],
                ST: ["239", "00", "(?:22|9\\d)\\d{5}", [7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[29]"]]
                    ]
                ],
                SV: ["503", "00", "[267]\\d{7}|(?:80\\d|900)\\d{4}(?:\\d{4})?", [7, 8, 11],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[89]"]],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[267]"]],
                        ["(\\d{3})(\\d{4})(\\d{4})", "$1 $2 $3", ["[89]"]]
                    ]
                ],
                SX: ["1", "011", "7215\\d{6}|(?:[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "(5\\d{6})$|1", "721$1", 0, "721"],
                SY: ["963", "00", "[1-359]\\d{8}|[1-5]\\d{7}", [8, 9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[1-4]|5[1-3]"], "0$1", 1],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[59]"], "0$1", 1]
                    ], "0"
                ],
                SZ: ["268", "00", "0800\\d{4}|(?:[237]\\d|900)\\d{6}", [8, 9],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[0237]"]],
                        ["(\\d{5})(\\d{4})", "$1 $2", ["9"]]
                    ]
                ],
                TA: ["290", "00", "8\\d{3}", [4], 0, 0, 0, 0, 0, 0, "8"],
                TC: ["1", "011", "(?:[58]\\d\\d|649|900)\\d{7}", [10], 0, "1", 0, "([2-479]\\d{6})$|1", "649$1", 0, "649"],
                TD: ["235", "00|16", "(?:22|[689]\\d|77)\\d{6}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[26-9]"]]
                    ], 0, 0, 0, 0, 0, 0, 0, "00"
                ],
                TG: ["228", "00", "[279]\\d{7}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[279]"]]
                    ]
                ],
                TH: ["66", "00[1-9]", "(?:001800|[2-57]|[689]\\d)\\d{7}|1\\d{7,9}", [8, 9, 10, 13],
                    [
                        ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["2"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[13-9]"], "0$1"],
                        ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1"]]
                    ], "0"
                ],
                TJ: ["992", "810", "[0-57-9]\\d{8}", [9],
                    [
                        ["(\\d{6})(\\d)(\\d{2})", "$1 $2 $3", ["331", "3317"]],
                        ["(\\d{3})(\\d{2})(\\d{4})", "$1 $2 $3", ["44[02-479]|[34]7"]],
                        ["(\\d{4})(\\d)(\\d{4})", "$1 $2 $3", ["3(?:[1245]|3[12])"]],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[0-57-9]"]]
                    ], 0, 0, 0, 0, 0, 0, 0, "8~10"
                ],
                TK: ["690", "00", "[2-47]\\d{3,6}", [4, 5, 6, 7]],
                TL: ["670", "00", "7\\d{7}|(?:[2-47]\\d|[89]0)\\d{5}", [7, 8],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[2-489]|70"]],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["7"]]
                    ]
                ],
                TM: ["993", "810", "(?:[1-6]\\d|71)\\d{6}", [8],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["12"], "(8 $1)"],
                        ["(\\d{3})(\\d)(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["[1-5]"], "(8 $1)"],
                        ["(\\d{2})(\\d{6})", "$1 $2", ["[67]"], "8 $1"]
                    ], "8", 0, 0, 0, 0, 0, 0, "8~10"
                ],
                TN: ["216", "00", "[2-57-9]\\d{7}", [8],
                    [
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2-57-9]"]]
                    ]
                ],
                TO: ["676", "00", "(?:0800|(?:[5-8]\\d\\d|999)\\d)\\d{3}|[2-8]\\d{4}", [5, 7],
                    [
                        ["(\\d{2})(\\d{3})", "$1-$2", ["[2-4]|50|6[09]|7[0-24-69]|8[05]"]],
                        ["(\\d{4})(\\d{3})", "$1 $2", ["0"]],
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[5-9]"]]
                    ]
                ],
                TR: ["90", "00", "4\\d{6}|8\\d{11,12}|(?:[2-58]\\d\\d|900)\\d{7}", [7, 10, 12, 13],
                    [
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["512|8[01589]|90"], "0$1", 1],
                        ["(\\d{3})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["5(?:[0-59]|61)", "5(?:[0-59]|61[06])", "5(?:[0-59]|61[06]1)"], "0$1", 1],
                        ["(\\d{3})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[24][1-8]|3[1-9]"], "(0$1)", 1],
                        ["(\\d{3})(\\d{3})(\\d{6,7})", "$1 $2 $3", ["80"], "0$1", 1]
                    ], "0"
                ],
                TT: ["1", "011", "(?:[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-46-8]\\d{6})$|1", "868$1", 0, "868"],
                TV: ["688", "00", "(?:2|7\\d\\d|90)\\d{4}", [5, 6, 7],
                    [
                        ["(\\d{2})(\\d{3})", "$1 $2", ["2"]],
                        ["(\\d{2})(\\d{4})", "$1 $2", ["90"]],
                        ["(\\d{2})(\\d{5})", "$1 $2", ["7"]]
                    ]
                ],
                TW: ["886", "0(?:0[25-79]|19)", "[2-689]\\d{8}|7\\d{9,10}|[2-8]\\d{7}|2\\d{6}", [7, 8, 9, 10, 11],
                    [
                        ["(\\d{2})(\\d)(\\d{4})", "$1 $2 $3", ["202"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[258]0"], "0$1"],
                        ["(\\d)(\\d{3,4})(\\d{4})", "$1 $2 $3", ["[23568]|4(?:0[02-48]|[1-47-9])|7[1-9]", "[23568]|4(?:0[2-48]|[1-47-9])|(?:400|7)[1-9]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[49]"], "0$1"],
                        ["(\\d{2})(\\d{4})(\\d{4,5})", "$1 $2 $3", ["7"], "0$1"]
                    ], "0", 0, 0, 0, 0, 0, 0, 0, "#"
                ],
                TZ: ["255", "00[056]", "(?:[25-8]\\d|41|90)\\d{7}", [9],
                    [
                        ["(\\d{3})(\\d{2})(\\d{4})", "$1 $2 $3", ["[89]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[24]"], "0$1"],
                        ["(\\d{2})(\\d{7})", "$1 $2", ["5"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[67]"], "0$1"]
                    ], "0"
                ],
                UA: ["380", "00", "[89]\\d{9}|[3-9]\\d{8}", [9, 10],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["6[12][29]|(?:3[1-8]|4[136-8]|5[12457]|6[49])2|(?:56|65)[24]", "6[12][29]|(?:35|4[1378]|5[12457]|6[49])2|(?:56|65)[24]|(?:3[1-46-8]|46)2[013-9]"], "0$1"],
                        ["(\\d{4})(\\d{5})", "$1 $2", ["3[1-8]|4(?:[1367]|[45][6-9]|8[4-6])|5(?:[1-5]|6[0135689]|7[4-6])|6(?:[12][3-7]|[459])", "3[1-8]|4(?:[1367]|[45][6-9]|8[4-6])|5(?:[1-5]|6(?:[015689]|3[02389])|7[4-6])|6(?:[12][3-7]|[459])"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[3-7]|89|9[1-9]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[89]"], "0$1"]
                    ], "0", 0, 0, 0, 0, 0, 0, "0~0"
                ],
                UG: ["256", "00[057]", "800\\d{6}|(?:[29]0|[347]\\d)\\d{7}", [9],
                    [
                        ["(\\d{4})(\\d{5})", "$1 $2", ["202", "2024"], "0$1"],
                        ["(\\d{3})(\\d{6})", "$1 $2", ["[27-9]|4(?:6[45]|[7-9])"], "0$1"],
                        ["(\\d{2})(\\d{7})", "$1 $2", ["[34]"], "0$1"]
                    ], "0"
                ],
                US: ["1", "011", "[2-9]\\d{9}|3\\d{6}", [10],
                    [
                        ["(\\d{3})(\\d{4})", "$1-$2", ["310"], 0, 1],
                        ["(\\d{3})(\\d{3})(\\d{4})", "($1) $2-$3", ["[2-9]"], 0, 1, "$1-$2-$3"]
                    ], "1", 0, 0, 0, 0, 0, [
                        ["(?:3052(?:0[0-8]|[1-9]\\d)|5056(?:[0-35-9]\\d|4[0-468]))\\d{4}|(?:2742|305[3-9]|472[247-9]|505[2-57-9]|983[2-47-9])\\d{6}|(?:2(?:0[1-35-9]|1[02-9]|2[03-57-9]|3[1459]|4[08]|5[1-46]|6[0279]|7[0269]|8[13])|3(?:0[1-47-9]|1[02-9]|2[0135-79]|3[0-24679]|4[167]|5[0-2]|6[01349]|8[056])|4(?:0[124-9]|1[02-579]|2[3-5]|3[0245]|4[023578]|58|6[349]|7[0589]|8[04])|5(?:0[1-47-9]|1[0235-8]|20|3[0149]|4[01]|5[179]|6[1-47]|7[0-5]|8[0256])|6(?:0[1-35-9]|1[024-9]|2[03689]|3[016]|4[0156]|5[01679]|6[0-279]|78|8[0-29])|7(?:0[1-46-8]|1[2-9]|2[04-8]|3[0-247]|4[037]|5[47]|6[02359]|7[0-59]|8[156])|8(?:0[1-68]|1[02-8]|2[068]|3[0-2589]|4[03578]|5[046-9]|6[02-5]|7[028])|9(?:0[1346-9]|1[02-9]|2[0589]|3[0146-8]|4[01357-9]|5[12469]|7[0-389]|8[04-69]))[2-9]\\d{6}"],
                        [""],
                        ["8(?:00|33|44|55|66|77|88)[2-9]\\d{6}"],
                        ["900[2-9]\\d{6}"],
                        ["52(?:3(?:[2-46-9][02-9]\\d|5(?:[02-46-9]\\d|5[0-46-9]))|4(?:[2-478][02-9]\\d|5(?:[034]\\d|2[024-9]|5[0-46-9])|6(?:0[1-9]|[2-9]\\d)|9(?:[05-9]\\d|2[0-5]|49)))\\d{4}|52[34][2-9]1[02-9]\\d{4}|5(?:00|2[125-9]|33|44|66|77|88)[2-9]\\d{6}"], 0, 0, 0, ["305209\\d{4}"]
                    ]
                ],
                UY: ["598", "0(?:0|1[3-9]\\d)", "0004\\d{2,9}|[1249]\\d{7}|(?:[49]\\d|80)\\d{5}", [6, 7, 8, 9, 10, 11, 12, 13],
                    [
                        ["(\\d{3})(\\d{3,4})", "$1 $2", ["0"]],
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[49]0|8"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["9"], "0$1"],
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[124]"]],
                        ["(\\d{3})(\\d{3})(\\d{2,4})", "$1 $2 $3", ["0"]],
                        ["(\\d{3})(\\d{3})(\\d{3})(\\d{2,4})", "$1 $2 $3 $4", ["0"]]
                    ], "0", 0, 0, 0, 0, 0, 0, "00", " int. "
                ],
                UZ: ["998", "00", "(?:20|33|[5-9]\\d)\\d{7}", [9],
                    [
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[235-9]"]]
                    ]
                ],
                VA: ["39", "00", "0\\d{5,10}|3[0-8]\\d{7,10}|55\\d{8}|8\\d{5}(?:\\d{2,4})?|(?:1\\d|39)\\d{7,8}", [6, 7, 8, 9, 10, 11, 12], 0, 0, 0, 0, 0, 0, "06698"],
                VC: ["1", "011", "(?:[58]\\d\\d|784|900)\\d{7}", [10], 0, "1", 0, "([2-7]\\d{6})$|1", "784$1", 0, "784"],
                VE: ["58", "00", "[68]00\\d{7}|(?:[24]\\d|[59]0)\\d{8}", [10],
                    [
                        ["(\\d{3})(\\d{7})", "$1-$2", ["[24-689]"], "0$1"]
                    ], "0"
                ],
                VG: ["1", "011", "(?:284|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-578]\\d{6})$|1", "284$1", 0, "284"],
                VI: ["1", "011", "[58]\\d{9}|(?:34|90)0\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "340$1", 0, "340"],
                VN: ["84", "00", "[12]\\d{9}|[135-9]\\d{8}|[16]\\d{7}|[16-8]\\d{6}", [7, 8, 9, 10],
                    [
                        ["(\\d{2})(\\d{5})", "$1 $2", ["80"], "0$1", 1],
                        ["(\\d{4})(\\d{4,6})", "$1 $2", ["1"], 0, 1],
                        ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["6"], "0$1", 1],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[357-9]"], "0$1", 1],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["2[48]"], "0$1", 1],
                        ["(\\d{3})(\\d{4})(\\d{3})", "$1 $2 $3", ["2"], "0$1", 1]
                    ], "0"
                ],
                VU: ["678", "00", "[57-9]\\d{6}|(?:[238]\\d|48)\\d{3}", [5, 7],
                    [
                        ["(\\d{3})(\\d{4})", "$1 $2", ["[57-9]"]]
                    ]
                ],
                WF: ["681", "00", "(?:40|72|8\\d{4})\\d{4}|[89]\\d{5}", [6, 9],
                    [
                        ["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["[47-9]"]],
                        ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"]]
                    ]
                ],
                WS: ["685", "0", "(?:[2-6]|8\\d{5})\\d{4}|[78]\\d{6}|[68]\\d{5}", [5, 6, 7, 10],
                    [
                        ["(\\d{5})", "$1", ["[2-5]|6[1-9]"]],
                        ["(\\d{3})(\\d{3,7})", "$1 $2", ["[68]"]],
                        ["(\\d{2})(\\d{5})", "$1 $2", ["7"]]
                    ]
                ],
                XK: ["383", "00", "2\\d{7,8}|3\\d{7,11}|(?:4\\d\\d|[89]00)\\d{5}", [8, 9, 10, 11, 12],
                    [
                        ["(\\d{3})(\\d{5})", "$1 $2", ["[89]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2-4]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["2|39"], "0$1"],
                        ["(\\d{2})(\\d{7,10})", "$1 $2", ["3"], "0$1"]
                    ], "0"
                ],
                YE: ["967", "00", "(?:1|7\\d)\\d{7}|[1-7]\\d{6}", [7, 8, 9],
                    [
                        ["(\\d)(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[1-6]|7(?:[24-6]|8[0-7])"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["7"], "0$1"]
                    ], "0"
                ],
                YT: ["262", "00", "7093\\d{5}|(?:80|9\\d)\\d{7}|(?:26|63)9\\d{6}", [9], 0, "0", 0, 0, 0, 0, 0, [
                    ["269(?:0[0-467]|15|5[0-4]|6\\d|[78]0)\\d{4}"],
                    ["(?:639(?:0[0-79]|1[019]|[267]\\d|3[09]|40|5[05-9]|9[04-79])|7093[5-7])\\d{4}"],
                    ["80\\d{7}"], 0, 0, 0, 0, 0, ["9(?:(?:39|47)8[01]|769\\d)\\d{4}"]
                ]],
                ZA: ["27", "00", "[1-79]\\d{8}|8\\d{4,9}", [5, 6, 7, 8, 9, 10],
                    [
                        ["(\\d{2})(\\d{3,4})", "$1 $2", ["8[1-4]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{2,3})", "$1 $2 $3", ["8[1-4]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["860"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[1-9]"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"], "0$1"]
                    ], "0"
                ],
                ZM: ["260", "00", "800\\d{6}|(?:21|[579]\\d|63)\\d{7}", [9],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[28]"], "0$1"],
                        ["(\\d{2})(\\d{7})", "$1 $2", ["[579]"], "0$1"]
                    ], "0"
                ],
                ZW: ["263", "00", "2(?:[0-57-9]\\d{6,8}|6[0-24-9]\\d{6,7})|[38]\\d{9}|[35-8]\\d{8}|[3-6]\\d{7}|[1-689]\\d{6}|[1-3569]\\d{5}|[1356]\\d{4}", [5, 6, 7, 8, 9, 10],
                    [
                        ["(\\d{3})(\\d{3,5})", "$1 $2", ["2(?:0[45]|2[278]|[49]8)|3(?:[09]8|17)|6(?:[29]8|37|75)|[23][78]|(?:33|5[15]|6[68])[78]"], "0$1"],
                        ["(\\d)(\\d{3})(\\d{2,4})", "$1 $2 $3", ["[49]"], "0$1"],
                        ["(\\d{3})(\\d{4})", "$1 $2", ["80"], "0$1"],
                        ["(\\d{2})(\\d{7})", "$1 $2", ["24|8[13-59]|(?:2[05-79]|39|5[45]|6[15-8])2", "2(?:02[014]|4|[56]20|[79]2)|392|5(?:42|525)|6(?:[16-8]21|52[013])|8[13-59]"], "(0$1)"],
                        ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["7"], "0$1"],
                        ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["2(?:1[39]|2[0157]|[378]|[56][14])|3(?:12|29)", "2(?:1[39]|2[0157]|[378]|[56][14])|3(?:123|29)"], "0$1"],
                        ["(\\d{4})(\\d{6})", "$1 $2", ["8"], "0$1"],
                        ["(\\d{2})(\\d{3,5})", "$1 $2", ["1|2(?:0[0-36-9]|12|29|[56])|3(?:1[0-689]|[24-6])|5(?:[0236-9]|1[2-4])|6(?:[013-59]|7[0-46-9])|(?:33|55|6[68])[0-69]|(?:29|3[09]|62)[0-79]"], "0$1"],
                        ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["29[013-9]|39|54"], "0$1"],
                        ["(\\d{4})(\\d{3,5})", "$1 $2", ["(?:25|54)8", "258|5483"], "0$1"]
                    ], "0"
                ]
            },
            nonGeographic: {
                800: ["800", 0, "(?:00|[1-9]\\d)\\d{6}", [8],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["\\d"]]
                    ], 0, 0, 0, 0, 0, 0, [0, 0, ["(?:00|[1-9]\\d)\\d{6}"]]
                ],
                808: ["808", 0, "[1-9]\\d{7}", [8],
                    [
                        ["(\\d{4})(\\d{4})", "$1 $2", ["[1-9]"]]
                    ], 0, 0, 0, 0, 0, 0, [0, 0, 0, 0, 0, 0, 0, 0, 0, ["[1-9]\\d{7}"]]
                ],
                870: ["870", 0, "7\\d{11}|[235-7]\\d{8}", [9, 12],
                    [
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[235-7]"]]
                    ], 0, 0, 0, 0, 0, 0, [0, ["(?:[356]|774[45])\\d{8}|7[6-8]\\d{7}"], 0, 0, 0, 0, 0, 0, ["2\\d{8}", [9]]]
                ],
                878: ["878", 0, "10\\d{10}", [12],
                    [
                        ["(\\d{2})(\\d{5})(\\d{5})", "$1 $2 $3", ["1"]]
                    ], 0, 0, 0, 0, 0, 0, [0, 0, 0, 0, 0, 0, 0, 0, ["10\\d{10}"]]
                ],
                881: ["881", 0, "6\\d{9}|[0-36-9]\\d{8}", [9, 10],
                    [
                        ["(\\d)(\\d{3})(\\d{5})", "$1 $2 $3", ["[0-37-9]"]],
                        ["(\\d)(\\d{3})(\\d{5,6})", "$1 $2 $3", ["6"]]
                    ], 0, 0, 0, 0, 0, 0, [0, ["6\\d{9}|[0-36-9]\\d{8}"]]
                ],
                882: ["882", 0, "[13]\\d{6}(?:\\d{2,5})?|[19]\\d{7}|(?:[25]\\d\\d|4)\\d{7}(?:\\d{2})?", [7, 8, 9, 10, 11, 12],
                    [
                        ["(\\d{2})(\\d{5})", "$1 $2", ["16|342"]],
                        ["(\\d{2})(\\d{6})", "$1 $2", ["49"]],
                        ["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["1[36]|9"]],
                        ["(\\d{2})(\\d{4})(\\d{3})", "$1 $2 $3", ["3[23]"]],
                        ["(\\d{2})(\\d{3,4})(\\d{4})", "$1 $2 $3", ["16"]],
                        ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["10|23|3(?:[15]|4[57])|4|51"]],
                        ["(\\d{3})(\\d{4})(\\d{4})", "$1 $2 $3", ["34"]],
                        ["(\\d{2})(\\d{4,5})(\\d{5})", "$1 $2 $3", ["[1-35]"]]
                    ], 0, 0, 0, 0, 0, 0, [0, ["342\\d{4}|(?:337|49)\\d{6}|(?:3(?:2|47|7\\d{3})|50\\d{3})\\d{7}", [7, 8, 9, 10, 12]], 0, 0, 0, ["348[57]\\d{7}", [11]], 0, 0, ["1(?:3(?:0[0347]|[13][0139]|2[035]|4[013568]|6[0459]|7[06]|8[15-8]|9[0689])\\d{4}|6\\d{5,10})|(?:345\\d|9[89])\\d{6}|(?:10|2(?:3|85\\d)|3(?:[15]|[69]\\d\\d)|4[15-8]|51)\\d{8}"]]
                ],
                883: ["883", 0, "(?:[1-4]\\d|51)\\d{6,10}", [8, 9, 10, 11, 12],
                    [
                        ["(\\d{3})(\\d{3})(\\d{2,8})", "$1 $2 $3", ["[14]|2[24-689]|3[02-689]|51[24-9]"]],
                        ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["510"]],
                        ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["21"]],
                        ["(\\d{4})(\\d{4})(\\d{4})", "$1 $2 $3", ["51[13]"]],
                        ["(\\d{3})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["[235]"]]
                    ], 0, 0, 0, 0, 0, 0, [0, 0, 0, 0, 0, 0, 0, 0, ["(?:2(?:00\\d\\d|10)|(?:370[1-9]|51\\d0)\\d)\\d{7}|51(?:00\\d{5}|[24-9]0\\d{4,7})|(?:1[0-79]|2[24-689]|3[02-689]|4[0-4])0\\d{5,9}"]]
                ],
                888: ["888", 0, "\\d{11}", [11],
                    [
                        ["(\\d{3})(\\d{3})(\\d{5})", "$1 $2 $3"]
                    ], 0, 0, 0, 0, 0, 0, [0, 0, 0, 0, 0, 0, ["\\d{11}"]]
                ],
                979: ["979", 0, "[1359]\\d{8}", [9],
                    [
                        ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["[1359]"]]
                    ], 0, 0, 0, 0, 0, 0, [0, 0, 0, ["[1359]\\d{8}"]]
                ]
            }
        };

    function cd(e, t) {
        e = e.split("-"), t = t.split("-");
        for (var r = e[0].split("."), n = t[0].split("."), o = 0; o < 3; o++) {
            var i = Number(r[o]),
                d = Number(n[o]);
            if (i > d) return 1;
            if (d > i) return -1;
            if (!isNaN(i) && isNaN(d)) return 1;
            if (isNaN(i) && !isNaN(d)) return -1
        }
        return e[1] && t[1] ? e[1] > t[1] ? 1 : e[1] < t[1] ? -1 : 0 : !e[1] && t[1] ? 1 : e[1] && !t[1] ? -1 : 0
    }
    var fd = {}.constructor;

    function $d(e) {
        return null != e && e.constructor === fd
    }

    function pd(e) {
        return (pd = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function hd(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function md(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
        }
    }

    function _d(e, t, r) {
        return t && md(e.prototype, t), r && md(e, r), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }
    var yd = " ext. ",
        vd = /^\d+$/,
        gd = function() {
            function e(t) {
                hd(this, e), Od(t), this.metadata = t, Md.call(this, t)
            }
            return _d(e, [{
                key: "getCountries",
                value: function() {
                    return Object.keys(this.metadata.countries).filter((function(e) {
                        return "001" !== e
                    }))
                }
            }, {
                key: "getCountryMetadata",
                value: function(e) {
                    return this.metadata.countries[e]
                }
            }, {
                key: "nonGeographic",
                value: function() {
                    if (!(this.v1 || this.v2 || this.v3)) return this.metadata.nonGeographic || this.metadata.nonGeographical
                }
            }, {
                key: "hasCountry",
                value: function(e) {
                    return void 0 !== this.getCountryMetadata(e)
                }
            }, {
                key: "hasCallingCode",
                value: function(e) {
                    if (this.getCountryCodesForCallingCode(e)) return !0;
                    if (this.nonGeographic()) {
                        if (this.nonGeographic()[e]) return !0
                    } else {
                        var t = this.countryCallingCodes()[e];
                        if (t && 1 === t.length && "001" === t[0]) return !0
                    }
                }
            }, {
                key: "isNonGeographicCallingCode",
                value: function(e) {
                    return this.nonGeographic() ? !!this.nonGeographic()[e] : !this.getCountryCodesForCallingCode(e)
                }
            }, {
                key: "country",
                value: function(e) {
                    return this.selectNumberingPlan(e)
                }
            }, {
                key: "selectNumberingPlan",
                value: function(e, t) {
                    if (e && vd.test(e) && (t = e, e = null), e && "001" !== e) {
                        if (!this.hasCountry(e)) throw new Error("Unknown country: ".concat(e));
                        this.numberingPlan = new bd(this.getCountryMetadata(e), this)
                    } else if (t) {
                        if (!this.hasCallingCode(t)) throw new Error("Unknown calling code: ".concat(t));
                        this.numberingPlan = new bd(this.getNumberingPlanMetadata(t), this)
                    } else this.numberingPlan = void 0;
                    return this
                }
            }, {
                key: "getCountryCodesForCallingCode",
                value: function(e) {
                    var t = this.countryCallingCodes()[e];
                    if (t) {
                        if (1 === t.length && 3 === t[0].length) return;
                        return t
                    }
                }
            }, {
                key: "getCountryCodeForCallingCode",
                value: function(e) {
                    var t = this.getCountryCodesForCallingCode(e);
                    if (t) return t[0]
                }
            }, {
                key: "getNumberingPlanMetadata",
                value: function(e) {
                    var t = this.getCountryCodeForCallingCode(e);
                    if (t) return this.getCountryMetadata(t);
                    if (this.nonGeographic()) {
                        var r = this.nonGeographic()[e];
                        if (r) return r
                    } else {
                        var n = this.countryCallingCodes()[e];
                        if (n && 1 === n.length && "001" === n[0]) return this.metadata.countries["001"]
                    }
                }
            }, {
                key: "countryCallingCode",
                value: function() {
                    return this.numberingPlan.callingCode()
                }
            }, {
                key: "IDDPrefix",
                value: function() {
                    return this.numberingPlan.IDDPrefix()
                }
            }, {
                key: "defaultIDDPrefix",
                value: function() {
                    return this.numberingPlan.defaultIDDPrefix()
                }
            }, {
                key: "nationalNumberPattern",
                value: function() {
                    return this.numberingPlan.nationalNumberPattern()
                }
            }, {
                key: "possibleLengths",
                value: function() {
                    return this.numberingPlan.possibleLengths()
                }
            }, {
                key: "formats",
                value: function() {
                    return this.numberingPlan.formats()
                }
            }, {
                key: "nationalPrefixForParsing",
                value: function() {
                    return this.numberingPlan.nationalPrefixForParsing()
                }
            }, {
                key: "nationalPrefixTransformRule",
                value: function() {
                    return this.numberingPlan.nationalPrefixTransformRule()
                }
            }, {
                key: "leadingDigits",
                value: function() {
                    return this.numberingPlan.leadingDigits()
                }
            }, {
                key: "hasTypes",
                value: function() {
                    return this.numberingPlan.hasTypes()
                }
            }, {
                key: "type",
                value: function(e) {
                    return this.numberingPlan.type(e)
                }
            }, {
                key: "ext",
                value: function() {
                    return this.numberingPlan.ext()
                }
            }, {
                key: "countryCallingCodes",
                value: function() {
                    return this.v1 ? this.metadata.country_phone_code_to_countries : this.metadata.country_calling_codes
                }
            }, {
                key: "chooseCountryByCountryCallingCode",
                value: function(e) {
                    return this.selectNumberingPlan(e)
                }
            }, {
                key: "hasSelectedNumberingPlan",
                value: function() {
                    return void 0 !== this.numberingPlan
                }
            }]), e
        }(),
        bd = function() {
            function e(t, r) {
                hd(this, e), this.globalMetadataObject = r, this.metadata = t, Md.call(this, r.metadata)
            }
            return _d(e, [{
                key: "callingCode",
                value: function() {
                    return this.metadata[0]
                }
            }, {
                key: "getDefaultCountryMetadataForRegion",
                value: function() {
                    return this.globalMetadataObject.getNumberingPlanMetadata(this.callingCode())
                }
            }, {
                key: "IDDPrefix",
                value: function() {
                    if (!this.v1 && !this.v2) return this.metadata[1]
                }
            }, {
                key: "defaultIDDPrefix",
                value: function() {
                    if (!this.v1 && !this.v2) return this.metadata[12]
                }
            }, {
                key: "nationalNumberPattern",
                value: function() {
                    return this.v1 || this.v2 ? this.metadata[1] : this.metadata[2]
                }
            }, {
                key: "possibleLengths",
                value: function() {
                    if (!this.v1) return this.metadata[this.v2 ? 2 : 3]
                }
            }, {
                key: "_getFormats",
                value: function(e) {
                    return e[this.v1 ? 2 : this.v2 ? 3 : 4]
                }
            }, {
                key: "formats",
                value: function() {
                    var e = this;
                    return (this._getFormats(this.metadata) || this._getFormats(this.getDefaultCountryMetadataForRegion()) || []).map((function(t) {
                        return new wd(t, e)
                    }))
                }
            }, {
                key: "nationalPrefix",
                value: function() {
                    return this.metadata[this.v1 ? 3 : this.v2 ? 4 : 5]
                }
            }, {
                key: "_getNationalPrefixFormattingRule",
                value: function(e) {
                    return e[this.v1 ? 4 : this.v2 ? 5 : 6]
                }
            }, {
                key: "nationalPrefixFormattingRule",
                value: function() {
                    return this._getNationalPrefixFormattingRule(this.metadata) || this._getNationalPrefixFormattingRule(this.getDefaultCountryMetadataForRegion())
                }
            }, {
                key: "_nationalPrefixForParsing",
                value: function() {
                    return this.metadata[this.v1 ? 5 : this.v2 ? 6 : 7]
                }
            }, {
                key: "nationalPrefixForParsing",
                value: function() {
                    return this._nationalPrefixForParsing() || this.nationalPrefix()
                }
            }, {
                key: "nationalPrefixTransformRule",
                value: function() {
                    return this.metadata[this.v1 ? 6 : this.v2 ? 7 : 8]
                }
            }, {
                key: "_getNationalPrefixIsOptionalWhenFormatting",
                value: function() {
                    return !!this.metadata[this.v1 ? 7 : this.v2 ? 8 : 9]
                }
            }, {
                key: "nationalPrefixIsOptionalWhenFormattingInNationalFormat",
                value: function() {
                    return this._getNationalPrefixIsOptionalWhenFormatting(this.metadata) || this._getNationalPrefixIsOptionalWhenFormatting(this.getDefaultCountryMetadataForRegion())
                }
            }, {
                key: "leadingDigits",
                value: function() {
                    return this.metadata[this.v1 ? 8 : this.v2 ? 9 : 10]
                }
            }, {
                key: "types",
                value: function() {
                    return this.metadata[this.v1 ? 9 : this.v2 ? 10 : 11]
                }
            }, {
                key: "hasTypes",
                value: function() {
                    return (!this.types() || 0 !== this.types().length) && !!this.types()
                }
            }, {
                key: "type",
                value: function(e) {
                    if (this.hasTypes() && Pd(this.types(), e)) return new Sd(Pd(this.types(), e), this)
                }
            }, {
                key: "ext",
                value: function() {
                    return this.v1 || this.v2 ? yd : this.metadata[13] || yd
                }
            }]), e
        }(),
        wd = function() {
            function e(t, r) {
                hd(this, e), this._format = t, this.metadata = r
            }
            return _d(e, [{
                key: "pattern",
                value: function() {
                    return this._format[0]
                }
            }, {
                key: "format",
                value: function() {
                    return this._format[1]
                }
            }, {
                key: "leadingDigitsPatterns",
                value: function() {
                    return this._format[2] || []
                }
            }, {
                key: "nationalPrefixFormattingRule",
                value: function() {
                    return this._format[3] || this.metadata.nationalPrefixFormattingRule()
                }
            }, {
                key: "nationalPrefixIsOptionalWhenFormattingInNationalFormat",
                value: function() {
                    return !!this._format[4] || this.metadata.nationalPrefixIsOptionalWhenFormattingInNationalFormat()
                }
            }, {
                key: "nationalPrefixIsMandatoryWhenFormattingInNationalFormat",
                value: function() {
                    return this.usesNationalPrefix() && !this.nationalPrefixIsOptionalWhenFormattingInNationalFormat()
                }
            }, {
                key: "usesNationalPrefix",
                value: function() {
                    return !(!this.nationalPrefixFormattingRule() || Cd.test(this.nationalPrefixFormattingRule()))
                }
            }, {
                key: "internationalFormat",
                value: function() {
                    return this._format[5] || this.format()
                }
            }]), e
        }(),
        Cd = /^\(?\$1\)?$/,
        Sd = function() {
            function e(t, r) {
                hd(this, e), this.type = t, this.metadata = r
            }
            return _d(e, [{
                key: "pattern",
                value: function() {
                    return this.metadata.v1 ? this.type : this.type[0]
                }
            }, {
                key: "possibleLengths",
                value: function() {
                    if (!this.metadata.v1) return this.type[1] || this.metadata.possibleLengths()
                }
            }]), e
        }();

    function Pd(e, t) {
        switch (t) {
            case "FIXED_LINE":
                return e[0];
            case "MOBILE":
                return e[1];
            case "TOLL_FREE":
                return e[2];
            case "PREMIUM_RATE":
                return e[3];
            case "PERSONAL_NUMBER":
                return e[4];
            case "VOICEMAIL":
                return e[5];
            case "UAN":
                return e[6];
            case "PAGER":
                return e[7];
            case "VOIP":
                return e[8];
            case "SHARED_COST":
                return e[9]
        }
    }

    function Od(e) {
        if (!e) throw new Error("[libphonenumber-js] `metadata` argument not passed. Check your arguments.");
        if (!$d(e) || !$d(e.countries)) throw new Error("[libphonenumber-js] `metadata` argument was passed but it's not a valid metadata. Must be an object having `.countries` child object property. Got ".concat($d(e) ? "an object of shape: { " + Object.keys(e).join(", ") + " }" : "a " + xd(e) + ": " + e, "."))
    }
    var xd = function(e) {
        return pd(e)
    };

    function Ed(e, t) {
        if ((t = new gd(t)).hasCountry(e)) return t.country(e).countryCallingCode();
        throw new Error("Unknown country: ".concat(e))
    }

    function Md(e) {
        var t = e.version;
        "number" == typeof t ? (this.v1 = 1 === t, this.v2 = 2 === t, this.v3 = 3 === t, this.v4 = 4 === t) : t ? -1 === cd(t, "1.2.0") ? this.v2 = !0 : -1 === cd(t, "1.7.35") ? this.v3 = !0 : this.v4 = !0 : this.v1 = !0
    }

    function Dd(e, t) {
        var r = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
        if (r) return (r = r.call(e)).next.bind(r);
        if (Array.isArray(e) || (r = function(e, t) {
                if (!e) return;
                if ("string" == typeof e) return Nd(e, t);
                var r = Object.prototype.toString.call(e).slice(8, -1);
                "Object" === r && e.constructor && (r = e.constructor.name);
                if ("Map" === r || "Set" === r) return Array.from(e);
                if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Nd(e, t)
            }(e)) || t && e && "number" == typeof e.length) {
            r && (e = r);
            var n = 0;
            return function() {
                return n >= e.length ? {
                    done: !0
                } : {
                    done: !1,
                    value: e[n++]
                }
            }
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }

    function Nd(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }

    function Id(e, t) {
        return kd(e, void 0, t)
    }

    function kd(e, t, r) {
        var n = r.type(t),
            o = n && n.possibleLengths() || r.possibleLengths();
        if (!o) return "IS_POSSIBLE";
        if ("FIXED_LINE_OR_MOBILE" === t) {
            if (!r.type("FIXED_LINE")) return kd(e, "MOBILE", r);
            var i = r.type("MOBILE");
            i && (o = function(e, t) {
                for (var r, n = e.slice(), o = Dd(t); !(r = o()).done;) {
                    var i = r.value;
                    e.indexOf(i) < 0 && n.push(i)
                }
                return n.sort((function(e, t) {
                    return e - t
                }))
            }(o, i.possibleLengths()))
        } else if (t && !n) return "INVALID_LENGTH";
        var d = e.length,
            a = o[0];
        return a === d ? "IS_POSSIBLE" : a > d ? "TOO_SHORT" : o[o.length - 1] < d ? "TOO_LONG" : o.indexOf(d, 1) >= 0 ? "IS_POSSIBLE" : "INVALID_LENGTH"
    }

    function Td(e, t) {
        return "IS_POSSIBLE" === Id(e, t)
    }

    function Ad(e, t) {
        return e = e || "", new RegExp("^(?:" + t + ")$").test(e)
    }

    function jd(e, t) {
        var r = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
        if (r) return (r = r.call(e)).next.bind(r);
        if (Array.isArray(e) || (r = function(e, t) {
                if (!e) return;
                if ("string" == typeof e) return Rd(e, t);
                var r = Object.prototype.toString.call(e).slice(8, -1);
                "Object" === r && e.constructor && (r = e.constructor.name);
                if ("Map" === r || "Set" === r) return Array.from(e);
                if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Rd(e, t)
            }(e)) || t && e && "number" == typeof e.length) {
            r && (e = r);
            var n = 0;
            return function() {
                return n >= e.length ? {
                    done: !0
                } : {
                    done: !1,
                    value: e[n++]
                }
            }
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }

    function Rd(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var Ld = ["MOBILE", "PREMIUM_RATE", "TOLL_FREE", "SHARED_COST", "VOIP", "PERSONAL_NUMBER", "PAGER", "UAN", "VOICEMAIL"];

    function Fd(e, t, r) {
        if (t = t || {}, e.country || e.countryCallingCode) {
            (r = new gd(r)).selectNumberingPlan(e.country, e.countryCallingCode);
            var n = t.v2 ? e.nationalNumber : e.phone;
            if (Ad(n, r.nationalNumberPattern())) {
                if (Bd(n, "FIXED_LINE", r)) return r.type("MOBILE") && "" === r.type("MOBILE").pattern() ? "FIXED_LINE_OR_MOBILE" : r.type("MOBILE") ? Bd(n, "MOBILE", r) ? "FIXED_LINE_OR_MOBILE" : "FIXED_LINE" : "FIXED_LINE_OR_MOBILE";
                for (var o, i = jd(Ld); !(o = i()).done;) {
                    var d = o.value;
                    if (Bd(n, d, r)) return d
                }
            }
        }
    }

    function Bd(e, t, r) {
        return !(!(t = r.type(t)) || !t.pattern()) && (!(t.possibleLengths() && t.possibleLengths().indexOf(e.length) < 0) && Ad(e, t.pattern()))
    }

    function Yd(e, t, r) {
        var n = new gd(r).getCountryCodesForCallingCode(e);
        return n ? n.filter((function(e) {
            return function(e, t, r) {
                var n = new gd(r);
                if (n.selectNumberingPlan(t), n.numberingPlan.possibleLengths().indexOf(e.length) >= 0) return !0;
                return !1
            }(t, e, r)
        })) : []
    }
    var Ud = "0-9０-９٠-٩۰-۹",
        zd = "".concat("-‐-―−ー－").concat("／/").concat("．.").concat("  ­​⁠　").concat("()（）［］\\[\\]").concat("~⁓∼～"),
        Wd = new RegExp("([" + Ud + "])");

    function Gd(e, t) {
        var r = function(e, t) {
                if (e && t.numberingPlan.nationalPrefixForParsing()) {
                    var r = new RegExp("^(?:" + t.numberingPlan.nationalPrefixForParsing() + ")"),
                        n = r.exec(e);
                    if (n) {
                        var o, i, d, a = n.length - 1,
                            s = a > 0 && n[a];
                        if (t.nationalPrefixTransformRule() && s) o = e.replace(r, t.nationalPrefixTransformRule()), a > 1 && (i = n[1]);
                        else {
                            var u = n[0];
                            o = e.slice(u.length), s && (i = n[1])
                        }
                        if (s) {
                            var l = e.indexOf(n[1]);
                            e.slice(0, l) === t.numberingPlan.nationalPrefix() && (d = t.numberingPlan.nationalPrefix())
                        } else d = n[0];
                        return {
                            nationalNumber: o,
                            nationalPrefix: d,
                            carrierCode: i
                        }
                    }
                }
                return {
                    nationalNumber: e
                }
            }(e, t),
            n = r.carrierCode,
            o = r.nationalNumber;
        if (o !== e) {
            if (! function(e, t, r) {
                    if (Ad(e, r.nationalNumberPattern()) && !Ad(t, r.nationalNumberPattern())) return !1;
                    return !0
                }(e, o, t)) return {
                nationalNumber: e
            };
            if (t.possibleLengths() && ! function(e, t) {
                    switch (Id(e, t)) {
                        case "TOO_SHORT":
                        case "INVALID_LENGTH":
                            return !1;
                        default:
                            return !0
                    }
                }(o, t)) return {
                nationalNumber: e
            }
        }
        return {
            nationalNumber: o,
            carrierCode: n
        }
    }

    function Hd(e, t, r, n) {
        if (!e) return {};
        var o;
        if ("+" !== e[0]) {
            var i = function(e, t, r, n) {
                if (t) {
                    var o = new gd(n);
                    o.selectNumberingPlan(t, r);
                    var i = new RegExp(o.IDDPrefix());
                    if (0 === e.search(i)) {
                        var d = (e = e.slice(e.match(i)[0].length)).match(Wd);
                        if (!(d && null != d[1] && d[1].length > 0 && "0" === d[1])) return e
                    }
                }
            }(e, t, r, n);
            if (!i || i === e) {
                if (t || r) {
                    var d = function(e, t, r, n) {
                            var o = t ? Ed(t, n) : r;
                            if (0 === e.indexOf(o)) {
                                (n = new gd(n)).selectNumberingPlan(t, r);
                                var i = e.slice(o.length),
                                    d = Gd(i, n).nationalNumber,
                                    a = Gd(e, n).nationalNumber;
                                if (!Ad(a, n.nationalNumberPattern()) && Ad(d, n.nationalNumberPattern()) || "TOO_LONG" === Id(a, n)) return {
                                    countryCallingCode: o,
                                    number: i
                                }
                            }
                            return {
                                number: e
                            }
                        }(e, t, r, n),
                        a = d.countryCallingCode,
                        s = d.number;
                    if (a) return {
                        countryCallingCodeSource: "FROM_NUMBER_WITHOUT_PLUS_SIGN",
                        countryCallingCode: a,
                        number: s
                    }
                }
                return {
                    number: e
                }
            }
            o = !0, e = "+" + i
        }
        if ("0" === e[1]) return {};
        n = new gd(n);
        for (var u = 2; u - 1 <= 3 && u <= e.length;) {
            var l = e.slice(1, u);
            if (n.hasCallingCode(l)) return n.selectNumberingPlan(l), {
                countryCallingCodeSource: o ? "FROM_NUMBER_WITH_IDD" : "FROM_NUMBER_WITH_PLUS_SIGN",
                countryCallingCode: l,
                number: e.slice(u)
            };
            u++
        }
        return {}
    }
    var Vd = /(\$\d)/;

    function qd(e, t, r) {
        var n = r.useInternationalFormat,
            o = r.withNationalPrefix;
        r.carrierCode, r.metadata;
        var i = e.replace(new RegExp(t.pattern()), n ? t.internationalFormat() : o && t.nationalPrefixFormattingRule() ? t.format().replace(Vd, t.nationalPrefixFormattingRule()) : t.format());
        return n ? function(e) {
            return e.replace(new RegExp("[".concat(zd, "]+"), "g"), " ").trim()
        }(i) : i
    }
    var Kd = /^[\d]+(?:[~\u2053\u223C\uFF5E][\d]+)?$/;
    var Zd = function(e) {
        return "([".concat(Ud, "]{1,").concat(e, "})")
    };

    function Jd(e) {
        var t = "[  \\t,]*",
            r = "[:\\.．]?[  \\t,-]*",
            n = "#?",
            o = "[  \\t]*";
        return ";ext=" + Zd("20") + "|" + (t + "(?:e?xt(?:ensi(?:ó?|ó))?n?|ｅ?ｘｔｎ?|доб|anexo)" + r + Zd("20") + n) + "|" + (t + "(?:[xｘ#＃~～]|int|ｉｎｔ)" + r + Zd("9") + n) + "|" + ("[- ]+" + Zd("6") + "#") + "|" + (o + "(?:,{2}|;)" + r + Zd("15") + n) + "|" + (o + "(?:,)+" + r + Zd("9") + n)
    }
    var Xd = "[" + Ud + "]{2}",
        Qd = "[+＋]{0,1}(?:[" + zd + "]*[" + Ud + "]){3,}[" + zd + Ud + "]*",
        ea = new RegExp("^[+＋]{0,1}(?:[" + zd + "]*[" + Ud + "]){1,2}$", "i"),
        ta = Qd + "(?:" + Jd() + ")?",
        ra = new RegExp("^" + Xd + "$|^" + ta + "$", "i");

    function na(e, t) {
        var r = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
        if (r) return (r = r.call(e)).next.bind(r);
        if (Array.isArray(e) || (r = function(e, t) {
                if (!e) return;
                if ("string" == typeof e) return oa(e, t);
                var r = Object.prototype.toString.call(e).slice(8, -1);
                "Object" === r && e.constructor && (r = e.constructor.name);
                if ("Map" === r || "Set" === r) return Array.from(e);
                if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return oa(e, t)
            }(e)) || t && e && "number" == typeof e.length) {
            r && (e = r);
            var n = 0;
            return function() {
                return n >= e.length ? {
                    done: !0
                } : {
                    done: !1,
                    value: e[n++]
                }
            }
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }

    function oa(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }

    function ia(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), r.push.apply(r, n)
        }
        return r
    }

    function da(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2 ? ia(Object(r), !0).forEach((function(t) {
                aa(e, t, r[t])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : ia(Object(r)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
            }))
        }
        return e
    }

    function aa(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }
    var sa = {
        formatExtension: function(e, t, r) {
            return "".concat(e).concat(r.ext()).concat(t)
        }
    };

    function ua(e, t, r, n) {
        if (r = r ? da(da({}, sa), r) : sa, n = new gd(n), e.country && "001" !== e.country) {
            if (!n.hasCountry(e.country)) throw new Error("Unknown country: ".concat(e.country));
            n.country(e.country)
        } else {
            if (!e.countryCallingCode) return e.phone || "";
            n.selectNumberingPlan(e.countryCallingCode)
        }
        var o, i = n.countryCallingCode(),
            d = r.v2 ? e.nationalNumber : e.phone;
        switch (t) {
            case "NATIONAL":
                return d ? ca(o = la(d, e.carrierCode, "NATIONAL", n, r), e.ext, n, r.formatExtension) : "";
            case "INTERNATIONAL":
                return d ? (o = la(d, null, "INTERNATIONAL", n, r), ca(o = "+".concat(i, " ").concat(o), e.ext, n, r.formatExtension)) : "+".concat(i);
            case "E.164":
                return "+".concat(i).concat(d);
            case "RFC3966":
                return function(e) {
                    var t = e.number,
                        r = e.ext;
                    if (!t) return "";
                    if ("+" !== t[0]) throw new Error('"formatRFC3966()" expects "number" to be in E.164 format.');
                    return "tel:".concat(t).concat(r ? ";ext=" + r : "")
                }({
                    number: "+".concat(i).concat(d),
                    ext: e.ext
                });
            case "IDD":
                if (!r.fromCountry) return;
                var a = function(e, t, r, n, o) {
                    var i = Ed(n, o.metadata);
                    if (i === r) {
                        var d = la(e, t, "NATIONAL", o);
                        return "1" === r ? r + " " + d : d
                    }
                    var a = function(e, t, r) {
                        var n = new gd(r);
                        return n.selectNumberingPlan(e, t), n.defaultIDDPrefix() ? n.defaultIDDPrefix() : Kd.test(n.IDDPrefix()) ? n.IDDPrefix() : void 0
                    }(n, void 0, o.metadata);
                    if (a) return "".concat(a, " ").concat(r, " ").concat(la(e, null, "INTERNATIONAL", o))
                }(d, e.carrierCode, i, r.fromCountry, n);
                return ca(a, e.ext, n, r.formatExtension);
            default:
                throw new Error('Unknown "format" argument passed to "formatNumber()": "'.concat(t, '"'))
        }
    }

    function la(e, t, r, n, o) {
        var i = function(e, t) {
            for (var r, n = na(e); !(r = n()).done;) {
                var o = r.value;
                if (o.leadingDigitsPatterns().length > 0) {
                    var i = o.leadingDigitsPatterns()[o.leadingDigitsPatterns().length - 1];
                    if (0 !== t.search(i)) continue
                }
                if (Ad(t, o.pattern())) return o
            }
        }(n.formats(), e);
        return i ? qd(e, i, {
            useInternationalFormat: "INTERNATIONAL" === r,
            withNationalPrefix: !i.nationalPrefixIsOptionalWhenFormattingInNationalFormat() || !o || !1 !== o.nationalPrefix,
            carrierCode: t,
            metadata: n
        }) : e
    }

    function ca(e, t, r, n) {
        return t ? n(e, t, r) : e
    }

    function fa(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), r.push.apply(r, n)
        }
        return r
    }

    function $a(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2 ? fa(Object(r), !0).forEach((function(t) {
                pa(e, t, r[t])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : fa(Object(r)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
            }))
        }
        return e
    }

    function pa(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }

    function ha(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
        }
    }
    var ma = function() {
            function e(t, r, n) {
                if (function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e), !t) throw new TypeError("First argument is required");
                if ("string" != typeof t) throw new TypeError("First argument must be a string");
                if ("string" == typeof t) {
                    if ("+" === t[0] && !r) throw new TypeError("`metadata` argument not passed");
                    if ($d(r) && $d(r.countries)) {
                        n = r;
                        var o = t;
                        if (!ya.test(o)) throw new Error('Invalid `number` argument passed: must consist of a "+" followed by digits');
                        var i = Hd(o, void 0, void 0, n);
                        if (t = i.countryCallingCode, !(r = i.number)) throw new Error("Invalid `number` argument passed: too short")
                    }
                }
                if (!r) throw new TypeError("`nationalNumber` argument is required");
                if ("string" != typeof r) throw new TypeError("`nationalNumber` argument must be a string");
                Od(n);
                var d = function(e, t) {
                        var r, n, o = new gd(t);
                        _a(e) ? (r = e, o.selectNumberingPlan(r), n = o.countryCallingCode()) : n = e;
                        return {
                            country: r,
                            countryCallingCode: n
                        }
                    }(t, n),
                    a = d.country,
                    s = d.countryCallingCode;
                this.country = a, this.countryCallingCode = s, this.nationalNumber = r, this.number = "+" + this.countryCallingCode + this.nationalNumber, this.getMetadata = function() {
                    return n
                }
            }
            var t, r, n;
            return t = e, (r = [{
                key: "setExt",
                value: function(e) {
                    this.ext = e
                }
            }, {
                key: "getPossibleCountries",
                value: function() {
                    return this.country ? [this.country] : Yd(this.countryCallingCode, this.nationalNumber, this.getMetadata())
                }
            }, {
                key: "isPossible",
                value: function() {
                    return function(e, t, r) {
                        if (void 0 === t && (t = {}), r = new gd(r), t.v2) {
                            if (!e.countryCallingCode) throw new Error("Invalid phone number object passed");
                            r.selectNumberingPlan(e.countryCallingCode)
                        } else {
                            if (!e.phone) return !1;
                            if (e.country) {
                                if (!r.hasCountry(e.country)) throw new Error("Unknown country: ".concat(e.country));
                                r.country(e.country)
                            } else {
                                if (!e.countryCallingCode) throw new Error("Invalid phone number object passed");
                                r.selectNumberingPlan(e.countryCallingCode)
                            }
                        }
                        if (r.possibleLengths()) return Td(e.phone || e.nationalNumber, r);
                        if (e.countryCallingCode && r.isNonGeographicCallingCode(e.countryCallingCode)) return !0;
                        throw new Error('Missing "possibleLengths" in metadata. Perhaps the metadata has been generated before v1.0.18.')
                    }(this, {
                        v2: !0
                    }, this.getMetadata())
                }
            }, {
                key: "isValid",
                value: function() {
                    return e = this, t = {
                        v2: !0
                    }, r = this.getMetadata(), t = t || {}, (r = new gd(r)).selectNumberingPlan(e.country, e.countryCallingCode), r.hasTypes() ? void 0 !== Fd(e, t, r.metadata) : Ad(t.v2 ? e.nationalNumber : e.phone, r.nationalNumberPattern());
                    var e, t, r
                }
            }, {
                key: "isNonGeographic",
                value: function() {
                    return new gd(this.getMetadata()).isNonGeographicCallingCode(this.countryCallingCode)
                }
            }, {
                key: "isEqual",
                value: function(e) {
                    return this.number === e.number && this.ext === e.ext
                }
            }, {
                key: "getType",
                value: function() {
                    return Fd(this, {
                        v2: !0
                    }, this.getMetadata())
                }
            }, {
                key: "format",
                value: function(e, t) {
                    return ua(this, e, t ? $a($a({}, t), {}, {
                        v2: !0
                    }) : {
                        v2: !0
                    }, this.getMetadata())
                }
            }, {
                key: "formatNational",
                value: function(e) {
                    return this.format("NATIONAL", e)
                }
            }, {
                key: "formatInternational",
                value: function(e) {
                    return this.format("INTERNATIONAL", e)
                }
            }, {
                key: "getURI",
                value: function(e) {
                    return this.format("RFC3966", e)
                }
            }]) && ha(t.prototype, r), n && ha(t, n), Object.defineProperty(t, "prototype", {
                writable: !1
            }), e
        }(),
        _a = function(e) {
            return /^[A-Z]{2}$/.test(e)
        };
    var ya = /^\+\d+$/;

    function va(e) {
        return (va = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function ga(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
        }
    }

    function ba(e) {
        var t = Pa();
        return function() {
            var r, n = xa(e);
            if (t) {
                var o = xa(this).constructor;
                r = Reflect.construct(n, arguments, o)
            } else r = n.apply(this, arguments);
            return function(e, t) {
                if (t && ("object" === va(t) || "function" == typeof t)) return t;
                if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
                return wa(e)
            }(this, r)
        }
    }

    function wa(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }

    function Ca(e) {
        var t = "function" == typeof Map ? new Map : void 0;
        return Ca = function(e) {
            if (null === e || (r = e, -1 === Function.toString.call(r).indexOf("[native code]"))) return e;
            var r;
            if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
            if (void 0 !== t) {
                if (t.has(e)) return t.get(e);
                t.set(e, n)
            }

            function n() {
                return Sa(e, arguments, xa(this).constructor)
            }
            return n.prototype = Object.create(e.prototype, {
                constructor: {
                    value: n,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), Oa(n, e)
        }, Ca(e)
    }

    function Sa(e, t, r) {
        return Sa = Pa() ? Reflect.construct : function(e, t, r) {
            var n = [null];
            n.push.apply(n, t);
            var o = new(Function.bind.apply(e, n));
            return r && Oa(o, r.prototype), o
        }, Sa.apply(null, arguments)
    }

    function Pa() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
        } catch (Ln) {
            return !1
        }
    }

    function Oa(e, t) {
        return (Oa = Object.setPrototypeOf || function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function xa(e) {
        return (xa = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    var Ea = function(e) {
            ! function(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && Oa(e, t)
            }(i, e);
            var t, r, n, o = ba(i);

            function i(e) {
                var t;
                return function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, i), t = o.call(this, e), Object.setPrototypeOf(wa(t), i.prototype), t.name = t.constructor.name, t
            }
            return t = i, r && ga(t.prototype, r), n && ga(t, n), Object.defineProperty(t, "prototype", {
                writable: !1
            }), t
        }(Ca(Error)),
        Ma = new RegExp("(?:" + Jd() + ")$", "i");
    var Da = {
        0: "0",
        1: "1",
        2: "2",
        3: "3",
        4: "4",
        5: "5",
        6: "6",
        7: "7",
        8: "8",
        9: "9",
        "０": "0",
        "１": "1",
        "２": "2",
        "３": "3",
        "４": "4",
        "５": "5",
        "６": "6",
        "７": "7",
        "８": "8",
        "９": "9",
        "٠": "0",
        "١": "1",
        "٢": "2",
        "٣": "3",
        "٤": "4",
        "٥": "5",
        "٦": "6",
        "٧": "7",
        "٨": "8",
        "٩": "9",
        "۰": "0",
        "۱": "1",
        "۲": "2",
        "۳": "3",
        "۴": "4",
        "۵": "5",
        "۶": "6",
        "۷": "7",
        "۸": "8",
        "۹": "9"
    };

    function Na(e, t) {
        var r = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
        if (r) return (r = r.call(e)).next.bind(r);
        if (Array.isArray(e) || (r = function(e, t) {
                if (!e) return;
                if ("string" == typeof e) return Ia(e, t);
                var r = Object.prototype.toString.call(e).slice(8, -1);
                "Object" === r && e.constructor && (r = e.constructor.name);
                if ("Map" === r || "Set" === r) return Array.from(e);
                if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ia(e, t)
            }(e)) || t && e && "number" == typeof e.length) {
            r && (e = r);
            var n = 0;
            return function() {
                return n >= e.length ? {
                    done: !0
                } : {
                    done: !1,
                    value: e[n++]
                }
            }
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }

    function Ia(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }

    function ka(e) {
        for (var t, r = "", n = Na(e.split("")); !(t = n()).done;) {
            r += Ta(t.value, r) || ""
        }
        return r
    }

    function Ta(e, t, r) {
        return "+" === e ? t ? void("function" == typeof r && r("end")) : "+" : function(e) {
            return Da[e]
        }(e)
    }

    function Aa(e, t) {
        var r = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
        if (r) return (r = r.call(e)).next.bind(r);
        if (Array.isArray(e) || (r = function(e, t) {
                if (!e) return;
                if ("string" == typeof e) return ja(e, t);
                var r = Object.prototype.toString.call(e).slice(8, -1);
                "Object" === r && e.constructor && (r = e.constructor.name);
                if ("Map" === r || "Set" === r) return Array.from(e);
                if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return ja(e, t)
            }(e)) || t && e && "number" == typeof e.length) {
            r && (e = r);
            var n = 0;
            return function() {
                return n >= e.length ? {
                    done: !0
                } : {
                    done: !1,
                    value: e[n++]
                }
            }
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }

    function ja(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }

    function Ra(e, t) {
        var r = t.nationalNumber,
            n = t.defaultCountry,
            o = t.metadata;
        var i = o.getCountryCodesForCallingCode(e);
        if (i) return 1 === i.length ? i[0] : function(e, t) {
            var r = t.countries;
            t.defaultCountry;
            var n = t.metadata;
            n = new gd(n);
            for (var o, i = Aa(r); !(o = i()).done;) {
                var d = o.value;
                if (n.country(d), n.leadingDigits()) {
                    if (e && 0 === e.search(n.leadingDigits())) return d
                } else if (Fd({
                        phone: e,
                        country: d
                    }, void 0, n.metadata)) return d
            }
        }(r, {
            countries: i,
            defaultCountry: n,
            metadata: o.metadata
        })
    }
    var La = "([" + Ud + "]|[\\-\\.\\(\\)]?)",
        Fa = new RegExp("^\\+" + La + "*[" + Ud + "]" + La + "*$", "g"),
        Ba = new RegExp("^(" + ("[" + Ud + "]+((\\-)*[" + Ud + "])*") + "\\.)*" + ("[a-zA-Z]+((\\-)*[" + Ud + "])*") + "\\.?$", "g"),
        Ya = "tel:",
        Ua = ";phone-context=";

    function za(e, t) {
        var r, n = t.extractFormattedPhoneNumber,
            o = function(e) {
                var t = e.indexOf(Ua);
                if (t < 0) return null;
                var r = t + 15;
                if (r >= e.length) return "";
                var n = e.indexOf(";", r);
                return n >= 0 ? e.substring(r, n) : e.substring(r)
            }(e);
        if (! function(e) {
                return null === e || 0 !== e.length && (Fa.test(e) || Ba.test(e))
            }(o)) throw new Ea("NOT_A_NUMBER");
        if (null === o) r = n(e) || "";
        else {
            r = "", "+" === o.charAt(0) && (r += o);
            var i, d = e.indexOf(Ya);
            i = d >= 0 ? d + 4 : 0;
            var a = e.indexOf(Ua);
            r += e.substring(i, a)
        }
        var s = r.indexOf(";isub=");
        if (s > 0 && (r = r.substring(0, s)), "" !== r) return r
    }
    var Wa = new RegExp("[+＋" + Ud + "]"),
        Ga = new RegExp("[^" + Ud + "#]+$");

    function Ha(e, t, r) {
        if (t = t || {}, r = new gd(r), t.defaultCountry && !r.hasCountry(t.defaultCountry)) {
            if (t.v2) throw new Ea("INVALID_COUNTRY");
            throw new Error("Unknown country: ".concat(t.defaultCountry))
        }
        var n = function(e, t, r) {
                var n = za(e, {
                    extractFormattedPhoneNumber: function(e) {
                        return function(e, t, r) {
                            if (!e) return;
                            if (e.length > 250) {
                                if (r) throw new Ea("TOO_LONG");
                                return
                            }
                            if (!1 === t) return e;
                            var n = e.search(Wa);
                            if (n < 0) return;
                            return e.slice(n).replace(Ga, "")
                        }(e, r, t)
                    }
                });
                if (!n) return {};
                if (! function(e) {
                        return e.length >= 2 && ra.test(e)
                    }(n)) return function(e) {
                    return ea.test(e)
                }(n) ? {
                    error: "TOO_SHORT"
                } : {};
                var o = function(e) {
                    var t = e.search(Ma);
                    if (t < 0) return {};
                    for (var r = e.slice(0, t), n = e.match(Ma), o = 1; o < n.length;) {
                        if (n[o]) return {
                            number: r,
                            ext: n[o]
                        };
                        o++
                    }
                }(n);
                if (o.ext) return o;
                return {
                    number: n
                }
            }(e, t.v2, t.extract),
            o = n.number,
            i = n.ext,
            d = n.error;
        if (!o) {
            if (t.v2) {
                if ("TOO_SHORT" === d) throw new Ea("TOO_SHORT");
                throw new Ea("NOT_A_NUMBER")
            }
            return {}
        }
        var a = function(e, t, r, n) {
                var o, i = Hd(ka(e), t, r, n.metadata),
                    d = i.countryCallingCodeSource,
                    a = i.countryCallingCode,
                    s = i.number;
                if (a) n.selectNumberingPlan(a);
                else {
                    if (!s || !t && !r) return {};
                    n.selectNumberingPlan(t, r), t && (o = t), a = r || Ed(t, n.metadata)
                }
                if (!s) return {
                    countryCallingCodeSource: d,
                    countryCallingCode: a
                };
                var u = Gd(ka(s), n),
                    l = u.nationalNumber,
                    c = u.carrierCode,
                    f = Ra(a, {
                        nationalNumber: l,
                        defaultCountry: t,
                        metadata: n
                    });
                f && (o = f, "001" === f || n.country(o));
                return {
                    country: o,
                    countryCallingCode: a,
                    countryCallingCodeSource: d,
                    nationalNumber: l,
                    carrierCode: c
                }
            }(o, t.defaultCountry, t.defaultCallingCode, r),
            s = a.country,
            u = a.nationalNumber,
            l = a.countryCallingCode,
            c = a.countryCallingCodeSource,
            f = a.carrierCode;
        if (!r.hasSelectedNumberingPlan()) {
            if (t.v2) throw new Ea("INVALID_COUNTRY");
            return {}
        }
        if (!u || u.length < 2) {
            if (t.v2) throw new Ea("TOO_SHORT");
            return {}
        }
        if (u.length > 17) {
            if (t.v2) throw new Ea("TOO_LONG");
            return {}
        }
        if (t.v2) {
            var $ = new ma(l, u, r.metadata);
            return s && ($.country = s), f && ($.carrierCode = f), i && ($.ext = i), $.__countryCallingCodeSource = c, $
        }
        var p = !!(t.extended ? r.hasSelectedNumberingPlan() : s) && Ad(u, r.nationalNumberPattern());
        return t.extended ? {
            country: s,
            countryCallingCode: l,
            carrierCode: f,
            valid: p,
            possible: !!p || !(!0 !== t.extended || !r.possibleLengths() || !Td(u, r)),
            phone: u,
            ext: i
        } : p ? function(e, t, r) {
            var n = {
                country: e,
                phone: t
            };
            r && (n.ext = r);
            return n
        }(s, u, i) : {}
    }

    function Va(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), r.push.apply(r, n)
        }
        return r
    }

    function qa(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2 ? Va(Object(r), !0).forEach((function(t) {
                Ka(e, t, r[t])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Va(Object(r)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
            }))
        }
        return e
    }

    function Ka(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }

    function Za(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), r.push.apply(r, n)
        }
        return r
    }

    function Ja(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }

    function Xa(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            var r = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null == r) return;
            var n, o, i = [],
                d = !0,
                a = !1;
            try {
                for (r = r.call(e); !(d = (n = r.next()).done) && (i.push(n.value), !t || i.length !== t); d = !0);
            } catch (s) {
                a = !0, o = s
            } finally {
                try {
                    d || null == r.return || r.return()
                } finally {
                    if (a) throw o
                }
            }
            return i
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return Qa(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Qa(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Qa(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }

    function es(e) {
        var t, r, n, o = Xa(Array.prototype.slice.call(e), 4),
            i = o[0],
            d = o[1],
            a = o[2],
            s = o[3];
        if ("string" != typeof i) throw new TypeError("A text for parsing must be a string.");
        if (t = i, d && "string" != typeof d) {
            if (!$d(d)) throw new Error("Invalid second argument: ".concat(d));
            a ? (r = d, n = a) : n = d
        } else s ? (r = a, n = s) : (r = void 0, n = a), d && (r = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r = null != arguments[t] ? arguments[t] : {};
                t % 2 ? Za(Object(r), !0).forEach((function(t) {
                    Ja(e, t, r[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Za(Object(r)).forEach((function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                }))
            }
            return e
        }({
            defaultCountry: d
        }, r));
        return {
            text: t,
            options: r,
            metadata: n
        }
    }

    function ts(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), r.push.apply(r, n)
        }
        return r
    }

    function rs(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2 ? ts(Object(r), !0).forEach((function(t) {
                ns(e, t, r[t])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : ts(Object(r)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
            }))
        }
        return e
    }

    function ns(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }

    function os(e, t, r) {
        t && t.defaultCountry && ! function(e, t) {
            return t.countries.hasOwnProperty(e)
        }(t.defaultCountry, r) && (t = rs(rs({}, t), {}, {
            defaultCountry: void 0
        }));
        try {
            return function(e, t, r) {
                return Ha(e, qa(qa({}, t), {}, {
                    v2: !0
                }), r)
            }(e, t, r)
        } catch (n) {
            if (!(n instanceof Ea)) throw n
        }
    }

    function is() {
        var e = es(arguments);
        return os(e.text, e.options, e.metadata)
    }

    function ds() {
        return function(e, t) {
            var r = Array.prototype.slice.call(t);
            return r.push(ld), e.apply(this, r)
        }(is, arguments)
    }

    function as(e) {
        const t = e.startsWith("+86");
        if (t) return function(e) {
            return /^1[3-9]\d{9}$/.test(e.replaceAll(" ", "").replaceAll("+86", ""))
        }(e);
        const r = t ? ds(e, "CN") : ds(e);
        return !!r && r.isValid()
    }
    var ss = (e => (e.EmailError = "email", e.FirstNameError = "first_name", e.LastNameError = "last_name", e.PhoneError = "phone", e.GdprError = "gdpr", e.TcpaError = "tcpa", e.BirthdayError = "birthday", e))(ss || {});
    const us = e => {
            if (Hn(e).isValid() && Hn(e).isBefore(Hn()) && /^\d{4}-\d{2}-\d{2}$/.test(e)) {
                const [t, r, n] = e.split("-").map(Number);
                return !(t <= 999 || r < 1 || r > 12 || n < 1 || n > 31)
            }
            return !1
        },
        ls = {
            labelWrapper: "_labelWrapper_rn85h_2",
            small: "_small_rn85h_9",
            standard: "_standard_rn85h_12",
            large: "_large_rn85h_15",
            mobile: "_mobile_rn85h_18",
            inputWrapper: "_inputWrapper_rn85h_30",
            yearWrapper: "_yearWrapper_rn85h_35",
            monthWrapper: "_monthWrapper_rn85h_39",
            dayWrapper: "_dayWrapper_rn85h_43"
        },
        cs = ["04", "06", "09", "11", "4", "6", "9"],
        fs = (e, t, r) => {
            const n = Number(e);
            return t ? cs.includes(t) ? Math.min(n, 30) : "02" === t && 4 === (null == r ? void 0 : r.length) ? Math.min(n, Number(r) % 4 == 0 ? 29 : 28) : n : n
        },
        $s = e => /^\d+$/.test(e),
        ps = e => {
            const {
                label: r,
                year: n,
                month: o,
                day: i,
                cornerRadius: d,
                colors: a,
                error: s,
                yearValue: u,
                monthValue: l,
                dayValue: c,
                format: f,
                onChange: $,
                showErrorText: p,
                size: h,
                isMobile: m
            } = e, _ = e => {
                setTimeout((() => {
                    var t, r;
                    return null == (r = null == (t = null == document ? void 0 : document.getElementById) ? void 0 : t.call(document, e)) ? void 0 : r.focus()
                }), 0)
            };
            t.useEffect((() => {
                if (!c) return;
                const e = fs(c, l, u);
                $(e < 10 && e > 0 ? `0${e}` : String(e), "day")
            }), [u, l, fs]);
            const y = Ao(Bi, {
                    className: ls.yearWrapper,
                    shape: d,
                    size: h,
                    color: a.primary_button_background_color,
                    style: {
                        color: a.input
                    },
                    value: u,
                    id: "year_input",
                    placeholder: n.placeholder,
                    onChange: e => {
                        const {
                            value: t
                        } = e.target;
                        !$s(t) && "" !== t || t.length > 4 || ($(t, "year"), t.length >= 4 && f === Dn.YYYYMMDD && _("month_input"))
                    },
                    type: "text"
                }),
                v = Ao(Bi, {
                    className: ls.monthWrapper,
                    shape: d,
                    size: h,
                    color: a.primary_button_background_color,
                    style: {
                        color: a.input
                    },
                    value: l,
                    id: "month_input",
                    placeholder: o.placeholder,
                    onChange: e => {
                        const {
                            value: t
                        } = e.target;
                        ($s(t) || "" === t) && ($(t.slice(0, 2), "month"), 2 === Number(t) && Number(c) > 29 && $("29", "day"), t.length >= 2 && (f === Dn.YYYYMMDD || f === Dn.MMDDYYYY ? _("day_input") : f === Dn.DDMMYYYY && _("year_input")))
                    },
                    onBlur: () => {
                        Number(l) >= 1 && 1 === l.length && $(`0${l}`, "month"), Number(l) > 12 && setTimeout((() => $("12", "month")), 0)
                    },
                    type: "text"
                }),
                g = Ao(Bi, {
                    className: ls.dayWrapper,
                    shape: d,
                    size: h,
                    color: a.primary_button_background_color,
                    style: {
                        color: a.input
                    },
                    value: c,
                    id: "day_input",
                    placeholder: i.placeholder,
                    onChange: e => {
                        const {
                            value: t
                        } = e.target;
                        if (!$s(t) && "" !== t) return;
                        let r = t.slice(0, 2);
                        u && Number(u) % 4 != 0 ? 2 === Number(l) && Number(t) > 28 && (r = "28") : 2 === Number(l) && Number(t) > 29 && (r = "29"), $(r, "day"), t.length >= 2 && (f === Dn.DDMMYYYY && _("month_input"), f === Dn.MMDDYYYY && _("year_input"))
                    },
                    onBlur: () => {
                        if (!c || 0 === Number(c)) return;
                        let e = Math.max(Number(c), 0);
                        e = Math.min(e, 31), cs.includes(l) && (e = Math.min(e, 30)), 2 === Number(l) && (e > 29 ? e = 29 : 4 === u.length && Number(u) % 4 != 0 && e > 28 && (e = 28)), setTimeout((() => {
                            const t = e < 10 ? `0${e}` : String(e);
                            $(t, "day")
                        }), 0)
                    },
                    type: "text"
                }),
                b = p && (e.required || u || l || c) && !us(`${u}-${l}-${c}`);
            return jo("div", {
                className: Go(gi("Input__BirthdayWrapper")),
                children: [Ao("div", {
                    className: Go(gi("Input__Label"), ls.labelWrapper, ls[h], m && ls.mobile),
                    style: {
                        color: a.label_text_color
                    },
                    children: r
                }), jo("div", {
                    className: Go(gi("Input__Wrapper"), ls.inputWrapper),
                    children: [f === Dn.YYYYMMDD && jo(Ro, {
                        children: [y, v, g]
                    }), f === Dn.MMDDYYYY && jo(Ro, {
                        children: [v, g, y]
                    }), f === Dn.DDMMYYYY && jo(Ro, {
                        children: [g, v, y]
                    })]
                }), b && Ao(Vi, {
                    embed: !0,
                    errText: s,
                    colors: a
                })]
            })
        };
    var hs = (e => (e[e.EmailInvalid = 1001] = "EmailInvalid", e[e.AlreadySubscribe = 1002] = "AlreadySubscribe", e[e.SubmitFail = 1003] = "SubmitFail", e[e.FirstNameInvalid = 1004] = "FirstNameInvalid", e[e.LastNameInvalid = 1005] = "LastNameInvalid", e[e.PhoneInvalid = 1030] = "PhoneInvalid", e[e.PhoneAlreadySubscribe = 1031] = "PhoneAlreadySubscribe", e[e.GDPRInvalid = 1040] = "GDPRInvalid", e[e.TCPAInvalid = 1050] = "TCPAInvalid", e))(hs || {});
    const ms = e => {
            const {
                required: t,
                cornerRadius: r,
                placeholder: n,
                colors: o,
                error: i,
                alreadyError: d,
                size: a,
                value: s,
                onChange: u,
                showErrorText: l,
                errorCodeList: c
            } = e, f = t && l && !ud(s) || l && !t && "" !== s && !ud(s), $ = c.includes(hs.AlreadySubscribe);
            return jo("div", {
                children: [Ao(Bi, {
                    id: "email",
                    size: a,
                    shape: r,
                    value: s,
                    color: o.primary_button_background_color,
                    style: {
                        color: o.input
                    },
                    placeholder: n,
                    autoComplete: "email",
                    onChange: e => "function" == typeof u && u(e.target.value)
                }), (f || c.includes(hs.EmailInvalid)) && !$ && Ao(Vi, {
                    embed: !0,
                    errText: i,
                    colors: o
                }), $ && Ao(Vi, {
                    embed: !0,
                    errText: d,
                    colors: o
                })]
            })
        },
        _s = {
            inputWrapper: "_inputWrapper_1k4f0_2",
            horizontal: "_horizontal_1k4f0_2",
            small: "_small_1k4f0_7",
            first: "_first_1k4f0_10",
            last: "_last_1k4f0_13"
        },
        ys = e => {
            let {
                layout: t,
                field_type: r,
                first_name: n,
                last_name: o,
                cornerRadius: i,
                colors: d,
                error: a,
                firstValue: s,
                lastValue: u,
                onChange: l,
                showErrorText: c,
                size: f
            } = e, $ = r !== En.LAST, p = r !== En.FIRST;
            return r !== En.LAST && r !== En.FIRST || (t = "vertical"), jo("div", {
                style: {
                    marginBottom: "small" === f ? 16 : 20,
                    display: "horizontal" === t ? "flex" : ""
                },
                children: [$ && jo("div", {
                    className: Go(_s.inputWrapper, _s[t], _s[f], _s.first),
                    children: [Ao(Bi, {
                        shape: i,
                        size: f,
                        color: d.primary_button_background_color,
                        style: {
                            color: d.input
                        },
                        value: s,
                        id: "first_name",
                        placeholder: n.placeholder,
                        onChange: e => "function" == typeof l && l(e.target.value, "first"),
                        type: "text"
                    }), n.required && c && "" == s && Ao(Vi, {
                        embed: !0,
                        errText: a.first_name,
                        colors: d
                    })]
                }), p && jo("div", {
                    className: Go(_s.inputWrapper, _s[t], _s[f], _s.last),
                    children: [Ao(Bi, {
                        size: f,
                        shape: i,
                        color: d.primary_button_background_color,
                        style: {
                            color: d.input
                        },
                        value: u,
                        id: "last_name",
                        placeholder: o.placeholder,
                        onChange: e => "function" == typeof l && l(e.target.value, "last"),
                        type: "text"
                    }), o.required && c && "" == u && Ao(Vi, {
                        embed: !0,
                        errText: a.last_name,
                        colors: d
                    })]
                })]
            })
        },
        vs = {
            inputWrapper: "_inputWrapper_qsuuw_2",
            "size-small": "_size-small_qsuuw_11",
            "radius-standard": "_radius-standard_qsuuw_20",
            "radius-none": "_radius-none_qsuuw_23",
            "radius-large": "_radius-large_qsuuw_26"
        };
    var gs = {
        exports: {}
    };
    ! function(e) {
        var r;
        r = e => (() => {
            var t = {
                    386: (e, t, r) => {
                        r.r(t)
                    },
                    652: (e, t, r) => {
                        r.r(t)
                    },
                    249: (e, t, r) => {
                        r.r(t)
                    },
                    782: (e, t, r) => {
                        r.r(t)
                    },
                    425: (e, t, r) => {
                        r.r(t)
                    },
                    110: function(e, t, r) {
                        var n = this && this.__assign || function() {
                                return n = Object.assign || function(e) {
                                    for (var t, r = 1, n = arguments.length; r < n; r++)
                                        for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                                    return e
                                }, n.apply(this, arguments)
                            },
                            o = this && this.__createBinding || (Object.create ? function(e, t, r, n) {
                                void 0 === n && (n = r);
                                var o = Object.getOwnPropertyDescriptor(t, r);
                                o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                                    enumerable: !0,
                                    get: function() {
                                        return t[r]
                                    }
                                }), Object.defineProperty(e, n, o)
                            } : function(e, t, r, n) {
                                void 0 === n && (n = r), e[n] = t[r]
                            }),
                            i = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                                Object.defineProperty(e, "default", {
                                    enumerable: !0,
                                    value: t
                                })
                            } : function(e, t) {
                                e.default = t
                            }),
                            d = this && this.__importStar || function(e) {
                                if (e && e.__esModule) return e;
                                var t = {};
                                if (null != e)
                                    for (var r in e) "default" !== r && Object.prototype.hasOwnProperty.call(e, r) && o(t, e, r);
                                return i(t, e), t
                            },
                            a = this && this.__rest || function(e, t) {
                                var r = {};
                                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                                if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                                    var o = 0;
                                    for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]])
                                }
                                return r
                            };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.CountrySelector = void 0, r(386);
                        var s = d(r(156)),
                            u = r(445),
                            l = r(379),
                            c = r(197),
                            f = r(289),
                            $ = r(946);
                        t.CountrySelector = function(e) {
                            var t, r, o = e.selectedCountry,
                                i = e.onSelect,
                                d = e.disabled,
                                p = e.hideDropdown,
                                h = e.countries,
                                m = void 0 === h ? u.defaultCountries : h,
                                _ = e.renderButtonWrapper,
                                y = a(e, ["selectedCountry", "onSelect", "disabled", "hideDropdown", "countries", "renderButtonWrapper"]),
                                v = (0, s.useState)(!1),
                                g = v[0],
                                b = v[1],
                                w = (0, s.useMemo)((function() {
                                    if (o) return (0, c.getCountry)({
                                        value: o,
                                        field: "iso2",
                                        countries: m
                                    })
                                }), [m, o]),
                                C = (0, s.useRef)(null);
                            return s.default.createElement("div", {
                                className: (0, l.buildClassNames)({
                                    addPrefix: ["country-selector"],
                                    rawClassNames: [y.className]
                                }),
                                style: y.style,
                                ref: C
                            }, (t = {
                                title: null == w ? void 0 : w.name,
                                onClick: function() {
                                    return b((function(e) {
                                        return !e
                                    }))
                                },
                                onMouseDown: function(e) {
                                    return e.preventDefault()
                                },
                                onKeyDown: function(e) {
                                    e.key && ["ArrowUp", "ArrowDown"].includes(e.key) && (e.preventDefault(), b(!0))
                                },
                                disabled: p || d,
                                role: "combobox",
                                "aria-label": "Country selector",
                                "aria-haspopup": "listbox",
                                "aria-expanded": g
                            }, r = s.default.createElement("div", {
                                className: (0, l.buildClassNames)({
                                    addPrefix: ["country-selector-button__button-content"],
                                    rawClassNames: [y.buttonContentWrapperClassName]
                                }),
                                style: y.buttonContentWrapperStyle
                            }, s.default.createElement(f.FlagEmoji, {
                                iso2: o,
                                className: (0, l.buildClassNames)({
                                    addPrefix: ["country-selector-button__flag-emoji", d && "country-selector-button__flag-emoji--disabled"],
                                    rawClassNames: [y.flagClassName]
                                }),
                                style: n({
                                    visibility: o ? "visible" : "hidden"
                                }, y.flagStyle)
                            }), !p && s.default.createElement("div", {
                                className: (0, l.buildClassNames)({
                                    addPrefix: ["country-selector-button__dropdown-arrow", d && "country-selector-button__dropdown-arrow--disabled", g && "country-selector-button__dropdown-arrow--active"],
                                    rawClassNames: [y.dropdownArrowClassName]
                                }),
                                style: y.dropdownArrowStyle
                            })), _ ? _({
                                children: r,
                                rootProps: t
                            }) : s.default.createElement("button", n({}, t, {
                                type: "button",
                                className: (0, l.buildClassNames)({
                                    addPrefix: ["country-selector-button", g && "country-selector-button--active", d && "country-selector-button--disabled", p && "country-selector-button--hide-dropdown"],
                                    rawClassNames: [y.buttonClassName]
                                }),
                                "data-country": o,
                                style: y.buttonStyle
                            }), r)), s.default.createElement($.CountrySelectorDropdown, n({
                                show: g,
                                countries: m,
                                onSelect: function(e) {
                                    b(!1), null == i || i(e)
                                },
                                selectedCountry: o,
                                onClose: function() {
                                    b(!1)
                                }
                            }, y.dropdownStyleProps)))
                        }
                    },
                    946: function(e, t, r) {
                        var n = this && this.__assign || function() {
                                return n = Object.assign || function(e) {
                                    for (var t, r = 1, n = arguments.length; r < n; r++)
                                        for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                                    return e
                                }, n.apply(this, arguments)
                            },
                            o = this && this.__createBinding || (Object.create ? function(e, t, r, n) {
                                void 0 === n && (n = r);
                                var o = Object.getOwnPropertyDescriptor(t, r);
                                o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                                    enumerable: !0,
                                    get: function() {
                                        return t[r]
                                    }
                                }), Object.defineProperty(e, n, o)
                            } : function(e, t, r, n) {
                                void 0 === n && (n = r), e[n] = t[r]
                            }),
                            i = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                                Object.defineProperty(e, "default", {
                                    enumerable: !0,
                                    value: t
                                })
                            } : function(e, t) {
                                e.default = t
                            }),
                            d = this && this.__importStar || function(e) {
                                if (e && e.__esModule) return e;
                                var t = {};
                                if (null != e)
                                    for (var r in e) "default" !== r && Object.prototype.hasOwnProperty.call(e, r) && o(t, e, r);
                                return i(t, e), t
                            },
                            a = this && this.__rest || function(e, t) {
                                var r = {};
                                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                                if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                                    var o = 0;
                                    for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]])
                                }
                                return r
                            };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.CountrySelectorDropdown = void 0, r(652);
                        var s = d(r(156)),
                            u = r(445),
                            l = r(379),
                            c = r(197),
                            f = r(289);
                        t.CountrySelectorDropdown = function(e) {
                            var t = e.show,
                                r = e.dialCodePrefix,
                                o = void 0 === r ? "+" : r,
                                i = e.selectedCountry,
                                d = e.countries,
                                $ = void 0 === d ? u.defaultCountries : d,
                                p = e.onSelect,
                                h = e.onClose,
                                m = a(e, ["show", "dialCodePrefix", "selectedCountry", "countries", "onSelect", "onClose"]),
                                _ = (0, s.useRef)(null),
                                y = (0, s.useRef)(),
                                v = (0, s.useRef)({
                                    updatedAt: void 0,
                                    value: ""
                                }),
                                g = (0, s.useCallback)((function(e) {
                                    return $.findIndex((function(t) {
                                        return (0, c.parseCountry)(t).iso2 === e
                                    }))
                                }), [$]),
                                b = (0, s.useState)(g(i)),
                                w = b[0],
                                C = b[1],
                                S = function() {
                                    y.current !== i && C(g(i))
                                },
                                P = (0, s.useCallback)((function(e) {
                                    C(g(e.iso2)), null == p || p(e)
                                }), [p, g]),
                                O = function(e) {
                                    var t = $.length - 1;
                                    C((function(r) {
                                        var n, o = (n = r, "prev" === e ? n - 1 : "next" === e ? n + 1 : "last" === e ? t : 0);
                                        return o < 0 ? 0 : o > t ? t : o
                                    }))
                                },
                                x = (0, s.useCallback)((function() {
                                    if (_.current && void 0 !== w) {
                                        var e = (0, c.parseCountry)($[w]).iso2;
                                        if (e !== y.current) {
                                            var t = _.current.querySelector('[data-country="'.concat(e, '"]'));
                                            t && ((0, c.scrollToChild)(_.current, t), y.current = e)
                                        }
                                    }
                                }), [w, $]);
                            return (0, s.useEffect)((function() {
                                x()
                            }), [w, x]), (0, s.useEffect)((function() {
                                _.current && (t ? _.current.focus() : S())
                            }), [t]), (0, s.useEffect)((function() {
                                S()
                            }), [i]), s.default.createElement("ul", {
                                ref: _,
                                role: "listbox",
                                className: (0, l.buildClassNames)({
                                    addPrefix: ["country-selector-dropdown"],
                                    rawClassNames: [m.className]
                                }),
                                style: n({
                                    display: t ? "block" : "none"
                                }, m.style),
                                onKeyDown: function(e) {
                                    if (e.stopPropagation(), "Enter" !== e.key)
                                        if ("Escape" !== e.key) {
                                            if ("ArrowUp" === e.key) return e.preventDefault(), void O("prev");
                                            if ("ArrowDown" === e.key) return e.preventDefault(), void O("next");
                                            if ("PageUp" === e.key) return e.preventDefault(), void O("first");
                                            if ("PageDown" === e.key) return e.preventDefault(), void O("last");
                                            " " === e.key && e.preventDefault(), 1 !== e.key.length || e.altKey || e.ctrlKey || e.metaKey || function(e) {
                                                var t = v.current.updatedAt && (new Date).getTime() - v.current.updatedAt.getTime() > 1e3;
                                                v.current = {
                                                    value: t ? e : "".concat(v.current.value).concat(e),
                                                    updatedAt: new Date
                                                };
                                                var r = $.findIndex((function(e) {
                                                    return (0, c.parseCountry)(e).name.toLowerCase().startsWith(v.current.value)
                                                })); - 1 !== r && C(r)
                                            }(e.key.toLocaleLowerCase())
                                        } else null == h || h();
                                    else {
                                        var t = (0, c.parseCountry)($[w]);
                                        P(t)
                                    }
                                },
                                onBlur: h,
                                tabIndex: -1,
                                "aria-activedescendant": "".concat((0, c.parseCountry)($[w]).iso2, "-option")
                            }, $.map((function(e, t) {
                                var r = (0, c.parseCountry)(e),
                                    n = r.iso2 === i,
                                    d = t === w;
                                return s.default.createElement("li", {
                                    key: r.iso2,
                                    "data-country": r.iso2,
                                    role: "option",
                                    "aria-selected": n,
                                    "aria-label": "".concat(r.name, " ").concat(o).concat(r.dialCode),
                                    id: "".concat(r.iso2, "-option"),
                                    className: (0, l.buildClassNames)({
                                        addPrefix: ["country-selector-dropdown__list-item", n && "country-selector-dropdown__list-item--selected", d && "country-selector-dropdown__list-item--focused"],
                                        rawClassNames: [m.listItemClassName]
                                    }),
                                    onClick: function() {
                                        return P(r)
                                    },
                                    style: m.listItemStyle
                                }, s.default.createElement(f.FlagEmoji, {
                                    iso2: r.iso2,
                                    className: (0, l.buildClassNames)({
                                        addPrefix: ["country-selector-dropdown__list-item-flag-emoji"],
                                        rawClassNames: [m.listItemFlagClassName]
                                    }),
                                    style: m.listItemFlagStyle
                                }), s.default.createElement("span", {
                                    className: (0, l.buildClassNames)({
                                        addPrefix: ["country-selector-dropdown__list-item-country-name"],
                                        rawClassNames: [m.listItemCountryNameClassName]
                                    }),
                                    style: m.listItemCountryNameStyle
                                }, r.name), s.default.createElement("span", {
                                    className: (0, l.buildClassNames)({
                                        addPrefix: ["country-selector-dropdown__list-item-dial-code"],
                                        rawClassNames: [m.listItemDialCodeClassName]
                                    }),
                                    style: m.listItemDialCodeStyle
                                }, o, r.dialCode))
                            })))
                        }
                    },
                    805: function(e, t, r) {
                        var n = this && this.__importDefault || function(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            }
                        };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.DialCodePreview = void 0, r(249);
                        var o = n(r(156)),
                            i = r(379);
                        t.DialCodePreview = function(e) {
                            var t = e.dialCode,
                                r = e.prefix,
                                n = e.disabled,
                                d = e.style,
                                a = e.className;
                            return o.default.createElement("div", {
                                className: (0, i.buildClassNames)({
                                    addPrefix: ["dial-code-preview", n && "dial-code-preview--disabled"],
                                    rawClassNames: [a]
                                }),
                                style: d
                            }, "".concat(r).concat(t))
                        }
                    },
                    289: function(e, t, r) {
                        var n = this && this.__assign || function() {
                                return n = Object.assign || function(e) {
                                    for (var t, r = 1, n = arguments.length; r < n; r++)
                                        for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                                    return e
                                }, n.apply(this, arguments)
                            },
                            o = this && this.__rest || function(e, t) {
                                var r = {};
                                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                                if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                                    var o = 0;
                                    for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]])
                                }
                                return r
                            },
                            i = this && this.__importDefault || function(e) {
                                return e && e.__esModule ? e : {
                                    default: e
                                }
                            };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.FlagEmoji = void 0, r(782);
                        var d = i(r(156)),
                            a = r(379),
                            s = "abcdefghijklmnopqrstuvwxyz".split("").reduce((function(e, t, r) {
                                var o, i, d;
                                return n(n({}, e), ((o = {})[t] = (i = r, d = parseInt("1f1e6", 16), Number(d + i).toString(16)), o))
                            }), {});
                        t.FlagEmoji = function(e) {
                            var t = e.iso2,
                                r = e.size,
                                i = void 0 === r ? "24px" : r,
                                u = e.protocol,
                                l = void 0 === u ? "https" : u,
                                c = e.disableLazyLoading,
                                f = e.className,
                                $ = o(e, ["iso2", "size", "protocol", "disableLazyLoading", "className"]);
                            if (!t) return d.default.createElement("img", n({
                                width: i,
                                height: i
                            }, $));
                            var p, h = [s[(p = t)[0]], s[p[1]]].join("-"),
                                m = "".concat(l, "://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/svg/").concat(h, ".svg");
                            return d.default.createElement("img", n({
                                className: (0, a.buildClassNames)({
                                    addPrefix: ["flag-emoji"],
                                    rawClassNames: [f]
                                }),
                                src: m,
                                width: i,
                                height: i,
                                draggable: !1,
                                "data-country": t,
                                loading: c ? void 0 : "lazy"
                            }, $))
                        }
                    },
                    519: function(e, t, r) {
                        var n = this && this.__assign || function() {
                                return n = Object.assign || function(e) {
                                    for (var t, r = 1, n = arguments.length; r < n; r++)
                                        for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                                    return e
                                }, n.apply(this, arguments)
                            },
                            o = this && this.__createBinding || (Object.create ? function(e, t, r, n) {
                                void 0 === n && (n = r);
                                var o = Object.getOwnPropertyDescriptor(t, r);
                                o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                                    enumerable: !0,
                                    get: function() {
                                        return t[r]
                                    }
                                }), Object.defineProperty(e, n, o)
                            } : function(e, t, r, n) {
                                void 0 === n && (n = r), e[n] = t[r]
                            }),
                            i = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                                Object.defineProperty(e, "default", {
                                    enumerable: !0,
                                    value: t
                                })
                            } : function(e, t) {
                                e.default = t
                            }),
                            d = this && this.__importStar || function(e) {
                                if (e && e.__esModule) return e;
                                var t = {};
                                if (null != e)
                                    for (var r in e) "default" !== r && Object.prototype.hasOwnProperty.call(e, r) && o(t, e, r);
                                return i(t, e), t
                            },
                            a = this && this.__rest || function(e, t) {
                                var r = {};
                                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                                if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                                    var o = 0;
                                    for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]])
                                }
                                return r
                            };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.PhoneInput = void 0, r(425);
                        var s = d(r(156)),
                            u = r(445),
                            l = r(268),
                            c = r(379),
                            f = r(197),
                            $ = r(110),
                            p = r(805);
                        t.PhoneInput = function(e) {
                            var t, r = e.hideDropdown,
                                o = e.placeholder,
                                i = e.disabled,
                                d = e.showDisabledDialCodeAndPrefix,
                                h = e.inputProps,
                                m = e.onChange,
                                _ = e.style,
                                y = e.className,
                                v = e.inputStyle,
                                g = e.inputClassName,
                                b = e.countrySelectorStyleProps,
                                w = e.dialCodePreviewStyleProps,
                                C = e.value,
                                S = e.countries,
                                P = void 0 === S ? u.defaultCountries : S,
                                O = a(e, ["hideDropdown", "placeholder", "disabled", "showDisabledDialCodeAndPrefix", "inputProps", "onChange", "style", "className", "inputStyle", "inputClassName", "countrySelectorStyleProps", "dialCodePreviewStyleProps", "value", "countries"]),
                                x = (0, l.usePhoneInput)(n(n({
                                    value: C,
                                    countries: P
                                }, O), {
                                    onChange: function(e) {
                                        null == m || m(e.phone, e.country)
                                    }
                                })),
                                E = x.phone,
                                M = x.inputRef,
                                D = x.country,
                                N = x.setCountry,
                                I = x.handlePhoneValueChange,
                                k = (0, s.useMemo)((function() {
                                    if (D) return (0, f.getCountry)({
                                        value: D,
                                        field: "iso2",
                                        countries: P
                                    })
                                }), [P, D]),
                                T = O.disableDialCodeAndPrefix && d && (null == k ? void 0 : k.dialCode);
                            return s.default.createElement("div", {
                                className: (0, c.buildClassNames)({
                                    addPrefix: ["input-container"],
                                    rawClassNames: [y]
                                }),
                                style: _
                            }, s.default.createElement($.CountrySelector, n({
                                onSelect: function(e) {
                                    return N(e.iso2)
                                },
                                selectedCountry: D,
                                countries: P,
                                disabled: i,
                                hideDropdown: r
                            }, b)), T && s.default.createElement(p.DialCodePreview, n({
                                dialCode: k.dialCode,
                                prefix: null !== (t = O.prefix) && void 0 !== t ? t : "+",
                                disabled: i
                            }, w)), s.default.createElement("input", n({
                                onChange: I,
                                value: E,
                                type: "tel",
                                ref: M,
                                className: (0, c.buildClassNames)({
                                    addPrefix: ["input", i && "input--disabled"],
                                    rawClassNames: [g]
                                }),
                                placeholder: o,
                                disabled: i,
                                style: v
                            }, h)))
                        }
                    },
                    445: (e, t) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.defaultCountries = void 0, t.defaultCountries = [
                            ["Afghanistan", "af", "93"],
                            ["Albania", "al", "355"],
                            ["Algeria", "dz", "213"],
                            ["Andorra", "ad", "376"],
                            ["Angola", "ao", "244"],
                            ["Antigua and Barbuda", "ag", "1268"],
                            ["Argentina", "ar", "54", "(..) ........", 0],
                            ["Armenia", "am", "374", ".. ......"],
                            ["Aruba", "aw", "297"],
                            ["Australia", "au", "61", ". .... ....", 0],
                            ["Austria", "at", "43"],
                            ["Azerbaijan", "az", "994", "(..) ... .. .."],
                            ["Bahamas", "bs", "1242"],
                            ["Bahrain", "bh", "973"],
                            ["Bangladesh", "bd", "880"],
                            ["Barbados", "bb", "1246"],
                            ["Belarus", "by", "375", "(..) ... .. .."],
                            ["Belgium", "be", "32", "... .. .. .."],
                            ["Belize", "bz", "501"],
                            ["Benin", "bj", "229"],
                            ["Bhutan", "bt", "975"],
                            ["Bolivia", "bo", "591"],
                            ["Bosnia and Herzegovina", "ba", "387"],
                            ["Botswana", "bw", "267"],
                            ["Brazil", "br", "55", "(..) ........."],
                            ["British Indian Ocean Territory", "io", "246"],
                            ["Brunei", "bn", "673"],
                            ["Bulgaria", "bg", "359"],
                            ["Burkina Faso", "bf", "226"],
                            ["Burundi", "bi", "257"],
                            ["Cambodia", "kh", "855"],
                            ["Cameroon", "cm", "237"],
                            ["Canada", "ca", "1", "(...) ...-....", 1, ["204", "226", "236", "249", "250", "289", "306", "343", "365", "387", "403", "416", "418", "431", "437", "438", "450", "506", "514", "519", "548", "579", "581", "587", "604", "613", "639", "647", "672", "705", "709", "742", "778", "780", "782", "807", "819", "825", "867", "873", "902", "905"]],
                            ["Cape Verde", "cv", "238"],
                            ["Caribbean Netherlands", "bq", "599", "", 1],
                            ["Central African Republic", "cf", "236"],
                            ["Chad", "td", "235"],
                            ["Chile", "cl", "56"],
                            ["China", "cn", "86", "... .... ...."],
                            ["Colombia", "co", "57", "... ... ...."],
                            ["Comoros", "km", "269"],
                            ["Congo", "cd", "243"],
                            ["Congo", "cg", "242"],
                            ["Costa Rica", "cr", "506", "....-...."],
                            ["Côte d'Ivoire", "ci", "225", ".. .. .. .. .."],
                            ["Croatia", "hr", "385"],
                            ["Cuba", "cu", "53"],
                            ["Curaçao", "cw", "599", "", 0],
                            ["Cyprus", "cy", "357", ".. ......"],
                            ["Czech Republic", "cz", "420", "... ... ..."],
                            ["Denmark", "dk", "45", ".. .. .. .."],
                            ["Djibouti", "dj", "253"],
                            ["Dominica", "dm", "1767"],
                            ["Dominican Republic", "do", "1", "", 2],
                            ["Ecuador", "ec", "593"],
                            ["Egypt", "eg", "20"],
                            ["El Salvador", "sv", "503", "....-...."],
                            ["Equatorial Guinea", "gq", "240"],
                            ["Eritrea", "er", "291"],
                            ["Estonia", "ee", "372", ".... ......"],
                            ["Ethiopia", "et", "251"],
                            ["Fiji", "fj", "679"],
                            ["Finland", "fi", "358", ".. ... .. .."],
                            ["France", "fr", "33", ". .. .. .. .."],
                            ["French Guiana", "gf", "594"],
                            ["French Polynesia", "pf", "689"],
                            ["Gabon", "ga", "241"],
                            ["Gambia", "gm", "220"],
                            ["Georgia", "ge", "995"],
                            ["Germany", "de", "49", ".... ........"],
                            ["Ghana", "gh", "233"],
                            ["Greece", "gr", "30"],
                            ["Grenada", "gd", "1473"],
                            ["Guadeloupe", "gp", "590", "", 0],
                            ["Guam", "gu", "1671"],
                            ["Guatemala", "gt", "502", "....-...."],
                            ["Guinea", "gn", "224"],
                            ["Guinea-Bissau", "gw", "245"],
                            ["Guyana", "gy", "592"],
                            ["Haiti", "ht", "509", "....-...."],
                            ["Honduras", "hn", "504"],
                            ["Hong Kong", "hk", "852", ".... ...."],
                            ["Hungary", "hu", "36"],
                            ["Iceland", "is", "354", "... ...."],
                            ["India", "in", "91", ".....-....."],
                            ["Indonesia", "id", "62"],
                            ["Iran", "ir", "98", "... ... ...."],
                            ["Iraq", "iq", "964"],
                            ["Ireland", "ie", "353", ".. ......."],
                            ["Israel", "il", "972", "... ... ...."],
                            ["Italy", "it", "39", "... .......", 0],
                            ["Jamaica", "jm", "1876"],
                            ["Japan", "jp", "81", ".. .... ...."],
                            ["Jordan", "jo", "962"],
                            ["Kazakhstan", "kz", "7", "... ...-..-..", 0],
                            ["Kenya", "ke", "254"],
                            ["Kiribati", "ki", "686"],
                            ["Kosovo", "xk", "383"],
                            ["Kuwait", "kw", "965"],
                            ["Kyrgyzstan", "kg", "996", "... ... ..."],
                            ["Laos", "la", "856"],
                            ["Latvia", "lv", "371", ".. ... ..."],
                            ["Lebanon", "lb", "961"],
                            ["Lesotho", "ls", "266"],
                            ["Liberia", "lr", "231"],
                            ["Libya", "ly", "218"],
                            ["Liechtenstein", "li", "423"],
                            ["Lithuania", "lt", "370"],
                            ["Luxembourg", "lu", "352"],
                            ["Macau", "mo", "853"],
                            ["Macedonia", "mk", "389"],
                            ["Madagascar", "mg", "261"],
                            ["Malawi", "mw", "265"],
                            ["Malaysia", "my", "60", "..-....-...."],
                            ["Maldives", "mv", "960"],
                            ["Mali", "ml", "223"],
                            ["Malta", "mt", "356"],
                            ["Marshall Islands", "mh", "692"],
                            ["Martinique", "mq", "596"],
                            ["Mauritania", "mr", "222"],
                            ["Mauritius", "mu", "230"],
                            ["Mexico", "mx", "52", "... ... ....", 0],
                            ["Micronesia", "fm", "691"],
                            ["Moldova", "md", "373", "(..) ..-..-.."],
                            ["Monaco", "mc", "377"],
                            ["Mongolia", "mn", "976"],
                            ["Montenegro", "me", "382"],
                            ["Morocco", "ma", "212"],
                            ["Mozambique", "mz", "258"],
                            ["Myanmar", "mm", "95"],
                            ["Namibia", "na", "264"],
                            ["Nauru", "nr", "674"],
                            ["Nepal", "np", "977"],
                            ["Netherlands", "nl", "31", ".. ........"],
                            ["New Caledonia", "nc", "687"],
                            ["New Zealand", "nz", "64", "...-...-...."],
                            ["Nicaragua", "ni", "505"],
                            ["Niger", "ne", "227"],
                            ["Nigeria", "ng", "234"],
                            ["North Korea", "kp", "850"],
                            ["Norway", "no", "47", "... .. ..."],
                            ["Oman", "om", "968"],
                            ["Pakistan", "pk", "92", "...-......."],
                            ["Palau", "pw", "680"],
                            ["Palestine", "ps", "970"],
                            ["Panama", "pa", "507"],
                            ["Papua New Guinea", "pg", "675"],
                            ["Paraguay", "py", "595"],
                            ["Peru", "pe", "51"],
                            ["Philippines", "ph", "63", ".... ......."],
                            ["Poland", "pl", "48", "...-...-..."],
                            ["Portugal", "pt", "351"],
                            ["Puerto Rico", "pr", "1", "", 3],
                            ["Qatar", "qa", "974"],
                            ["Réunion", "re", "262"],
                            ["Romania", "ro", "40"],
                            ["Russia", "ru", "7", "(...) ...-..-..", 1],
                            ["Rwanda", "rw", "250"],
                            ["Saint Kitts and Nevis", "kn", "1869"],
                            ["Saint Lucia", "lc", "1758"],
                            ["Saint Vincent and the Grenadines", "vc", "1784"],
                            ["Samoa", "ws", "685"],
                            ["San Marino", "sm", "378"],
                            ["São Tomé and Príncipe", "st", "239"],
                            ["Saudi Arabia", "sa", "966"],
                            ["Senegal", "sn", "221"],
                            ["Serbia", "rs", "381"],
                            ["Seychelles", "sc", "248"],
                            ["Sierra Leone", "sl", "232"],
                            ["Singapore", "sg", "65", "....-...."],
                            ["Slovakia", "sk", "421"],
                            ["Slovenia", "si", "386"],
                            ["Solomon Islands", "sb", "677"],
                            ["Somalia", "so", "252"],
                            ["South Africa", "za", "27"],
                            ["South Korea", "kr", "82", "... .... ...."],
                            ["South Sudan", "ss", "211"],
                            ["Spain", "es", "34", "... ... ..."],
                            ["Sri Lanka", "lk", "94"],
                            ["Sudan", "sd", "249"],
                            ["Suriname", "sr", "597"],
                            ["Swaziland", "sz", "268"],
                            ["Sweden", "se", "46", "(...) ...-..."],
                            ["Switzerland", "ch", "41", ".. ... .. .."],
                            ["Syria", "sy", "963"],
                            ["Taiwan", "tw", "886"],
                            ["Tajikistan", "tj", "992"],
                            ["Tanzania", "tz", "255"],
                            ["Thailand", "th", "66"],
                            ["Timor-Leste", "tl", "670"],
                            ["Togo", "tg", "228"],
                            ["Tonga", "to", "676"],
                            ["Trinidad and Tobago", "tt", "1868"],
                            ["Tunisia", "tn", "216"],
                            ["Turkey", "tr", "90", "... ... .. .."],
                            ["Turkmenistan", "tm", "993"],
                            ["Tuvalu", "tv", "688"],
                            ["Uganda", "ug", "256"],
                            ["Ukraine", "ua", "380", "(..) ... .. .."],
                            ["United Arab Emirates", "ae", "971"],
                            ["United Kingdom", "gb", "44", ".... ......"],
                            ["United States", "us", "1", "(...) ...-....", 0],
                            ["Uruguay", "uy", "598"],
                            ["Uzbekistan", "uz", "998", ".. ... .. .."],
                            ["Vanuatu", "vu", "678"],
                            ["Vatican City", "va", "39", ".. .... ....", 1],
                            ["Venezuela", "ve", "58"],
                            ["Vietnam", "vn", "84"],
                            ["Yemen", "ye", "967"],
                            ["Zambia", "zm", "260"],
                            ["Zimbabwe", "zw", "263"]
                        ]
                    },
                    616: function(e, t, r) {
                        var n = this && this.__assign || function() {
                                return n = Object.assign || function(e) {
                                    for (var t, r = 1, n = arguments.length; r < n; r++)
                                        for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                                    return e
                                }, n.apply(this, arguments)
                            },
                            o = this && this.__spreadArray || function(e, t, r) {
                                if (r || 2 === arguments.length)
                                    for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), n[o] = t[o]);
                                return e.concat(n || Array.prototype.slice.call(t))
                            };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.useHistoryState = void 0;
                        var i = r(156),
                            d = r(459),
                            a = {
                                size: 20,
                                overrideLastItemDebounceMS: -1
                            };
                        t.useHistoryState = function(e, t) {
                            var r = n(n({}, a), t),
                                s = r.size,
                                u = r.overrideLastItemDebounceMS,
                                l = r.onChange,
                                c = (0, i.useState)(e),
                                f = c[0],
                                $ = c[1],
                                p = (0, i.useState)([f]),
                                h = p[0],
                                m = p[1],
                                _ = (0, i.useState)(0),
                                y = _[0],
                                v = _[1],
                                g = (0, d.useTimer)();
                            return [f, function(e, t) {
                                if (("object" != typeof e || Object.entries(e).toString() !== Object.entries(f).toString()) && e !== f) {
                                    var r = u > 0,
                                        n = g.check(),
                                        i = !r || void 0 === n || n > u;
                                    if (void 0 !== (null == t ? void 0 : t.overrideLastItem) ? t.overrideLastItem : !i) m((function(t) {
                                        return o(o([], t.slice(0, y), !0), [e], !1)
                                    }));
                                    else {
                                        var d = h.length >= s;
                                        m((function(t) {
                                            return o(o([], t.slice(d ? 1 : 0, y + 1), !0), [e], !1)
                                        })), d || v((function(e) {
                                            return e + 1
                                        }))
                                    }
                                    $(e), null == l || l(e)
                                }
                            }, function() {
                                if (y <= 0) return {
                                    success: !1
                                };
                                var e = h[y - 1];
                                return $(e), v((function(e) {
                                    return e - 1
                                })), null == l || l(e), {
                                    success: !0,
                                    value: e
                                }
                            }, function() {
                                if (y + 1 >= h.length) return {
                                    success: !1
                                };
                                var e = h[y + 1];
                                return $(e), v((function(e) {
                                    return e + 1
                                })), null == l || l(e), {
                                    success: !0,
                                    value: e
                                }
                            }]
                        }
                    },
                    268: (e, t, r) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.usePhoneInput = t.defaultConfig = t.MASK_CHAR = void 0;
                        var n = r(156),
                            o = r(445),
                            i = r(197),
                            d = r(616);
                        t.MASK_CHAR = ".", t.defaultConfig = {
                            defaultCountry: "us",
                            value: "",
                            prefix: "+",
                            defaultMask: "............",
                            charAfterDialCode: " ",
                            historySaveDebounceMS: 200,
                            disableCountryGuess: !1,
                            disableDialCodePrefill: !1,
                            forceDialCode: !1,
                            disableDialCodeAndPrefix: !1,
                            countries: o.defaultCountries
                        }, t.usePhoneInput = function(e) {
                            var r = e.defaultCountry,
                                o = void 0 === r ? t.defaultConfig.defaultCountry : r,
                                a = e.value,
                                s = void 0 === a ? t.defaultConfig.value : a,
                                u = e.countries,
                                l = void 0 === u ? t.defaultConfig.countries : u,
                                c = e.prefix,
                                f = void 0 === c ? t.defaultConfig.prefix : c,
                                $ = e.defaultMask,
                                p = void 0 === $ ? t.defaultConfig.defaultMask : $,
                                h = e.charAfterDialCode,
                                m = void 0 === h ? t.defaultConfig.charAfterDialCode : h,
                                _ = e.historySaveDebounceMS,
                                y = void 0 === _ ? t.defaultConfig.historySaveDebounceMS : _,
                                v = e.disableCountryGuess,
                                g = void 0 === v ? t.defaultConfig.disableCountryGuess : v,
                                b = e.disableDialCodePrefill,
                                w = void 0 === b ? t.defaultConfig.disableDialCodePrefill : b,
                                C = e.forceDialCode,
                                S = void 0 === C ? t.defaultConfig.forceDialCode : C,
                                P = e.disableDialCodeAndPrefix,
                                O = void 0 === P ? t.defaultConfig.disableDialCodeAndPrefix : P,
                                x = e.onChange,
                                E = !O && !g,
                                M = (0, n.useRef)(null),
                                D = function(e) {
                                    var r, n = e.value,
                                        o = e.country,
                                        d = e.trimNonDigitsEnd,
                                        a = e.insertDialCodeOnEmpty,
                                        s = !e.forceDisableCountryGuess && E ? (0, i.guessCountryByPartialNumber)({
                                            phone: n,
                                            countries: l,
                                            currentCountryIso2: o.iso2
                                        }) : void 0,
                                        u = null !== (r = null == s ? void 0 : s.country) && void 0 !== r ? r : o;
                                    return {
                                        phone: u ? (0, i.formatPhone)(n, {
                                            prefix: f,
                                            mask: u.format || p,
                                            maskChar: t.MASK_CHAR,
                                            dialCode: u.dialCode,
                                            trimNonDigitsEnd: d,
                                            charAfterDialCode: m,
                                            forceDialCode: S,
                                            insertDialCodeOnEmpty: a,
                                            disableDialCodeAndPrefix: O
                                        }) : n,
                                        countryGuessResult: s,
                                        formatCountry: u
                                    }
                                },
                                N = function(e) {
                                    Promise.resolve().then((function() {
                                        var t;
                                        null === (t = M.current) || void 0 === t || t.setSelectionRange(e, e)
                                    }))
                                },
                                I = (0, d.useHistoryState)((function() {
                                    var e = (0, i.guessCountryByPartialNumber)({
                                            phone: s,
                                            countries: l,
                                            currentCountryIso2: o
                                        }).country || (0, i.getCountry)({
                                            value: o,
                                            field: "iso2",
                                            countries: l
                                        }),
                                        t = e || (0, i.parseCountry)(l.find((function(e) {
                                            return "us" === (0, i.parseCountry)(e).iso2
                                        }))),
                                        r = D({
                                            value: s,
                                            country: t,
                                            insertDialCodeOnEmpty: !w
                                        }).phone;
                                    return N(r.length), {
                                        phone: r,
                                        country: t.iso2
                                    }
                                }), {
                                    overrideLastItemDebounceMS: y,
                                    onChange: x
                                }),
                                k = I[0],
                                T = k.phone,
                                A = k.country,
                                j = I[1],
                                R = I[2],
                                L = I[3],
                                F = (0, n.useMemo)((function() {
                                    return (0, i.getCountry)({
                                        value: A,
                                        field: "iso2",
                                        countries: l
                                    })
                                }), [l, A]),
                                B = function(e, t) {
                                    var r, n, o = void 0 === t ? {} : t,
                                        d = o.deletion,
                                        a = o.cursorPosition,
                                        s = o.insertDialCodeOnEmpty,
                                        u = o.inserted,
                                        l = e,
                                        c = a;
                                    S && !O && F && !(0, i.removeNonDigits)(e).startsWith(F.dialCode) && e && (u && e.startsWith(f) && e.length - (null != a ? a : 0) == 0 ? l = e : (l = T, c = 0));
                                    var $ = D({
                                            value: l,
                                            country: F,
                                            trimNonDigitsEnd: "backward" === d,
                                            insertDialCodeOnEmpty: s,
                                            forceDisableCountryGuess: S && !!d && (0, i.removeNonDigits)(l).length < F.dialCode.length
                                        }),
                                        p = $.phone,
                                        h = $.countryGuessResult,
                                        _ = F;
                                    E && (null == h ? void 0 : h.country) && h.country.name !== A && h.fullDialCodeMatch && (_ = h.country);
                                    var y = (0, i.getCursorPosition)({
                                        cursorPositionAfterInput: null != c ? c : 0,
                                        phoneBeforeInput: T,
                                        phoneAfterInput: e,
                                        phoneAfterFormatted: p,
                                        leftOffset: S ? f.length + (null !== (n = null === (r = null == F ? void 0 : F.dialCode) || void 0 === r ? void 0 : r.length) && void 0 !== n ? n : 0) + m.length : 0,
                                        deletion: d
                                    });
                                    return j({
                                        phone: p,
                                        country: _.iso2
                                    }), N(y), p
                                };
                            (0, n.useEffect)((function() {
                                var e = M.current;
                                if (e) {
                                    var t = function(e) {
                                        if (e.key) {
                                            var t = e.ctrlKey,
                                                r = e.shiftKey,
                                                n = "z" === e.key.toLowerCase();
                                            t && n && (r ? L() : R())
                                        }
                                    };
                                    return e.addEventListener("keydown", t),
                                        function() {
                                            e.removeEventListener("keydown", t)
                                        }
                                }
                            }), [M, R, L]);
                            var Y = (0, n.useState)(!1),
                                U = Y[0],
                                z = Y[1];
                            return (0, n.useEffect)((function() {
                                if (!U) return z(!0), void(s !== T && (null == x || x({
                                    phone: T,
                                    country: A
                                })));
                                s !== T && B(s)
                            }), [s]), {
                                phone: T,
                                country: A,
                                setCountry: function(e) {
                                    var t = (0, i.getCountry)({
                                        value: e,
                                        field: "iso2",
                                        countries: l
                                    });
                                    if (t) {
                                        var r = O ? "" : "".concat(f).concat(t.dialCode).concat(m);
                                        j({
                                            phone: r,
                                            country: t.iso2
                                        }), Promise.resolve().then((function() {
                                            var e;
                                            null === (e = M.current) || void 0 === e || e.focus()
                                        }))
                                    }
                                },
                                handlePhoneValueChange: function(e) {
                                    var t;
                                    e.preventDefault();
                                    var r = e.nativeEvent.inputType,
                                        n = null == r ? void 0 : r.startsWith("insertFrom"),
                                        o = B(e.target.value, {
                                            deletion: function() {
                                                var e;
                                                if (null !== (e = null == r ? void 0 : r.toLocaleLowerCase().includes("delete")) && void 0 !== e && e) return (null == r ? void 0 : r.toLocaleLowerCase().includes("forward")) ? "forward" : "backward"
                                            }(),
                                            inserted: n,
                                            cursorPosition: null !== (t = e.target.selectionStart) && void 0 !== t ? t : 0
                                        });
                                    return O && F ? (0, i.addDialCode)({
                                        phone: o,
                                        dialCode: F.dialCode,
                                        charAfterDialCode: m,
                                        prefix: f
                                    }) : o
                                },
                                inputRef: M
                            }
                        }
                    },
                    459: (e, t, r) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.useTimer = void 0;
                        var n = r(156);
                        t.useTimer = function() {
                            var e = (0, n.useRef)(),
                                t = (0, n.useRef)(Date.now());
                            return {
                                check: function() {
                                    var r = Date.now(),
                                        n = e.current ? r - t.current : void 0;
                                    return e.current = t.current, t.current = r, n
                                }
                            }
                        }
                    },
                    379: function(e, t) {
                        var r = this && this.__spreadArray || function(e, t, r) {
                            if (r || 2 === arguments.length)
                                for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), n[o] = t[o]);
                            return e.concat(n || Array.prototype.slice.call(t))
                        };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.buildClassNames = t.classNamesWithPrefix = t.joinClasses = t.classPrefix = void 0, t.classPrefix = "react-international-phone-", t.joinClasses = function() {
                            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                            return e.filter((function(e) {
                                return !!e
                            })).join(" ").trim()
                        }, t.classNamesWithPrefix = function() {
                            for (var e = [], r = 0; r < arguments.length; r++) e[r] = arguments[r];
                            return t.joinClasses.apply(void 0, e).split(" ").map((function(e) {
                                return "".concat(t.classPrefix).concat(e)
                            })).join(" ")
                        }, t.buildClassNames = function(e) {
                            var n = e.addPrefix,
                                o = e.rawClassNames;
                            return t.joinClasses.apply(void 0, r([t.classNamesWithPrefix.apply(void 0, n)], o, !1))
                        }
                    },
                    36: (e, t) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.applyMask = void 0, t.applyMask = function(e) {
                            var t = e.value,
                                r = e.mask,
                                n = e.maskSymbol,
                                o = e.offset,
                                i = void 0 === o ? 0 : o,
                                d = e.trimNonMaskCharsLeftover,
                                a = void 0 !== d && d;
                            if (t.length < i) return t;
                            for (var s = t.slice(0, i), u = t.slice(i), l = s, c = 0, f = 0, $ = r.split(""); f < $.length; f++) {
                                var p = $[f];
                                if (c >= u.length) {
                                    if (!a && p !== n) {
                                        l += p;
                                        continue
                                    }
                                    break
                                }
                                p === n ? (l += u[c], c += 1) : l += p
                            }
                            return l
                        }
                    },
                    945: function(e, t, r) {
                        var n = this && this.__createBinding || (Object.create ? function(e, t, r, n) {
                                void 0 === n && (n = r);
                                var o = Object.getOwnPropertyDescriptor(t, r);
                                o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                                    enumerable: !0,
                                    get: function() {
                                        return t[r]
                                    }
                                }), Object.defineProperty(e, n, o)
                            } : function(e, t, r, n) {
                                void 0 === n && (n = r), e[n] = t[r]
                            }),
                            o = this && this.__exportStar || function(e, t) {
                                for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || n(t, e, r)
                            };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), o(r(36), t), o(r(961), t), o(r(230), t)
                    },
                    961: (e, t) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.removeNonDigits = void 0, t.removeNonDigits = function(e) {
                            return e.replace(/\D/g, "")
                        }
                    },
                    230: (e, t) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.scrollToChild = void 0, t.scrollToChild = function(e, t) {
                            var r = e.style.display;
                            "block" !== r && (e.style.display = "block");
                            var n = e.getBoundingClientRect(),
                                o = t.getBoundingClientRect(),
                                i = o.top - n.top,
                                d = n.bottom - o.bottom;
                            i >= 0 && d >= 0 || (Math.abs(i) < Math.abs(d) ? e.scrollTop += i : e.scrollTop -= d), e.style.display = r
                        }
                    },
                    738: (e, t) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.buildCountryData = void 0, t.buildCountryData = function(e) {
                            for (var t = [e.name, e.iso2, e.dialCode, e.format, e.priority, e.areaCodes], r = 0; r < t.length; r += 1)
                                if (0 !== r) {
                                    var n = t[r - 1],
                                        o = t[r];
                                    if (void 0 === n && void 0 !== o) {
                                        var i = JSON.stringify(t, (function(e, t) {
                                            return void 0 === t ? "__undefined" : t
                                        })).replace(/"__undefined"/g, "undefined");
                                        throw new Error("[react-international-phone] invalid country values passed to buildCountryData. Check ".concat(n, " in: ").concat(i))
                                    }
                                }
                            return t.filter((function(e) {
                                return void 0 !== e
                            }))
                        }
                    },
                    183: (e, t, r) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.getCountry = void 0;
                        var n = r(863);
                        t.getCountry = function(e) {
                            var t = e.value,
                                r = e.field,
                                o = e.countries;
                            if (["priority"].includes(r)) throw new Error('Field "'.concat(r, '" is not supported'));
                            var i = o.find((function(e) {
                                var o = (0, n.parseCountry)(e);
                                return t === o[r]
                            }));
                            if (i) return (0, n.parseCountry)(i)
                        }
                    },
                    265: (e, t, r) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.guessCountryByPartialNumber = void 0;
                        var n = r(945),
                            o = r(183),
                            i = r(863);
                        t.guessCountryByPartialNumber = function(e) {
                            var t, r = e.phone,
                                d = e.countries,
                                a = e.currentCountryIso2,
                                s = {
                                    country: void 0,
                                    fullDialCodeMatch: !1
                                };
                            if (!r) return s;
                            var u = (0, n.removeNonDigits)(r);
                            if (!u) return s;
                            for (var l = s, c = function(e) {
                                    var t, r, n, o, i = e.country,
                                        d = e.fullDialCodeMatch,
                                        a = i.dialCode === (null === (t = l.country) || void 0 === t ? void 0 : t.dialCode),
                                        s = (null !== (r = i.priority) && void 0 !== r ? r : 0) < (null !== (o = null === (n = l.country) || void 0 === n ? void 0 : n.priority) && void 0 !== o ? o : 0);
                                    a && !s || (l = {
                                        country: i,
                                        fullDialCodeMatch: d
                                    })
                                }, f = 0, $ = d; f < $.length; f++) {
                                var p = $[f],
                                    h = (0, i.parseCountry)(p),
                                    m = h.dialCode,
                                    _ = h.areaCodes;
                                if (u.startsWith(m)) {
                                    var y = !l.country || Number(m) >= Number(l.country.dialCode);
                                    if (_)
                                        for (var v = u.substring(m.length), g = 0, b = _; g < b.length; g++) {
                                            var w = b[g];
                                            if (v.startsWith(w)) return {
                                                country: h,
                                                fullDialCodeMatch: !0
                                            }
                                        }!y && m !== u && l.fullDialCodeMatch || c({
                                            country: h,
                                            fullDialCodeMatch: !0
                                        })
                                }
                                l.fullDialCodeMatch || u.length < m.length && m.startsWith(u) && (!l.country || Number(m) <= Number(l.country.dialCode)) && c({
                                    country: h,
                                    fullDialCodeMatch: !1
                                })
                            }
                            if (a) {
                                var C = (0, o.getCountry)({
                                    value: a,
                                    field: "iso2",
                                    countries: d
                                });
                                if (!C) return l;
                                var S = !!C && function(e) {
                                    if (!(null == e ? void 0 : e.areaCodes)) return !1;
                                    var t = u.substring(e.dialCode.length);
                                    return e.areaCodes.some((function(e) {
                                        return e.startsWith(t)
                                    }))
                                }(C);
                                l && (null === (t = l.country) || void 0 === t ? void 0 : t.dialCode) === C.dialCode && l.country !== C && l.fullDialCodeMatch && (!C.areaCodes || S) && (l = {
                                    country: C,
                                    fullDialCodeMatch: !0
                                })
                            }
                            return l
                        }
                    },
                    373: function(e, t, r) {
                        var n = this && this.__createBinding || (Object.create ? function(e, t, r, n) {
                                void 0 === n && (n = r);
                                var o = Object.getOwnPropertyDescriptor(t, r);
                                o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                                    enumerable: !0,
                                    get: function() {
                                        return t[r]
                                    }
                                }), Object.defineProperty(e, n, o)
                            } : function(e, t, r, n) {
                                void 0 === n && (n = r), e[n] = t[r]
                            }),
                            o = this && this.__exportStar || function(e, t) {
                                for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || n(t, e, r)
                            };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), o(r(738), t), o(r(183), t), o(r(265), t), o(r(863), t)
                    },
                    863: (e, t) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.parseCountry = void 0, t.parseCountry = function(e) {
                            return {
                                name: e[0],
                                iso2: e[1],
                                dialCode: e[2],
                                format: e[3],
                                priority: e[4],
                                areaCodes: e[5]
                            }
                        }
                    },
                    197: function(e, t, r) {
                        var n = this && this.__createBinding || (Object.create ? function(e, t, r, n) {
                                void 0 === n && (n = r);
                                var o = Object.getOwnPropertyDescriptor(t, r);
                                o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                                    enumerable: !0,
                                    get: function() {
                                        return t[r]
                                    }
                                }), Object.defineProperty(e, n, o)
                            } : function(e, t, r, n) {
                                void 0 === n && (n = r), e[n] = t[r]
                            }),
                            o = this && this.__exportStar || function(e, t) {
                                for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || n(t, e, r)
                            };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), o(r(945), t), o(r(373), t), o(r(367), t)
                    },
                    479: (e, t, r) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.addDialCode = void 0;
                        var n = r(617);
                        t.addDialCode = function(e) {
                            var t = e.phone,
                                r = e.dialCode,
                                o = e.prefix,
                                i = void 0 === o ? "+" : o,
                                d = e.charAfterDialCode,
                                a = void 0 === d ? " " : d;
                            return "".concat(i).concat(r).concat(a).concat((0, n.removeDialCode)({
                                phone: t,
                                dialCode: r,
                                charAfterDialCode: a,
                                prefix: i
                            }))
                        }
                    },
                    854: (e, t, r) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.formatPhone = void 0;
                        var n = r(945);
                        t.formatPhone = function(e, t) {
                            var r = !t.disableDialCodeAndPrefix && t.forceDialCode,
                                o = !t.disableDialCodeAndPrefix && t.insertDialCodeOnEmpty,
                                i = e,
                                d = function(e) {
                                    return t.trimNonDigitsEnd ? e.trim() : e
                                };
                            if (!i) return o && !i.length || r ? d("".concat(t.prefix).concat(t.dialCode).concat(t.charAfterDialCode)) : d(i);
                            if ((i = (0, n.removeNonDigits)(i)) === t.dialCode && !t.disableDialCodeAndPrefix) return d("".concat(t.prefix).concat(t.dialCode).concat(t.charAfterDialCode));
                            if (t.dialCode.startsWith(i) && !t.disableDialCodeAndPrefix) return d(r ? "".concat(t.prefix).concat(t.dialCode).concat(t.charAfterDialCode) : "".concat(t.prefix).concat(i));
                            if (!i.startsWith(t.dialCode) && !t.disableDialCodeAndPrefix) {
                                if (r) return d("".concat(t.prefix).concat(t.dialCode).concat(t.charAfterDialCode));
                                if (i.length < t.dialCode.length) return d("".concat(t.prefix).concat(i))
                            }
                            var a, s = (a = t.dialCode.length, t.disableDialCodeAndPrefix && (a = 0), {
                                    phoneLeftSide: i.slice(0, a),
                                    phoneRightSide: i.slice(a)
                                }),
                                u = s.phoneLeftSide,
                                l = s.phoneRightSide;
                            return u = "".concat(t.prefix).concat(u).concat(t.charAfterDialCode), l = (0, n.applyMask)({
                                value: l,
                                mask: t.mask,
                                maskSymbol: t.maskChar,
                                trimNonMaskCharsLeftover: t.trimNonDigitsEnd
                            }), t.disableDialCodeAndPrefix && (u = ""), d("".concat(u).concat(l))
                        }
                    },
                    753: (e, t) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.getCursorPosition = void 0;
                        var r = function(e) {
                            return /\d/.test(e)
                        };
                        t.getCursorPosition = function(e) {
                            var t = e.phoneBeforeInput,
                                n = e.phoneAfterInput,
                                o = e.phoneAfterFormatted,
                                i = e.cursorPositionAfterInput,
                                d = e.leftOffset,
                                a = void 0 === d ? 0 : d,
                                s = e.deletion;
                            if (i < a) return a;
                            if (!t) return o.length;
                            var u = "backward" === s;
                            if (0 === i && n.length > 0 && o.length > 0) {
                                if (u) return 0;
                                for (var l = 0; l < o.length; l += 1)
                                    if (r(o[l])) return l;
                                return o.length
                            }
                            if (n.length < t.length && 1 === n.length) return o.length;
                            var c = null;
                            for (l = i - 1; l >= 0; l -= 1)
                                if (r(n[l])) {
                                    c = l;
                                    break
                                }
                            if (null === c) return 0 !== i ? i : o.length;
                            var f = 0;
                            for (l = 0; l < c; l += 1) r(n[l]) && (f += 1);
                            u && (f -= 1);
                            var $ = 0,
                                p = 0;
                            for (l = 0; l < o.length && ($ += 1, r(o[l]) && (p += 1), p !== f + 1); l += 1);
                            for (; !r(o[$]) && $ < o.length;) $ += 1;
                            return u && ($ += 1), $
                        }
                    },
                    367: function(e, t, r) {
                        var n = this && this.__createBinding || (Object.create ? function(e, t, r, n) {
                                void 0 === n && (n = r);
                                var o = Object.getOwnPropertyDescriptor(t, r);
                                o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                                    enumerable: !0,
                                    get: function() {
                                        return t[r]
                                    }
                                }), Object.defineProperty(e, n, o)
                            } : function(e, t, r, n) {
                                void 0 === n && (n = r), e[n] = t[r]
                            }),
                            o = this && this.__exportStar || function(e, t) {
                                for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || n(t, e, r)
                            };
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), o(r(479), t), o(r(854), t), o(r(753), t), o(r(617), t)
                    },
                    617: (e, t) => {
                        Object.defineProperty(t, "__esModule", {
                            value: !0
                        }), t.removeDialCode = void 0, t.removeDialCode = function(e) {
                            var t = e.phone,
                                r = e.dialCode,
                                n = e.prefix,
                                o = void 0 === n ? "+" : n,
                                i = e.charAfterDialCode,
                                d = void 0 === i ? " " : i;
                            if (!t || !r) return t;
                            var a = t;
                            return a.startsWith(o) && (a = a.replace(o, "")), a.startsWith(r) ? ((a = a.replace(r, "")).startsWith(d) && (a = a.replace(d, "")), a) : t
                        }
                    },
                    156: t => {
                        t.exports = e
                    }
                },
                r = {};

            function n(e) {
                var o = r[e];
                if (void 0 !== o) return o.exports;
                var i = r[e] = {
                    exports: {}
                };
                return t[e].call(i.exports, i, i.exports, n), i.exports
            }
            n.r = e => {
                "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                    value: "Module"
                }), Object.defineProperty(e, "__esModule", {
                    value: !0
                })
            };
            var o = {};
            return (() => {
                var e = o;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.parseCountry = e.buildCountryData = e.usePhoneInput = e.defaultCountries = e.PhoneInput = e.FlagEmoji = e.DialCodePreview = e.CountrySelectorDropdown = e.CountrySelector = void 0;
                var t = n(110);
                Object.defineProperty(e, "CountrySelector", {
                    enumerable: !0,
                    get: function() {
                        return t.CountrySelector
                    }
                });
                var r = n(946);
                Object.defineProperty(e, "CountrySelectorDropdown", {
                    enumerable: !0,
                    get: function() {
                        return r.CountrySelectorDropdown
                    }
                });
                var i = n(805);
                Object.defineProperty(e, "DialCodePreview", {
                    enumerable: !0,
                    get: function() {
                        return i.DialCodePreview
                    }
                });
                var d = n(289);
                Object.defineProperty(e, "FlagEmoji", {
                    enumerable: !0,
                    get: function() {
                        return d.FlagEmoji
                    }
                });
                var a = n(519);
                Object.defineProperty(e, "PhoneInput", {
                    enumerable: !0,
                    get: function() {
                        return a.PhoneInput
                    }
                });
                var s = n(445);
                Object.defineProperty(e, "defaultCountries", {
                    enumerable: !0,
                    get: function() {
                        return s.defaultCountries
                    }
                });
                var u = n(268);
                Object.defineProperty(e, "usePhoneInput", {
                    enumerable: !0,
                    get: function() {
                        return u.usePhoneInput
                    }
                });
                var l = n(197);
                Object.defineProperty(e, "buildCountryData", {
                    enumerable: !0,
                    get: function() {
                        return l.buildCountryData
                    }
                }), Object.defineProperty(e, "parseCountry", {
                    enumerable: !0,
                    get: function() {
                        return l.parseCountry
                    }
                })
            })(), o
        })(), e.exports = r(t)
    }(gs);
    var bs = gs.exports;
    const ws = t.forwardRef(((e, r) => {
            const {
                required: n,
                country: o,
                cornerRadius: i,
                placeholder: d,
                colors: a,
                size: s,
                error: u,
                alreadyError: l,
                value: c,
                onChange: f,
                showErrorText: $,
                errorCodeList: p
            } = e, [h, m] = t.useState($), [_, y] = t.useState(o);
            t.useEffect((() => {
                $ && m(!0)
            }), [$]), t.useEffect((() => {
                $ && m(!1)
            }), [_]), t.useEffect((() => {
                let e = bs.defaultCountries.find((e => e[2] == o.toLocaleLowerCase()));
                e && e[3] !== c && (m(!1), "function" == typeof f && f("+" + e[3]))
            }), [o]), t.useImperativeHandle(r, (() => ({
                updateInputErrorShow() {
                    m(!0)
                }
            })));
            const v = $ && h && (n || function(e) {
                    var t;
                    const r = e.trim().match(/^\+\d+\s*(\d.*)?$/);
                    if (r) return ((null == (t = r[1]) ? void 0 : t.trim()) || "").length > 0;
                    return !1
                }(c)) && !as(c),
                g = p.includes(hs.AlreadySubscribe);
            return jo("div", {
                children: [Ao(bs.PhoneInput, {
                    style: {
                        "--react-international-phone-text-color": a.input
                    },
                    className: Go(vs.inputWrapper, gi("Modal__Phone"), vs[`radius-${i}`], vs[`size-${s}`]),
                    defaultCountry: o.toLocaleLowerCase(),
                    value: c,
                    placeholder: d,
                    onChange: (e, t) => {
                        y(t), "function" == typeof f && f(e)
                    }
                }), (v || p.includes(hs.PhoneInvalid)) && !g && Ao(Vi, {
                    embed: !0,
                    errText: u,
                    colors: a
                }), g && Ao(Vi, {
                    embed: !0,
                    errText: l,
                    colors: a
                })]
            })
        })),
        Cs = "_pretty_1n924_2",
        Ss = "_state_1n924_25",
        Ps = "_svg_1n924_25",
        Os = "_richTextStyle_1n924_89",
        xs = e => {
            let {
                value: t,
                onChange: r
            } = e, {
                labelText: n,
                svgColor: o = "#089BE9"
            } = e;
            return jo("div", {
                className: Cs,
                children: [Ao("input", {
                    type: "checkbox",
                    name: "checkbox",
                    checked: t,
                    onChange: () => r(!t)
                }), jo("div", {
                    className: Ss,
                    children: [Ao("svg", {
                        className: Ps,
                        viewBox: "0 0 1260 1024",
                        children: Ao("path", {
                            d: "M157.538462 315.076923l275.692307 315.076923L1142.153846 0l118.153846 118.153846-827.076923 905.846154L0 433.230769z",
                            fill: o,
                            "p-id": "10987"
                        })
                    }), Ao("label", {
                        className: Os,
                        dangerouslySetInnerHTML: {
                            __html: n
                        }
                    })]
                })]
            })
        },
        Es = {
            checkedWrapper: "_checkedWrapper_tibs3_2",
            small: "_small_tibs3_8"
        },
        Ms = e => {
            let {
                content: t,
                value: r,
                onChange: n,
                error: o,
                colors: i,
                size: d,
                showErrorText: a
            } = e;
            return jo("div", {
                className: Go(gi("Modal__PolicyBoxWrapper"), Es.checkedWrapper, Es[d]),
                style: {
                    color: `${i.checkbox}`
                },
                children: [Ao(xs, {
                    value: r,
                    onChange: n,
                    labelText: t
                }), a && 0 == r && Ao(Vi, {
                    errText: o,
                    colors: i
                })]
            })
        },
        Ds = (e, t) => {
            let {
                enabled: r,
                type: n,
                open_specific_page: o,
                open_specific_page_new_window: i
            } = e;
            r && (n === Nn.Close ? t() : n === Nn.OpenSpecificPage && o && window.open(o, i ? "_blank" : "_self"))
        },
        Ns = (e, t) => {
            let {
                action: r,
                link: n,
                new_context: o
            } = e;
            r === Mn.CLOSE ? t() : r === Mn.LINK && n && window.open(n, o ? "_blank" : "_self")
        },
        Is = (e, t) => {
            if ("<p></p>" === e) return "";
            let r = e.replaceAll("<li>\n<a href=", "<li><a href=");
            return t ? r.replaceAll('target="_self"', 'target="_blank"') : r
        },
        ks = t.forwardRef(((e, r) => {
            const {
                forms: n,
                formsIndex: o,
                actions: i,
                errorText: d,
                cornerRadius: a,
                isAdmin: s,
                size: u,
                isMobile: l,
                colors: c,
                actionMap: f
            } = e, $ = [];
            o.forEach((e => {
                n[e] && n[e].enabled && $.push(n[e])
            }));
            const [p, h] = t.useState(!1), [m, _] = t.useState([]), [y, v] = t.useState(""), [g, b] = t.useState(""), [w, C] = t.useState(""), [S, P] = t.useState(""), [O, x] = t.useState(""), [E, M] = t.useState(""), [D, N] = t.useState(""), [I, k] = t.useState(!1), [T, A] = t.useState(!1), [j, R] = t.useState(!1), L = t.useRef(null);
            t.useImperativeHandle(r, (() => ({
                clearForm: () => {
                    if (h(!1), _([]), v(""), b(""), C(""), P(""), x(""), M(""), n.phone) {
                        const e = bs.defaultCountries.find((e => e[2] == n.phone.country.toLocaleLowerCase()));
                        e && e[3] !== D && N("+" + e[3])
                    }
                    k(!1), A(!1)
                }
            })));
            const F = () => {
                L.current && L.current.updateInputErrorShow();
                const e = {
                    email: y,
                    phone: D,
                    first_name: g,
                    last_name: w,
                    birthday: `${S}-${O}-${E}`,
                    year: S,
                    month: O,
                    day: E,
                    gdpr: T,
                    tcpa: I
                };
                "" === e.birthday.replaceAll("-", "") && (e.birthday = "");
                const [t, r] = (e => {
                    let {
                        formsIndex: t,
                        forms: r,
                        data: n
                    } = e, o = [];
                    return t.forEach((e => {
                        r[e].enabled && ((e === xn.EMAIL && r[e].required && !ud(n.email) || e === xn.EMAIL && !r[e].required && n.email && !ud(n.email)) && o.push("email"), e === xn.NAME && (r[e].field_type !== En.LAST && r[e].first_name.required && Qi(n.first_name) && o.push("first_name"), r[e].field_type !== En.FIRST && r[e].last_name.required && Qi(n.last_name) && o.push("last_name")), e === xn.PHONE && r[e].required && !as(n.phone) && o.push("phone"), e !== xn.PHONE || r[e].required || (("" === n.phone || 1 === n.phone.split(" ").length || n.phone.length <= 3) && (n.phone = ""), "" === n.phone || as(n.phone) || o.push("phone")), e !== xn.GDPR || n.gdpr || o.push("gdpr"), e !== xn.TCPA || n.tcpa || o.push("tcpa"), e === xn.BIRTHDAY && (n.birthday.replaceAll("-", "") || r[e].required) && (us(n.birthday) || o.push("birthday")))
                    })), [0 !== o.length, o]
                })({
                    formsIndex: o,
                    forms: n,
                    data: e
                });
                if (t) {
                    const e = r[0] === ss.PhoneError,
                        t = e ? document.querySelector(".react-international-phone-input") : document.getElementById(r[0]);
                    return e && (t.value = D), t && t.focus(), void h(!0)
                }
                _([]), R(!0), f.submit(e).then((e => {
                    _([]), setTimeout((() => {
                        R(!0)
                    }), e.timer || 0)
                })).catch((e => {
                    var t;
                    R(!1), e && (_(e), e.includes(hs.PhoneInvalid) && document.querySelector(".react-international-phone-input").focus(), e.includes(hs.EmailInvalid) && (null == (t = document.getElementById("email")) || t.focus()))
                }))
            };
            return t.useEffect((() => {
                var e, t, r;
                (null == (r = null == (t = null == (e = null == window ? void 0 : window.EcomSendApps) ? void 0 : e.common) ? void 0 : t.customer) ? void 0 : r.email) && v(window.EcomSendApps.common.customer.email), window.setPopupEmail = e => v(e)
            }), []), jo(Ro, {
                children: [o.map((e => {
                    if (n[e].enabled) switch (e) {
                        case xn.NAME:
                            return t.createElement(ys, __spreadProps(__spreadValues({}, n[e]), {
                                error: {
                                    first_name: d.first_name,
                                    last_name: d.last_name
                                },
                                cornerRadius: a,
                                size: u,
                                colors: c,
                                firstValue: g,
                                lastValue: w,
                                onChange: (e, t) => {
                                    "first" === t && b(e), "last" === t && C(e)
                                },
                                showErrorText: p,
                                key: e
                            }));
                        case xn.EMAIL:
                            return t.createElement(ms, __spreadProps(__spreadValues({}, n[e]), {
                                error: d.invalid_email,
                                alreadyError: d.already_subscribed,
                                cornerRadius: a,
                                size: u,
                                colors: c,
                                value: y,
                                onChange: v,
                                showErrorText: p,
                                errorCodeList: m,
                                key: e
                            }));
                        case xn.PHONE:
                            return t.createElement(ws, __spreadProps(__spreadValues({}, n[e]), {
                                error: d.phone_number,
                                alreadyError: d.already_subscribed,
                                cornerRadius: a,
                                size: u,
                                colors: c,
                                value: D,
                                onChange: N,
                                showErrorText: p,
                                errorCodeList: m,
                                ref: L,
                                key: e
                            }));
                        case xn.BIRTHDAY:
                            return t.createElement(ps, __spreadProps(__spreadValues({}, n[e]), {
                                error: d.invalid_birthday,
                                cornerRadius: a,
                                size: u,
                                isMobile: l,
                                colors: c,
                                yearValue: S,
                                monthValue: O,
                                dayValue: E,
                                onChange: (e, t) => {
                                    ((e, t) => {
                                        "year" === t && P(e), "month" === t && x(e), "day" === t && M(e)
                                    })(e, t)
                                },
                                showErrorText: p,
                                key: e
                            }));
                        case xn.TCPA:
                            return t.createElement(Ms, __spreadProps(__spreadValues({}, n[e]), {
                                error: d.policy_not_checked,
                                colors: c,
                                size: u,
                                value: I,
                                onChange: k,
                                showErrorText: p,
                                content: Is(n[e].content, s),
                                key: e
                            }));
                        case xn.GDPR:
                            return t.createElement(Ms, __spreadProps(__spreadValues({}, n[e]), {
                                error: d.policy_not_checked,
                                colors: c,
                                size: u,
                                value: T,
                                onChange: A,
                                showErrorText: p,
                                content: Is(n[e].content, s),
                                key: e
                            }));
                        default:
                            return null
                    }
                })), i.primary_btn.enabled && Ao(Oi, {
                    shape: a,
                    colors: c,
                    size: u,
                    buttonTextConfig: i.primary_btn.text,
                    loading: j,
                    onClick: () => {
                        if (s || j) return;
                        const {
                            action: e,
                            link: t,
                            new_context: r
                        } = i.primary_btn;
                        e === Mn.LINK && t ? window.open(t, r ? "_blank" : "_self") : e === Mn.SUBMIT ? F() : e === Mn.CLOSE && f.close()
                    }
                })]
            })
        }));

    function Ts({
        popupId: e,
        myDialogStyle: t,
        successStatus: r,
        textConfig: n,
        isAdmin: o,
        isHideRemove: i,
        marketingBranding: d,
        colors: a,
        manuallyCode: s,
        isNoDiscount: u,
        isManuallyCode: l,
        onClose: c
    }) {
        const {
            start_status: f,
            success_status: $,
            error_text: p
        } = n, {
            size: h,
            alignment: m,
            cornerRadius: _,
            logoURL: y,
            logoWidth: v,
            imgLayout: g,
            imgMobilePosition: b,
            imgURL: w
        } = t, {
            IntentionsStore: C,
            ConfigStore: S
        } = ao;

        function P(t) {
            if (e) return new Promise((async (r, n) => {
                try {
                    const {
                        data: o,
                        status: i
                    } = await pn.subscribed(__spreadValues({
                        popupId: e
                    }, t));
                    if (wi.OK === i) {
                        let t = Hn().add(365, "day");
                        io.setCookie(Jn() ? `pp_preview_success_subscribed${e}` : `pp_success_subscribed${e}`, "true", {
                            expires: t.toDate()
                        }), po.setDiscountCode(o.discount_code, Jn() && !0, e), C.setModalSuccessStatus(e, !0), S.setConfig("discount_code", o.discount_code), r(!0)
                    } else n(o.status)
                } catch (o) {
                    n([hs.SubmitFail])
                }
            }))
        }
        const O = ({
            titleText: e,
            titleHelpText: t
        }) => Ao(Do, {
            children: () => jo(Ro, {
                children: [e && Ao("header", {
                    className: Go(gi("Modal__TitleText"), Yi.titleText, Yi[h]),
                    style: {
                        color: `${null==a?void 0:a.text_heading_color}`
                    },
                    children: e
                }), t && Ao("div", {
                    className: Go(gi("Modal__TitleHelpText"), Yi.titleHelpText, Yi[h]),
                    style: {
                        color: `${null==a?void 0:a.text_description_color}`
                    },
                    children: t
                })]
            })
        });
        return Ao(Do, {
            children: () => Ao("div", {
                className: Go(gi("Modal__Container"), Yi.modalContainer, o ? null : Yi.adminModalContainer),
                children: jo("div", {
                    className: Go(gi("Modal__Content"), Yi.modalContent, Yi[`size-${h}`], Yi[`cornerRadius-${_}`], ["left", "right"].includes(g) ? Yi[g] : null, ["left", "right"].includes(g) && "background" === b ? Yi.mobilePosition : null),
                    style: w && ("background" === g || ["left", "right"].includes(g) && "background" === b) ? {
                        backgroundColor: `${null==a?void 0:a.popup_background_color}`,
                        "--backgroundImage": `url(${w})`,
                        backgroundImage: "var(--backgroundImage)",
                        backgroundPosition: "center",
                        backgroundRepeat: "no-repeat",
                        backgroundSize: "cover"
                    } : {
                        backgroundColor: `${null==a?void 0:a.popup_background_color}`
                    },
                    children: [
                        ["left", "right"].includes(g) && Ao("div", {
                            className: Go(gi("Modal__CustomPic"), Yi.customPic),
                            style: {
                                backgroundImage: `url(${w})`,
                                backgroundPosition: "center",
                                backgroundRepeat: "no-repeat",
                                backgroundSize: "cover"
                            }
                        }), Ao("div", {
                            className: Go(gi("Modal__CustomDialogWrapper"), Yi.myCustomDialogWrapper),
                            children: jo("div", {
                                className: Go(gi("Modal__CustomDialog"), Yi.myCustomDialog, Yi[m]),
                                children: [Ao("div", {
                                    className: Go(gi("Modal__CloseButton"), Yi.closeBtn),
                                    onClick: c,
                                    children: Ao(Ci, {})
                                }), y ? Ao("img", {
                                    className: Yi.myLogoImg,
                                    src: y,
                                    alt: "logo",
                                    style: {
                                        "--width": `${v}%`
                                    }
                                }) : null, Ao(O, {
                                    titleText: r ? $.heading : f.heading,
                                    titleHelpText: r ? $.description : f.description
                                }), !r && Ao(ks, {
                                    isAdmin: o,
                                    forms: f.forms,
                                    formsIndex: f.forms_index,
                                    actions: f.actions,
                                    errorText: p,
                                    cornerRadius: _,
                                    size: h,
                                    colors: a,
                                    actionMap: {
                                        close: c,
                                        submit: P
                                    }
                                }), r && !u && Ao(Bi, {
                                    size: h,
                                    shape: _,
                                    id: "Discount_code",
                                    color: a.primary_button_background_color,
                                    manuallyCode: s,
                                    value: e && C.modal_success_status_list[e] ? S.discount_code : "",
                                    placeholder: "Discount_code",
                                    isSuccess: r,
                                    isManuallyCode: l,
                                    onChange: () => {}
                                }), r && $.button_action.enabled && Ao(Oi, {
                                    classNames: gi("Button__Success_status"),
                                    colors: a,
                                    buttonTextConfig: $.button_text,
                                    size: h,
                                    onClick: () => {
                                        !o && Ds($.button_action, c)
                                    },
                                    shape: _
                                }), !r && jo(Ro, {
                                    children: [f.actions.secondary_btn.enabled && f.actions.secondary_btn.text && Ao("div", {
                                        onClick: () => {
                                            !o && Ns(f.actions.secondary_btn, c)
                                        },
                                        className: Go(gi("Modal__CloseText"), Yi.closeText, Yi[h]),
                                        style: {
                                            "--color": `${null==a?void 0:a.secondary_button}`,
                                            background: `${null==a?void 0:a.secondary_button}`
                                        },
                                        children: f.actions.secondary_btn.text
                                    }), f.footer_text && Ao("div", {
                                        className: Go(gi("Modal__DescriptionText"), Yi.descriptionText, Yi[h]),
                                        style: {
                                            color: `${null==a?void 0:a.footer_text_color}`
                                        },
                                        dangerouslySetInnerHTML: {
                                            __html: Is(f.footer_text, o)
                                        }
                                    })]
                                })]
                            })
                        })
                    ]
                })
            })
        })
    }
    const As = {
        modalContainer: "_modalContainer_rg2mi_2",
        adminModalContainer: "_adminModalContainer_rg2mi_6",
        modalContent: "_modalContent_rg2mi_15",
        forbidUserSelect: "_forbidUserSelect_rg2mi_20",
        customDialogWrapper: "_customDialogWrapper_rg2mi_23",
        closeBtn: "_closeBtn_rg2mi_33",
        customDialog: "_customDialog_rg2mi_23",
        spinWheelWrapper: "_spinWheelWrapper_rg2mi_63",
        customDialogContent: "_customDialogContent_rg2mi_69",
        middleWrapper: "_middleWrapper_rg2mi_78",
        myLogoImg: "_myLogoImg_rg2mi_81",
        descriptionText: "_descriptionText_rg2mi_85",
        small: "_small_rg2mi_106",
        center: "_center_rg2mi_126",
        left: "_left_rg2mi_140",
        closeText: "_closeText_rg2mi_143",
        right: "_right_rg2mi_152",
        marketingBranding: "_marketingBranding_rg2mi_165",
        greySign: "_greySign_rg2mi_174",
        blueText: "_blueText_rg2mi_185",
        errContent: "_errContent_rg2mi_217",
        errIcon: "_errIcon_rg2mi_224",
        errText: "_errText_rg2mi_236",
        hideBackground: "_hideBackground_rg2mi_304"
    };
    let js = [4, 5, 0, 1, 2, 3],
        Rs = [3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2];
    const Ls = e => Ao(Do, {
            children: () => {
                let {
                    mustSpin: t,
                    setMustSpin: r,
                    rewards: o,
                    colors: i,
                    prizeNumber: d
                } = e, a = [];
                return o = function(e, t) {
                    let r = [],
                        n = 0;
                    for (; n < e.length; n++) r.push(e[n + t]), n + t >= e.length - 1 && (t = 0 - (n + 1));
                    return r
                }(o, 2), d = js[d], [...o, ...o].forEach(((e, t) => {
                    a.push({
                        option: e.label,
                        style: {
                            textAlign: "right",
                            backgroundColor: i[`bg${Rs[t]}`],
                            textColor: i[`text${Rs[t]}`]
                        }
                    })
                })), Ao(n.Wheel, {
                    mustStartSpinning: t,
                    prizeNumber: d,
                    data: a,
                    outerBorderWidth: 0,
                    radiusLineColor: "none",
                    innerBorderWidth: 0,
                    spinDuration: .6,
                    textDistance: 58,
                    fontSize: 15,
                    onStopSpinning: () => {
                        r(!1)
                    }
                })
            }
        }),
        Fs = {
            titleText: "_titleText_1naa9_2",
            titleTextMobile: "_titleTextMobile_1naa9_12",
            small: "_small_1naa9_22",
            large: "_large_1naa9_25",
            titleHelpText: "_titleHelpText_1naa9_29",
            titleHelpTextMobile: "_titleHelpTextMobile_1naa9_61",
            closeText: "_closeText_1naa9_73",
            descriptionText: "_descriptionText_1naa9_94",
            errContent: "_errContent_1naa9_116"
        },
        Bs = ({
            titleText: e,
            titleHelpText: t,
            colors: r,
            size: n,
            fontSize: o,
            isMobile: i
        }) => Ao(Do, {
            children: () => jo(Ro, {
                children: [e && Ao("header", {
                    className: Go(bi("Modal__TitleText"), i ? Fs.titleTextMobile : Fs.titleText, Fs[n]),
                    style: {
                        color: `${null==r?void 0:r.text_heading_color}`,
                        fontSize: o
                    },
                    children: e
                }), t && Ao("div", {
                    className: Go(bi("Modal__TitleHelpText"), i ? Fs.titleHelpTextMobile : Fs.titleHelpText, Fs[n]),
                    style: {
                        color: `${null==r?void 0:r.text_description_color}`
                    },
                    children: t
                })]
            })
        });

    function Ys({
        popupId: e,
        forbidUserSelect: r,
        rulesConfig: n,
        myDialogStyle: o,
        successStatus: i,
        textConfig: d,
        isAdmin: a,
        marketingBranding: s,
        colors: u,
        manuallyCode: l,
        isHideRemove: c,
        isManuallyCode: f,
        onClose: $
    }) {
        const {
            IntentionsStore: p
        } = ao, {
            start_status: h,
            success_status: m,
            error_text: _
        } = d, y = t.useRef(null), {
            size: v,
            alignment: g,
            cornerRadius: b,
            logoURL: w,
            logoWidth: C,
            imgURL: S,
            hideOnMobile: P
        } = o, [O, x] = t.useState(!1), [E, M] = t.useState(0);
        let [D, N] = t.useState(m.heading), [I, k] = t.useState(m.description);
        const T = t.useRef(null);

        function A(t) {
            if (e) return new Promise((async (r, o) => {
                try {
                    const {
                        data: i,
                        status: d
                    } = await pn.subscribed(__spreadValues({
                        popupId: e
                    }, t));
                    if (wi.OK === d) {
                        (() => {
                            let e = null;
                            clearInterval(e), e = setInterval((() => {
                                var t, r, n;
                                0 != (null == (t = null == T ? void 0 : T.current) ? void 0 : t.scrollTop) ? null == (n = null == T ? void 0 : T.current) || n.scroll(0, Math.max((null == (r = null == T ? void 0 : T.current) ? void 0 : r.scrollTop) - 50, 0)) : clearInterval(e)
                            }), 10)
                        })(), M(i.reward_index), x(!0);
                        let t = Hn().add(365, "day");
                        setTimeout((() => {
                            io.setCookie(Jn() ? `pp_preview_success_subscribed${e}` : `pp_success_subscribed${e}`, "true", {
                                expires: t.toDate()
                            }), io.setCookie(Jn() ? `pp_preview_success_subscribed${e}_reward_index` : `pp_success_subscribed${e}_reward_index`, `${i.reward_index}`, {
                                expires: t.toDate()
                            }), po.setDiscountCode(i.discount_code, Jn() && !0, e), p.setModalSuccessStatus(e, !0), N(D.replaceAll("{{reward_label}}", n.rewards[i.reward_index].label)), k(I.replaceAll("{{reward_label}}", n.rewards[i.reward_index].label))
                        }), 7e3), r({
                            timer: 7e3
                        })
                    } else o(i.status)
                } catch (i) {
                    o([hs.SubmitFail])
                }
            }))
        }
        const j = () => {
            $(), y.current && y.current.clearForm()
        };
        return Ao(Do, {
            children: () => {
                io.getCookie(Jn() ? `pp_preview_success_subscribed${e}` : `pp_success_subscribed${e}`);
                let t = Jn() ? io.getCookie(`preview_discount_code${e}`) : io.getCookie(`discount_code${e}`);
                return Ao("div", {
                    className: Go(bi("Modal__Container"), As.modalContainer, r ? As.forbidUserSelect : "", a ? As.adminModalContainer : null),
                    children: Ao("div", {
                        className: Go(bi("Modal__Content"), As.modalContent, P ? As.hideBackground : "", As[`size-${v}`], As[`cornerRadius-${b}`]),
                        style: {
                            backgroundColor: `${null==u?void 0:u.popup_background_color}`,
                            backgroundImage: S ? `url(${S})` : "",
                            backgroundPosition: "center",
                            backgroundRepeat: "no-repeat",
                            backgroundSize: "cover"
                        },
                        children: Ao("div", {
                            className: Go(bi("Modal__CustomDialogWrapper"), As.customDialogWrapper),
                            children: jo("div", {
                                className: Go(bi("Modal__CustomDialog"), As.customDialog),
                                ref: T,
                                children: [Ao("div", {
                                    className: Go(bi("Modal__CloseButton"), As.closeBtn),
                                    onClick: j,
                                    children: Ao(Ci, {})
                                }), Ao("div", {
                                    className: Go(bi("Modal__SpinWheelWrapper"), As.spinWheelWrapper),
                                    children: Ao(Ls, {
                                        colors: u.wheel,
                                        rewards: n.rewards,
                                        prizeNumber: E,
                                        mustSpin: O,
                                        setMustSpin: x
                                    })
                                }), Ao("div", {
                                    className: Go(bi("Modal__CustomDialogContent"), As.customDialogContent, As[g]),
                                    children: jo("div", {
                                        className: Go(bi("Modal__MiddleWrapper"), As.middleWrapper),
                                        children: [w && Ao("img", {
                                            className: As.myLogoImg,
                                            src: w,
                                            alt: "logo",
                                            style: {
                                                "--width": `${C}%`
                                            }
                                        }), Ao(Bs, {
                                            titleText: i ? a ? m.heading : D : h.heading,
                                            titleHelpText: i ? a ? m.description : I : h.description,
                                            colors: u
                                        }), !i && Ao(ks, {
                                            ref: y,
                                            isAdmin: a,
                                            forms: h.forms,
                                            formsIndex: h.forms_index,
                                            actions: h.actions,
                                            errorText: _,
                                            cornerRadius: b,
                                            size: v,
                                            colors: u,
                                            actionMap: {
                                                close: j,
                                                submit: A
                                            }
                                        }), jo("div", {
                                            children: [i && Ao(Bi, {
                                                size: v,
                                                shape: b,
                                                id: "Discount_code",
                                                color: u.primary_button_background_color,
                                                manuallyCode: l,
                                                value: t,
                                                placeholder: "Discount_code",
                                                isSuccess: i,
                                                isManuallyCode: f,
                                                onChange: () => {}
                                            }), i && m.button_action.enabled && Ao(Oi, {
                                                classNames: gi("Button__Success_status"),
                                                colors: u,
                                                buttonTextConfig: m.button_text,
                                                size: v,
                                                onClick: () => {
                                                    !a && Ds(m.button_action, j)
                                                },
                                                shape: b
                                            })]
                                        }), !i && jo(Ro, {
                                            children: [h.actions.secondary_btn.enabled && h.actions.secondary_btn.text && Ao("div", {
                                                onClick: () => {
                                                    !a && Ns(h.actions.secondary_btn, j)
                                                },
                                                className: Go(bi("Modal__CloseText"), As.closeText),
                                                style: {
                                                    "--color": `${null==u?void 0:u.secondary_button}`,
                                                    background: `${null==u?void 0:u.secondary_button}`
                                                },
                                                children: h.actions.secondary_btn.text
                                            }), h.footer_text && Ao("div", {
                                                className: Go(bi("Modal__DescriptionText"), As.descriptionText),
                                                style: {
                                                    color: `${null==u?void 0:u.footer_text_color}`
                                                },
                                                dangerouslySetInnerHTML: {
                                                    __html: Is(h.footer_text, a)
                                                }
                                            })]
                                        })]
                                    })
                                })]
                            })
                        })
                    })
                })
            }
        })
    }
    const Us = "_myCustomSticky_1x33c_2",
        zs = "_stickyBarCloseBtn_1x33c_11",
        Ws = "_mobilePlatform_1x33c_19",
        Gs = "_pcPlatform_1x33c_23",
        Hs = "_stickyContentBox_1x33c_26",
        Vs = "_discountText_1x33c_36";

    function qs({
        popupId: e,
        discountType: r,
        discountCode: n,
        manuallyCode: o,
        colors: i,
        stickyBarDescription: d,
        myStickyBarStyle: a,
        mobilePlatformParam: s
    }) {
        var u;
        const l = a,
            {
                sticky_discount_bar_background_color: c,
                sticky_discount_bar_text_color: f
            } = i;
        return t.useEffect((() => {
            var t, r;
            const n = null == (t = document.getElementById(`sticky-bar-${e}`)) ? void 0 : t.offsetHeight;
            let o = document.querySelector(".EcomSendAPP") ? document.querySelector(".EcomSendAPP").offsetHeight : 0;
            null == (r = document.querySelector(".EcomSendAPP")) || r.setAttribute("style", `height:${o+(n||0)}px`)
        }), []), Ao(Ro, {
            children: jo("div", {
                id: `sticky-bar-${e}`,
                className: Go(gi("Popover__Sticky"), Us, "sticky-bar_unset"),
                style: __spreadProps(__spreadValues({
                    top: document.querySelector(".EcomSendAPP") ? document.querySelector(".EcomSendAPP").offsetHeight - ((null == (u = document.getElementById(`sticky-bar-${e}`)) ? void 0 : u.offsetHeight) || 0) : 0
                }, l), {
                    background: `${c}`
                }),
                children: [jo("div", {
                    className: Go(gi("Popover__Sticky__Container"), Hs, s ? Ws : Gs),
                    children: [Ao("span", {
                        className: Go(gi("Popover__Sticky__DiscountText"), Vs),
                        style: {
                            color: `${f}`
                        },
                        children: d
                    }), Ao(Bi, {
                        value: "manually_code" === r ? o : n,
                        placeholder: "Discount_code",
                        size: "regular",
                        shape: "small",
                        color: "#6C6B80",
                        isSuccess: !0,
                        fromSticky: !0,
                        stickyBarCustomStyle: !s,
                        block: !!s,
                        onChange: () => {}
                    })]
                }), Ao("div", {
                    className: Go(gi("Popover__Sticky__CloseButton"), zs, s ? Ws : Gs),
                    onClick: () => {
                        var t, r;
                        if (!e) return;
                        po.removeModal("forever", e);
                        let n = document.querySelector(".EcomSendAPP").offsetHeight;
                        const o = null == (t = document.getElementById(`sticky-bar-${e}`)) ? void 0 : t.offsetHeight;
                        null == (r = document.querySelector(".EcomSendAPP")) || r.setAttribute("style", `height:${n-(o||0)}px`)
                    },
                    children: Ao(Ci, {})
                })]
            })
        })
    }
    const Ks = e => jo("svg", __spreadProps(__spreadValues({
            width: 28,
            height: 28,
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        }, e), {
            children: [Ao("g", {
                filter: "url(#widget_btn_svg__a)",
                children: Ao("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M14 22c5.523 0 10-4.477 10-10S19.523 2 14 2 4 6.477 4 12s4.477 10 10 10Zm4.817-13.933L14.884 12l3.933 3.933a.625.625 0 1 1-.884.884L14 12.884l-3.933 3.933a.625.625 0 0 1-.884-.884L13.116 12 9.183 8.067a.625.625 0 0 1 .884-.884L14 11.116l3.933-3.933a.625.625 0 0 1 .884.884Z",
                    fill: "#fff"
                })
            }), Ao("defs", {
                children: jo("filter", {
                    id: "widget_btn_svg__a",
                    x: 0,
                    y: 0,
                    width: 28,
                    height: 28,
                    filterUnits: "userSpaceOnUse",
                    colorInterpolationFilters: "sRGB",
                    children: [Ao("feFlood", {
                        floodOpacity: 0,
                        result: "BackgroundImageFix"
                    }), Ao("feColorMatrix", { in: "SourceAlpha",
                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                        result: "hardAlpha"
                    }), Ao("feOffset", {
                        dy: 2
                    }), Ao("feGaussianBlur", {
                        stdDeviation: 2
                    }), Ao("feColorMatrix", {
                        values: "0 0 0 0 0.0705882 0 0 0 0 0.0666667 0 0 0 0 0.152941 0 0 0 0.2 0"
                    }), Ao("feBlend", {
                        in2: "BackgroundImageFix",
                        result: "effect1_dropShadow_90_3334"
                    }), Ao("feBlend", { in: "SourceGraphic",
                        in2: "effect1_dropShadow_90_3334",
                        result: "shape"
                    })]
                })
            })]
        })),
        Zs = "_widgetContent_1qtor_2",
        Js = "_mobilePlatform_1qtor_7",
        Xs = "_left_1qtor_11",
        Qs = "_right_1qtor_14",
        eu = "_widgetIndexTop_1qtor_17",
        tu = "_myCustomWidget_1qtor_20",
        ru = "_mobile_left_1qtor_30",
        nu = "_mobile_right_1qtor_34",
        ou = "_widgetText_1qtor_41",
        iu = "_stickyWidgetCloseBtn_1qtor_49";

    function du({
        popupId: e,
        widgetText: t,
        position: r,
        mobilePlatformParam: n,
        colors: o,
        fixedPosition: i,
        onOpen: d,
        isSpinWheel: a
    }) {
        const {
            IntentionsStore: s
        } = ao, {
            sidebar_widget_background_color: u,
            sidebar_widget_text_color: l
        } = o, c = Go(gi("Popover__Widget"), Zs, fe(r, yn.LEFT) && [Xs], fe(r, yn.RIGHT) && [Qs], n && [Js], a && eu);
        return Ao(Ro, {
            children: Ao("div", {
                className: Go(gi("Popover__Widget"), c),
                style: i ? {
                    position: "fixed",
                    top: "-10vh"
                } : {
                    position: "relative",
                    top: "-10vh"
                },
                children: jo("div", {
                    className: Go(gi("Popover__Widget__CustomContainer"), gi(fe(r, yn.LEFT) ? "Popover__Widget__left" : fe(r, yn.RIGHT) ? "Popover__Widget__right" : ""), tu, n && [Js], fe(r, yn.LEFT) && [ru], fe(r, yn.RIGHT) && [nu]),
                    style: {
                        background: `${u}`
                    },
                    onClick: d,
                    children: [Ao(Ks, {
                        className: Go(iu, null === r ? null : r === yn.LEFT ? Xs : Qs),
                        onClick: t => {
                            e && s.hideWidgetModal(e), e && io.setSessionStorage(`close_widget_modal${e}`, "true"), t.stopPropagation()
                        }
                    }), Ao("span", {
                        className: Go(gi("Popover__Widget__Text"), ou),
                        style: {
                            color: `${l}`
                        },
                        children: t
                    })]
                })
            })
        })
    }
    var au = {
        exports: {}
    };
    ! function(e) {
        e.exports = function() {
            var e = {
                    LTS: "h:mm:ss A",
                    LT: "h:mm A",
                    L: "MM/DD/YYYY",
                    LL: "MMMM D, YYYY",
                    LLL: "MMMM D, YYYY h:mm A",
                    LLLL: "dddd, MMMM D, YYYY h:mm A"
                },
                t = /(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|Q|YYYY|YY?|ww?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g,
                r = /\d/,
                n = /\d\d/,
                o = /\d\d?/,
                i = /\d*[^-_:/,()\s\d]+/,
                d = {},
                a = function(e) {
                    return (e = +e) + (e > 68 ? 1900 : 2e3)
                },
                s = function(e) {
                    return function(t) {
                        this[e] = +t
                    }
                },
                u = [/[+-]\d\d:?(\d\d)?|Z/, function(e) {
                    (this.zone || (this.zone = {})).offset = function(e) {
                        if (!e) return 0;
                        if ("Z" === e) return 0;
                        var t = e.match(/([+-]|\d\d)/g),
                            r = 60 * t[1] + (+t[2] || 0);
                        return 0 === r ? 0 : "+" === t[0] ? -r : r
                    }(e)
                }],
                l = function(e) {
                    var t = d[e];
                    return t && (t.indexOf ? t : t.s.concat(t.f))
                },
                c = function(e, t) {
                    var r, n = d.meridiem;
                    if (n) {
                        for (var o = 1; o <= 24; o += 1)
                            if (e.indexOf(n(o, 0, t)) > -1) {
                                r = o > 12;
                                break
                            }
                    } else r = e === (t ? "pm" : "PM");
                    return r
                },
                f = {
                    A: [i, function(e) {
                        this.afternoon = c(e, !1)
                    }],
                    a: [i, function(e) {
                        this.afternoon = c(e, !0)
                    }],
                    Q: [r, function(e) {
                        this.month = 3 * (e - 1) + 1
                    }],
                    S: [r, function(e) {
                        this.milliseconds = 100 * +e
                    }],
                    SS: [n, function(e) {
                        this.milliseconds = 10 * +e
                    }],
                    SSS: [/\d{3}/, function(e) {
                        this.milliseconds = +e
                    }],
                    s: [o, s("seconds")],
                    ss: [o, s("seconds")],
                    m: [o, s("minutes")],
                    mm: [o, s("minutes")],
                    H: [o, s("hours")],
                    h: [o, s("hours")],
                    HH: [o, s("hours")],
                    hh: [o, s("hours")],
                    D: [o, s("day")],
                    DD: [n, s("day")],
                    Do: [i, function(e) {
                        var t = d.ordinal,
                            r = e.match(/\d+/);
                        if (this.day = r[0], t)
                            for (var n = 1; n <= 31; n += 1) t(n).replace(/\[|\]/g, "") === e && (this.day = n)
                    }],
                    w: [o, s("week")],
                    ww: [n, s("week")],
                    M: [o, s("month")],
                    MM: [n, s("month")],
                    MMM: [i, function(e) {
                        var t = l("months"),
                            r = (l("monthsShort") || t.map((function(e) {
                                return e.slice(0, 3)
                            }))).indexOf(e) + 1;
                        if (r < 1) throw new Error;
                        this.month = r % 12 || r
                    }],
                    MMMM: [i, function(e) {
                        var t = l("months").indexOf(e) + 1;
                        if (t < 1) throw new Error;
                        this.month = t % 12 || t
                    }],
                    Y: [/[+-]?\d+/, s("year")],
                    YY: [n, function(e) {
                        this.year = a(e)
                    }],
                    YYYY: [/\d{4}/, s("year")],
                    Z: u,
                    ZZ: u
                };

            function $(r) {
                var n, o;
                n = r, o = d && d.formats;
                for (var i = (r = n.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, (function(t, r, n) {
                        var i = n && n.toUpperCase();
                        return r || o[n] || e[n] || o[i].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, (function(e, t, r) {
                            return t || r.slice(1)
                        }))
                    }))).match(t), a = i.length, s = 0; s < a; s += 1) {
                    var u = i[s],
                        l = f[u],
                        c = l && l[0],
                        $ = l && l[1];
                    i[s] = $ ? {
                        regex: c,
                        parser: $
                    } : u.replace(/^\[|\]$/g, "")
                }
                return function(e) {
                    for (var t = {}, r = 0, n = 0; r < a; r += 1) {
                        var o = i[r];
                        if ("string" == typeof o) n += o.length;
                        else {
                            var d = o.regex,
                                s = o.parser,
                                u = e.slice(n),
                                l = d.exec(u)[0];
                            s.call(t, l), e = e.replace(l, "")
                        }
                    }
                    return function(e) {
                        var t = e.afternoon;
                        if (void 0 !== t) {
                            var r = e.hours;
                            t ? r < 12 && (e.hours += 12) : 12 === r && (e.hours = 0), delete e.afternoon
                        }
                    }(t), t
                }
            }
            return function(e, t, r) {
                r.p.customParseFormat = !0, e && e.parseTwoDigitYear && (a = e.parseTwoDigitYear);
                var n = t.prototype,
                    o = n.parse;
                n.parse = function(e) {
                    var t = e.date,
                        n = e.utc,
                        i = e.args;
                    this.$u = n;
                    var a = i[1];
                    if ("string" == typeof a) {
                        var s = !0 === i[2],
                            u = !0 === i[3],
                            l = s || u,
                            c = i[2];
                        u && (c = i[2]), d = this.$locale(), !s && c && (d = r.Ls[c]), this.$d = function(e, t, r, n) {
                            try {
                                if (["x", "X"].indexOf(t) > -1) return new Date(("X" === t ? 1e3 : 1) * e);
                                var o = $(t)(e),
                                    i = o.year,
                                    d = o.month,
                                    a = o.day,
                                    s = o.hours,
                                    u = o.minutes,
                                    l = o.seconds,
                                    c = o.milliseconds,
                                    f = o.zone,
                                    p = o.week,
                                    h = new Date,
                                    m = a || (i || d ? 1 : h.getDate()),
                                    _ = i || h.getFullYear(),
                                    y = 0;
                                i && !d || (y = d > 0 ? d - 1 : h.getMonth());
                                var v, g = s || 0,
                                    b = u || 0,
                                    w = l || 0,
                                    C = c || 0;
                                return f ? new Date(Date.UTC(_, y, m, g, b, w, C + 60 * f.offset * 1e3)) : r ? new Date(Date.UTC(_, y, m, g, b, w, C)) : (v = new Date(_, y, m, g, b, w, C), p && (v = n(v).week(p).toDate()), v)
                            } catch (S) {
                                return new Date("")
                            }
                        }(t, a, n, r), this.init(), c && !0 !== c && (this.$L = this.locale(c).$L), l && t != this.format(a) && (this.$d = new Date("")), d = {}
                    } else if (a instanceof Array)
                        for (var f = a.length, p = 1; p <= f; p += 1) {
                            i[1] = a[p - 1];
                            var h = r.apply(this, i);
                            if (h.isValid()) {
                                this.$d = h.$d, this.$L = h.$L, this.init();
                                break
                            }
                            p === f && (this.$d = new Date(""))
                        } else o.call(this, e)
                }
            }
        }()
    }(au);
    const su = Wn(au.exports);
    var uu = {
        exports: {}
    };
    ! function(e) {
        e.exports = function() {
            var e = {
                    year: 0,
                    month: 1,
                    day: 2,
                    hour: 3,
                    minute: 4,
                    second: 5
                },
                t = {};
            return function(r, n, o) {
                var i, d = function(e, r, n) {
                        void 0 === n && (n = {});
                        var o = new Date(e);
                        return function(e, r) {
                            void 0 === r && (r = {});
                            var n = r.timeZoneName || "short",
                                o = e + "|" + n,
                                i = t[o];
                            return i || (i = new Intl.DateTimeFormat("en-US", {
                                hour12: !1,
                                timeZone: e,
                                year: "numeric",
                                month: "2-digit",
                                day: "2-digit",
                                hour: "2-digit",
                                minute: "2-digit",
                                second: "2-digit",
                                timeZoneName: n
                            }), t[o] = i), i
                        }(r, n).formatToParts(o)
                    },
                    a = function(t, r) {
                        for (var n = d(t, r), i = [], a = 0; a < n.length; a += 1) {
                            var s = n[a],
                                u = s.type,
                                l = s.value,
                                c = e[u];
                            c >= 0 && (i[c] = parseInt(l, 10))
                        }
                        var f = i[3],
                            $ = 24 === f ? 0 : f,
                            p = i[0] + "-" + i[1] + "-" + i[2] + " " + $ + ":" + i[4] + ":" + i[5] + ":000",
                            h = +t;
                        return (o.utc(p).valueOf() - (h -= h % 1e3)) / 6e4
                    },
                    s = n.prototype;
                s.tz = function(e, t) {
                    void 0 === e && (e = i);
                    var r, n = this.utcOffset(),
                        d = this.toDate(),
                        a = d.toLocaleString("en-US", {
                            timeZone: e
                        }),
                        s = Math.round((d - new Date(a)) / 1e3 / 60),
                        u = 15 * -Math.round(d.getTimezoneOffset() / 15) - s;
                    if (Number(u)) {
                        if (r = o(a, {
                                locale: this.$L
                            }).$set("millisecond", this.$ms).utcOffset(u, !0), t) {
                            var l = r.utcOffset();
                            r = r.add(n - l, "minute")
                        }
                    } else r = this.utcOffset(0, t);
                    return r.$x.$timezone = e, r
                }, s.offsetName = function(e) {
                    var t = this.$x.$timezone || o.tz.guess(),
                        r = d(this.valueOf(), t, {
                            timeZoneName: e
                        }).find((function(e) {
                            return "timezonename" === e.type.toLowerCase()
                        }));
                    return r && r.value
                };
                var u = s.startOf;
                s.startOf = function(e, t) {
                    if (!this.$x || !this.$x.$timezone) return u.call(this, e, t);
                    var r = o(this.format("YYYY-MM-DD HH:mm:ss:SSS"), {
                        locale: this.$L
                    });
                    return u.call(r, e, t).tz(this.$x.$timezone, !0)
                }, o.tz = function(e, t, r) {
                    var n = r && t,
                        d = r || t || i,
                        s = a(+o(), d);
                    if ("string" != typeof e) return o(e).tz(d);
                    var u = function(e, t, r) {
                            var n = e - 60 * t * 1e3,
                                o = a(n, r);
                            if (t === o) return [n, t];
                            var i = a(n -= 60 * (o - t) * 1e3, r);
                            return o === i ? [n, o] : [e - 60 * Math.min(o, i) * 1e3, Math.max(o, i)]
                        }(o.utc(e, n).valueOf(), s, d),
                        l = u[0],
                        c = u[1],
                        f = o(l).utcOffset(c);
                    return f.$x.$timezone = d, f
                }, o.tz.guess = function() {
                    return Intl.DateTimeFormat().resolvedOptions().timeZone
                }, o.tz.setDefault = function(e) {
                    i = e
                }
            }
        }()
    }(uu);
    const lu = Wn(uu.exports);
    var cu = {
        exports: {}
    };
    ! function(e) {
        e.exports = function() {
            var e = "minute",
                t = /[+-]\d\d(?::?\d\d)?/g,
                r = /([+-]|\d\d)/g;
            return function(n, o, i) {
                var d = o.prototype;
                i.utc = function(e) {
                    return new o({
                        date: e,
                        utc: !0,
                        args: arguments
                    })
                }, d.utc = function(t) {
                    var r = i(this.toDate(), {
                        locale: this.$L,
                        utc: !0
                    });
                    return t ? r.add(this.utcOffset(), e) : r
                }, d.local = function() {
                    return i(this.toDate(), {
                        locale: this.$L,
                        utc: !1
                    })
                };
                var a = d.parse;
                d.parse = function(e) {
                    e.utc && (this.$u = !0), this.$utils().u(e.$offset) || (this.$offset = e.$offset), a.call(this, e)
                };
                var s = d.init;
                d.init = function() {
                    if (this.$u) {
                        var e = this.$d;
                        this.$y = e.getUTCFullYear(), this.$M = e.getUTCMonth(), this.$D = e.getUTCDate(), this.$W = e.getUTCDay(), this.$H = e.getUTCHours(), this.$m = e.getUTCMinutes(), this.$s = e.getUTCSeconds(), this.$ms = e.getUTCMilliseconds()
                    } else s.call(this)
                };
                var u = d.utcOffset;
                d.utcOffset = function(n, o) {
                    var i = this.$utils().u;
                    if (i(n)) return this.$u ? 0 : i(this.$offset) ? u.call(this) : this.$offset;
                    if ("string" == typeof n && null === (n = function(e) {
                            void 0 === e && (e = "");
                            var n = e.match(t);
                            if (!n) return null;
                            var o = ("" + n[0]).match(r) || ["-", 0, 0],
                                i = o[0],
                                d = 60 * +o[1] + +o[2];
                            return 0 === d ? 0 : "+" === i ? d : -d
                        }(n))) return this;
                    var d = Math.abs(n) <= 16 ? 60 * n : n,
                        a = this;
                    if (o) return a.$offset = d, a.$u = 0 === n, a;
                    if (0 !== n) {
                        var s = this.$u ? this.toDate().getTimezoneOffset() : -1 * this.utcOffset();
                        (a = this.local().add(d + s, e)).$offset = d, a.$x.$localOffset = s
                    } else a = this.utc();
                    return a
                };
                var l = d.format;
                d.format = function(e) {
                    var t = e || (this.$u ? "YYYY-MM-DDTHH:mm:ss[Z]" : "");
                    return l.call(this, t)
                }, d.valueOf = function() {
                    var e = this.$utils().u(this.$offset) ? 0 : this.$offset + (this.$x.$localOffset || this.$d.getTimezoneOffset());
                    return this.$d.valueOf() - 6e4 * e
                }, d.isUTC = function() {
                    return !!this.$u
                }, d.toISOString = function() {
                    return this.toDate().toISOString()
                }, d.toString = function() {
                    return this.toDate().toUTCString()
                };
                var c = d.toDate;
                d.toDate = function(e) {
                    return "s" === e && this.$offset ? i(this.format("YYYY-MM-DD HH:mm:ss:SSS")).toDate() : c.call(this)
                };
                var f = d.diff;
                d.diff = function(e, t, r) {
                    if (e && this.$u === e.$u) return f.call(this, e, t, r);
                    var n = this.local(),
                        o = i(e).local();
                    return f.call(n, o, t, r)
                }
            }
        }()
    }(cu);
    const fu = Wn(cu.exports);
    Hn.extend(su), Hn.extend(fu), Hn.extend(lu);
    const $u = (e, t) => {
        let r;
        return r = e.filter((e => (e => {
            switch (e) {
                case Cn.Desktop:
                    return !co();
                case Cn.Mobile:
                    return co();
                default:
                    return !0
            }
        })(e.rules.trigger.devices) && (e => {
            const {
                type: t,
                specific_page: r,
                match_mode: n
            } = e;
            let {
                AnyPage: o,
                SpecificPage: i
            } = Sn;
            return t === o || (t === i ? lo(r, an(window.location.pathname, "/"), n === On.OR) : void 0)
        })(e.rules.page_display_rules) && ((e, t) => e.type === hn.ANY || (e.type === hn.IN ? e.in.includes(t.country_iso_code) : e.type === hn.NOTIN ? !e.not_in.includes(t.country_iso_code) : void 0))(e.rules.location, t) && ((e, t) => {
            let {
                type: r,
                start_unix: n,
                has_end_unix: o,
                end_unix: i
            } = e;
            if (r === mn.PERIOD) {
                let e = Hn(Hn().tz(t.timezone).format("YYYY-MM-DD HH:mm:ss")).unix();
                return o ? e > n && e < i : e > n
            }
            return !0
        })(e.rules.schedule, t))), r
    };

    function pu() {
        Jn();
        const [e, r] = t.useState(!0), {
            ConfigStore: n,
            IntentionsStore: o,
            PopupsStore: i
        } = ao, d = t.useCallback((async () => {
            const e = function() {
                    let e = yt(window, "EcomSendApps.searchParams.popup-id", "false");
                    return e || (e = io.getSessionStorage("popup_id")), e ? window.atob(e) : ""
                }(),
                t = await pn.getConfig(e);
            if (e) Xn() ? i.setConfig("popups", $u([t.data], t.metadata)) : i.setConfig("popups", [t.data]);
            else {
                let {
                    data: e,
                    metadata: r
                } = t;
                Xn() && (e = $u(e, r)), e = e.filter(((t, r) => e.findIndex((e => e.template.type === t.template.type)) === r)), e.sort((function(e, t) {
                    const r = e.template.type,
                        n = t.template.type;
                    return r > n ? -1 : r < n ? 1 : 0
                })), i.setConfig("popups", e)
            }
            r(!1)
        }), []);
        t.useLayoutEffect((() => {
            d().then(null)
        }), []), t.useEffect((() => {
            if (!e) {
                i.popups.forEach((e => {
                    po.init(e.id, !0)
                }));
                const e = document.getElementById("ecomsend-custom-style");
                e && (e.innerHTML = i.popups.map((e => e.style.css)).join("\n"))
            }
        }), [e]);
        const a = e => {
            o.modal_success_status_list[e] ? po.removeModal("success_subscriber", e) : po.removeModal("normal", e), i.popups.forEach((e => {
                po.init(e.id)
            }))
        };
        return Ao(Do, {
            children: () => {
                const e = e => {
                        let {
                            start_status: t,
                            success_status: r,
                            error_text: n,
                            sidebar_widget: o,
                            sticky_discount_bar: i
                        } = e;
                        return "won_reward" in r && (r = r.won_reward), {
                            start_status: t,
                            success_status: r,
                            error_text: n,
                            sidebar_widget: o,
                            sticky_discount_bar: i
                        }
                    },
                    t = e => {
                        const {
                            display: t,
                            colors: r,
                            logo: n,
                            layout: i
                        } = e;
                        return setTimeout((() => {
                            document.body.style.overflow = o.show_modal ? "hidden" : "initial"
                        }), 10), {
                            alignment: t.align,
                            cornerRadius: t.corner_radius,
                            imgLayout: i.image_position,
                            imgMobilePosition: i.image_mobile_position,
                            imgURL: i.image_url,
                            hideOnMobile: i.hide_on_mobile,
                            logoURL: n.url,
                            logoWidth: n.width,
                            size: t.size,
                            wheel: r.wheel
                        }
                    };
                return jo("div", {
                    className: "EcomSendAPP",
                    children: [o.show_sticky_bar_list.map((e => {
                        const t = Jn() ? io.getCookie(`pp_preview_success_subscribed${e}_reward_index`) : io.getCookie(`pp_success_subscribed${e}_reward_index`),
                            r = i.popups.find((t => t.id === e));
                        let n;
                        if (void 0 !== t) {
                            const r = i.popups.find((t => t.id === e));
                            r && (n = r.rules.rewards[Number(t)].discount_coupon)
                        }
                        return Ao(qs, {
                            popupId: e,
                            discountType: n ? n.value : r.rules.discount_coupon.value,
                            colors: __spreadValues({}, r.style.colors),
                            manuallyCode: n ? n.manually_code : r.rules.discount_coupon.manually_code,
                            discountCode: Jn() ? io.getCookie(`preview_discount_code${e}`) : io.getCookie(`discount_code${e}`),
                            stickyBarDescription: r.text.sticky_discount_bar.description
                        }, e)
                    })), o.show_widget_modal_list.map((e => {
                        const t = i.popups.find((t => t.id === e));
                        return Ao(du, {
                            isSpinWheel: t.template.type === In.SpinWheel,
                            popupId: e,
                            widgetText: t ? t.text.sidebar_widget.button_text : "",
                            position: t ? t.rules.sidebar_widget.show_position : null,
                            fixedPosition: !0,
                            colors: t ? t.style.colors : n.style.colors,
                            onOpen: () => (e => {
                                po.showModal(!0, !1, e)
                            })(e)
                        }, t.id)
                    })), i.popups.map((r => r.template.type === In.SpinWheel ? jo("div", {
                        className: "spinWheelWrapper " + (o.show_modal && o.show_modal_by_id == r.id ? "dialogVisible" : "hideWrapper"),
                        style: Xn() ? {} : {
                            overflow: "hidden"
                        },
                        children: [Ao(Ys, {
                            popupId: r.id,
                            forbidUserSelect: !Xn(),
                            rulesConfig: r.rules,
                            myDialogStyle: t(r.style),
                            marketingBranding: r.rules.marketing_branding.remove_powered_by,
                            successStatus: o.modal_success_status_list[r.id],
                            colors: r.style.colors,
                            isHideRemove: !0,
                            textConfig: e(r.text),
                            onClose: () => a(r.id)
                        }), !Xn() && Ao("div", {
                            className: "iframeMask"
                        })]
                    }, r.id) : r.template.type === In.OptIn ? jo(vi, {
                        open: o.show_modal && o.show_modal_by_id == r.id,
                        onClose: () => a(r.id),
                        animationDuration: 200,
                        center: !0,
                        closeOnEsc: !1,
                        blockScroll: !Qn(),
                        "aria-modal": !0,
                        focusTrapped: !1,
                        showCloseIcon: !1,
                        closeOnOverlayClick: !1,
                        classNames: {
                            modal: "pp-modal",
                            overlay: "pp-overlay"
                        },
                        children: [Ao(Ts, {
                            popupId: r.id,
                            myDialogStyle: t(r.style),
                            marketingBranding: r.rules.marketing_branding.remove_powered_by,
                            successStatus: o.modal_success_status_list[r.id],
                            colors: r.style.colors,
                            isManuallyCode: "manually_code" === r.rules.discount_coupon.value,
                            isHideRemove: !0,
                            manuallyCode: r.rules.discount_coupon.manually_code,
                            textConfig: r.text,
                            isNoDiscount: "no_discount" === r.rules.discount_coupon.value,
                            onClose: () => a(r.id)
                        }), !Xn() && Ao("div", {
                            className: "iframeMask"
                        })]
                    }, r.id) : void 0))]
                })
            }
        })
    }
    const hu = new URLSearchParams(window.location.search);
    if (tn(window, "EcomSendApps.searchParams", {
            "clean-cookie": hu.get("clean-cookie") || "false",
            "popup-preview": hu.get("popup-preview") || "false",
            "popup-id": hu.get("popup-id"),
            "shop-id": hu.get("shop-id"),
            "user-select": hu.get("user-select")
        }), hu.has("clean-cookie") && "true" === hu.get("clean-cookie") && po.clean(), tn(window, "EcomSendApps.buildTime", "2025-04-17 12:04:49"), Kr(yt(window, "EcomSendApps.config.text", {})) || en(window.EcomSendApps.config.text, mo.unflatten(yt(window, "EcomSendApps.texts", {}))), !(ho.sort(((e, t) => e.length > t.length ? -1 : 1)).filter((e => {
            var t;
            return !0 === (null == (t = null == navigator ? void 0 : navigator.userAgent) ? void 0 : t.includes(e))
        })).length > 0)) {
        const e = document.createElement("div");
        e.setAttribute("id", "ecomsend-widget");
        Uo.createRoot(e).render(Ao(t.StrictMode, {
            children: Ao(Yo, __spreadProps(__spreadValues({}, ao), {
                children: Ao(pu, {})
            }))
        })), document.body.insertBefore(e, document.body.childNodes[0])
    }
}(mobx, React, ReactDOM, Wheel);