var sn = Object.defineProperty;
var on = (e, t, n) => t in e ? sn(e, t, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: n
}) : e[t] = n;
var Ye = (e, t, n) => (on(e, typeof t != "symbol" ? t + "" : t, n), n);

function sr() {
    import.meta.url,
        import ("_").catch(() => 1);
    async function* e() {}
}
const rn = () => {
    const {
        origin: e,
        search: t
    } = document.location, n = new URLSearchParams(t), s = n.get("isFeed"), o = n.get("publishId"), r = [e, s ? "feed" : "", o].filter(c => c);
    n.delete("isFeed"), n.delete("publishId");
    let i = r.join("/");
    n.toString().length && (i += "?".concat(n.toString())), history.replaceState(null, null, i)
};
rn();
const an = function() {
        const t = typeof document < "u" && document.createElement("link").relList;
        return t && t.supports && t.supports("modulepreload") ? "modulepreload" : "preload"
    }(),
    cn = function(e) {
        return "https://play.gotolstoy.com/2.0.0-l/" + e
    },
    We = {},
    ln = function(t, n, s) {
        if (!n || n.length === 0) return t();
        const o = document.getElementsByTagName("link");
        return Promise.all(n.map(r => {
            if (r = cn(r), r in We) return;
            We[r] = !0;
            const i = r.endsWith(".css"),
                c = i ? '[rel="stylesheet"]' : "";
            if (!!s)
                for (let u = o.length - 1; u >= 0; u--) {
                    const d = o[u];
                    if (d.href === r && (!i || d.rel === "stylesheet")) return
                } else if (document.querySelector('link[href="'.concat(r, '"]').concat(c))) return;
            const l = document.createElement("link");
            if (l.rel = i ? "stylesheet" : an, i || (l.as = "script", l.crossOrigin = ""), l.href = r, document.head.appendChild(l), i) return new Promise((u, d) => {
                l.addEventListener("load", u), l.addEventListener("error", () => d(new Error("Unable to preload CSS for ".concat(r))))
            })
        })).then(() => t()).catch(r => {
            const i = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (i.payload = r, window.dispatchEvent(i), !i.defaultPrevented) throw r
        })
    },
    or = "tolstoyModalOpen",
    un = "tolstoyModalClose",
    dt = "tolstoyPlayerReady",
    rr = "tolstoyPlayerMetadataChange",
    ir = "tolstoyPlayerMutedChange",
    ar = "tolstoyPlayerPlayPause",
    cr = "tolstoyPlayerPlayBackRate",
    lr = "tolstoyPlayerSeek",
    ur = "tolstoyPlay",
    dr = "tolstoyEscapeKeyPressed",
    fr = "focusCloseButton",
    pr = "tolstoyWatchedProductIds",
    Er = "tolstoyReportModalOpen",
    hr = "tolstoyReportModalClose",
    mr = "showFeedProductModal",
    gr = "toggleFeedCloseButton",
    yr = "showFeedCartMobile",
    Sr = "feedPlay",
    wr = "feedPause",
    _r = "videoUnmuted",
    Rr = "productSelected",
    Ar = "tolstoyMoveToUrl",
    Tr = "tolstoyCloseModalMessage",
    br = "tolstoyOpenRebuyCart",
    Pr = "tolstoyOpenKendoModal",
    Or = "tolstoyIsRebuyAppInstalled",
    Ir = "tolstoyIsAfterpayAppInstalled",
    Cr = "tolstoyProductCardClick",
    Lr = "tolstoyProductCardClickSubscribed",
    Ur = "tolstoyUrlLocaleUpdate",
    Dr = "tolstoyRequestProductsUpdate",
    Nr = "tolstoyProductUpdateResponse",
    Fr = "tolstoyIsNonBaseCurrency",
    vr = "tolstoyModalMessagingReady",
    Mr = {
        ready: "tolstoyPreConfigMessengerReady",
        vodAssetIds: "tolstoyVodAssetIds"
    },
    g = {
        pageView: "pageView",
        sessionStart: "sessionStart",
        sessionEnd: "sessionEnd",
        videoPause: "videoPause",
        videoStart: "videoStart",
        videoResume: "videoResume",
        videoReplay: "videoReplay",
        clickCta: "clickCta",
        submitInput: "submitInput",
        collectInfo: "collectInfo",
        videoResponse: "videoResponse",
        audioResponse: "audioResponse",
        imageResponse: "imageResponse",
        tolstoyClick: "tolstoyClick",
        chapterSelected: "chapterSelected",
        chapterPickerOpened: "chapterPickerOpened",
        videoSeeked: "videoSeeked",
        shareClick: "shareClick",
        quizResult: "quizResult",
        autoplayStart: "autoplayStart"
    },
    N = {
        sessionStart: "tolstoyStarted",
        sessionEnd: "tolstoyReachedEnd",
        clickCta: "tolstoyAnswerClicked",
        submitInput: "tolstoyInputSubmit",
        collectInfo: "tolstoyLeadFormSubmit",
        videoResponse: "tolstoyVideoSubmit",
        audioResponse: "tolstoyAudioSubmit",
        imageResponse: "tolstoyImageSubmit",
        openGorgias: "tolstoyOpenGorgias",
        hideGorgias: "tolstoyHideGorgias",
        openIntercom: "tolstoyOpenIntercom",
        hideIntercom: "tolstoyHideIntercom",
        openTawkTo: "tolstoyOpenTawkTo",
        hideTawkTo: "tolstoyHideTawkTo",
        openLiveChat: "tolstoyOpenLiveChat",
        hideLiveChat: "tolstoyHideLiveChat",
        openHubSpot: "tolstoyOpenHubSpot",
        hideHubSpot: "tolstoyHideHubSpot",
        openHelpScout: "tolstoyOpenHelpScout",
        hideHelpScout: "tolstoyHideHelpScout",
        openDrift: "tolstoyOpenDrift",
        hideDrift: "tolstoyHideDrift",
        openZendesk: "tolstoyOpenZendesk",
        hideZendesk: "tolstoyHideZendesk"
    },
    dn = "production",
    ze = "UA-180961004-6",
    fn = "4003456519730074",
    kr = "videos.gotolstoy.com",
    pn = "https://api.gotolstoy.com",
    xr = "https://tolstoyprojects221542-prod.s3.amazonaws.com/public",
    Br = "https://tolstoy-files-prod-output.s3.amazonaws.com",
    Hr = "3f8e942efa104ecba7d77cd94845d95a",
    En = "https://assets.gotolstoy.com",
    Vr = "udo8kqf9tsneg0t116idg2afe",
    qr = {}.VITE_REACT_APP_SENTRY_RELEASE,
    hn = {}.VITE_BASE_URL;

function ft(e, t) {
    return function() {
        return e.apply(t, arguments)
    }
}
const {
    toString: mn
} = Object.prototype, {
    getPrototypeOf: ve
} = Object, ue = (e => t => {
    const n = mn.call(t);
    return e[n] || (e[n] = n.slice(8, -1).toLowerCase())
})(Object.create(null)), L = e => (e = e.toLowerCase(), t => ue(t) === e), de = e => t => typeof t === e, {
    isArray: $
} = Array, K = de("undefined");

function gn(e) {
    return e !== null && !K(e) && e.constructor !== null && !K(e.constructor) && I(e.constructor.isBuffer) && e.constructor.isBuffer(e)
}
const pt = L("ArrayBuffer");

function yn(e) {
    let t;
    return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? t = ArrayBuffer.isView(e) : t = e && e.buffer && pt(e.buffer), t
}
const Sn = de("string"),
    I = de("function"),
    Et = de("number"),
    fe = e => e !== null && typeof e == "object",
    wn = e => e === !0 || e === !1,
    ne = e => {
        if (ue(e) !== "object") return !1;
        const t = ve(e);
        return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e)
    },
    _n = L("Date"),
    Rn = L("File"),
    An = L("Blob"),
    Tn = L("FileList"),
    bn = e => fe(e) && I(e.pipe),
    Pn = e => {
        let t;
        return e && (typeof FormData == "function" && e instanceof FormData || I(e.append) && ((t = ue(e)) === "formdata" || t === "object" && I(e.toString) && e.toString() === "[object FormData]"))
    },
    On = L("URLSearchParams"),
    [In, Cn, Ln, Un] = ["ReadableStream", "Request", "Response", "Headers"].map(L),
    Dn = e => e.trim ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");

function Q(e, t, {
    allOwnKeys: n = !1
} = {}) {
    if (e === null || typeof e > "u") return;
    let s, o;
    if (typeof e != "object" && (e = [e]), $(e))
        for (s = 0, o = e.length; s < o; s++) t.call(null, e[s], s, e);
    else {
        const r = n ? Object.getOwnPropertyNames(e) : Object.keys(e),
            i = r.length;
        let c;
        for (s = 0; s < i; s++) c = r[s], t.call(null, e[c], c, e)
    }
}

function ht(e, t) {
    t = t.toLowerCase();
    const n = Object.keys(e);
    let s = n.length,
        o;
    for (; s-- > 0;)
        if (o = n[s], t === o.toLowerCase()) return o;
    return null
}
const H = (() => typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global)(),
    mt = e => !K(e) && e !== H;

function Ae() {
    const {
        caseless: e
    } = mt(this) && this || {}, t = {}, n = (s, o) => {
        const r = e && ht(t, o) || o;
        ne(t[r]) && ne(s) ? t[r] = Ae(t[r], s) : ne(s) ? t[r] = Ae({}, s) : $(s) ? t[r] = s.slice() : t[r] = s
    };
    for (let s = 0, o = arguments.length; s < o; s++) arguments[s] && Q(arguments[s], n);
    return t
}
const Nn = (e, t, n, {
        allOwnKeys: s
    } = {}) => (Q(t, (o, r) => {
        n && I(o) ? e[r] = ft(o, n) : e[r] = o
    }, {
        allOwnKeys: s
    }), e),
    Fn = e => (e.charCodeAt(0) === 65279 && (e = e.slice(1)), e),
    vn = (e, t, n, s) => {
        e.prototype = Object.create(t.prototype, s), e.prototype.constructor = e, Object.defineProperty(e, "super", {
            value: t.prototype
        }), n && Object.assign(e.prototype, n)
    },
    Mn = (e, t, n, s) => {
        let o, r, i;
        const c = {};
        if (t = t || {}, e == null) return t;
        do {
            for (o = Object.getOwnPropertyNames(e), r = o.length; r-- > 0;) i = o[r], (!s || s(i, e, t)) && !c[i] && (t[i] = e[i], c[i] = !0);
            e = n !== !1 && ve(e)
        } while (e && (!n || n(e, t)) && e !== Object.prototype);
        return t
    },
    kn = (e, t, n) => {
        e = String(e), (n === void 0 || n > e.length) && (n = e.length), n -= t.length;
        const s = e.indexOf(t, n);
        return s !== -1 && s === n
    },
    xn = e => {
        if (!e) return null;
        if ($(e)) return e;
        let t = e.length;
        if (!Et(t)) return null;
        const n = new Array(t);
        for (; t-- > 0;) n[t] = e[t];
        return n
    },
    Bn = (e => t => e && t instanceof e)(typeof Uint8Array < "u" && ve(Uint8Array)),
    Hn = (e, t) => {
        const s = (e && e[Symbol.iterator]).call(e);
        let o;
        for (;
            (o = s.next()) && !o.done;) {
            const r = o.value;
            t.call(e, r[0], r[1])
        }
    },
    Vn = (e, t) => {
        let n;
        const s = [];
        for (;
            (n = e.exec(t)) !== null;) s.push(n);
        return s
    },
    qn = L("HTMLFormElement"),
    Gn = e => e.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(n, s, o) {
        return s.toUpperCase() + o
    }),
    Ke = (({
        hasOwnProperty: e
    }) => (t, n) => e.call(t, n))(Object.prototype),
    jn = L("RegExp"),
    gt = (e, t) => {
        const n = Object.getOwnPropertyDescriptors(e),
            s = {};
        Q(n, (o, r) => {
            let i;
            (i = t(o, r, e)) !== !1 && (s[r] = i || o)
        }), Object.defineProperties(e, s)
    },
    $n = e => {
        gt(e, (t, n) => {
            if (I(e) && ["arguments", "caller", "callee"].indexOf(n) !== -1) return !1;
            const s = e[n];
            if (I(s)) {
                if (t.enumerable = !1, "writable" in t) {
                    t.writable = !1;
                    return
                }
                t.set || (t.set = () => {
                    throw Error("Can not rewrite read-only method '" + n + "'")
                })
            }
        })
    },
    Yn = (e, t) => {
        const n = {},
            s = o => {
                o.forEach(r => {
                    n[r] = !0
                })
            };
        return $(e) ? s(e) : s(String(e).split(t)), n
    },
    Wn = () => {},
    zn = (e, t) => e != null && Number.isFinite(e = +e) ? e : t,
    ye = "abcdefghijklmnopqrstuvwxyz",
    Je = "0123456789",
    yt = {
        DIGIT: Je,
        ALPHA: ye,
        ALPHA_DIGIT: ye + ye.toUpperCase() + Je
    },
    Kn = (e = 16, t = yt.ALPHA_DIGIT) => {
        let n = "";
        const {
            length: s
        } = t;
        for (; e--;) n += t[Math.random() * s | 0];
        return n
    };

function Jn(e) {
    return !!(e && I(e.append) && e[Symbol.toStringTag] === "FormData" && e[Symbol.iterator])
}
const Xn = e => {
        const t = new Array(10),
            n = (s, o) => {
                if (fe(s)) {
                    if (t.indexOf(s) >= 0) return;
                    if (!("toJSON" in s)) {
                        t[o] = s;
                        const r = $(s) ? [] : {};
                        return Q(s, (i, c) => {
                            const f = n(i, o + 1);
                            !K(f) && (r[c] = f)
                        }), t[o] = void 0, r
                    }
                }
                return s
            };
        return n(e, 0)
    },
    Qn = L("AsyncFunction"),
    Zn = e => e && (fe(e) || I(e)) && I(e.then) && I(e.catch),
    St = ((e, t) => e ? setImmediate : t ? ((n, s) => (H.addEventListener("message", ({
        source: o,
        data: r
    }) => {
        o === H && r === n && s.length && s.shift()()
    }, !1), o => {
        s.push(o), H.postMessage(n, "*")
    }))("axios@".concat(Math.random()), []) : n => setTimeout(n))(typeof setImmediate == "function", I(H.postMessage)),
    es = typeof queueMicrotask < "u" ? queueMicrotask.bind(H) : typeof process < "u" && process.nextTick || St,
    a = {
        isArray: $,
        isArrayBuffer: pt,
        isBuffer: gn,
        isFormData: Pn,
        isArrayBufferView: yn,
        isString: Sn,
        isNumber: Et,
        isBoolean: wn,
        isObject: fe,
        isPlainObject: ne,
        isReadableStream: In,
        isRequest: Cn,
        isResponse: Ln,
        isHeaders: Un,
        isUndefined: K,
        isDate: _n,
        isFile: Rn,
        isBlob: An,
        isRegExp: jn,
        isFunction: I,
        isStream: bn,
        isURLSearchParams: On,
        isTypedArray: Bn,
        isFileList: Tn,
        forEach: Q,
        merge: Ae,
        extend: Nn,
        trim: Dn,
        stripBOM: Fn,
        inherits: vn,
        toFlatObject: Mn,
        kindOf: ue,
        kindOfTest: L,
        endsWith: kn,
        toArray: xn,
        forEachEntry: Hn,
        matchAll: Vn,
        isHTMLForm: qn,
        hasOwnProperty: Ke,
        hasOwnProp: Ke,
        reduceDescriptors: gt,
        freezeMethods: $n,
        toObjectSet: Yn,
        toCamelCase: Gn,
        noop: Wn,
        toFiniteNumber: zn,
        findKey: ht,
        global: H,
        isContextDefined: mt,
        ALPHABET: yt,
        generateString: Kn,
        isSpecCompliantForm: Jn,
        toJSONObject: Xn,
        isAsyncFn: Qn,
        isThenable: Zn,
        setImmediate: St,
        asap: es
    };

function h(e, t, n, s, o) {
    Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack, this.message = e, this.name = "AxiosError", t && (this.code = t), n && (this.config = n), s && (this.request = s), o && (this.response = o, this.status = o.status ? o.status : null)
}
a.inherits(h, Error, {
    toJSON: function() {
        return {
            message: this.message,
            name: this.name,
            description: this.description,
            number: this.number,
            fileName: this.fileName,
            lineNumber: this.lineNumber,
            columnNumber: this.columnNumber,
            stack: this.stack,
            config: a.toJSONObject(this.config),
            code: this.code,
            status: this.status
        }
    }
});
const wt = h.prototype,
    _t = {};
["ERR_BAD_OPTION_VALUE", "ERR_BAD_OPTION", "ECONNABORTED", "ETIMEDOUT", "ERR_NETWORK", "ERR_FR_TOO_MANY_REDIRECTS", "ERR_DEPRECATED", "ERR_BAD_RESPONSE", "ERR_BAD_REQUEST", "ERR_CANCELED", "ERR_NOT_SUPPORT", "ERR_INVALID_URL"].forEach(e => {
    _t[e] = {
        value: e
    }
});
Object.defineProperties(h, _t);
Object.defineProperty(wt, "isAxiosError", {
    value: !0
});
h.from = (e, t, n, s, o, r) => {
    const i = Object.create(wt);
    return a.toFlatObject(e, i, function(f) {
        return f !== Error.prototype
    }, c => c !== "isAxiosError"), h.call(i, e.message, t, n, s, o), i.cause = e, i.name = e.name, r && Object.assign(i, r), i
};
const ts = null;

function Te(e) {
    return a.isPlainObject(e) || a.isArray(e)
}

function Rt(e) {
    return a.endsWith(e, "[]") ? e.slice(0, -2) : e
}

function Xe(e, t, n) {
    return e ? e.concat(t).map(function(o, r) {
        return o = Rt(o), !n && r ? "[" + o + "]" : o
    }).join(n ? "." : "") : t
}

function ns(e) {
    return a.isArray(e) && !e.some(Te)
}
const ss = a.toFlatObject(a, {}, null, function(t) {
    return /^is[A-Z]/.test(t)
});

function pe(e, t, n) {
    if (!a.isObject(e)) throw new TypeError("target must be an object");
    t = t || new FormData, n = a.toFlatObject(n, {
        metaTokens: !0,
        dots: !1,
        indexes: !1
    }, !1, function(m, E) {
        return !a.isUndefined(E[m])
    });
    const s = n.metaTokens,
        o = n.visitor || u,
        r = n.dots,
        i = n.indexes,
        f = (n.Blob || typeof Blob < "u" && Blob) && a.isSpecCompliantForm(t);
    if (!a.isFunction(o)) throw new TypeError("visitor must be a function");

    function l(p) {
        if (p === null) return "";
        if (a.isDate(p)) return p.toISOString();
        if (!f && a.isBlob(p)) throw new h("Blob is not supported. Use a Buffer instead.");
        return a.isArrayBuffer(p) || a.isTypedArray(p) ? f && typeof Blob == "function" ? new Blob([p]) : Buffer.from(p) : p
    }

    function u(p, m, E) {
        let S = p;
        if (p && !E && typeof p == "object") {
            if (a.endsWith(m, "{}")) m = s ? m : m.slice(0, -2), p = JSON.stringify(p);
            else if (a.isArray(p) && ns(p) || (a.isFileList(p) || a.endsWith(m, "[]")) && (S = a.toArray(p))) return m = Rt(m), S.forEach(function(T, v) {
                !(a.isUndefined(T) || T === null) && t.append(i === !0 ? Xe([m], v, r) : i === null ? m : m + "[]", l(T))
            }), !1
        }
        return Te(p) ? !0 : (t.append(Xe(E, m, r), l(p)), !1)
    }
    const d = [],
        y = Object.assign(ss, {
            defaultVisitor: u,
            convertValue: l,
            isVisitable: Te
        });

    function R(p, m) {
        if (!a.isUndefined(p)) {
            if (d.indexOf(p) !== -1) throw Error("Circular reference detected in " + m.join("."));
            d.push(p), a.forEach(p, function(S, A) {
                (!(a.isUndefined(S) || S === null) && o.call(t, S, a.isString(A) ? A.trim() : A, m, y)) === !0 && R(S, m ? m.concat(A) : [A])
            }), d.pop()
        }
    }
    if (!a.isObject(e)) throw new TypeError("data must be an object");
    return R(e), t
}

function Qe(e) {
    const t = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+",
        "%00": "\0"
    };
    return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g, function(s) {
        return t[s]
    })
}

function Me(e, t) {
    this._pairs = [], e && pe(e, this, t)
}
const At = Me.prototype;
At.append = function(t, n) {
    this._pairs.push([t, n])
};
At.toString = function(t) {
    const n = t ? function(s) {
        return t.call(this, s, Qe)
    } : Qe;
    return this._pairs.map(function(o) {
        return n(o[0]) + "=" + n(o[1])
    }, "").join("&")
};

function os(e) {
    return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
}

function Tt(e, t, n) {
    if (!t) return e;
    const s = n && n.encode || os;
    a.isFunction(n) && (n = {
        serialize: n
    });
    const o = n && n.serialize;
    let r;
    if (o ? r = o(t, n) : r = a.isURLSearchParams(t) ? t.toString() : new Me(t, n).toString(s), r) {
        const i = e.indexOf("#");
        i !== -1 && (e = e.slice(0, i)), e += (e.indexOf("?") === -1 ? "?" : "&") + r
    }
    return e
}
class rs {
    constructor() {
        this.handlers = []
    }
    use(t, n, s) {
        return this.handlers.push({
            fulfilled: t,
            rejected: n,
            synchronous: s ? s.synchronous : !1,
            runWhen: s ? s.runWhen : null
        }), this.handlers.length - 1
    }
    eject(t) {
        this.handlers[t] && (this.handlers[t] = null)
    }
    clear() {
        this.handlers && (this.handlers = [])
    }
    forEach(t) {
        a.forEach(this.handlers, function(s) {
            s !== null && t(s)
        })
    }
}
const Ze = rs,
    bt = {
        silentJSONParsing: !0,
        forcedJSONParsing: !0,
        clarifyTimeoutError: !1
    },
    is = typeof URLSearchParams < "u" ? URLSearchParams : Me,
    as = typeof FormData < "u" ? FormData : null,
    cs = typeof Blob < "u" ? Blob : null,
    ls = {
        isBrowser: !0,
        classes: {
            URLSearchParams: is,
            FormData: as,
            Blob: cs
        },
        protocols: ["http", "https", "file", "blob", "url", "data"]
    },
    ke = typeof window < "u" && typeof document < "u",
    be = typeof navigator == "object" && navigator || void 0,
    us = ke && (!be || ["ReactNative", "NativeScript", "NS"].indexOf(be.product) < 0),
    ds = (() => typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope && typeof self.importScripts == "function")(),
    fs = ke && window.location.href || "http://localhost",
    ps = Object.freeze(Object.defineProperty({
        __proto__: null,
        hasBrowserEnv: ke,
        hasStandardBrowserEnv: us,
        hasStandardBrowserWebWorkerEnv: ds,
        navigator: be,
        origin: fs
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    P = { ...ps,
        ...ls
    };

function Es(e, t) {
    return pe(e, new P.classes.URLSearchParams, Object.assign({
        visitor: function(n, s, o, r) {
            return P.isNode && a.isBuffer(n) ? (this.append(s, n.toString("base64")), !1) : r.defaultVisitor.apply(this, arguments)
        }
    }, t))
}

function hs(e) {
    return a.matchAll(/\w+|\[(\w*)]/g, e).map(t => t[0] === "[]" ? "" : t[1] || t[0])
}

function ms(e) {
    const t = {},
        n = Object.keys(e);
    let s;
    const o = n.length;
    let r;
    for (s = 0; s < o; s++) r = n[s], t[r] = e[r];
    return t
}

function Pt(e) {
    function t(n, s, o, r) {
        let i = n[r++];
        if (i === "__proto__") return !0;
        const c = Number.isFinite(+i),
            f = r >= n.length;
        return i = !i && a.isArray(o) ? o.length : i, f ? (a.hasOwnProp(o, i) ? o[i] = [o[i], s] : o[i] = s, !c) : ((!o[i] || !a.isObject(o[i])) && (o[i] = []), t(n, s, o[i], r) && a.isArray(o[i]) && (o[i] = ms(o[i])), !c)
    }
    if (a.isFormData(e) && a.isFunction(e.entries)) {
        const n = {};
        return a.forEachEntry(e, (s, o) => {
            t(hs(s), o, n, 0)
        }), n
    }
    return null
}

function gs(e, t, n) {
    if (a.isString(e)) try {
        return (t || JSON.parse)(e), a.trim(e)
    } catch (s) {
        if (s.name !== "SyntaxError") throw s
    }
    return (n || JSON.stringify)(e)
}
const xe = {
    transitional: bt,
    adapter: ["xhr", "http", "fetch"],
    transformRequest: [function(t, n) {
        const s = n.getContentType() || "",
            o = s.indexOf("application/json") > -1,
            r = a.isObject(t);
        if (r && a.isHTMLForm(t) && (t = new FormData(t)), a.isFormData(t)) return o ? JSON.stringify(Pt(t)) : t;
        if (a.isArrayBuffer(t) || a.isBuffer(t) || a.isStream(t) || a.isFile(t) || a.isBlob(t) || a.isReadableStream(t)) return t;
        if (a.isArrayBufferView(t)) return t.buffer;
        if (a.isURLSearchParams(t)) return n.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), t.toString();
        let c;
        if (r) {
            if (s.indexOf("application/x-www-form-urlencoded") > -1) return Es(t, this.formSerializer).toString();
            if ((c = a.isFileList(t)) || s.indexOf("multipart/form-data") > -1) {
                const f = this.env && this.env.FormData;
                return pe(c ? {
                    "files[]": t
                } : t, f && new f, this.formSerializer)
            }
        }
        return r || o ? (n.setContentType("application/json", !1), gs(t)) : t
    }],
    transformResponse: [function(t) {
        const n = this.transitional || xe.transitional,
            s = n && n.forcedJSONParsing,
            o = this.responseType === "json";
        if (a.isResponse(t) || a.isReadableStream(t)) return t;
        if (t && a.isString(t) && (s && !this.responseType || o)) {
            const i = !(n && n.silentJSONParsing) && o;
            try {
                return JSON.parse(t)
            } catch (c) {
                if (i) throw c.name === "SyntaxError" ? h.from(c, h.ERR_BAD_RESPONSE, this, null, this.response) : c
            }
        }
        return t
    }],
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
        FormData: P.classes.FormData,
        Blob: P.classes.Blob
    },
    validateStatus: function(t) {
        return t >= 200 && t < 300
    },
    headers: {
        common: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": void 0
        }
    }
};
a.forEach(["delete", "get", "head", "post", "put", "patch"], e => {
    xe.headers[e] = {}
});
const Be = xe,
    ys = a.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]),
    Ss = e => {
        const t = {};
        let n, s, o;
        return e && e.split("\n").forEach(function(i) {
            o = i.indexOf(":"), n = i.substring(0, o).trim().toLowerCase(), s = i.substring(o + 1).trim(), !(!n || t[n] && ys[n]) && (n === "set-cookie" ? t[n] ? t[n].push(s) : t[n] = [s] : t[n] = t[n] ? t[n] + ", " + s : s)
        }), t
    },
    et = Symbol("internals");

function W(e) {
    return e && String(e).trim().toLowerCase()
}

function se(e) {
    return e === !1 || e == null ? e : a.isArray(e) ? e.map(se) : String(e)
}

function ws(e) {
    const t = Object.create(null),
        n = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let s;
    for (; s = n.exec(e);) t[s[1]] = s[2];
    return t
}
const _s = e => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim());

function Se(e, t, n, s, o) {
    if (a.isFunction(s)) return s.call(this, t, n);
    if (o && (t = n), !!a.isString(t)) {
        if (a.isString(s)) return t.indexOf(s) !== -1;
        if (a.isRegExp(s)) return s.test(t)
    }
}

function Rs(e) {
    return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (t, n, s) => n.toUpperCase() + s)
}

function As(e, t) {
    const n = a.toCamelCase(" " + t);
    ["get", "set", "has"].forEach(s => {
        Object.defineProperty(e, s + n, {
            value: function(o, r, i) {
                return this[s].call(this, t, o, r, i)
            },
            configurable: !0
        })
    })
}
class Ee {
    constructor(t) {
        t && this.set(t)
    }
    set(t, n, s) {
        const o = this;

        function r(c, f, l) {
            const u = W(f);
            if (!u) throw new Error("header name must be a non-empty string");
            const d = a.findKey(o, u);
            (!d || o[d] === void 0 || l === !0 || l === void 0 && o[d] !== !1) && (o[d || f] = se(c))
        }
        const i = (c, f) => a.forEach(c, (l, u) => r(l, u, f));
        if (a.isPlainObject(t) || t instanceof this.constructor) i(t, n);
        else if (a.isString(t) && (t = t.trim()) && !_s(t)) i(Ss(t), n);
        else if (a.isHeaders(t))
            for (const [c, f] of t.entries()) r(f, c, s);
        else t != null && r(n, t, s);
        return this
    }
    get(t, n) {
        if (t = W(t), t) {
            const s = a.findKey(this, t);
            if (s) {
                const o = this[s];
                if (!n) return o;
                if (n === !0) return ws(o);
                if (a.isFunction(n)) return n.call(this, o, s);
                if (a.isRegExp(n)) return n.exec(o);
                throw new TypeError("parser must be boolean|regexp|function")
            }
        }
    }
    has(t, n) {
        if (t = W(t), t) {
            const s = a.findKey(this, t);
            return !!(s && this[s] !== void 0 && (!n || Se(this, this[s], s, n)))
        }
        return !1
    }
    delete(t, n) {
        const s = this;
        let o = !1;

        function r(i) {
            if (i = W(i), i) {
                const c = a.findKey(s, i);
                c && (!n || Se(s, s[c], c, n)) && (delete s[c], o = !0)
            }
        }
        return a.isArray(t) ? t.forEach(r) : r(t), o
    }
    clear(t) {
        const n = Object.keys(this);
        let s = n.length,
            o = !1;
        for (; s--;) {
            const r = n[s];
            (!t || Se(this, this[r], r, t, !0)) && (delete this[r], o = !0)
        }
        return o
    }
    normalize(t) {
        const n = this,
            s = {};
        return a.forEach(this, (o, r) => {
            const i = a.findKey(s, r);
            if (i) {
                n[i] = se(o), delete n[r];
                return
            }
            const c = t ? Rs(r) : String(r).trim();
            c !== r && delete n[r], n[c] = se(o), s[c] = !0
        }), this
    }
    concat(...t) {
        return this.constructor.concat(this, ...t)
    }
    toJSON(t) {
        const n = Object.create(null);
        return a.forEach(this, (s, o) => {
            s != null && s !== !1 && (n[o] = t && a.isArray(s) ? s.join(", ") : s)
        }), n
    }[Symbol.iterator]() {
        return Object.entries(this.toJSON())[Symbol.iterator]()
    }
    toString() {
        return Object.entries(this.toJSON()).map(([t, n]) => t + ": " + n).join("\n")
    }
    get[Symbol.toStringTag]() {
        return "AxiosHeaders"
    }
    static from(t) {
        return t instanceof this ? t : new this(t)
    }
    static concat(t, ...n) {
        const s = new this(t);
        return n.forEach(o => s.set(o)), s
    }
    static accessor(t) {
        const s = (this[et] = this[et] = {
                accessors: {}
            }).accessors,
            o = this.prototype;

        function r(i) {
            const c = W(i);
            s[c] || (As(o, i), s[c] = !0)
        }
        return a.isArray(t) ? t.forEach(r) : r(t), this
    }
}
Ee.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
a.reduceDescriptors(Ee.prototype, ({
    value: e
}, t) => {
    let n = t[0].toUpperCase() + t.slice(1);
    return {
        get: () => e,
        set(s) {
            this[n] = s
        }
    }
});
a.freezeMethods(Ee);
const C = Ee;

function we(e, t) {
    const n = this || Be,
        s = t || n,
        o = C.from(s.headers);
    let r = s.data;
    return a.forEach(e, function(c) {
        r = c.call(n, r, o.normalize(), t ? t.status : void 0)
    }), o.normalize(), r
}

function Ot(e) {
    return !!(e && e.__CANCEL__)
}

function Y(e, t, n) {
    h.call(this, e == null ? "canceled" : e, h.ERR_CANCELED, t, n), this.name = "CanceledError"
}
a.inherits(Y, h, {
    __CANCEL__: !0
});

function It(e, t, n) {
    const s = n.config.validateStatus;
    !n.status || !s || s(n.status) ? e(n) : t(new h("Request failed with status code " + n.status, [h.ERR_BAD_REQUEST, h.ERR_BAD_RESPONSE][Math.floor(n.status / 100) - 4], n.config, n.request, n))
}

function Ts(e) {
    const t = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e);
    return t && t[1] || ""
}

function bs(e, t) {
    e = e || 10;
    const n = new Array(e),
        s = new Array(e);
    let o = 0,
        r = 0,
        i;
    return t = t !== void 0 ? t : 1e3,
        function(f) {
            const l = Date.now(),
                u = s[r];
            i || (i = l), n[o] = f, s[o] = l;
            let d = r,
                y = 0;
            for (; d !== o;) y += n[d++], d = d % e;
            if (o = (o + 1) % e, o === r && (r = (r + 1) % e), l - i < t) return;
            const R = u && l - u;
            return R ? Math.round(y * 1e3 / R) : void 0
        }
}

function Ps(e, t) {
    let n = 0,
        s = 1e3 / t,
        o, r;
    const i = (l, u = Date.now()) => {
        n = u, o = null, r && (clearTimeout(r), r = null), e.apply(null, l)
    };
    return [(...l) => {
        const u = Date.now(),
            d = u - n;
        d >= s ? i(l, u) : (o = l, r || (r = setTimeout(() => {
            r = null, i(o)
        }, s - d)))
    }, () => o && i(o)]
}
const ie = (e, t, n = 3) => {
        let s = 0;
        const o = bs(50, 250);
        return Ps(r => {
            const i = r.loaded,
                c = r.lengthComputable ? r.total : void 0,
                f = i - s,
                l = o(f),
                u = i <= c;
            s = i;
            const d = {
                loaded: i,
                total: c,
                progress: c ? i / c : void 0,
                bytes: f,
                rate: l || void 0,
                estimated: l && c && u ? (c - i) / l : void 0,
                event: r,
                lengthComputable: c != null,
                [t ? "download" : "upload"]: !0
            };
            e(d)
        }, n)
    },
    tt = (e, t) => {
        const n = e != null;
        return [s => t[0]({
            lengthComputable: n,
            total: e,
            loaded: s
        }), t[1]]
    },
    nt = e => (...t) => a.asap(() => e(...t)),
    Os = P.hasStandardBrowserEnv ? ((e, t) => n => (n = new URL(n, P.origin), e.protocol === n.protocol && e.host === n.host && (t || e.port === n.port)))(new URL(P.origin), P.navigator && /(msie|trident)/i.test(P.navigator.userAgent)) : () => !0,
    Is = P.hasStandardBrowserEnv ? {
        write(e, t, n, s, o, r) {
            const i = [e + "=" + encodeURIComponent(t)];
            a.isNumber(n) && i.push("expires=" + new Date(n).toGMTString()), a.isString(s) && i.push("path=" + s), a.isString(o) && i.push("domain=" + o), r === !0 && i.push("secure"), document.cookie = i.join("; ")
        },
        read(e) {
            const t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
            return t ? decodeURIComponent(t[3]) : null
        },
        remove(e) {
            this.write(e, "", Date.now() - 864e5)
        }
    } : {
        write() {},
        read() {
            return null
        },
        remove() {}
    };

function Cs(e) {
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(e)
}

function Ls(e, t) {
    return t ? e.replace(/\/?\/$/, "") + "/" + t.replace(/^\/+/, "") : e
}

function Ct(e, t) {
    return e && !Cs(t) ? Ls(e, t) : t
}
const st = e => e instanceof C ? { ...e
} : e;

function V(e, t) {
    t = t || {};
    const n = {};

    function s(l, u, d, y) {
        return a.isPlainObject(l) && a.isPlainObject(u) ? a.merge.call({
            caseless: y
        }, l, u) : a.isPlainObject(u) ? a.merge({}, u) : a.isArray(u) ? u.slice() : u
    }

    function o(l, u, d, y) {
        if (a.isUndefined(u)) {
            if (!a.isUndefined(l)) return s(void 0, l, d, y)
        } else return s(l, u, d, y)
    }

    function r(l, u) {
        if (!a.isUndefined(u)) return s(void 0, u)
    }

    function i(l, u) {
        if (a.isUndefined(u)) {
            if (!a.isUndefined(l)) return s(void 0, l)
        } else return s(void 0, u)
    }

    function c(l, u, d) {
        if (d in t) return s(l, u);
        if (d in e) return s(void 0, l)
    }
    const f = {
        url: r,
        method: r,
        data: r,
        baseURL: i,
        transformRequest: i,
        transformResponse: i,
        paramsSerializer: i,
        timeout: i,
        timeoutMessage: i,
        withCredentials: i,
        withXSRFToken: i,
        adapter: i,
        responseType: i,
        xsrfCookieName: i,
        xsrfHeaderName: i,
        onUploadProgress: i,
        onDownloadProgress: i,
        decompress: i,
        maxContentLength: i,
        maxBodyLength: i,
        beforeRedirect: i,
        transport: i,
        httpAgent: i,
        httpsAgent: i,
        cancelToken: i,
        socketPath: i,
        responseEncoding: i,
        validateStatus: c,
        headers: (l, u, d) => o(st(l), st(u), d, !0)
    };
    return a.forEach(Object.keys(Object.assign({}, e, t)), function(u) {
        const d = f[u] || o,
            y = d(e[u], t[u], u);
        a.isUndefined(y) && d !== c || (n[u] = y)
    }), n
}
const Lt = e => {
        const t = V({}, e);
        let {
            data: n,
            withXSRFToken: s,
            xsrfHeaderName: o,
            xsrfCookieName: r,
            headers: i,
            auth: c
        } = t;
        t.headers = i = C.from(i), t.url = Tt(Ct(t.baseURL, t.url), e.params, e.paramsSerializer), c && i.set("Authorization", "Basic " + btoa((c.username || "") + ":" + (c.password ? unescape(encodeURIComponent(c.password)) : "")));
        let f;
        if (a.isFormData(n)) {
            if (P.hasStandardBrowserEnv || P.hasStandardBrowserWebWorkerEnv) i.setContentType(void 0);
            else if ((f = i.getContentType()) !== !1) {
                const [l, ...u] = f ? f.split(";").map(d => d.trim()).filter(Boolean) : [];
                i.setContentType([l || "multipart/form-data", ...u].join("; "))
            }
        }
        if (P.hasStandardBrowserEnv && (s && a.isFunction(s) && (s = s(t)), s || s !== !1 && Os(t.url))) {
            const l = o && r && Is.read(r);
            l && i.set(o, l)
        }
        return t
    },
    Us = typeof XMLHttpRequest < "u",
    Ds = Us && function(e) {
        return new Promise(function(n, s) {
            const o = Lt(e);
            let r = o.data;
            const i = C.from(o.headers).normalize();
            let {
                responseType: c,
                onUploadProgress: f,
                onDownloadProgress: l
            } = o, u, d, y, R, p;

            function m() {
                R && R(), p && p(), o.cancelToken && o.cancelToken.unsubscribe(u), o.signal && o.signal.removeEventListener("abort", u)
            }
            let E = new XMLHttpRequest;
            E.open(o.method.toUpperCase(), o.url, !0), E.timeout = o.timeout;

            function S() {
                if (!E) return;
                const T = C.from("getAllResponseHeaders" in E && E.getAllResponseHeaders()),
                    O = {
                        data: !c || c === "text" || c === "json" ? E.responseText : E.response,
                        status: E.status,
                        statusText: E.statusText,
                        headers: T,
                        config: e,
                        request: E
                    };
                It(function(B) {
                    n(B), m()
                }, function(B) {
                    s(B), m()
                }, O), E = null
            }
            "onloadend" in E ? E.onloadend = S : E.onreadystatechange = function() {
                !E || E.readyState !== 4 || E.status === 0 && !(E.responseURL && E.responseURL.indexOf("file:") === 0) || setTimeout(S)
            }, E.onabort = function() {
                E && (s(new h("Request aborted", h.ECONNABORTED, e, E)), E = null)
            }, E.onerror = function() {
                s(new h("Network Error", h.ERR_NETWORK, e, E)), E = null
            }, E.ontimeout = function() {
                let v = o.timeout ? "timeout of " + o.timeout + "ms exceeded" : "timeout exceeded";
                const O = o.transitional || bt;
                o.timeoutErrorMessage && (v = o.timeoutErrorMessage), s(new h(v, O.clarifyTimeoutError ? h.ETIMEDOUT : h.ECONNABORTED, e, E)), E = null
            }, r === void 0 && i.setContentType(null), "setRequestHeader" in E && a.forEach(i.toJSON(), function(v, O) {
                E.setRequestHeader(O, v)
            }), a.isUndefined(o.withCredentials) || (E.withCredentials = !!o.withCredentials), c && c !== "json" && (E.responseType = o.responseType), l && ([y, p] = ie(l, !0), E.addEventListener("progress", y)), f && E.upload && ([d, R] = ie(f), E.upload.addEventListener("progress", d), E.upload.addEventListener("loadend", R)), (o.cancelToken || o.signal) && (u = T => {
                E && (s(!T || T.type ? new Y(null, e, E) : T), E.abort(), E = null)
            }, o.cancelToken && o.cancelToken.subscribe(u), o.signal && (o.signal.aborted ? u() : o.signal.addEventListener("abort", u)));
            const A = Ts(o.url);
            if (A && P.protocols.indexOf(A) === -1) {
                s(new h("Unsupported protocol " + A + ":", h.ERR_BAD_REQUEST, e));
                return
            }
            E.send(r || null)
        })
    },
    Ns = (e, t) => {
        const {
            length: n
        } = e = e ? e.filter(Boolean) : [];
        if (t || n) {
            let s = new AbortController,
                o;
            const r = function(l) {
                if (!o) {
                    o = !0, c();
                    const u = l instanceof Error ? l : this.reason;
                    s.abort(u instanceof h ? u : new Y(u instanceof Error ? u.message : u))
                }
            };
            let i = t && setTimeout(() => {
                i = null, r(new h("timeout ".concat(t, " of ms exceeded"), h.ETIMEDOUT))
            }, t);
            const c = () => {
                e && (i && clearTimeout(i), i = null, e.forEach(l => {
                    l.unsubscribe ? l.unsubscribe(r) : l.removeEventListener("abort", r)
                }), e = null)
            };
            e.forEach(l => l.addEventListener("abort", r));
            const {
                signal: f
            } = s;
            return f.unsubscribe = () => a.asap(c), f
        }
    },
    Fs = Ns,
    vs = function*(e, t) {
        let n = e.byteLength;
        if (!t || n < t) {
            yield e;
            return
        }
        let s = 0,
            o;
        for (; s < n;) o = s + t, yield e.slice(s, o), s = o
    },
    Ms = async function*(e, t) {
        for await (const n of ks(e)) yield* vs(n, t)
    },
    ks = async function*(e) {
        if (e[Symbol.asyncIterator]) {
            yield* e;
            return
        }
        const t = e.getReader();
        try {
            for (;;) {
                const {
                    done: n,
                    value: s
                } = await t.read();
                if (n) break;
                yield s
            }
        } finally {
            await t.cancel()
        }
    },
    ot = (e, t, n, s) => {
        const o = Ms(e, t);
        let r = 0,
            i, c = f => {
                i || (i = !0, s && s(f))
            };
        return new ReadableStream({
            async pull(f) {
                try {
                    const {
                        done: l,
                        value: u
                    } = await o.next();
                    if (l) {
                        c(), f.close();
                        return
                    }
                    let d = u.byteLength;
                    if (n) {
                        let y = r += d;
                        n(y)
                    }
                    f.enqueue(new Uint8Array(u))
                } catch (l) {
                    throw c(l), l
                }
            },
            cancel(f) {
                return c(f), o.return()
            }
        }, {
            highWaterMark: 2
        })
    },
    he = typeof fetch == "function" && typeof Request == "function" && typeof Response == "function",
    Ut = he && typeof ReadableStream == "function",
    xs = he && (typeof TextEncoder == "function" ? (e => t => e.encode(t))(new TextEncoder) : async e => new Uint8Array(await new Response(e).arrayBuffer())),
    Dt = (e, ...t) => {
        try {
            return !!e(...t)
        } catch (n) {
            return !1
        }
    },
    Bs = Ut && Dt(() => {
        let e = !1;
        const t = new Request(P.origin, {
            body: new ReadableStream,
            method: "POST",
            get duplex() {
                return e = !0, "half"
            }
        }).headers.has("Content-Type");
        return e && !t
    }),
    rt = 64 * 1024,
    Pe = Ut && Dt(() => a.isReadableStream(new Response("").body)),
    ae = {
        stream: Pe && (e => e.body)
    };
he && (e => {
    ["text", "arrayBuffer", "blob", "formData", "stream"].forEach(t => {
        !ae[t] && (ae[t] = a.isFunction(e[t]) ? n => n[t]() : (n, s) => {
            throw new h("Response type '".concat(t, "' is not supported"), h.ERR_NOT_SUPPORT, s)
        })
    })
})(new Response);
const Hs = async e => {
        if (e == null) return 0;
        if (a.isBlob(e)) return e.size;
        if (a.isSpecCompliantForm(e)) return (await new Request(P.origin, {
            method: "POST",
            body: e
        }).arrayBuffer()).byteLength;
        if (a.isArrayBufferView(e) || a.isArrayBuffer(e)) return e.byteLength;
        if (a.isURLSearchParams(e) && (e = e + ""), a.isString(e)) return (await xs(e)).byteLength
    },
    Vs = async (e, t) => {
        const n = a.toFiniteNumber(e.getContentLength());
        return n == null ? Hs(t) : n
    },
    qs = he && (async e => {
        let {
            url: t,
            method: n,
            data: s,
            signal: o,
            cancelToken: r,
            timeout: i,
            onDownloadProgress: c,
            onUploadProgress: f,
            responseType: l,
            headers: u,
            withCredentials: d = "same-origin",
            fetchOptions: y
        } = Lt(e);
        l = l ? (l + "").toLowerCase() : "text";
        let R = Fs([o, r && r.toAbortSignal()], i),
            p;
        const m = R && R.unsubscribe && (() => {
            R.unsubscribe()
        });
        let E;
        try {
            if (f && Bs && n !== "get" && n !== "head" && (E = await Vs(u, s)) !== 0) {
                let O = new Request(t, {
                        method: "POST",
                        body: s,
                        duplex: "half"
                    }),
                    M;
                if (a.isFormData(s) && (M = O.headers.get("content-type")) && u.setContentType(M), O.body) {
                    const [B, ee] = tt(E, ie(nt(f)));
                    s = ot(O.body, rt, B, ee)
                }
            }
            a.isString(d) || (d = d ? "include" : "omit");
            const S = "credentials" in Request.prototype;
            p = new Request(t, { ...y,
                signal: R,
                method: n.toUpperCase(),
                headers: u.normalize().toJSON(),
                body: s,
                duplex: "half",
                credentials: S ? d : void 0
            });
            let A = await fetch(p);
            const T = Pe && (l === "stream" || l === "response");
            if (Pe && (c || T && m)) {
                const O = {};
                ["status", "statusText", "headers"].forEach($e => {
                    O[$e] = A[$e]
                });
                const M = a.toFiniteNumber(A.headers.get("content-length")),
                    [B, ee] = c && tt(M, ie(nt(c), !0)) || [];
                A = new Response(ot(A.body, rt, B, () => {
                    ee && ee(), m && m()
                }), O)
            }
            l = l || "text";
            let v = await ae[a.findKey(ae, l) || "text"](A, e);
            return !T && m && m(), await new Promise((O, M) => {
                It(O, M, {
                    data: v,
                    headers: C.from(A.headers),
                    status: A.status,
                    statusText: A.statusText,
                    config: e,
                    request: p
                })
            })
        } catch (S) {
            throw m && m(), S && S.name === "TypeError" && /fetch/i.test(S.message) ? Object.assign(new h("Network Error", h.ERR_NETWORK, e, p), {
                cause: S.cause || S
            }) : h.from(S, S && S.code, e, p)
        }
    }),
    Oe = {
        http: ts,
        xhr: Ds,
        fetch: qs
    };
a.forEach(Oe, (e, t) => {
    if (e) {
        try {
            Object.defineProperty(e, "name", {
                value: t
            })
        } catch (n) {}
        Object.defineProperty(e, "adapterName", {
            value: t
        })
    }
});
const it = e => "- ".concat(e),
    Gs = e => a.isFunction(e) || e === null || e === !1,
    Nt = {
        getAdapter: e => {
            e = a.isArray(e) ? e : [e];
            const {
                length: t
            } = e;
            let n, s;
            const o = {};
            for (let r = 0; r < t; r++) {
                n = e[r];
                let i;
                if (s = n, !Gs(n) && (s = Oe[(i = String(n)).toLowerCase()], s === void 0)) throw new h("Unknown adapter '".concat(i, "'"));
                if (s) break;
                o[i || "#" + r] = s
            }
            if (!s) {
                const r = Object.entries(o).map(([c, f]) => "adapter ".concat(c, " ") + (f === !1 ? "is not supported by the environment" : "is not available in the build"));
                let i = t ? r.length > 1 ? "since :\n" + r.map(it).join("\n") : " " + it(r[0]) : "as no adapter specified";
                throw new h("There is no suitable adapter to dispatch the request " + i, "ERR_NOT_SUPPORT")
            }
            return s
        },
        adapters: Oe
    };

function _e(e) {
    if (e.cancelToken && e.cancelToken.throwIfRequested(), e.signal && e.signal.aborted) throw new Y(null, e)
}

function at(e) {
    return _e(e), e.headers = C.from(e.headers), e.data = we.call(e, e.transformRequest), ["post", "put", "patch"].indexOf(e.method) !== -1 && e.headers.setContentType("application/x-www-form-urlencoded", !1), Nt.getAdapter(e.adapter || Be.adapter)(e).then(function(s) {
        return _e(e), s.data = we.call(e, e.transformResponse, s), s.headers = C.from(s.headers), s
    }, function(s) {
        return Ot(s) || (_e(e), s && s.response && (s.response.data = we.call(e, e.transformResponse, s.response), s.response.headers = C.from(s.response.headers))), Promise.reject(s)
    })
}
const Ft = "1.7.9",
    me = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((e, t) => {
    me[e] = function(s) {
        return typeof s === e || "a" + (t < 1 ? "n " : " ") + e
    }
});
const ct = {};
me.transitional = function(t, n, s) {
    function o(r, i) {
        return "[Axios v" + Ft + "] Transitional option '" + r + "'" + i + (s ? ". " + s : "")
    }
    return (r, i, c) => {
        if (t === !1) throw new h(o(i, " has been removed" + (n ? " in " + n : "")), h.ERR_DEPRECATED);
        return n && !ct[i] && (ct[i] = !0, console.warn(o(i, " has been deprecated since v" + n + " and will be removed in the near future"))), t ? t(r, i, c) : !0
    }
};
me.spelling = function(t) {
    return (n, s) => (console.warn("".concat(s, " is likely a misspelling of ").concat(t)), !0)
};

function js(e, t, n) {
    if (typeof e != "object") throw new h("options must be an object", h.ERR_BAD_OPTION_VALUE);
    const s = Object.keys(e);
    let o = s.length;
    for (; o-- > 0;) {
        const r = s[o],
            i = t[r];
        if (i) {
            const c = e[r],
                f = c === void 0 || i(c, r, e);
            if (f !== !0) throw new h("option " + r + " must be " + f, h.ERR_BAD_OPTION_VALUE);
            continue
        }
        if (n !== !0) throw new h("Unknown option " + r, h.ERR_BAD_OPTION)
    }
}
const oe = {
        assertOptions: js,
        validators: me
    },
    U = oe.validators;
class ce {
    constructor(t) {
        this.defaults = t, this.interceptors = {
            request: new Ze,
            response: new Ze
        }
    }
    async request(t, n) {
        try {
            return await this._request(t, n)
        } catch (s) {
            if (s instanceof Error) {
                let o = {};
                Error.captureStackTrace ? Error.captureStackTrace(o) : o = new Error;
                const r = o.stack ? o.stack.replace(/^.+\n/, "") : "";
                try {
                    s.stack ? r && !String(s.stack).endsWith(r.replace(/^.+\n.+\n/, "")) && (s.stack += "\n" + r) : s.stack = r
                } catch (i) {}
            }
            throw s
        }
    }
    _request(t, n) {
        typeof t == "string" ? (n = n || {}, n.url = t) : n = t || {}, n = V(this.defaults, n);
        const {
            transitional: s,
            paramsSerializer: o,
            headers: r
        } = n;
        s !== void 0 && oe.assertOptions(s, {
            silentJSONParsing: U.transitional(U.boolean),
            forcedJSONParsing: U.transitional(U.boolean),
            clarifyTimeoutError: U.transitional(U.boolean)
        }, !1), o != null && (a.isFunction(o) ? n.paramsSerializer = {
            serialize: o
        } : oe.assertOptions(o, {
            encode: U.function,
            serialize: U.function
        }, !0)), oe.assertOptions(n, {
            baseUrl: U.spelling("baseURL"),
            withXsrfToken: U.spelling("withXSRFToken")
        }, !0), n.method = (n.method || this.defaults.method || "get").toLowerCase();
        let i = r && a.merge(r.common, r[n.method]);
        r && a.forEach(["delete", "get", "head", "post", "put", "patch", "common"], p => {
            delete r[p]
        }), n.headers = C.concat(i, r);
        const c = [];
        let f = !0;
        this.interceptors.request.forEach(function(m) {
            typeof m.runWhen == "function" && m.runWhen(n) === !1 || (f = f && m.synchronous, c.unshift(m.fulfilled, m.rejected))
        });
        const l = [];
        this.interceptors.response.forEach(function(m) {
            l.push(m.fulfilled, m.rejected)
        });
        let u, d = 0,
            y;
        if (!f) {
            const p = [at.bind(this), void 0];
            for (p.unshift.apply(p, c), p.push.apply(p, l), y = p.length, u = Promise.resolve(n); d < y;) u = u.then(p[d++], p[d++]);
            return u
        }
        y = c.length;
        let R = n;
        for (d = 0; d < y;) {
            const p = c[d++],
                m = c[d++];
            try {
                R = p(R)
            } catch (E) {
                m.call(this, E);
                break
            }
        }
        try {
            u = at.call(this, R)
        } catch (p) {
            return Promise.reject(p)
        }
        for (d = 0, y = l.length; d < y;) u = u.then(l[d++], l[d++]);
        return u
    }
    getUri(t) {
        t = V(this.defaults, t);
        const n = Ct(t.baseURL, t.url);
        return Tt(n, t.params, t.paramsSerializer)
    }
}
a.forEach(["delete", "get", "head", "options"], function(t) {
    ce.prototype[t] = function(n, s) {
        return this.request(V(s || {}, {
            method: t,
            url: n,
            data: (s || {}).data
        }))
    }
});
a.forEach(["post", "put", "patch"], function(t) {
    function n(s) {
        return function(r, i, c) {
            return this.request(V(c || {}, {
                method: t,
                headers: s ? {
                    "Content-Type": "multipart/form-data"
                } : {},
                url: r,
                data: i
            }))
        }
    }
    ce.prototype[t] = n(), ce.prototype[t + "Form"] = n(!0)
});
const re = ce;
class He {
    constructor(t) {
        if (typeof t != "function") throw new TypeError("executor must be a function.");
        let n;
        this.promise = new Promise(function(r) {
            n = r
        });
        const s = this;
        this.promise.then(o => {
            if (!s._listeners) return;
            let r = s._listeners.length;
            for (; r-- > 0;) s._listeners[r](o);
            s._listeners = null
        }), this.promise.then = o => {
            let r;
            const i = new Promise(c => {
                s.subscribe(c), r = c
            }).then(o);
            return i.cancel = function() {
                s.unsubscribe(r)
            }, i
        }, t(function(r, i, c) {
            s.reason || (s.reason = new Y(r, i, c), n(s.reason))
        })
    }
    throwIfRequested() {
        if (this.reason) throw this.reason
    }
    subscribe(t) {
        if (this.reason) {
            t(this.reason);
            return
        }
        this._listeners ? this._listeners.push(t) : this._listeners = [t]
    }
    unsubscribe(t) {
        if (!this._listeners) return;
        const n = this._listeners.indexOf(t);
        n !== -1 && this._listeners.splice(n, 1)
    }
    toAbortSignal() {
        const t = new AbortController,
            n = s => {
                t.abort(s)
            };
        return this.subscribe(n), t.signal.unsubscribe = () => this.unsubscribe(n), t.signal
    }
    static source() {
        let t;
        return {
            token: new He(function(o) {
                t = o
            }),
            cancel: t
        }
    }
}
const $s = He;

function Ys(e) {
    return function(n) {
        return e.apply(null, n)
    }
}

function Ws(e) {
    return a.isObject(e) && e.isAxiosError === !0
}
const Ie = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511
};
Object.entries(Ie).forEach(([e, t]) => {
    Ie[t] = e
});
const zs = Ie;

function vt(e) {
    const t = new re(e),
        n = ft(re.prototype.request, t);
    return a.extend(n, re.prototype, t, {
        allOwnKeys: !0
    }), a.extend(n, t, null, {
        allOwnKeys: !0
    }), n.create = function(o) {
        return vt(V(e, o))
    }, n
}
const _ = vt(Be);
_.Axios = re;
_.CanceledError = Y;
_.CancelToken = $s;
_.isCancel = Ot;
_.VERSION = Ft;
_.toFormData = pe;
_.AxiosError = h;
_.Cancel = _.CanceledError;
_.all = function(t) {
    return Promise.all(t)
};
_.spread = Ys;
_.isAxiosError = Ws;
_.mergeConfig = V;
_.AxiosHeaders = C;
_.formToJSON = e => Pt(a.isHTMLForm(e) ? new FormData(e) : e);
_.getAdapter = Nt.getAdapter;
_.HttpStatusCode = zs;
_.default = _;
const lt = _;
class Ks {
    static async get(t, n, s) {
        try {
            return await lt.get(t)
        } catch (o) {
            return console.log("Network Error", o), !n || s && s > n ? null : await this.get(t, n, s ? s + 1 : 1)
        }
    }
    static async post(t, n, s) {
        var o;
        try {
            return await lt.post(t, JSON.parse(s), {
                headers: n
            })
        } catch (r) {
            console.log("Network Error", r), console.log("Network Online Status", (o = window.navigator) == null ? void 0 : o.onLine)
        }
    }
}
var te, Js = new Uint8Array(16);

function Xs() {
    if (!te && (te = typeof crypto < "u" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto < "u" && typeof msCrypto.getRandomValues == "function" && msCrypto.getRandomValues.bind(msCrypto), !te)) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
    return te(Js)
}
const Qs = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;

function Zs(e) {
    return typeof e == "string" && Qs.test(e)
}
var b = [];
for (var Re = 0; Re < 256; ++Re) b.push((Re + 256).toString(16).substr(1));

function eo(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0,
        n = (b[e[t + 0]] + b[e[t + 1]] + b[e[t + 2]] + b[e[t + 3]] + "-" + b[e[t + 4]] + b[e[t + 5]] + "-" + b[e[t + 6]] + b[e[t + 7]] + "-" + b[e[t + 8]] + b[e[t + 9]] + "-" + b[e[t + 10]] + b[e[t + 11]] + b[e[t + 12]] + b[e[t + 13]] + b[e[t + 14]] + b[e[t + 15]]).toLowerCase();
    if (!Zs(n)) throw TypeError("Stringified UUID is invalid");
    return n
}

function Ve(e, t, n) {
    e = e || {};
    var s = e.random || (e.rng || Xs)();
    if (s[6] = s[6] & 15 | 64, s[8] = s[8] & 63 | 128, t) {
        n = n || 0;
        for (var o = 0; o < 16; ++o) t[n + o] = s[o];
        return t
    }
    return eo(s)
}
const Gr = "tolstoy-interaction-date-verification",
    jr = "player-buttons",
    $r = "feed-hide-share",
    Yr = "feed-hide-checkout-button",
    Wr = "player-resolution",
    zr = "feed-use-mux",
    to = "widget-events",
    Kr = "feed-hide-buy-now-button",
    Jr = "feed-open-pdp-in-same-tab",
    Xr = "feed-open-description-cta-in-same-tab",
    Qr = "player-hide-end-screen",
    Zr = "recharge-integration",
    ei = "tolstoy-customer-login",
    ti = "description-close-feed-pdp",
    ni = "player-feed-custom-style",
    si = "show-video-name",
    oi = "feed-product-variant-picker",
    ri = "feed-report-button",
    ii = "feed-video-search",
    ai = "white-label",
    ci = "studio-white-label",
    li = "player-feed-mobile-price-top-location",
    ui = "interactive-feed",
    di = "interactive-feed-post-mvp",
    fi = "shopify-price-formatting",
    pi = "widget-poster-settings",
    Ei = "hide-wishlist",
    hi = "https://www.gotolstoy.com/?utm_source=watermark&utm_medium=player&utm_campaign=logo_header",
    no = "isShopifyStore",
    so = "shopifyStoreUrl",
    mi = "shopifyRootRoute",
    oo = "currentPageDbProductId",
    ro = "productId",
    gi = "variant",
    io = "isTapcart",
    ao = "tolstoyStartVideo",
    yi = "tolstoyAutoOpen",
    Si = "shopifypreview.com",
    co = 160,
    lo = e => {
        const t = parseInt(e.substring(1, 3), 16),
            n = parseInt(e.substring(3, 5), 16),
            s = parseInt(e.substring(5, 7), 16);
        return [t, n, s]
    },
    uo = e => {
        const [t, n, s] = lo(e);
        return (t * 299 + n * 587 + s * 114) / 1e3
    },
    fo = e => e ? uo(e) < co : !1,
    po = e => Math.round(e * 2.55).toString(16).toUpperCase().padStart(2, "0"),
    wi = (e, t) => "".concat(e).concat(po(t)),
    Eo = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
    ho = ["Win32", "Win64", "Windows", "WinCE"],
    G = class G {
        static getIsEmbed(t) {
            return t === "embed"
        }
        static getIsTv(t) {
            return t === "tv"
        }
        static getIsAiVideo(t) {
            return t === "aiVideo"
        }
        static getIsLandingPage() {
            return !window.location.search.includes("host")
        }
        static getParam(t) {
            return new URLSearchParams(window.location.search).get(t)
        }
        static getPlayerVersion() {
            return this.getParam("pv")
        }
        static getWidgetSessionId() {
            return this.getParam("si")
        }
        static getUserConsent() {
            return this.getParam("userConsent") !== "false"
        }
        static getWidgetAnonymousId() {
            return this.getParam("ai")
        }
        static getResolution() {
            return this.getParam("resolution")
        }
        static getPlayerType() {
            return this.getParam("playerType")
        }
        static getIsAppPreview() {
            return window.location.origin === hn
        }
        static getParentUrl() {
            return this.getParam("url")
        }
        static getName() {
            return this.getParam("name")
        }
        static getEmail() {
            return this.getParam("email")
        }
        static getPhone() {
            return this.getParam("phone")
        }
        static getPublishId() {
            return this.getParam("publishId")
        }
        static getVodAssetId() {
            return this.getParam("vodAssetId")
        }
        static getReplyProjectId() {
            return this.getParam("replyProjectId")
        }
        static getIsShoppable() {
            return this.getParam("isShoppable") !== "false"
        }
        static getCurrentPageDbProductId() {
            return this.getParam(oo)
        }
        static getProductId() {
            return this.getParam(ro)
        }
        static getIsDebug() {
            return this.getParam("td")
        }
        static getIsDynamic() {
            return this.getParam("isDynamic") === "true"
        }
        static getShopifyStoreUrl() {
            return this.getParam(so)
        }
        static getPlayerId() {
            return this.getParam("pi")
        }
        static getIsShopifyStore() {
            return this.getParam(no) === "true"
        }
        static getIsTapcart() {
            return this.getParam(io) === "true"
        }
        static getStartVideoId() {
            return this.getParam(ao)
        }
        static isNullOrUndefined(t) {
            return t == null
        }
        static isSafari() {
            const t = new URLSearchParams(window.location.search);
            return window.safari !== void 0 || t.get("safari") === "true"
        }
        static isIphone() {
            return navigator.platform === "iPhone" || navigator.platform === "iPhone Simulator"
        }
        static isValidEmail(t) {
            return t && !t.endsWith(".dbz") && Eo.test(String(t).toLowerCase())
        }
        static isFirefox() {
            return navigator.userAgent.toLowerCase().indexOf("firefox") > -1
        }
        static isWindows() {
            return ho.some(t => t === navigator.platform)
        }
        static componentLoader(t, n) {
            return n = n || 20, new Promise((s, o) => {
                t().then(s).catch(() => {
                    setTimeout(() => {
                        if (n === 1) {
                            this.log("Failed to lazy load component.");
                            return
                        }
                        this.componentLoader(t, n - 1).then(s, o)
                    }, 500)
                })
            })
        }
        static log(t) {
            if (window.Sentry) {
                window.Sentry.captureMessage(t);
                return
            }
            console.error(t)
        }
        static logError(t, n) {
            if (!window.Sentry) {
                console.log("error ", t, n);
                return
            }
            n ? window.Sentry.captureException(t, {
                tags: {
                    message: n
                }
            }) : window.Sentry.captureException(t)
        }
        static async hasPermission(t) {
            try {
                const n = await navigator.permissions.query({
                    name: t
                });
                return (n == null ? void 0 : n.state) === "granted"
            } catch (n) {
                return console.error(n), !1
            }
        }
        static isMobile() {
            return this.isAndroid() || this.isIos()
        }
        static openInNewTab(t) {
            const n = window.open(t, "_blank");
            n == null || n.focus()
        }
        static isAndroid() {
            return navigator.userAgent.toLowerCase().indexOf("android") > -1
        }
        static isIos() {
            return /iPad|iPhone|iPod/.test(navigator.platform) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1
        }
        static isChrome() {
            return /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor)
        }
        static enforceProtocol(t, n = "https") {
            return t.startsWith("http") || t.startsWith("//") || t.startsWith("tel:") || t.startsWith("mailto:") ? t : "".concat(n, "://").concat(t)
        }
        static addUrlParam(t, n, s) {
            const o = new URL(this.enforceProtocol(t));
            return o.searchParams.set(n, s), o.toString()
        }
        static getVisibilityEventNames() {
            let t, n;
            return typeof document.hidden < "u" ? (t = "hidden", n = "visibilitychange") : typeof document.msHidden < "u" ? (t = "msHidden", n = "msvisibilitychange") : typeof document.webkitHidden < "u" && (t = "webkitHidden", n = "webkitvisibilitychange"), {
                hidden: t,
                visibilityChange: n
            }
        }
        static loadScript(t, n) {
            const s = document.createElement("script");
            s.type = "text/javascript", s.async = !0, s.src = t, n && (s.onload = n);
            const o = document.getElementsByTagName("script")[0];
            o.parentNode.insertBefore(s, o)
        }
        static sizeInBytesToMb(t) {
            return (t / (1024 * 1024)).toFixed(2)
        }
        static isInnerTheme(t) {
            return t === "inner"
        }
        static uniq(t) {
            return [...new Set(t)]
        }
        static getFromArray(t, n, s) {
            return n.reduce((o, r) => o && o[r], t) || s
        }
        static formatDateMinutes(t) {
            return ("0" + t.getMinutes()).slice(-2)
        }
        static isResponse(t) {
            return [g.audioResponse, g.videoResponse, g.imageResponse, g.collectInfo, g.submitInput].includes(t)
        }
        static isLightHouse(t) {
            return t.toLocaleLowerCase().includes("chrome-lighthouse")
        }
        static getButtonTextColor({
            color: t,
            theme: n,
            defaultColor: s
        }) {
            return t ? fo(t) ? n.colors.white : n.colors.black : s || n.colors.white
        }
        static scheduleCallbackToNextRender(t) {
            requestAnimationFrame(() => {
                requestAnimationFrame(() => {
                    t()
                })
            })
        }
        static getAccountLogoUrl(t) {
            return "".concat(En, "/public/assets/").concat(t, "/player-logo.png")
        }
        static checkIfUrlIsAllowed(t, n) {
            if (!n) return !0;
            let s;
            try {
                s = new URL(t).origin
            } catch (o) {
                return G.logError("Failed to parse url", t), !1
            }
            return n.some(o => (o = new URL(o).origin, s === o))
        }
        static checkIfParentUrlIsAllowed(t) {
            if (!t) return !0;
            const n = G.getIsLandingPage() ? window.location.href : document.referrer;
            return G.checkIfUrlIsAllowed(n, t)
        }
    };
Ye(G, "getCookieValue", t => {
    var n;
    return ((n = document.cookie.match("(^|;)\\s*" + t + "\\s*=\\s*([^;]+)")) == null ? void 0 : n.pop()) || ""
});
let w = G;

function _i() {
    (function(e, t, n, s, o, r, i) {
        e.fbq || (o = e.fbq = function() {
            o.callMethod ? o.callMethod.apply(o, arguments) : o.queue.push(arguments)
        }, e._fbq || (e._fbq = o), o.push = o, o.loaded = !0, o.version = "2.0", o.queue = [], r = t.createElement(n), r.async = !0, r.src = s, i = t.getElementsByTagName(n)[0], i.parentNode.insertBefore(r, i))
    })(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js")
}
const mo = e => {
        const {
            eventName: t,
            facebookAnalyticsID: n,
            playlist: s,
            text: o,
            collectInfoType: r
        } = e;
        if (!window.fbq || !n) return;
        const i = "tolstoy-".concat(s);
        t === g.sessionStart ? k(n, "".concat(i, "-click"), {
            value: "Start Tolstoy"
        }) : t === g.clickCta ? k(n, "".concat(i, "-click"), {
            value: o
        }) : t === g.submitInput ? k(n, "".concat(i, "-input"), {
            value: o
        }) : t === g.collectInfo ? k(n, "".concat(i, "-").concat(g.collectInfo), {
            value: r
        }) : t === g.videoResponse ? k(n, "".concat(i, "-").concat(g.videoResponse)) : t === g.imageResponse ? k(n, "".concat(i, "-").concat(g.imageResponse)) : t === g.audioResponse ? k(n, "".concat(i, "-").concat(g.audioResponse)) : t === g.sessionEnd && k(n, "".concat(i, "-").concat(g.sessionEnd))
    },
    k = (e, t, n) => {
        window.fbq("trackSingleCustom", e, t, n)
    },
    go = e => {
        !e || !window.fbq || (window.fbq("init", fn), window.fbq("track", "PageView"), window.fbq("init", e), window.fbq("trackSingle", e, "PageView"))
    },
    Ri = () => {
        if (window.gtag || window.dataLayer) return;
        const e = document.createElement("script");
        e.src = "https://www.googletagmanager.com/gtag/js?id=".concat(ze), document.head.appendChild(e), window.dataLayer = window.dataLayer || [];

        function t() {
            window.dataLayer.push(arguments)
        }
        window.gtag = t, window.gtag("js", new Date), window.gtag("config", ze)
    },
    yo = ({
        eventName: e,
        text: t,
        playlist: n,
        collectInfoType: s
    }) => {
        window.gtag && (e === g.sessionStart ? (D(n, "click", "Start Tolstoy"), D(n, N.sessionStart)) : e === g.clickCta ? (D(n, "click", t), D(n, N.clickCta, t)) : e === g.submitInput ? D(n, N.submitInput) : e === g.collectInfo ? D(n, N.collectInfo, s) : e === g.videoResponse ? D(n, N.videoResponse) : e === g.imageResponse ? D(n, N.imageResponse) : e === g.audioResponse ? D(n, N.audioResponse) : e === g.sessionEnd && D(n, N.sessionEnd))
    },
    D = (e, t, n) => {
        const s = "tolstoy-".concat(e);
        window.gtag("event", t, {
            event_category: s,
            event_label: n
        })
    },
    So = e => {
        const t = e;
        !t || !window.gtag || (window.gtag("config", t, {
            campaign_name: "clientTracker",
            cookie_domain: "auto",
            cookie_flags: "max-age=7200;secure;samesite=none"
        }), window.gtag("event", "tolstoyPageView"))
    },
    wo = 4e3;
let Mt = !1;
const Ce = [],
    _o = () => {
        for (; Ce.length;) {
            const {
                eventFunction: e,
                args: t
            } = Ce.shift();
            e(...t)
        }
    };
setTimeout(() => {
    Mt = !0, _o()
}, wo);
const Ro = e => (...t) => {
        if (Mt) return e(...t);
        Ce.push({
            eventFunction: e,
            args: t
        })
    },
    kt = {
        VISIBILITY_CHANGE: "visibilitychange",
        MODAL_CLOSE: "tolstoyModalClose",
        PLAY: "tolstoyPlay",
        ADD_TO_CART: "addToCart",
        CART_ITEM_QUANTITY_CHANGE: "cartItemQuantityChange"
    },
    Ai = {
        getProductsMetafields: "getProductsMetafields",
        returnProductsMetafields: "returnProductsMetafields"
    },
    x = {},
    Ti = (e, t) => {
        x[e] || (x[e] = []), x[e].push(t)
    },
    bi = (e, t) => {
        x[e] && (x[e] = x[e].filter(n => n !== t))
    },
    xt = (e, t) => {
        x[e] && x[e].forEach(n => n(t))
    },
    Ao = e => {
        xt(kt.VISIBILITY_CHANGE, e)
    },
    To = e => {
        const t = Ht(e);
        xt(t, e)
    },
    Bt = {
        [kt.VISIBILITY_CHANGE]: Ao
    },
    Pi = () => {
        window.addEventListener("message", e => {
            To(e)
        }), Object.entries(Bt).forEach(([e, t]) => {
            document.addEventListener(e, t)
        })
    },
    Oi = () => {
        Object.entries(Bt).forEach(([e, t]) => {
            document.removeEventListener(e, t)
        })
    },
    Ht = e => {
        var t, n;
        return ((t = e.data) == null ? void 0 : t.eventName) || ((n = e.data) == null ? void 0 : n.name) || e.data
    },
    Vt = ["mousedown", "mousemove", "keypress", "scroll", "touchstart", "keydown"],
    bo = [g.pageView, "embedView"];
let F = {
    sessionId: w.getWidgetSessionId() || Ve()
};
const Po = 7200,
    Oo = 60,
    Io = 1e3;
let J = 0,
    qt = 0,
    qe = 0,
    j, q, z = 0,
    Z = !1,
    X = 0,
    Gt = {},
    Le = !1,
    Ue = !1,
    De;
const jt = ({
    playerType: e
} = {}) => w.getIsEmbed(e) || w.getIsLandingPage() || !Gt[to] ? !0 : Le ? !1 : !w.getWidgetSessionId();
window.addEventListener("message", e => {
    if (!e.data) return;
    const t = Ht(e);
    t === un && F.parentUrl && Wt(), t === "setTolstoyData" && Ge({
        parentUrl: e.data.parentUrl
    }), t === "tolstoyWidgetShown" && jt() && je(g.pageView, F), t === "embedView" && Uo(le(e)), e.data.playerVariant === "inTileCarousel" && Lo(le(e))
});
const Co = e => bo.includes(e),
    le = e => {
        const {
            name: t,
            ...n
        } = e.data;
        return {
            eventName: t,
            data: n
        }
    },
    Lo = ({
        eventName: e,
        data: t = {}
    } = {}) => {
        Co(e) || (Yt(t), ge(e, t))
    },
    Uo = ({
        data: e = {}
    } = {}) => {
        $t(e)
    },
    $t = (e = {}) => {
        ge("embedView", e)
    },
    Yt = (e = {}) => {
        Ue || (Ue = !0, ge(g.sessionStart, e))
    },
    Wt = (e = !0) => {
        F.sessionId = Ve(), qt = J, J = 0, qe = 0, z = 0, Z = !1, X = 0, Ue = !1, e && (clearInterval(j), Fe(), j = null)
    },
    Ge = e => {
        F = { ...F,
            ...e
        }
    },
    zt = () => {
        const e = w.getWidgetAnonymousId();
        if (e) return e;
        try {
            const t = document.cookie.split("; ").find(n => n.startsWith("tolstoy-anonymousId"));
            if (t) {
                const [, n] = t.split("=");
                return n
            }
            return window.localStorage.getItem("tolstoy-anonymousId")
        } catch (t) {
            return console.log("Failed to read from the local storage."), null
        }
    },
    Do = e => {
        if (!(!e || e === "undefined")) try {
            window.localStorage.setItem("tolstoy-anonymousId", e), document.cookie = "tolstoy-anonymousId=".concat(e, "; samesite=none; secure=true; domain=gotolstoy.com; path=/; max-age=31536000;")
        } catch (t) {
            console.log("Failed to read from the local storage.")
        }
    },
    No = e => {
        if (!e) return;
        const t = w.getCookieValue("tolstoy-viewed");
        if (t.includes(e)) return;
        const n = t.split(",");
        let s;
        n.length === 10 ? (n.pop(), n.unshift(e), s = n.join(",")) : s = "".concat(e).concat(t && ",".concat(t)), document.cookie = "tolstoy-viewed=".concat(s, "; samesite=none; secure=true; Domain=gotolstoy.com")
    },
    Kt = (e, t, n = {}, s = {}) => {
        window.anonymousId = e.anonymousId || zt();
        const {
            facebookAnalyticsID: o,
            preview: r
        } = e;
        console.log("init analytics");
        const i = { ...e
        };
        Object.keys(n).length && (i.customParams = JSON.stringify(n)), Gt = s, Ge(i), (!window.anonymousId || ["undefined", "false"].includes(window.anonymousId)) && (window.anonymousId = Ve()), Do(window.anonymousId), Fo({
            preview: r,
            facebookAnalyticsID: o,
            analyticsData: F,
            delayPageView: t
        })
    },
    Fo = ({
        preview: e,
        facebookAnalyticsID: t,
        analyticsData: n,
        delayPageView: s
    }) => {
        Le || s || (e || (So(n.googleAnalyticsID), go(t)), jt(n) && (je(g.pageView, n), Jt(g.pageView, n)), Le = !0)
    },
    ge = async (e, t) => {
        if (De) {
            De.track(e, t);
            return
        }
        g.sessionStart === e && !j && !F.preview && (j = window.setInterval(ko, 1e3)), e === g.videoPause ? Fe() : [g.sessionStart, g.videoStart, g.videoResume].includes(e) && ut();
        const n = { ...F,
            ...t,
            responseTime: qe
        };
        n.answerType && (Fe(), z = 0), !n.answerType && z && w.isResponse(e) && (ut(), n.responseTime = z), Jt(e, n), console.log("track", e, n), await je(e, n)
    },
    Jt = (e, t) => {
        const n = N[e] || g[e] || e,
            s = {};
        if (!n || (e === g.sessionStart && No(t.publishId), window.parent.postMessage({ ...t,
                anonymousId: window.anonymousId,
                name: n,
                totalTime: J || qt,
                ...s
            }, "*"), !N[e])) return;
        const o = new CustomEvent("tolstoyPlayerEvent", {
            detail: { ...t,
                anonymousId: window.anonymousId,
                name: n
            }
        });
        window.dispatchEvent(o)
    },
    je = async (e, t) => {
        await vo(e, t)
    },
    vo = async (e, t) => {
        const n = {
            timestamp: new Date().toISOString(),
            anonymousId: window.anonymousId,
            eventName: e,
            ...t
        };
        await Ho("".concat(pn, "/events/event"), n), console.log("SENT", {
            anonymousId: window.anonymousId,
            eventName: e,
            ...t
        })
    },
    Mo = () => {
        var t;
        const e = document.querySelector("#root");
        return !!((t = e == null ? void 0 : e.firstChild) != null && t.offsetWidth)
    },
    ko = () => {
        const e = Mo();
        (document.hasFocus() || e) && !document.hidden && !Z && (J += 1, qe += 1, z += 1), J >= Po && (clearInterval(j), j = null)
    },
    Ne = (e, t) => Ks.post(e, {}, t),
    xo = (e, t) => {
        try {
            if (!window.navigator.sendBeacon(e, t)) return Ne(e, t)
        } catch (n) {
            return w.logError(n), Ne(e, t)
        }
    },
    Bo = Ro((e, t) => {
        var n;
        if (w.getUserConsent()) return (n = window.navigator) != null && n.sendBeacon ? xo(e, t) : Ne(e, t)
    }),
    Ho = async (e, t) => {
        F.preview || w.getIsAppPreview() || !w.getUserConsent() || (await Bo(e, JSON.stringify(t)), yo(t), mo(t))
    },
    Xt = () => {
        q || (q = setInterval(() => {
            X += 1, Oo === X && Vo()
        }, Io))
    },
    Vo = () => {
        Z = !0, clearInterval(q), X = 0, q = null
    },
    Qt = () => {
        X = 0, Z = !1, Xt()
    },
    Fe = () => {
        clearInterval(q), q = null, Z = !1, Vt.forEach(e => {
            document.removeEventListener(e, Qt, !0)
        })
    },
    ut = () => {
        q || (Xt(), Vt.forEach(e => {
            document.addEventListener(e, Qt, !0)
        }))
    },
    qo = () => F.sessionId,
    Go = e => {
        De = e
    },
    Ii = Object.freeze(Object.defineProperty({
        __proto__: null,
        addAnalyticsData: Ge,
        formatWidgetEventData: le,
        getAnonymousId: zt,
        getSessionId: qo,
        initAnalytics: Kt,
        resetSession: Wt,
        track: ge,
        trackEmbedView: $t,
        trackSessionStart: Yt,
        updateTracker: Go
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    jo = () => w.getIsDebug() || dn !== "production",
    $o = () => {
        jo() || (window.tolstoyLogs = [], window.tolstoyConsoleLog = console.log, window.tolstoyRestoreConsoleLog = () => {
            console.log = window.tolstoyConsoleLog, window.tolstoyLogs.forEach(console.log), window.tolstoyLogs = []
        }, console.log = function() {
            try {
                window.tolstoyLogs.push([...arguments])
            } catch (e) {
                w.logError(e, "error while storing log message")
            }
        })
    },
    Zt = [],
    Yo = ["embedView", "embedPlay", "embedPause", "embedMute", "embedUnmute", "embedExpand"];
let en = !1,
    tn = {};
const Wo = () => {
        const e = window.location.pathname,
            t = e == null ? void 0 : e.split("/");
        return t == null ? void 0 : t[(t == null ? void 0 : t.length) - 1]
    },
    zo = ({
        data: e
    } = {}) => !(e != null && e.name) && !(e != null && e.eventName) ? !0 : Yo.includes(e.name || e.eventName),
    nn = async e => {
        if (console.log("new event ", Wo(), e), zo(e)) {
            console.log("event ignored");
            return
        }
        if (e.data.name === "analyticsData") return Qo(e.data);
        if (e.data.name === "pageView") return Zo(le(e));
        if (e.data.eventName === dt) return Jo();
        Zt.push(e), !en && await Ko()
    },
    Ko = async () => {
        en = !0, await ln(() =>
            import ("../index.js").then(e => e.O), ["index.css"])
    },
    Jo = () => {
        window.removeEventListener("message", nn), Zt.forEach(e => {
            window.postMessage(e.data, window.location.origin || "*")
        })
    },
    Xo = () => {
        window.addEventListener("message", nn)
    },
    Qo = ({
        params: e
    }) => {
        tn = {
            playerType: w.getPlayerType(),
            parentUrl: w.getParentUrl(),
            name: w.getName(),
            email: w.getEmail(),
            phone: w.getPhone(),
            abTestId: e.abTestId,
            accountId: e.accountId,
            appKey: e.appKey,
            isMobile: e.isMobile,
            publishId: e.publishId,
            projectId: e.projectId,
            playlist: e.playlist,
            facebookAnalyticsID: e.facebookAnalyticsID,
            googleAnalyticsID: e.googleAnalyticsID
        }
    },
    Zo = ({
        data: e
    }) => {
        Kt({ ...tn,
            ...e
        })
    },
    er = () => {
        window.parent.postMessage({
            eventName: dt
        }, "*")
    },
    tr = () => {
        $o(), Xo(), er()
    };
tr();
export {
    pn as $, qo as A, dt as B, Ur as C, Lr as D, kt as E, pi as F, Ir as G, Ks as H, Fr as I, Or as J, Rr as K, ur as L, vr as M, dn as N, un as O, Mr as P, or as Q, Dr as R, yr as S, yi as T, w as U, mr as V, gr as W, si as X, Kt as Y, lt as Z, ln as _, sr as __vite_legacy_guard, ao as a, ge as a0, g as a1, hi as a2, Hr as a3, fo as a4, Qr as a5, Wt as a6, N as a7, Gr as a8, jr as a9, no as aA, so as aB, mi as aC, Zr as aD, Ai as aE, Ii as aF, Go as aG, _r as aH, wr as aI, Sr as aJ, ro as aK, ni as aL, Br as aM, li as aN, Ve as aO, xr as aP, Wr as aa, fr as ab, Ar as ac, gi as ad, Si as ae, ti as af, Pr as ag, Cr as ah, ei as ai, fi as aj, dr as ak, pr as al, cr as am, lr as an, ar as ao, ir as ap, Yr as aq, oi as ar, Kr as as, Jr as at, Tr as au, br as av, Er as aw, hr as ax, ui as ay, di as az, Nr as b, zt as c, kr as d, wi as e, qr as f, Ht as g, _i as h, Pi as i, ai as j, rr as k, Ri as l, $r as m, ri as n, $o as o, Xr as p, ii as q, Oi as r, Ti as s, Ei as t, bi as u, ci as v, zr as w, Ge as x, Yt as y, Vr as z
};