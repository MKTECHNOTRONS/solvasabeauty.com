var T = (e, a, d) => new Promise((p, c) => {
    var E = o => {
            try {
                r(d.next(o))
            } catch (n) {
                c(n)
            }
        },
        s = o => {
            try {
                r(d.throw(o))
            } catch (n) {
                c(n)
            }
        },
        r = o => o.done ? p(o.value) : Promise.resolve(o.value).then(E, s);
    r((d = d.apply(e, a)).next())
});
const S = {
        BASE_URL: "https://play.gotolstoy.com/widget-v2",
        DEV: !1,
        MODE: "production",
        PROD: !0,
        SSR: !1,
        VITE_API_BASE_URL: "https://api.gotolstoy.com",
        VITE_API_LB_BASE_URL: "https://apilb.gotolstoy.com",
        VITE_API_LB_CDN_BASE_URL: "https://cf-apilb.gotolstoy.com",
        VITE_ENV: "production",
        VITE_INDEX_PATH: "./widget.js",
        VITE_ON_YOU_BASE_URL: "https://on-you.gotolstoy.com",
        VITE_ON_YOU_BASE_URL_V2: "https://play.gotolstoy.com/widget-v2",
        VITE_ON_YOU_SHOPIFY_PROXY_PREFIX: "apps",
        VITE_ON_YOU_SHOPIFY_PROXY_SUBPATH: "onyou",
        VITE_REACT_APP_API_BASE_URL: "https://api.gotolstoy.com",
        VITE_REACT_APP_ASSETS_OUTPUT: "https://assets.gotolstoy.com",
        VITE_REACT_APP_CONFIG_URL_CDN: "https://d39ynn9qmq2swd.cloudfront.net/public/published",
        VITE_REACT_APP_FACEBOOK_ANALYTICS_KEY: "4003456519730074",
        VITE_REACT_APP_GOOGLE_ANALYTICS_KEY: "UA-180961004-6",
        VITE_REACT_APP_IMAGE_OUTPUT: "https://tolstoy-files-prod-output.s3.amazonaws.com",
        VITE_REACT_APP_MUX_DATA_KEY: "udo8kqf9tsneg0t116idg2afe",
        VITE_REACT_APP_PROJECTS_URL: "https://tolstoyprojects221542-prod.s3.amazonaws.com/public",
        VITE_REACT_APP_VIDEO_OUTPUT: "videos.gotolstoy.com",
        VITE_REACT_APP_ZEROBOUNCE_KEY: "3f8e942efa104ecba7d77cd94845d95a"
    },
    u = e => {
        const a = S[e];
        return a === void 0 ? "" : a
    },
    V = () => u("VITE_ENV") === "production",
    f = () => u("VITE_ENV") === "development",
    D = () => u("VITE_API_LB_BASE_URL"),
    w = () => u("VITE_API_LB_CDN_BASE_URL"),
    v = () => u("VITE_API_BASE_URL"),
    Y = () => u("VITE_ON_YOU_BASE_URL_V2"),
    B = () => u("VITE_ON_YOU_SHOPIFY_PROXY_PREFIX"),
    b = () => u("VITE_ON_YOU_SHOPIFY_PROXY_SUBPATH"),
    R = "td=true",
    g = window.location.search.includes(R) || f(),
    y = (...e) => {
        g && console.log("Tolstoy Error", ...e)
    },
    G = e => {
        g && console.log("Tolstoy", e)
    };
var I = (e => (e.LOADING = "loading", e.SUCCESS = "success", e.FAILED = "failed", e.INACTIVE = "inactive", e))(I || {});
const M = {
        COLLECTION_PAGE_TILE: "collection-page-tile",
        PRODUCT_TILE: "product-tile",
        PRODUCT_PAGE_VIDEO: "product-page-video",
        PRODUCT_PAGE_VIDEO_TEST_GALLERY: "product-page-video-test-gallery",
        ON_YOU: "on-you"
    },
    m = {
        PUBLISH_ID: "data-publish-id",
        PRODUCT_ID: "data-product-id",
        COLLECTION_ID: "data-collection-id",
        STATUS: "data-status",
        APP_URL: "data-app-url",
        URL: "data-url",
        HIDE_GOOGLE_SIGNIN: "data-hide-google-signin",
        HIDE_EMAIL_OTP_SIGNIN: "data-hide-email-otp-signin",
        OPEN_IN_NEW_WINDOW: "data-open-in-new-window",
        ALWAYS_MOBILE: "data-always-mobile",
        CUSTOMER_EMAIL: "data-customer-email",
        SIGNED_IN_TO_SHOPIFY: "data-signed-in-to-shopify",
        TAPCART_APP_ID: "data-tapcart-app-id",
        TAPCART_CUSTOMER_ACCESS_TOKEN: "data-tapcart-customer-access-token",
        FULLSCREEN_MODE: "data-fullscreen-mode",
        HARD_RESET: "data-hard-reset"
    },
    H = (d, ...p) => T(void 0, [d, ...p], function*(e, a = {}) {
        const c = Object.values(e).map(({
                key: t
            }) => t),
            E = new Map;
        let s = !1;
        const r = t => {
                const i = _ => _ instanceof HTMLElement ? c.some(A => _.classList.contains(A)) ? !0 : c.some(A => _.getElementsByClassName(A).length > 0) : !1,
                    l = new MutationObserver(_ => {
                        _.some(O => O.type === "childList" && Array.from(O.addedNodes).some(U => i(U))) && t()
                    });
                return l.observe(document.body, {
                    childList: !0,
                    subtree: !0
                }), l
            },
            o = (t, i) => T(void 0, null, function*() {
                if (E.get(t) === i || t.dataset.status) return;
                const l = Object.values(e).find(({
                    key: _
                }) => _ === i);
                if (l) try {
                    t.setAttribute(m.STATUS, I.LOADING), yield(yield l.controller()).default(t), E.set(t, i)
                } catch (_) {
                    y("error in widgetLoader", _), t.setAttribute(m.STATUS, I.FAILED), E.delete(t)
                }
            }),
            n = () => T(void 0, null, function*() {
                const t = c.flatMap(i => {
                    const l = document.getElementsByClassName(i);
                    return Array.from(l).map(_ => o(_, i))
                });
                yield Promise.all(t)
            });
        (() => {
            s || (window.addEventListener("DOMContentLoaded", n), window.addEventListener("load", n), "MutationObserver" in window && r(n), s = !0)
        })(), Object.values(a).forEach(({
            init: t
        }) => {
            t()
        }), yield n()
    }),
    h = function() {
        const a = typeof document != "undefined" && document.createElement("link").relList;
        return a && a.supports && a.supports("modulepreload") ? "modulepreload" : "preload"
    }(),
    C = function(e) {
        return "https://play.gotolstoy.com/widget-v2/" + e
    },
    L = {},
    F = function(a, d, p) {
        let c = Promise.resolve();
        if (d && d.length > 0) {
            document.getElementsByTagName("link");
            const s = document.querySelector("meta[property=csp-nonce]"),
                r = (s == null ? void 0 : s.nonce) || (s == null ? void 0 : s.getAttribute("nonce"));
            c = Promise.allSettled(d.map(o => {
                if (o = C(o), o in L) return;
                L[o] = !0;
                const n = o.endsWith(".css"),
                    P = n ? '[rel="stylesheet"]' : "";
                if (document.querySelector(`link[href="${o}"]${P}`)) return;
                const t = document.createElement("link");
                if (t.rel = n ? "stylesheet" : h, n || (t.as = "script"), t.crossOrigin = "", t.href = o, r && t.setAttribute("nonce", r), document.head.appendChild(t), n) return new Promise((i, l) => {
                    t.addEventListener("load", i), t.addEventListener("error", () => l(new Error(`Unable to preload CSS for ${o}`)))
                })
            }))
        }

        function E(s) {
            const r = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (r.payload = s, window.dispatchEvent(r), !r.defaultPrevented) throw s
        }
        return c.then(s => {
            for (const r of s || []) r.status === "rejected" && E(r.reason);
            return a().catch(E)
        })
    };
export {
    m as D, I as W, F as _, D as a, y as b, H as c, M as d, v as e, Y as f, w as g, B as h, V as i, b as j, R as k, G as l, f as m
};