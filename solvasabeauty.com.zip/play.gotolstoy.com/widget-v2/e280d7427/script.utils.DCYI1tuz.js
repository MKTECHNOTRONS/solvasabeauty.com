const s = () => document.getElementById("tolstoy-widget-script"),
    c = e => {
        const t = s();
        return (t == null ? void 0 : t.getAttribute(`data-${e}`)) || null
    },
    n = () => !(c("should-use-cache") === "false");
export {
    n as s
};