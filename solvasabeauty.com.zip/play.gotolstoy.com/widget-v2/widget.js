var R = Object.defineProperty,
    U = Object.defineProperties;
var G = Object.getOwnPropertyDescriptors;
var f = Object.getOwnPropertySymbols;
var M = Object.prototype.hasOwnProperty,
    k = Object.prototype.propertyIsEnumerable;
var w = (r, t, e) => t in r ? R(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    O = (r, t) => {
        for (var e in t || (t = {})) M.call(t, e) && w(r, e, t[e]);
        if (f)
            for (var e of f(t)) k.call(t, e) && w(r, e, t[e]);
        return r
    },
    m = (r, t) => U(r, G(t));
var A = (r, t, e) => w(r, typeof t != "symbol" ? t + "" : t, e);
var d = (r, t, e) => new Promise((o, s) => {
    var n = i => {
            try {
                l(e.next(i))
            } catch (u) {
                s(u)
            }
        },
        h = i => {
            try {
                l(e.throw(i))
            } catch (u) {
                s(u)
            }
        },
        l = i => i.done ? o(i.value) : Promise.resolve(i.value).then(n, h);
    l((e = e.apply(r, t)).next())
});
import {
    i as B,
    g as Y,
    a as j,
    l as p,
    b as g,
    _ as C,
    c as V
} from "./e280d7427/preload-helper.DRVb07P7.js";
import {
    s as N
} from "./e280d7427/script.utils.DCYI1tuz.js";
const T = {
        SUBSCRIBE: "TOLSTOY_WIDGET_V2_SUBSCRIBE",
        MESSAGE: "TOLSTOY_WIDGET_V2_MESSAGE"
    },
    y = {
        ADD_TO_CART: "tolstoy_add_to_cart",
        SPOTLIGHT_QUICK_SHOP: "tolstoy_spotlight_carousel_quick_shop_click",
        PRODUCT_CARD_CLICK: "tolstoy_product_card_click"
    },
    S = class S {
        constructor() {
            A(this, "subscribers");
            A(this, "eventsStatus");
            A(this, "handleMessage", t => {
                const {
                    detail: e
                } = t;
                if (e != null && e.eventName) switch (e.eventName) {
                    case y.ADD_TO_CART:
                    case y.SPOTLIGHT_QUICK_SHOP:
                    case y.PRODUCT_CARD_CLICK:
                        this.subscribe(e.eventName, e.callback);
                        break;
                    default:
                        this.notifySubscribers(e.eventName, e)
                }
            });
            this.subscribers = new Map, this.eventsStatus = {
                [y.ADD_TO_CART]: !1,
                [y.SPOTLIGHT_QUICK_SHOP]: !1,
                [y.PRODUCT_CARD_CLICK]: !1
            }
        }
        static getInstance() {
            return S.instance || (S.instance = new S), S.instance
        }
        formatMessage(t) {
            return m(O({}, t), {
                transmissionId: t.transmissionId || "widget-v2",
                timestamp: Date.now()
            })
        }
        updateEventStatus(t, e) {
            t in this.eventsStatus && (this.eventsStatus[t] = e)
        }
        isEventSubscribed(t) {
            return this.eventsStatus[t] || !1
        }
        notifySubscribers(t, e) {
            const o = this.subscribers.get(t);
            o == null || o.forEach(s => {
                try {
                    s(e)
                } catch (n) {
                    console.error(`Error in ${t} callback:`, n)
                }
            })
        }
        subscribe(t, e) {
            var o;
            this.subscribers.has(t) || this.subscribers.set(t, new Set), (o = this.subscribers.get(t)) == null || o.add(e), this.updateEventStatus(t, !0)
        }
        unsubscribe(t, e) {
            const o = this.subscribers.get(t);
            o == null || o.delete(e), (o == null ? void 0 : o.size) === 0 && this.updateEventStatus(t, !1)
        }
        postMessage(t) {
            const e = this.formatMessage(t),
                o = new CustomEvent(T.MESSAGE, {
                    detail: e
                });
            window.dispatchEvent(o)
        }
        init() {
            window.addEventListener(T.SUBSCRIBE, this.handleMessage), window.addEventListener(T.MESSAGE, this.handleMessage);
            const t = new CustomEvent(T.SUBSCRIBE);
            window.addEventListener("tolstoyWidgetReady", () => {
                window.dispatchEvent(t)
            }, {
                once: !0
            })
        }
        destroy() {
            window.removeEventListener(T.SUBSCRIBE, this.handleMessage), window.removeEventListener(T.MESSAGE, this.handleMessage)
        }
    };
A(S, "instance");
let b = S;
const H = () => {
        b.getInstance().init()
    },
    K = {
        PRODUCT_TILE: "tolstoy-product-tile"
    },
    ot = "./styles/product-tile.css",
    at = "w-full",
    W = "tolstoy-collection-page-tile",
    nt = "./styles/collection-page-tile.css",
    it = {
        display: "flex",
        width: "100%",
        height: "100%",
        position: "relative"
    },
    $ = (r, t) => d(void 0, null, function*() {
        var n, h;
        const o = N() && B() ? Y() : j(),
            s = new URLSearchParams;
        s.set("productId", r), s.set("appKey", t);
        try {
            const l = yield fetch(`${o}/settings/widget/get-product-gallery-config?${s}`);
            p({
                windowShopify: (n = window.Shopify) == null ? void 0 : n.shop
            });
            const i = [...document.querySelectorAll("script[data-shop]")].map(c => {
                var I;
                return (I = c == null ? void 0 : c.dataset) == null ? void 0 : I.shop
            }).find(Boolean);
            p({
                appDataShop: i
            });
            const u = i || ((h = window.Shopify) == null ? void 0 : h.shop),
                _ = yield l.json();
            return _.projects && (_.projects = _.projects.filter(c => c.appUrl === u)), _
        } catch (l) {
            return g(l, "Error getting collection page tile config"), null
        }
    }),
    q = "#tolstoy-video-preview",
    F = "thumbnail.0000000000",
    Q = ".product__media, .product-single__thumbnails, .gallery, .product-gallery, .slider, .carousel, section.product",
    ct = r => [...Q.split(",").map(t => t.trim()).filter(Boolean), "body"].map(t => `${t} :has(${r})`).join(","),
    x = r => {
        var t, e;
        return ((t = r == null ? void 0 : r.alt) == null ? void 0 : t.includes(q)) || ((e = r.src) == null ? void 0 : e.includes(F))
    },
    z = () => {
        var o, s, n;
        const r = (o = document.querySelector("script[data-product-id]")) == null ? void 0 : o.getAttribute("data-product-id"),
            t = (s = document.querySelector("script[data-app-key]")) == null ? void 0 : s.getAttribute("data-app-key"),
            e = (n = document.querySelector("script[data-product-gallery-projects]")) == null ? void 0 : n.getAttribute("data-product-gallery-projects");
        return {
            productId: r,
            appKey: t,
            productGalleryProjects: e
        }
    },
    D = (r, t) => d(void 0, null, function*() {
        if (r) {
            const {
                initThumbnailAnchorImageDetection: o
            } = yield C(() => d(void 0, null, function*() {
                const {
                    initThumbnailAnchorImageDetection: s
                } = yield
                import ("./e280d7427/thumbnail-anchor-image-detection.utils.Ai0mfLpU.js");
                return {
                    initThumbnailAnchorImageDetection: s
                }
            }), []);
            return o(t)
        }
        const {
            initFallbackImageDetection: e
        } = yield C(() => d(void 0, null, function*() {
            const {
                initFallbackImageDetection: o
            } = yield
            import ("./e280d7427/fallback-image-detection.utils.WuNCGn9M.js");
            return {
                initFallbackImageDetection: o
            }
        }), []);
        return e(t)
    }),
    J = () => d(void 0, null, function*() {
        var r, t, e, o;
        try {
            let s;
            p("init widget v2");
            const {
                productId: n,
                appKey: h,
                productGalleryProjects: l
            } = z();
            if (!n || !h) return;
            try {
                const a = JSON.parse(l);
                if (p({
                        productGalleryProjects: a
                    }), !(a != null && a.length)) return
            } catch (a) {
                g({
                    error: a.message
                });
                return
            }
            if (s = yield $(n, h), !((r = s == null ? void 0 : s.product) != null && r.images) || !((t = s == null ? void 0 : s.projects) != null && t.length) || !((e = s == null ? void 0 : s.vodAssets) != null && e.length) && !Object.keys((o = s == null ? void 0 : s.vodAssets) != null ? o : {}).length) return;
            const i = s.product.images.map(a => a.src),
                u = new URLSearchParams(location.search).get("test-gallery");
            if (u) {
                const {
                    renderTestGalleryIfNeeded: a
                } = yield C(() => d(void 0, null, function*() {
                    const {
                        renderTestGalleryIfNeeded: L
                    } = yield
                    import ("./e280d7427/render-test-gallery.CEkpcqMx.js");
                    return {
                        renderTestGalleryIfNeeded: L
                    }
                }), []);
                a(u, i)
            }
            const _ = s.product.images.some(x);
            p({
                hasThumbnailAnchorImage: _
            });
            let c = () => {};
            const I = !Array.isArray(s == null ? void 0 : s.vodAssets) && Object.keys(s.vodAssets).length > 0;
            if (p({
                    hasConfigVariants: I,
                    vodAssets: s.vodAssets
                }), I) {
                const a = () => d(void 0, null, function*() {
                    try {
                        const E = new URLSearchParams(location.search).get("variant");
                        if (p({
                                variant: E
                            }), c(), s != null && s.vodAssets[E]) {
                            const P = m(O({}, s), {
                                variant: E,
                                vodAssets: s == null ? void 0 : s.vodAssets[E]
                            });
                            p({
                                clientConfig: P
                            }), c = yield D(_, P)
                        } else c = () => {}
                    } catch (E) {
                        g({
                            error: E
                        })
                    }
                });
                let L = window.location.search;
                const v = new MutationObserver(() => {
                    window.location.search !== L && (L = window.location.search, a())
                });
                return v.observe(document, {
                    subtree: !0,
                    childList: !0
                }), a(), () => {
                    v.disconnect(), c()
                }
            } else return yield D(_, s)
        } catch (s) {
            g(s, "Error initializing product gallery video")
        }
    }),
    X = {
        PRODUCT_TILE: {
            key: K.PRODUCT_TILE,
            controller: () => C(() =>
                import ("./e280d7427/product-tiles-controller.DokM2WPq.js"), [])
        },
        COLLECTION_PAGE_TILE: {
            key: W,
            controller: () => C(() =>
                import ("./e280d7427/collection-page-tile-controller.BtX1_SG0.js"), [])
        }
    },
    Z = {
        PRODUCT_GALLERY_VIDEO: {
            init: J
        }
    },
    tt = () => d(void 0, null, function*() {
        try {
            H(), yield V(X, Z)
        } catch (r) {
            g(r)
        }
    });
tt();
export {
    nt as C, b as E, Q as G, ot as P, q as T, at as a, it as b, ct as g, x as i
};