{
    "token": "Z2NwLWFzaWEtc291dGhlYXN0MTowMUpTNEJDUUMyTlpCOEZTVzNDQjRYN1hGUg?key=4680f5f7c6a5f39bc0146849fbe44a8c",
    "note": "",
    "attributes": {
        "sponsorWebAlias": "solvasa"
    },
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "USD",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": [],
    "items_changelog": {
        "added": []
    }
}