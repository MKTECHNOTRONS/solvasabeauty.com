/*! shopify_app_compiler 2024-09-27 */
var requirejs, require, define;

! function(global, setTimeout) {
    var req, s, head, baseElement, dataMain, src, interactiveScript, currentlyAddingScript, mainScript, subPath, version = "2.3.6",
        commentRegExp = /\/\*[\s\S]*?\*\/|([^:"'=]|^)\/\/.*$/gm,
        cjsRequireRegExp = /[^.]\s*require\s*\(\s*["']([^'"\s]+)["']\s*\)/g,
        jsSuffixRegExp = /\.js$/,
        currDirRegExp = /^\.\//,
        op = Object.prototype,
        ostring = op.toString,
        hasOwn = op.hasOwnProperty,
        isBrowser = !("undefined" == typeof window || "undefined" == typeof navigator || !window.document),
        isWebWorker = !isBrowser && "undefined" != typeof importScripts,
        readyRegExp = isBrowser && "PLAYSTATION 3" === navigator.platform ? /^complete$/ : /^(complete|loaded)$/,
        defContextName = "_",
        isOpera = "undefined" != typeof opera && "[object Opera]" === opera.toString(),
        contexts = {},
        cfg = {},
        globalDefQueue = [],
        useInteractive = !1;

    function commentReplace(e, t) {
        return t || "";
    }

    function isFunction(e) {
        return "[object Function]" === ostring.call(e);
    }

    function isArray(e) {
        return "[object Array]" === ostring.call(e);
    }

    function each(e, t) {
        var i;
        if (e)
            for (i = 0; i < e.length && (!e[i] || !t(e[i], i, e)); i += 1);
    }

    function eachReverse(e, t) {
        var i;
        if (e)
            for (i = e.length - 1; - 1 < i && (!e[i] || !t(e[i], i, e)); i -= 1);
    }

    function hasProp(e, t) {
        return hasOwn.call(e, t);
    }

    function getOwn(e, t) {
        return hasProp(e, t) && e[t];
    }

    function eachProp(e, t) {
        var i;
        for (i in e)
            if (hasProp(e, i) && t(e[i], i)) break;
    }

    function mixin(i, e, r, n) {
        return e && eachProp(e, function(e, t) {
            !r && hasProp(i, t) || (!n || "object" != typeof e || !e || isArray(e) || isFunction(e) || e instanceof RegExp ? i[t] = e : (i[t] || (i[t] = {}),
                mixin(i[t], e, r, n)));
        }), i;
    }

    function bind(e, t) {
        return function() {
            return t.apply(e, arguments);
        };
    }

    function scripts() {
        return document.getElementsByTagName("script");
    }

    function defaultOnError(e) {
        throw e;
    }

    function getGlobal(e) {
        if (!e) return e;
        var t = global;
        return each(e.split("."), function(e) {
            t = t[e];
        }), t;
    }

    function makeError(e, t, i, r) {
        var n = new Error(t + "\nhttps://requirejs.org/docs/errors.html#" + e);
        return n.requireType = e, n.requireModules = r, i && (n.originalError = i),
            n;
    }
    if (void 0 === define) {
        if (void 0 !== requirejs) {
            if (isFunction(requirejs)) return;
            cfg = requirejs, requirejs = void 0;
        }
        void 0 === require || isFunction(require) || (cfg = require, require = void 0),
            req = requirejs = function(e, t, i, r) {
                var n, o, a = defContextName;
                return isArray(e) || "string" == typeof e || (o = e, isArray(t) ? (e = t,
                        t = i, i = r) : e = []), o && o.context && (a = o.context), (n = getOwn(contexts, a)) || (n = contexts[a] = req.s.newContext(a)),
                    o && n.configure(o), n.require(e, t, i);
            }, req.config = function(e) {
                return req(e);
            }, req.nextTick = void 0 !== setTimeout ? function(e) {
                setTimeout(e, 4);
            } : function(e) {
                e();
            }, require || (require = req), req.version = version, req.jsExtRegExp = /^\/|:|\?|\.js$/,
            req.isBrowser = isBrowser, s = req.s = {
                contexts: contexts,
                newContext: newContext
            }, req({}), each(["toUrl", "undef", "defined", "specified"], function(t) {
                req[t] = function() {
                    var e = contexts[defContextName];
                    return e.require[t].apply(e, arguments);
                };
            }), isBrowser && (head = s.head = document.getElementsByTagName("head")[0],
                baseElement = document.getElementsByTagName("base")[0], baseElement && (head = s.head = baseElement.parentNode)),
            req.onError = defaultOnError, req.createNode = function(e, t, i) {
                var r = e.xhtml ? document.createElementNS("http://www.w3.org/1999/xhtml", "html:script") : document.createElement("script");
                return r.type = e.scriptType || "text/javascript", r.charset = "utf-8",
                    r.async = !0, r;
            }, req.load = function(t, i, r) {
                var e, n = t && t.config || {};
                if (isBrowser) return (e = req.createNode(n, i, r)).setAttribute("data-requirecontext", t.contextName),
                    e.setAttribute("data-requiremodule", i), !e.attachEvent || e.attachEvent.toString && e.attachEvent.toString().indexOf("[native code") < 0 || isOpera ? (e.addEventListener("load", t.onScriptLoad, !1),
                        e.addEventListener("error", t.onScriptError, !1)) : (useInteractive = !0,
                        e.attachEvent("onreadystatechange", t.onScriptLoad)), e.src = r, n.onNodeCreated && n.onNodeCreated(e, n, i, r),
                    currentlyAddingScript = e, baseElement ? head.insertBefore(e, baseElement) : head.appendChild(e),
                    currentlyAddingScript = null, e;
                if (isWebWorker) try {
                    setTimeout(function() {}, 0), importScripts(r), t.completeLoad(i);
                } catch (e) {
                    t.onError(makeError("importscripts", "importScripts failed for " + i + " at " + r, e, [i]));
                }
            }, isBrowser && !cfg.skipDataMain && eachReverse(scripts(), function(e) {
                if (head || (head = e.parentNode), dataMain = e.getAttribute("data-main")) return mainScript = dataMain,
                    cfg.baseUrl || -1 !== mainScript.indexOf("!") || (mainScript = (src = mainScript.split("/")).pop(),
                        subPath = src.length ? src.join("/") + "/" : "./", cfg.baseUrl = subPath),
                    mainScript = mainScript.replace(jsSuffixRegExp, ""), req.jsExtRegExp.test(mainScript) && (mainScript = dataMain),
                    cfg.deps = cfg.deps ? cfg.deps.concat(mainScript) : [mainScript], !0;
            }), define = function(e, i, t) {
                var r, n;
                "string" != typeof e && (t = i, i = e, e = null), isArray(i) || (t = i,
                        i = null), !i && isFunction(t) && (i = [], t.length && (t.toString().replace(commentRegExp, commentReplace).replace(cjsRequireRegExp, function(e, t) {
                        i.push(t);
                    }), i = (1 === t.length ? ["require"] : ["require", "exports", "module"]).concat(i))),
                    useInteractive && (r = currentlyAddingScript || getInteractiveScript()) && (e || (e = r.getAttribute("data-requiremodule")),
                        n = contexts[r.getAttribute("data-requirecontext")]), n ? (n.defQueue.push([e, i, t]),
                        n.defQueueMap[e] = !0) : globalDefQueue.push([e, i, t]);
            }, define.amd = {
                jQuery: !0
            }, req.exec = function(text) {
                return eval(text);
            }, req(cfg);
    }

    function newContext(u) {
        var i, e, l, c, d, g = {
                waitSeconds: 7,
                baseUrl: "./",
                paths: {},
                bundles: {},
                pkgs: {},
                shim: {},
                config: {}
            },
            p = {},
            f = {},
            r = {},
            h = [],
            m = {},
            n = {},
            v = {},
            x = 1,
            b = 1;

        function q(e, t, i) {
            var r, n, o, a, s, u, c, d, p, f, l = t && t.split("/"),
                h = g.map,
                m = h && h["*"];
            if (e && (u = (e = e.split("/")).length - 1, g.nodeIdCompat && jsSuffixRegExp.test(e[u]) && (e[u] = e[u].replace(jsSuffixRegExp, "")),
                    "." === e[0].charAt(0) && l && (e = l.slice(0, l.length - 1).concat(e)),
                    function(e) {
                        var t, i;
                        for (t = 0; t < e.length; t++)
                            if ("." === (i = e[t])) e.splice(t, 1),
                                t -= 1;
                            else if (".." === i) {
                            if (0 === t || 1 === t && ".." === e[2] || ".." === e[t - 1]) continue;
                            0 < t && (e.splice(t - 1, 2), t -= 2);
                        }
                    }(e), e = e.join("/")), i && h && (l || m)) {
                e: for (o = (n = e.split("/")).length; 0 < o; o -= 1) {
                    if (s = n.slice(0, o).join("/"), l)
                        for (a = l.length; 0 < a; a -= 1)
                            if ((r = getOwn(h, l.slice(0, a).join("/"))) && (r = getOwn(r, s))) {
                                c = r, d = o;
                                break e;
                            }!p && m && getOwn(m, s) && (p = getOwn(m, s), f = o);
                }!c && p && (c = p, d = f),
                c && (n.splice(0, d, c), e = n.join("/"));
            }
            return getOwn(g.pkgs, e) || e;
        }

        function E(t) {
            isBrowser && each(scripts(), function(e) {
                if (e.getAttribute("data-requiremodule") === t && e.getAttribute("data-requirecontext") === l.contextName) return e.parentNode.removeChild(e), !0;
            });
        }

        function w(e) {
            var t = getOwn(g.paths, e);
            if (t && isArray(t) && 1 < t.length) return t.shift(), l.require.undef(e),
                l.makeRequire(null, {
                    skipMap: !0
                })([e]), !0;
        }

        function y(e) {
            var t, i = e ? e.indexOf("!") : -1;
            return -1 < i && (t = e.substring(0, i), e = e.substring(i + 1, e.length)), [t, e];
        }

        function S(e, t, i, r) {
            var n, o, a, s, u = null,
                c = t ? t.name : null,
                d = e,
                p = !0,
                f = "";
            return e || (p = !1, e = "_@r" + (x += 1)), u = (s = y(e))[0], e = s[1],
                u && (u = q(u, c, r), o = getOwn(m, u)), e && (u ? f = i ? e : o && o.normalize ? o.normalize(e, function(e) {
                    return q(e, c, r);
                }) : -1 === e.indexOf("!") ? q(e, c, r) : e : (u = (s = y(f = q(e, c, r)))[0],
                    f = s[1], i = !0, n = l.nameToUrl(f))), {
                    prefix: u,
                    name: f,
                    parentMap: t,
                    unnormalized: !!(a = !u || o || i ? "" : "_unnormalized" + (b += 1)),
                    url: n,
                    originalName: d,
                    isDefine: p,
                    id: (u ? u + "!" + f : f) + a
                };
        }

        function k(e) {
            var t = e.id,
                i = getOwn(p, t);
            return i || (i = p[t] = new l.Module(e)), i;
        }

        function M(e, t, i) {
            var r = e.id,
                n = getOwn(p, r);
            !hasProp(m, r) || n && !n.defineEmitComplete ? (n = k(e)).error && "error" === t ? i(n.error) : n.on(t, i) : "defined" === t && i(m[r]);
        }

        function O(i, e) {
            var t = i.requireModules,
                r = !1;
            e ? e(i) : (each(t, function(e) {
                var t = getOwn(p, e);
                t && (t.error = i, t.events.error && (r = !0, t.emit("error", i)));
            }), r || req.onError(i));
        }

        function j() {
            globalDefQueue.length && (each(globalDefQueue, function(e) {
                var t = e[0];
                "string" == typeof t && (l.defQueueMap[t] = !0), h.push(e);
            }), globalDefQueue = []);
        }

        function P(e) {
            delete p[e], delete f[e];
        }

        function R() {
            var e, r, t = 1e3 * g.waitSeconds,
                n = t && l.startTime + t < new Date().getTime(),
                o = [],
                a = [],
                s = !1,
                u = !0;
            if (!i) {
                if (i = !0, eachProp(f, function(e) {
                        var t = e.map,
                            i = t.id;
                        if (e.enabled && (t.isDefine || a.push(e), !e.error))
                            if (!e.inited && n) w(i) ? s = r = !0 : (o.push(i),
                                E(i));
                            else if (!e.inited && e.fetched && t.isDefine && (s = !0, !t.prefix)) return u = !1;
                    }), n && o.length) return (e = makeError("timeout", "Load timeout for modules: " + o, null, o)).contextName = l.contextName,
                    O(e);
                u && each(a, function(e) {
                    ! function n(o, a, s) {
                        var e = o.map.id;
                        o.error ? o.emit("error", o.error) : (a[e] = !0, each(o.depMaps, function(e, t) {
                            var i = e.id,
                                r = getOwn(p, i);
                            !r || o.depMatched[t] || s[i] || (getOwn(a, i) ? (o.defineDep(t, m[i]),
                                o.check()) : n(r, a, s));
                        }), s[e] = !0);
                    }(e, {}, {});
                }), n && !r || !s || !isBrowser && !isWebWorker || d || (d = setTimeout(function() {
                    d = 0, R();
                }, 50)), i = !1;
            }
        }

        function a(e) {
            hasProp(m, e[0]) || k(S(e[0], null, !0)).init(e[1], e[2]);
        }

        function o(e, t, i, r) {
            e.detachEvent && !isOpera ? r && e.detachEvent(r, t) : e.removeEventListener(i, t, !1);
        }

        function s(e) {
            var t = e.currentTarget || e.srcElement;
            return o(t, l.onScriptLoad, "load", "onreadystatechange"), o(t, l.onScriptError, "error"), {
                node: t,
                id: t && t.getAttribute("data-requiremodule")
            };
        }

        function T() {
            var e;
            for (j(); h.length;) {
                if (null === (e = h.shift())[0]) return O(makeError("mismatch", "Mismatched anonymous define() module: " + e[e.length - 1]));
                a(e);
            }
            l.defQueueMap = {};
        }
        return c = {
            require: function(e) {
                return e.require ? e.require : e.require = l.makeRequire(e.map);
            },
            exports: function(e) {
                if (e.usingExports = !0, e.map.isDefine) return e.exports ? m[e.map.id] = e.exports : e.exports = m[e.map.id] = {};
            },
            module: function(e) {
                return e.module ? e.module : e.module = {
                    id: e.map.id,
                    uri: e.map.url,
                    config: function() {
                        return getOwn(g.config, e.map.id) || {};
                    },
                    exports: e.exports || (e.exports = {})
                };
            }
        }, (e = function(e) {
            this.events = getOwn(r, e.id) || {}, this.map = e, this.shim = getOwn(g.shim, e.id),
                this.depExports = [], this.depMaps = [], this.depMatched = [], this.pluginMaps = {},
                this.depCount = 0;
        }).prototype = {
            init: function(e, t, i, r) {
                r = r || {}, this.inited || (this.factory = t, i ? this.on("error", i) : this.events.error && (i = bind(this, function(e) {
                        this.emit("error", e);
                    })), this.depMaps = e && e.slice(0), this.errback = i, this.inited = !0,
                    this.ignore = r.ignore, r.enabled || this.enabled ? this.enable() : this.check());
            },
            defineDep: function(e, t) {
                this.depMatched[e] || (this.depMatched[e] = !0, this.depCount -= 1,
                    this.depExports[e] = t);
            },
            fetch: function() {
                if (!this.fetched) {
                    this.fetched = !0, l.startTime = new Date().getTime();
                    var e = this.map;
                    if (!this.shim) return e.prefix ? this.callPlugin() : this.load();
                    l.makeRequire(this.map, {
                        enableBuildCallback: !0
                    })(this.shim.deps || [], bind(this, function() {
                        return e.prefix ? this.callPlugin() : this.load();
                    }));
                }
            },
            load: function() {
                var e = this.map.url;
                n[e] || (n[e] = !0, l.load(this.map.id, e));
            },
            check: function() {
                if (this.enabled && !this.enabling) {
                    var t, e, i = this.map.id,
                        r = this.depExports,
                        n = this.exports,
                        o = this.factory;
                    if (this.inited) {
                        if (this.error) this.emit("error", this.error);
                        else if (!this.defining) {
                            if (this.defining = !0, this.depCount < 1 && !this.defined) {
                                if (isFunction(o)) {
                                    if (this.events.error && this.map.isDefine || req.onError !== defaultOnError) try {
                                        n = l.execCb(i, o, r, n);
                                    } catch (e) {
                                        t = e;
                                    } else n = l.execCb(i, o, r, n);
                                    if (this.map.isDefine && void 0 === n && ((e = this.module) ? n = e.exports : this.usingExports && (n = this.exports)),
                                        t) return t.requireMap = this.map, t.requireModules = this.map.isDefine ? [this.map.id] : null,
                                        t.requireType = this.map.isDefine ? "define" : "require",
                                        O(this.error = t);
                                } else n = o;
                                if (this.exports = n, this.map.isDefine && !this.ignore && (m[i] = n,
                                        req.onResourceLoad)) {
                                    var a = [];
                                    each(this.depMaps, function(e) {
                                        a.push(e.normalizedMap || e);
                                    }), req.onResourceLoad(l, this.map, a);
                                }
                                P(i), this.defined = !0;
                            }
                            this.defining = !1, this.defined && !this.defineEmitted && (this.defineEmitted = !0,
                                this.emit("defined", this.exports), this.defineEmitComplete = !0);
                        }
                    } else hasProp(l.defQueueMap, i) || this.fetch();
                }
            },
            callPlugin: function() {
                var u = this.map,
                    c = u.id,
                    e = S(u.prefix);
                this.depMaps.push(e), M(e, "defined", bind(this, function(e) {
                    var o, t, i, r = getOwn(v, this.map.id),
                        n = this.map.name,
                        a = this.map.parentMap ? this.map.parentMap.name : null,
                        s = l.makeRequire(u.parentMap, {
                            enableBuildCallback: !0
                        });
                    return this.map.unnormalized ? (e.normalize && (n = e.normalize(n, function(e) {
                        return q(e, a, !0);
                    }) || ""), M(t = S(u.prefix + "!" + n, this.map.parentMap, !0), "defined", bind(this, function(e) {
                        this.map.normalizedMap = t, this.init([], function() {
                            return e;
                        }, null, {
                            enabled: !0,
                            ignore: !0
                        });
                    })), void((i = getOwn(p, t.id)) && (this.depMaps.push(t), this.events.error && i.on("error", bind(this, function(e) {
                        this.emit("error", e);
                    })), i.enable()))) : r ? (this.map.url = l.nameToUrl(r), void this.load()) : ((o = bind(this, function(e) {
                        this.init([], function() {
                            return e;
                        }, null, {
                            enabled: !0
                        });
                    })).error = bind(this, function(e) {
                        this.inited = !0, (this.error = e).requireModules = [c],
                            eachProp(p, function(e) {
                                0 === e.map.id.indexOf(c + "_unnormalized") && P(e.map.id);
                            }), O(e);
                    }), o.fromText = bind(this, function(e, t) {
                        var i = u.name,
                            r = S(i),
                            n = useInteractive;
                        t && (e = t), n && (useInteractive = !1), k(r), hasProp(g.config, c) && (g.config[i] = g.config[c]);
                        try {
                            req.exec(e);
                        } catch (e) {
                            return O(makeError("fromtexteval", "fromText eval for " + c + " failed: " + e, e, [c]));
                        }
                        n && (useInteractive = !0), this.depMaps.push(r), l.completeLoad(i),
                            s([i], o);
                    }), void e.load(u.name, s, o, g));
                })), l.enable(e, this), this.pluginMaps[e.id] = e;
            },
            enable: function() {
                (f[this.map.id] = this).enabled = !0, this.enabling = !0, each(this.depMaps, bind(this, function(e, t) {
                    var i, r, n;
                    if ("string" == typeof e) {
                        if (e = S(e, this.map.isDefine ? this.map : this.map.parentMap, !1, !this.skipMap),
                            this.depMaps[t] = e, n = getOwn(c, e.id)) return void(this.depExports[t] = n(this));
                        this.depCount += 1, M(e, "defined", bind(this, function(e) {
                            this.undefed || (this.defineDep(t, e), this.check());
                        })), this.errback ? M(e, "error", bind(this, this.errback)) : this.events.error && M(e, "error", bind(this, function(e) {
                            this.emit("error", e);
                        }));
                    }
                    i = e.id, r = p[i], hasProp(c, i) || !r || r.enabled || l.enable(e, this);
                })), eachProp(this.pluginMaps, bind(this, function(e) {
                    var t = getOwn(p, e.id);
                    t && !t.enabled && l.enable(e, this);
                })), this.enabling = !1, this.check();
            },
            on: function(e, t) {
                var i = this.events[e];
                i || (i = this.events[e] = []), i.push(t);
            },
            emit: function(e, t) {
                each(this.events[e], function(e) {
                    e(t);
                }), "error" === e && delete this.events[e];
            }
        }, (l = {
            config: g,
            contextName: u,
            registry: p,
            defined: m,
            urlFetched: n,
            defQueue: h,
            defQueueMap: {},
            Module: e,
            makeModuleMap: S,
            nextTick: req.nextTick,
            onError: O,
            configure: function(e) {
                if (e.baseUrl && "/" !== e.baseUrl.charAt(e.baseUrl.length - 1) && (e.baseUrl += "/"),
                    "string" == typeof e.urlArgs) {
                    var i = e.urlArgs;
                    e.urlArgs = function(e, t) {
                        return (-1 === t.indexOf("?") ? "?" : "&") + i;
                    };
                }
                var r = g.shim,
                    n = {
                        paths: !0,
                        bundles: !0,
                        config: !0,
                        map: !0
                    };
                eachProp(e, function(e, t) {
                    n[t] ? (g[t] || (g[t] = {}), mixin(g[t], e, !0, !0)) : g[t] = e;
                }), e.bundles && eachProp(e.bundles, function(e, t) {
                    each(e, function(e) {
                        e !== t && (v[e] = t);
                    });
                }), e.shim && (eachProp(e.shim, function(e, t) {
                    isArray(e) && (e = {
                            deps: e
                        }), !e.exports && !e.init || e.exportsFn || (e.exportsFn = l.makeShimExports(e)),
                        r[t] = e;
                }), g.shim = r), e.packages && each(e.packages, function(e) {
                    var t;
                    t = (e = "string" == typeof e ? {
                        name: e
                    } : e).name, e.location && (g.paths[t] = e.location), g.pkgs[t] = e.name + "/" + (e.main || "main").replace(currDirRegExp, "").replace(jsSuffixRegExp, "");
                }), eachProp(p, function(e, t) {
                    e.inited || e.map.unnormalized || (e.map = S(t, null, !0));
                }), (e.deps || e.callback) && l.require(e.deps || [], e.callback);
            },
            makeShimExports: function(t) {
                return function() {
                    var e;
                    return t.init && (e = t.init.apply(global, arguments)), e || t.exports && getGlobal(t.exports);
                };
            },
            makeRequire: function(o, a) {
                function s(e, t, i) {
                    var r, n;
                    return a.enableBuildCallback && t && isFunction(t) && (t.__requireJsBuild = !0),
                        "string" == typeof e ? isFunction(t) ? O(makeError("requireargs", "Invalid require call"), i) : o && hasProp(c, e) ? c[e](p[o.id]) : req.get ? req.get(l, e, o, s) : (r = S(e, o, !1, !0).id,
                            hasProp(m, r) ? m[r] : O(makeError("notloaded", 'Module name "' + r + '" has not been loaded yet for context: ' + u + (o ? "" : ". Use require([])")))) : (T(),
                            l.nextTick(function() {
                                T(), (n = k(S(null, o))).skipMap = a.skipMap, n.init(e, t, i, {
                                    enabled: !0
                                }), R();
                            }), s);
                }
                return a = a || {}, mixin(s, {
                    isBrowser: isBrowser,
                    toUrl: function(e) {
                        var t, i = e.lastIndexOf("."),
                            r = e.split("/")[0];
                        return -1 !== i && (!("." === r || ".." === r) || 1 < i) && (t = e.substring(i, e.length),
                            e = e.substring(0, i)), l.nameToUrl(q(e, o && o.id, !0), t, !0);
                    },
                    defined: function(e) {
                        return hasProp(m, S(e, o, !1, !0).id);
                    },
                    specified: function(e) {
                        return e = S(e, o, !1, !0).id, hasProp(m, e) || hasProp(p, e);
                    }
                }), o || (s.undef = function(i) {
                    j();
                    var e = S(i, o, !0),
                        t = getOwn(p, i);
                    t.undefed = !0, E(i), delete m[i], delete n[e.url], delete r[i],
                        eachReverse(h, function(e, t) {
                            e[0] === i && h.splice(t, 1);
                        }), delete l.defQueueMap[i], t && (t.events.defined && (r[i] = t.events),
                            P(i));
                }), s;
            },
            enable: function(e) {
                getOwn(p, e.id) && k(e).enable();
            },
            completeLoad: function(e) {
                var t, i, r, n = getOwn(g.shim, e) || {},
                    o = n.exports;
                for (j(); h.length;) {
                    if (null === (i = h.shift())[0]) {
                        if (i[0] = e, t) break;
                        t = !0;
                    } else i[0] === e && (t = !0);
                    a(i);
                }
                if (l.defQueueMap = {}, r = getOwn(p, e), !t && !hasProp(m, e) && r && !r.inited) {
                    if (!(!g.enforceDefine || o && getGlobal(o))) return w(e) ? void 0 : O(makeError("nodefine", "No define call for " + e, null, [e]));
                    a([e, n.deps || [], n.exportsFn]);
                }
                R();
            },
            nameToUrl: function(e, t, i) {
                var r, n, o, a, s, u, c = getOwn(g.pkgs, e);
                if (c && (e = c), u = getOwn(v, e)) return l.nameToUrl(u, t, i);
                if (req.jsExtRegExp.test(e)) a = e + (t || "");
                else {
                    for (r = g.paths, o = (n = e.split("/")).length; 0 < o; o -= 1)
                        if (s = getOwn(r, n.slice(0, o).join("/"))) {
                            isArray(s) && (s = s[0]), n.splice(0, o, s);
                            break;
                        }
                    a = n.join("/"), a = ("/" === (a += t || (/^data\:|^blob\:|\?/.test(a) || i ? "" : ".js")).charAt(0) || a.match(/^[\w\+\.\-]+:/) ? "" : g.baseUrl) + a;
                }
                return g.urlArgs && !/^blob\:/.test(a) ? a + g.urlArgs(e, a) : a;
            },
            load: function(e, t) {
                req.load(l, e, t);
            },
            execCb: function(e, t, i, r) {
                return t.apply(r, i);
            },
            onScriptLoad: function(e) {
                if ("load" === e.type || readyRegExp.test((e.currentTarget || e.srcElement).readyState)) {
                    interactiveScript = null;
                    var t = s(e);
                    l.completeLoad(t.id);
                }
            },
            onScriptError: function(e) {
                var i = s(e);
                if (!w(i.id)) {
                    var r = [];
                    return eachProp(p, function(e, t) {
                        0 !== t.indexOf("_@r") && each(e.depMaps, function(e) {
                            if (e.id === i.id) return r.push(t), !0;
                        });
                    }), O(makeError("scripterror", 'Script error for "' + i.id + (r.length ? '", needed by: ' + r.join(", ") : '"'), e, [i.id]));
                }
            }
        }).require = l.makeRequire(), l;
    }

    function getInteractiveScript() {
        return interactiveScript && "interactive" === interactiveScript.readyState || eachReverse(scripts(), function(e) {
            if ("interactive" === e.readyState) return interactiveScript = e;
        }), interactiveScript;
    }
}(this, "undefined" == typeof setTimeout ? void 0 : setTimeout);

var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s)
                if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};

var __spreadArray = this && this.__spreadArray || function(to, from, pack) {
    if (pack || arguments.length === 2)
        for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
    return to.concat(ar || Array.prototype.slice.call(from));
};

var __extends = this && this.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
            __proto__: []
        }
        instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);

        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype,
            new __());
    };
}();

var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new(P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }

        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }

        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

var __generator = this && this.__generator || function(thisArg, body) {
    var _ = {
            label: 0,
            sent: function() {
                if (t[0] & 1) throw t[1];
                return t[1];
            },
            trys: [],
            ops: []
        },
        f, y, t, g;
    return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;

    function verb(n) {
        return function(v) {
            return step([n, v]);
        };
    }

    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y),
                    0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0:
                case 1:
                    t = op;
                    break;

                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };

                case 5:
                    _.label++;
                    y = op[1];
                    op = [0];
                    continue;

                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;

                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [6, e];
            y = 0;
        } finally {
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
};

define("core/shopify-app/st-modules/_general-methods/dom-loaded", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StDOMLoaded = void 0;
    var StDOMLoaded = function() {
        function StDOMLoaded() {
            var _this = this;
            this.className = "DOMLoaded";
            this.domLoaded = false;
            this.domLoadedCallbacks = [];
            this.readyStateChange = function() {
                if (document.readyState === "interactive") {
                    _this.domLoaded = true;
                    _this.fireDOMLoadedCallbacks();
                }
            };
            this.fireDOMLoadedCallbacks = function() {
                for (var i = 0; i < _this.domLoadedCallbacks.length; i++) {
                    _this.domLoadedCallbacks[i]();
                }
            };
            this.subscribeDOMLoaded = function(cb) {
                if (_this.domLoaded) {
                    cb();
                } else {
                    _this.domLoadedCallbacks.push(cb);
                }
            };
        }
        StDOMLoaded.Instance = function() {
            return this._instance || (this._instance = new this());
        };
        StDOMLoaded.prototype.initDOMLoaded = function() {
            if (!StDOMLoaded.initStarted) {
                StDOMLoaded.initStarted = true;
                if (document.readyState === "interactive" || document.readyState === "complete") {
                    this.domLoaded = true;
                    this.fireDOMLoadedCallbacks();
                } else {
                    document.addEventListener("readystatechange", this.readyStateChange, false);
                }
            }
        };
        StDOMLoaded.initStarted = false;
        return StDOMLoaded;
    }();
    exports.StDOMLoaded = StDOMLoaded;
});

define("core/connector-app/_shared/routes.config", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.endpointData = void 0;
    exports.endpointData = {
        webalias: {
            repSite: "||-API-ROOT-||/webalias/sca/repSite"
        },
        webhook: {
            removeAll: "||-API-ROOT-||/webhook/gar/removeAll"
        },
        customer: {
            updatePersonalInfo: "||-API-ROOT-||/customer/sca/updatePersonalInfo",
            updateWebAlias: "||-API-ROOT-||/customer/sca/updateWebAlias",
            updateSponsor: "||-API-ROOT-||/customer/sca/updateSponsor"
        },
        auth: {
            sso: "||-API-ROOT-||/auth/sca/sso"
        },
        order: {},
        product: {},
        enrollment: {
            "validate-data": "||-API-ROOT-||/enrollment/sca/validate-data",
            submit: "||-API-ROOT-||/enrollment/sca/submit",
            createAccount: "||-API-ROOT-||/enrollment/sca/createAccount"
        },
        searchSponsor: {
            getSponsorInfo: "||-API-ROOT-||/searchSponsor/sca/getSponsorInfo",
            getSponsorByPersonalInfo: "||-API-ROOT-||/searchSponsor/sca/getSponsorByPersonalInfo"
        }
    };
});

define("core/shopify-app/st-modules/_static/static", ["require", "exports", "core/connector-app/_shared/routes.config"], function(require, exports, routes_config_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StStatic = void 0;
    var StStatic = function() {
        function StStatic() {
            var _this = this;
            this.className = "Static";
            this.shopConfig = window.stAppConfig;
            this.apiRoot = this.shopConfig.apiRoot;
            this.init = function() {};
            this.setup = function() {};
            this.obtainStaticEndpoints = function() {
                return _this.endpoint;
            };
            this.obtainMainScope = function() {
                return window.stApp;
            };
            this.obtainCart = function() {
                return window.shopifyCartData;
            };
            this.injectRootToEndpoints = function(endpoints) {
                for (var controllerKey in endpoints) {
                    for (var endpoint in endpoints[controllerKey]) {
                        endpoints[controllerKey][endpoint] = endpoints[controllerKey][endpoint].replace(/\|\|-API-ROOT-\|\|/g, _this.apiRoot);
                    }
                }
                return endpoints;
            };
            this.endpoint = this.injectRootToEndpoints(routes_config_1.endpointData);
        }
        StStatic.Instance = function() {
            return this._instance || (this._instance = new this());
        };
        return StStatic;
    }();
    exports.StStatic = StStatic;
});

define("core/shopify-app/st-modules/_general-methods/ajax", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAjax = void 0;
    var StAjax = function() {
        function StAjax() {}
        StAjax.Instance = function() {
            return this._instance || (this._instance = new this());
        };
        StAjax.prototype.setupFormatting = function(objectToQueryStringFn) {
            this.objectToQueryString = objectToQueryStringFn;
        };
        StAjax.prototype.determineContentType = function(contentType) {
            var output = {
                type: "application/x-www-form-urlencoded",
                prepFn: this.objectToQueryString
            };
            switch (contentType) {
                case "form":
                    output.type = "application/x-www-form-urlencoded";
                    output.prepFn = this.objectToQueryString;
                    break;

                case "json":
                    output.type = "application/json";
                    output.prepFn = JSON.stringify;
                    break;
            }
            return output;
        };
        StAjax.prototype.send = function(options) {
            var fnReference = this;
            if (typeof options == "object") {
                var defaultOptions = {
                    endpoint: "",
                    method: "POST",
                    contentType: "json",
                    data: {},
                    callback: function() {},
                    callbackParams: []
                };
                var completeOptions_1 = __assign(__assign({}, defaultOptions), options);
                var contentTypeData = this.determineContentType(completeOptions_1.contentType);
                var requestMethod = completeOptions_1.method.toUpperCase();
                var allowedMethods = ["POST", "GET", "PUT", "DELETE"];
                completeOptions_1.method = allowedMethods.indexOf(requestMethod) >= 0 ? requestMethod : "POST";
                var request_1 = new XMLHttpRequest();
                request_1.open(completeOptions_1.method, completeOptions_1.endpoint, true);
                request_1.withCredentials = true;
                request_1.setRequestHeader("X-Requested-With", "XMLHttpRequest");
                request_1.setRequestHeader("Content-Type", contentTypeData.type);
                request_1.setRequestHeader("credentials", "include");
                request_1.onreadystatechange = function() {
                    if (request_1.readyState === 4) {
                        completeOptions_1.callbackParams.unshift(request_1);
                        completeOptions_1.callback.apply(fnReference, completeOptions_1.callbackParams);
                    }
                };
                request_1.send(contentTypeData.prepFn(completeOptions_1.data));
                return request_1;
            }
        };
        return StAjax;
    }();
    exports.StAjax = StAjax;
});

define("core/shopify-app/st-modules/_di-container/st.module.interface", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/shopify-app/st-modules/_di-container/di.container.public", ["require", "exports", "core/shopify-app/st-modules/_general-methods/dom-loaded"], function(require, exports, dom_loaded_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.DiContainerPublic = void 0;
    var DiContainerPublic = function() {
        function DiContainerPublic() {
            this.className = "DI";
            this.subscribeDOMLoaded = function(cb) {
                dom_loaded_1.StDOMLoaded.Instance().subscribeDOMLoaded(cb);
            };
            this.init = function() {};
            this.setup = function() {};
        }
        return DiContainerPublic;
    }();
    exports.DiContainerPublic = DiContainerPublic;
});

define("core/shopify-app/st-modules/_di-container/st.module", ["require", "exports", "core/shopify-app/st-modules/_general-methods/ajax", "core/shopify-app/st-modules/_static/static", "core/shopify-app/st-modules/_general-methods/dom-loaded"], function(require, exports, ajax_1, static_1, dom_loaded_2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StModule = void 0;
    var StModule = function() {
        function StModule(args) {
            var _this = this;
            this.dependency = [];
            this.init = function() {};
            this.setup = function() {
                if (!_this.setupFlag) {
                    if (_this.hasOwnProperty("init")) {
                        console.log("Init : ", _this.className);
                        _this.setupFlag = true;
                        _this.init();
                        _this.dependency.forEach(function(dependency) {
                            dependency.setup();
                        });
                    }
                }
            };
            this.dependency = args && args.length > 0 ? __spreadArray([], args, true) : [];
            this.Static = static_1.StStatic.Instance();
            this.endpoint = this.Static.obtainStaticEndpoints();
            this.cart = this.Static.obtainCart();
            this.ajax = ajax_1.StAjax.Instance();
            this.subscribeDOMLoaded = dom_loaded_2.StDOMLoaded.Instance().subscribeDOMLoaded;
            this.setupFlag = false;
        }
        return StModule;
    }();
    exports.StModule = StModule;
});

define("core/shopify-app/st-modules/_di-container/di.container.setup", ["require", "exports", "core/shopify-app/st-modules/_general-methods/dom-loaded"], function(require, exports, dom_loaded_3) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StDIContainerSetup = void 0;
    var StDIContainerSetup = function() {
        function StDIContainerSetup(appName, StAppDIConfig) {
            var _this = this;
            this.className = "DI";
            this.getModules = function(appName) {
                return _this.StAppDIConfig.Instance.hierarchy(appName);
            };
            if (!window.stApp) window.stApp = {};
            this.StAppDIConfig = StAppDIConfig;
            this.init(appName);
        }
        StDIContainerSetup.prototype.init = function(appName) {
            document.querySelector("body").classList.add("st_app-".concat(appName));
            this.mainServices = this.getModules(appName);
            this.mainServices.forEach(function(service) {
                if (service.className) {
                    window.stApp[service.className] = service;
                    service.setup();
                } else {
                    console.error("Instance has no className: ", service);
                }
            });
            dom_loaded_3.StDOMLoaded.Instance().initDOMLoaded();
        };
        return StDIContainerSetup;
    }();
    exports.StDIContainerSetup = StDIContainerSetup;
});

define("core/shopify-app/st-modules/_general-methods/cookies/cookies", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StCookies = void 0;
    var StCookies = function(_super) {
        __extends(StCookies, _super);

        function StCookies() {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "Cookies";
            _this_1.init = function() {
                var _this = _this_1;
                _this_1.subscribeDOMLoaded(function() {
                    _this.initCookieApi();
                    _this.onPrivacyBannerAction();
                });
            };
            _this_1.initCookieApi = function() {
                var wShopify = window.Shopify;
                if (!!wShopify) {
                    wShopify.loadFeatures([{
                        name: "consent-tracking-api",
                        version: "0.1"
                    }], function(error) {
                        if (error) {
                            throw error;
                        }
                        _this_1.showPrivacyBanner();
                    });
                }
            };
            _this_1.showPrivacyBanner = function() {
                var wShopify = window.Shopify;
                var shouldShowBanner = wShopify.customerPrivacy.shouldShowGDPRBanner();
                var banner = document.querySelector(".st_privacy-bar_JS");
                if (!!banner && shouldShowBanner) {
                    banner.removeAttribute("hidden");
                }
            };
            _this_1.hidePrivacyBanner = function() {
                var banner = document.querySelector(".st_privacy-bar_JS");
                if (!!banner) {
                    banner.setAttribute("hidden", "");
                }
            };
            _this_1.onPrivacyBannerAction = function() {
                var _this = _this_1;
                var privacyBannerBtnList = document.querySelectorAll(".st_privacy-banner-btn_JS");
                if ((privacyBannerBtnList === null || privacyBannerBtnList === void 0 ? void 0 : privacyBannerBtnList.length) > 0) {
                    privacyBannerBtnList.forEach(function(btn) {
                        btn.addEventListener("click", function() {
                            var btnDataAction = btn.getAttribute("data-action");
                            var wShopify = window === null || window === void 0 ? void 0 : window.Shopify;
                            wShopify.customerPrivacy.setTrackingConsent(btnDataAction === "accept", _this.hidePrivacyBanner);
                        });
                    });
                }
            };
            _this_1.getCookie = function(cookieKey) {
                return window.localStorage.getItem(cookieKey);
            };
            _this_1.setCookies = function(cookieKey, cookieValue) {
                window.localStorage.setItem(cookieKey, cookieValue);
            };
            _this_1.clearCookie = function(cookieKey) {
                window.localStorage.removeItem(cookieKey);
            };
            _this_1.clearAllCookie = function() {
                window.localStorage.clear();
            };
            return _this_1;
        }
        return StCookies;
    }(st_module_1.StModule);
    exports.StCookies = StCookies;
});

define("_features.config", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.useCommissionEngineIdInRewardCode = exports.rewardItemCollectionId = exports.rewardDiscountMinimum = exports.rewardCodePrefix = exports.rewardAmount = exports.rewardType = exports.shareRefCodeFunctionality = exports.discountUsageLimit = exports.discountCollectionSpend = exports.discountMinimumRequirement = exports.discountSegmentConditionTag = exports.discountNamePrefix = exports.discountAmount = exports.discountType = exports.enrollmentParams = exports.reasonForRefundWhenReturnMoney = exports.availableRechargeUsage = exports.sponsorGenealogyTimeout = exports.downgradeRepresentativeByDesignWebhook = exports.cronJobReSyncOrders = exports.repDiscountWithPromoCode = exports.searchSponsorsMinNumOfResult = exports.searchSponsorsFetchAttemptsLimit = exports.representative = exports.commissionEngine = exports.autoshipItems = exports.productVolumesConfig = exports.EProductPriceType = exports.ECustomerType = exports.defaultCorporationImage = exports.additionalRepInfo = exports.activeLastSponsorFeature = exports.canGoUnderCorporateSite = exports.lockedRepresentativeSite = exports.corporationName = exports.aliasQueryParam = exports.defaultWebAlias = void 0;
    exports.defaultWebAlias = "solvasa";
    exports.aliasQueryParam = "als";
    exports.corporationName = "Solvasa";
    exports.lockedRepresentativeSite = true;
    exports.canGoUnderCorporateSite = true;
    exports.activeLastSponsorFeature = true;
    exports.additionalRepInfo = false;
    exports.defaultCorporationImage = "https://codemancystudio.com/cdm_template/wp-content/uploads/2018/03/cdm-logo-blacksmall.png";
    var ECustomerType;
    (function(ECustomerType) {
        ECustomerType["retail"] = "retail";
        ECustomerType["representative"] = "representative";
        ECustomerType["guest"] = "guest";
        ECustomerType["noType"] = "";
    })(ECustomerType = exports.ECustomerType || (exports.ECustomerType = {}));
    var EProductPriceType;
    (function(EProductPriceType) {
        EProductPriceType["retail"] = "retail";
        EProductPriceType["representative"] = "representative";
        EProductPriceType["noSpecificType"] = "";
    })(EProductPriceType = exports.EProductPriceType || (exports.EProductPriceType = {}));
    exports.productVolumesConfig = {
        cv: true,
        qv: false,
        bv: false,
        cvMetafieldKey: "cvolume",
        qvMetafieldKey: "qvolume",
        bvMetafieldKey: "bvolume",
        Volume: "cv",
        Volume2: "qv",
        Volume3: "bv",
        calculatePriceAsVolume: false,
        generalPriceVolumePercentage: 1,
        retailVolumeAndPricePercentage: 1,
        representativeVolumeAndPricePercentage: 1
    };
    exports.autoshipItems = [];
    exports.commissionEngine = "ByDesign";
    exports.representative = "representative";
    exports.searchSponsorsFetchAttemptsLimit = 3;
    exports.searchSponsorsMinNumOfResult = 3;
    exports.repDiscountWithPromoCode = false;
    exports.cronJobReSyncOrders = true;
    exports.downgradeRepresentativeByDesignWebhook = true;
    exports.sponsorGenealogyTimeout = 6e5;
    exports.availableRechargeUsage = true;
    exports.reasonForRefundWhenReturnMoney = "refundmoney";
    exports.enrollmentParams = ["SSN", "dateOfBirth", "day", "email", "firstName", "lastName", "month", "optionalKitRecurring", "optionalKits", "phoneNumber", "requiredKitRecurring", "requiredKits", "shopifyId", "sponsorWebAlias", "sponsorsWebAlias", "webAlias", "year"];
    exports.discountType = "fixed_amount";
    exports.discountAmount = 10;
    exports.discountNamePrefix = "Core_";
    exports.discountSegmentConditionTag = "no_order";
    exports.discountMinimumRequirement = "1.00";
    exports.discountCollectionSpend = 405622423800;
    exports.discountUsageLimit = 10;
    exports.shareRefCodeFunctionality = false;
    exports.rewardType = "fixed_amount";
    exports.rewardAmount = 20;
    exports.rewardCodePrefix = "RewardedFrom-";
    exports.rewardDiscountMinimum = 1;
    exports.rewardItemCollectionId = 405622423800;
    exports.useCommissionEngineIdInRewardCode = true;
});

define("core/shopify-app/st-modules/_general-methods/form/customer-type", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "_features.config"], function(require, exports, st_module_2, _features_config_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StCustomerType = void 0;
    var StCustomerType = function(_super) {
        __extends(StCustomerType, _super);

        function StCustomerType() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "CustomerType";
            _this.init = function() {};
            _this.get = function() {
                var customerType;
                if (!!window.customerInfoMetafields.customerType) {
                    customerType = window.customerInfoMetafields.customerType;
                } else {
                    customerType = _features_config_1.ECustomerType.guest;
                }
                return customerType;
            };
            return _this;
        }
        return StCustomerType;
    }(st_module_2.StModule);
    exports.StCustomerType = StCustomerType;
});

define("core/shopify-app/st-modules/_general-methods/object-formatting", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_3) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StObjectFormatting = void 0;
    var StObjectFormatting = function(_super) {
        __extends(StObjectFormatting, _super);

        function StObjectFormatting() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "ObjectFormatting";
            _this.convertObjectToQueryString = function(object) {
                var string = "",
                    i = 0;
                for (var j in object) {
                    var s = encodeURIComponent(j) + "=" + encodeURIComponent(object[j]);
                    string += i > 0 ? "&" + s : s;
                    i++;
                }
                return "?" + string;
            };
            _this.convertQueryStringToObject = function(query) {
                query = typeof query != "string" ? "" : query.substr(query.indexOf("?") + 1);
                var query_string = {};
                if (query !== "") {
                    var vars = query.split("&");
                    for (var i = 0; i < vars.length; i++) {
                        var pair = vars[i].split("=");
                        var key = decodeURIComponent(pair[0]);
                        var value = decodeURIComponent(pair[1]);
                        if (typeof query_string[key] === "undefined") {
                            query_string[key] = decodeURIComponent(value);
                        } else if (typeof query_string[key] === "string") {
                            query_string[key] = [query_string[key], decodeURIComponent(value)];
                        } else {
                            query_string[key].push(decodeURIComponent(value));
                        }
                    }
                } else {
                    console.warn("Invalid query string supplied to convertQueryStringToObject.");
                }
                return query_string;
            };
            _this.ajax.setupFormatting(_this.convertObjectToQueryString);
            return _this;
        }
        return StObjectFormatting;
    }(st_module_3.StModule);
    exports.StObjectFormatting = StObjectFormatting;
});

define("core/shopify-app/st-modules/_general-methods/browser-history", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_4) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StBrowserHistory = void 0;
    var StBrowserHistory = function(_super) {
        __extends(StBrowserHistory, _super);

        function StBrowserHistory(objectFormatting) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "BrowserHistory";
            _this.pushHistory = function(rootURL, urlParams) {
                var serializedUrlParams = _this.objectFormatting.convertObjectToQueryString(urlParams);
                window.history.replaceState(urlParams, "", rootURL + serializedUrlParams);
            };
            _this.objectFormatting = objectFormatting;
            return _this;
        }
        return StBrowserHistory;
    }(st_module_4.StModule);
    exports.StBrowserHistory = StBrowserHistory;
});

define("core/connector-app/_shared/models/webalias/webalias.request.model", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/shopify-app/st-modules/_general-methods/general-methods", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_5) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StGeneralMethods = void 0;
    var StGeneralMethods = function(_super) {
        __extends(StGeneralMethods, _super);

        function StGeneralMethods() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "GeneralMethods";
            _this.scrollTo = function(element, duration, offset) {
                if (offset === void 0) {
                    offset = 150;
                }
                var startingY = window.scrollY;
                var elementY = window.scrollY + element.getBoundingClientRect().top - offset;
                var targetY = document.body.scrollHeight - elementY < window.innerHeight ? document.body.scrollHeight - window.innerHeight : elementY;
                var diff = targetY - startingY;
                var easing = function(t) {
                    return t < .5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
                };
                var start;
                if (!diff) return;
                window.requestAnimationFrame(function step(timestamp) {
                    if (!start) start = timestamp;
                    var time = timestamp - start;
                    var percent = Math.min(time / duration, 1);
                    percent = easing(percent);
                    window.scrollTo(0, startingY + diff * percent);
                    if (time < duration) {
                        window.requestAnimationFrame(step);
                    }
                });
            };
            return _this;
        }
        StGeneralMethods.prototype.getClosestByClass = function(el, cls) {
            var res = el;
            while ((res = res.parentElement) && !res.classList.contains(cls));
            return res;
        };
        StGeneralMethods.prototype.getClosestByTag = function(el, tagName) {
            var res = el;
            while ((res = res.parentElement) && !res.tagName === tagName);
            return res;
        };
        return StGeneralMethods;
    }(st_module_5.StModule);
    exports.StGeneralMethods = StGeneralMethods;
});

define("core/shopify-app/st-modules/webalias/webalias-class-config", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_6) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StWebAliasClassConfig = void 0;
    var StWebAliasClassConfig = function(_super) {
        __extends(StWebAliasClassConfig, _super);

        function StWebAliasClassConfig() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "StWebAliasClassConfig";
            _this.classNameRepId = "st_representative-id_JS";
            _this.selectorRepId = "." + _this.classNameRepId;
            _this.classNameRepAlias = "st_representative-alias_JS";
            _this.selectorRepAlias = "." + _this.classNameRepAlias;
            _this.classNameRepFullName = "st_representative-fullname_JS";
            _this.selectorRepFullName = "." + _this.classNameRepFullName;
            _this.classNameRepInitials = "st_representative-initials_JS";
            _this.selectorRepInitials = "." + _this.classNameRepInitials;
            _this.classNameRepSite = "st_representative-site_JS";
            _this.selectorRepSite = "." + _this.classNameRepSite;
            _this.classNameRepBio = "st_representative-site-bio_JS";
            _this.selectorRepBio = "." + _this.classNameRepBio;
            _this.classNameRepAddress = "st_representative-address_JS";
            _this.selectorRepAddress = "." + _this.classNameRepAddress;
            _this.classNameNonSponsor = "st_non-sponsor_JS";
            _this.selectorNonSponsor = "." + _this.classNameNonSponsor;
            _this.classRepresentativeBannerWrapper = "st_representative-banner--wrapper_JS";
            _this.selectorRepresentativeBannerWrapper = "." + _this.classRepresentativeBannerWrapper;
            _this.classNameBusinessContentRepName = "st_account-business--rep-name_JS";
            _this.selectorBusinessContentRepName = "." + _this.classNameBusinessContentRepName;
            _this.classNamePersonalInfoForm = "st_personal-info-form_JS";
            _this.selectorPersonalInfoForm = "." + _this.classNamePersonalInfoForm;
            _this.classNamePersonalInfoRepFullName = "st_representative-info-fullname_JS";
            _this.selectorPersonalInfoRepFullName = "." + _this.classNamePersonalInfoRepFullName;
            return _this;
        }
        return StWebAliasClassConfig;
    }(st_module_6.StModule);
    exports.StWebAliasClassConfig = StWebAliasClassConfig;
});

define("core/shopify-app/st-modules/webalias/inject-representative-info", ["require", "exports", "_features.config", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, _features_config_2, st_module_7) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StInjectRepresentativeInfo = void 0;
    var StInjectRepresentativeInfo = function(_super) {
        __extends(StInjectRepresentativeInfo, _super);

        function StInjectRepresentativeInfo(classConfig) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "InjectRepresentativeInfo";
            _this.injectToFields = function(repInfo) {
                var repId = repInfo.repId,
                    webAlias = repInfo.webAlias,
                    firstName = repInfo.firstName,
                    lastName = repInfo.lastName,
                    imageUrl = repInfo.imageUrl;
                if (!!repId) {
                    _this.appendIdToField(repInfo.repId);
                }
                if (!!webAlias) {
                    _this.appendAlsToField(webAlias);
                    _this.appendRepSiteUrlToField(webAlias);
                }
                if (!!firstName || !!lastName) {
                    _this.appendRepFullNameToField(firstName, lastName, webAlias);
                }
                if (!!imageUrl && _features_config_2.additionalRepInfo) {
                    _this.appendRepBioToField(imageUrl);
                }
            };
            _this.injectSponsorInfoToField = function(firstName, lastName) {
                var repNameSelector = document.querySelector(_this.classConfig.selectorBusinessContentRepName);
                if (!!repNameSelector) {
                    repNameSelector.innerHTML = firstName + " " + lastName;
                }
                var personalInformationRep = document.querySelector(_this.classConfig.selectorPersonalInfoRepFullName);
                if (!!personalInformationRep) {
                    personalInformationRep.value = firstName + " " + lastName;
                }
            };
            _this.appendIdToField = function(id) {
                var repAliasFields = document.querySelectorAll(_this.classConfig.selectorRepId);
                if (repAliasFields.length > 0) {
                    _this.appendValueToFields(repAliasFields, id);
                }
            };
            _this.appendAlsToField = function(alias) {
                var repAliasFields = document.querySelectorAll(_this.classConfig.selectorRepAlias);
                if (repAliasFields.length > 0) {
                    _this.appendValueToFields(repAliasFields, alias);
                }
            };
            _this.appendRepSiteUrlToField = function(alias) {
                var repSiteFields = document.querySelectorAll(_this.classConfig.selectorRepSite);
                var repSite = window.location.origin + "/?als=" + alias;
                if (repSiteFields.length > 0) {
                    _this.appendValueToFields(repSiteFields, repSite);
                }
            };
            _this.appendRepFullNameToField = function(repFirstName, repLastName, webAlias) {
                var repFullNameFields = document.querySelectorAll(_this.classConfig.selectorRepFullName);
                var fullName = _this.getFullName(repFirstName, repLastName, webAlias);
                if (repFullNameFields.length > 0) {
                    _this.appendValueToFields(repFullNameFields, fullName);
                }
            };
            _this.appendRepBioToField = function(imageUrl) {
                var repImages = document.querySelectorAll(_this.classConfig.selectorRepBio);
                var imageString = 'BIO: <img class="" style="width: 50px; height: auto;" alt="representatve image" src="' + imageUrl + '">';
                if (repImages.length > 0) {
                    repImages.forEach(function(field) {
                        return field.innerHTML = imageString;
                    });
                }
            };
            _this.getFullName = function(repFirstName, repLastName, webAlias) {
                var fullName = "";
                if (!!repFirstName) {
                    fullName = repFirstName;
                    if (!!repLastName) {
                        fullName += " " + repLastName;
                    }
                }
                if (webAlias === _features_config_2.defaultWebAlias) {
                    fullName = _features_config_2.corporationName;
                }
                return fullName;
            };
            _this.appendValueToFields = function(fields, value) {
                fields.forEach(function(field) {
                    if (field.tagName.toLowerCase() === "input") {
                        field.value = value;
                    } else if (field.tagName.toLowerCase() === "a") {
                        field.setAttribute("href", value);
                    } else {
                        field.innerHTML = value;
                    }
                });
            };
            _this.classConfig = classConfig;
            return _this;
        }
        return StInjectRepresentativeInfo;
    }(st_module_7.StModule);
    exports.StInjectRepresentativeInfo = StInjectRepresentativeInfo;
});

define("core/shopify-app/st-modules/cart/cart", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_8) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StCart = void 0;
    var StCart = function(_super) {
        __extends(StCart, _super);

        function StCart() {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "Cart";
            _this_1.reloadSubscriber = [];
            _this_1.cartInterceptorEndpoints = ["/cart/add.js", "/cart/update.js", "/cart/change.js", "/cart/clear.js", "/wallets/checkouts/"];
            _this_1.shopifyCartApiEndpoints = {
                "get-cart": "/cart.js",
                "add-to-cart": "/cart/add.js",
                "clear-cart": "/cart/clear.js",
                "change-cart": "/cart/change.js",
                "update-cart": "/cart/update.js"
            };
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.cartFetchInterceptorInit();
                });
            };
            _this_1.cartFetchInterceptorInit = function() {
                var originalFetch = window.fetch;
                window.fetch = function() {
                    var args = [];
                    for (var _i = 0; _i < arguments.length; _i++) {
                        args[_i] = arguments[_i];
                    }
                    return __awaiter(_this_1, void 0, void 0, function() {
                        var resource, config, response;
                        return __generator(this, function(_a) {
                            switch (_a.label) {
                                case 0:
                                    resource = args[0], config = args[1];
                                    return [4, originalFetch(resource, config)];

                                case 1:
                                    response = _a.sent();
                                    if (this.isCartChangeRequest(response.url)) {
                                        this.getCart(this.handleChangeCartInterceptor);
                                    }
                                    return [2, response];
                            }
                        });
                    });
                };
            };
            _this_1.handleChangeCartInterceptor = function(cartObj) {
                try {
                    _this_1.setShopifyCartData(cartObj);
                    _this_1.addOrEditPropertiesForWebAlias(cartObj.items, cartObj.attributes.sponsorWebAlias);
                    _this_1.fireAllCallbacks(cartObj);
                } catch (err) {
                    console.error("handleChangeCartInterceptor ---\x3e Error:", err);
                }
            };
            _this_1.initCartSetup = function() {
                _this_1.getCart(function(cartObj) {
                    _this_1.setShopifyCartData(cartObj);
                });
            };
            _this_1.fireAllCallbacks = function(cartObject) {
                _this_1.fireChangeCartCallbacks(cartObject);
                setTimeout(function() {
                    _this_1.fireRenderCartCallbacks();
                }, 1e3);
            };
            _this_1.subscribeChangeCart = function(callback) {
                _this_1.subCallbacks.push(callback);
            };
            _this_1.fireChangeCartCallbacks = function(cartObject) {
                if (_this_1.subCallbacks.length > 0) {
                    _this_1.subCallbacks.forEach(function(callback) {
                        callback(cartObject);
                    });
                }
            };
            _this_1.subscribeRenderCart = function(callback) {
                _this_1.subRenderCartCallbacks.push(callback);
            };
            _this_1.fireRenderCartCallbacks = function() {
                if (_this_1.subRenderCartCallbacks.length > 0) {
                    _this_1.subRenderCartCallbacks.forEach(function(callback) {
                        callback();
                    });
                }
            };
            _this_1.matchUrlSnippet = function(url, urlSnippetArr) {
                for (var i = 0; i < urlSnippetArr.length; i++) {
                    if (url.includes(urlSnippetArr[i])) {
                        return true;
                    }
                }
                return false;
            };
            _this_1.isGetCartRequest = function(url) {
                return url.endsWith("/cart.json");
            };
            _this_1.isCartChangeRequest = function(url) {
                return _this_1.matchUrlSnippet(url, _this_1.cartInterceptorEndpoints);
            };
            _this_1.setShopifyCartData = function(cartObj) {
                window.shopifyCartData = cartObj;
                _this_1.setCartInfo(cartObj);
            };
            _this_1.handleChangeCartResponseGeneric = function(res, handleFunc, cartRefresh) {
                if (handleFunc === void 0) {
                    handleFunc = function() {};
                }
                if (cartRefresh === void 0) {
                    cartRefresh = true;
                }
                try {
                    var cartRes_1 = JSON.parse(res.response);
                    _this_1.getCart(function(cartObj) {
                        _this_1.setShopifyCartData(cartObj);
                        if (cartRefresh) {
                            _this_1.requestCartRefresh(cartObj);
                        }
                        _this_1.fireAllCallbacks(cartObj);
                        handleFunc(cartRes_1);
                    });
                } catch (err) {
                    console.log("handleChangeCartResponseGeneric ---\x3e Error: ", err);
                }
            };
            _this_1.getCart = function(responseHandle) {
                try {
                    _this_1.ajax.send({
                        endpoint: _this_1.shopifyCartApiEndpoints["get-cart"],
                        method: "GET",
                        contentType: "json",
                        callback: function(res) {
                            try {
                                var cartObj = JSON.parse(res.response);
                                responseHandle(cartObj);
                            } catch (err) {
                                console.log("Cart Api Error: ", err);
                            }
                        }
                    });
                } catch (err) {
                    console.log("Get Cart ---\x3e Error:", err);
                }
            };
            _this_1.clearCart = function(responseHandle) {
                try {
                    _this_1.ajax.send({
                        endpoint: _this_1.shopifyCartApiEndpoints["clear-cart"],
                        method: "POST",
                        contentType: "json",
                        callback: function(res) {
                            _this_1.handleChangeCartResponseGeneric(res, responseHandle);
                        }
                    });
                } catch (err) {
                    console.log("Clear Cart ---\x3e Error:", err);
                }
            };
            _this_1.changeCart = function(changeData, responseHandle, cartRefresh) {
                if (cartRefresh === void 0) {
                    cartRefresh = true;
                }
                try {
                    _this_1.ajax.send({
                        endpoint: _this_1.shopifyCartApiEndpoints["change-cart"],
                        method: "POST",
                        contentType: "json",
                        data: changeData,
                        callback: function(res) {
                            _this_1.handleChangeCartResponseGeneric(res, responseHandle, cartRefresh);
                        }
                    });
                } catch (err) {
                    console.log("Change Cart ---\x3e Error:", err);
                }
            };
            _this_1.updateCart = function(updateData, responseHandle) {
                try {
                    var data = Array.isArray(updateData) ? {
                        updates: updateData
                    } : updateData;
                    _this_1.ajax.send({
                        endpoint: _this_1.shopifyCartApiEndpoints["update-cart"],
                        method: "POST",
                        contentType: "json",
                        data: data,
                        callback: function(res) {
                            _this_1.handleChangeCartResponseGeneric(res, responseHandle);
                        }
                    });
                } catch (err) {
                    console.log("Update Cart ---\x3e Error:", err);
                }
            };
            _this_1.addCart = function(addData, responseHandle) {
                try {
                    var data = Array.isArray(addData) ? {
                        items: addData
                    } : addData;
                    _this_1.ajax.send({
                        endpoint: _this_1.shopifyCartApiEndpoints["add-to-cart"],
                        method: "POST",
                        contentType: "json",
                        data: data,
                        callback: function(res) {
                            _this_1.handleChangeCartResponseGeneric(res, responseHandle);
                        }
                    });
                } catch (err) {
                    console.log("Add To Cart ---\x3e Error:", err);
                }
            };
            _this_1.requestCartRefresh = function(cart) {
                var isCartPage = location.pathname === "/cart";
                if (isCartPage) {
                    var _this_2 = _this_1;
                    var refreshIndex_1 = _this_1.subscribeCartReload();
                    setTimeout(function() {
                        _this_2.triggerCartReload(refreshIndex_1);
                    }, 500);
                }
                if (!isCartPage) {
                    _this_1.ajax.send({
                        endpoint: "".concat(window.Shopify.routes.root, "?section_id=cart-drawer"),
                        method: "GET",
                        callback: function(request) {
                            var cartDrawerTemplate = request.responseText;
                            _this_1.triggerCartRefresh(cart, {
                                "cart-drawer": cartDrawerTemplate
                            });
                        }
                    });
                }
            };
            _this_1.triggerCartRefresh = function(cart, sections) {
                var addEvt = new CustomEvent("variant:add");
                var cartRefreshEvt = new CustomEvent("cart:refresh");
                var totalQuantity = cart.items.reduce(function(acc, item) {
                    return acc + item.quantity;
                }, 0);
                var cartChangeEvt = new CustomEvent("cart:change", {
                    detail: {
                        cart: __assign(__assign({}, cart), {
                            item_count: totalQuantity,
                            sections: sections
                        })
                    }
                });
                document.dispatchEvent(cartChangeEvt);
                document.dispatchEvent(cartRefreshEvt);
                document.dispatchEvent(addEvt);
            };
            _this_1.setCartInfo = function(shopifyCart) {
                _this_1.cart = __assign(__assign({}, _this_1.cart), shopifyCart);
            };
            _this_1.updateCartItemsProperies = function(alias) {
                _this_1.getCart(function(cartResponse) {
                    var attributes = cartResponse.attributes;
                    attributes = __assign(__assign({}, attributes), {
                        sponsorWebAlias: !!alias ? alias : ""
                    });
                    var updateAttributes = {
                        attributes: attributes
                    };
                    _this_1.updateCartAttributesOrNote(updateAttributes, function(cartRes) {
                        var items = cartRes.items;
                        _this_1.addOrEditPropertiesForWebAlias(items, alias);
                    });
                });
            };
            _this_1.addOrEditPropertiesForWebAlias = function(cartItems, alias) {
                var _a;
                var updateCartProperties = false;
                var item = {};
                var itemWithProperties = cartItems.find(function(item) {
                    var _a;
                    return ((_a = item.properties) === null || _a === void 0 ? void 0 : _a._sponsorWebAlias) !== undefined;
                });
                var duplicateItem = cartItems.find(function(item) {
                    var _a;
                    return item.sku === (itemWithProperties === null || itemWithProperties === void 0 ? void 0 : itemWithProperties.sku) && ((_a = item.properties) === null || _a === void 0 ? void 0 : _a._sponsorWebAlias) === undefined;
                });
                if (!itemWithProperties && cartItems.length > 0) {
                    item = cartItems[cartItems.length - 1];
                    updateCartProperties = true;
                } else if (duplicateItem) {
                    item = duplicateItem;
                    updateCartProperties = true;
                } else if (itemWithProperties && ((_a = itemWithProperties.properties) === null || _a === void 0 ? void 0 : _a._sponsorWebAlias) !== alias) {
                    item = itemWithProperties;
                    updateCartProperties = true;
                }
                var refreshCart = !!duplicateItem;
                if (updateCartProperties) {
                    _this_1.updateItemProperties(item, alias, refreshCart);
                }
            };
            _this_1.updateItemProperties = function(item, alias, refreshCart) {
                var updateData = {
                    id: "".concat(item.key),
                    quantity: item.quantity,
                    properties: __assign(__assign({}, item.properties), {
                        _sponsorWebAlias: alias
                    })
                };
                _this_1.changeCart(updateData, function(updatedCart) {
                    console.log("Updated Cart:", updatedCart);
                }, refreshCart);
            };
            _this_1.updateCartAttributesOrNote = function(updateData, responseHandle) {
                try {
                    _this_1.ajax.send({
                        endpoint: _this_1.shopifyCartApiEndpoints["update-cart"],
                        method: "POST",
                        contentType: "json",
                        data: updateData,
                        callback: function(res) {
                            _this_1.handleChangeCartResponseGenericNoRefresh(res, responseHandle);
                        }
                    });
                } catch (err) {
                    console.log("Update Cart ---\x3e Error:", err);
                }
            };
            _this_1.handleChangeCartResponseGenericNoRefresh = function(res, handleFunc) {
                try {
                    var cartRes = JSON.parse(res.response);
                    handleFunc(cartRes);
                    _this_1.getCart(function(cartObj) {
                        _this_1.setShopifyCartData(cartObj);
                        _this_1.handleChangeCartInterceptor(cartObj);
                    });
                } catch (err) {
                    console.log("handleChangeCartResponseGenericNoRefresh ---\x3e Error: ", err);
                }
            };
            _this_1.subscribeCartReload = function() {
                _this_1.reloadSubscriber.push(false);
                return _this_1.reloadSubscriber.length - 1;
            };
            _this_1.triggerCartReload = function(index) {
                var shouldRefresh = true;
                _this_1.reloadSubscriber[index] = true;
                for (var i = 0; i < _this_1.reloadSubscriber.length; i++) {
                    if (_this_1.reloadSubscriber[i] === false) {
                        shouldRefresh = false;
                        break;
                    }
                }
                if (shouldRefresh) window.location.reload();
            };
            _this_1.subCallbacks = [];
            _this_1.subRenderCartCallbacks = [];
            return _this_1;
        }
        Object.defineProperty(StCart.prototype, "getShopifyCartData", {
            get: function() {
                return window.shopifyCartData;
            },
            enumerable: false,
            configurable: true
        });
        return StCart;
    }(st_module_8.StModule);
    exports.StCart = StCart;
});

define("core/shopify-app/st-modules/search-sponsor/sponsor-search-class-config", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_9) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StSearchSponsorClassConfig = void 0;
    var StSearchSponsorClassConfig = function(_super) {
        __extends(StSearchSponsorClassConfig, _super);

        function StSearchSponsorClassConfig() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "SearchSponsorClassConfig";
            _this.classNameSponsorId = "st_sponsor-id_JS";
            _this.selectorSponsorId = "." + _this.classNameSponsorId;
            _this.classNameSponsorAlias = "st_sponsor-alias_JS";
            _this.selectorSponsorAlias = "." + _this.classNameSponsorAlias;
            _this.classNameSponsorFullName = "st_sponsor-fullname_JS";
            _this.selectorSponsorFullName = "." + _this.classNameSponsorFullName;
            _this.classNameSponsorInitials = "st_sponsor-initials_JS";
            _this.selectorSponsorInitials = "." + _this.classNameSponsorInitials;
            _this.classNameSponsorAddress = "st_sponsor-address_JS";
            _this.selectorSponsorAddress = "." + _this.classNameSponsorAddress;
            _this.classNameSearchSponsorWrapperPage = "st_search-sponsor--wrapper_JS";
            _this.selectorSearchSponsorWrapperPage = "." + _this.classNameSearchSponsorWrapperPage;
            _this.classNameInputBoxPage = "st_search-sponsor--by-id_JS";
            _this.selectorInputBoxPage = "." + _this.classNameInputBoxPage;
            _this.classNameChangeSponsorWrapperlink = "st_change-sponsor--wrapper_JS";
            _this.selectorChangeSponsorWrapperLink = "." + _this.classNameChangeSponsorWrapperlink;
            _this.classNameChangeSponsorWrapper = "st_change-sponsor_JS";
            _this.selectorChangeSponsorWrapper = "." + _this.classNameChangeSponsorWrapper;
            _this.classNameSearchInput = "st_search-input_JS";
            _this.selectorSearchInput = "." + _this.classNameSearchInput;
            _this.classNameNonSponsor = "st_non-sponsor_JS";
            _this.selectorNonSponsor = "." + _this.classNameNonSponsor;
            _this.classNameChooseSponsor = "st_choose-sponsor_JS";
            _this.selectorChooseSponsor = "." + _this.classNameChooseSponsor;
            _this.classNameSearchResult = "st_search-result_JS";
            _this.selectorSearchResult = "." + _this.classNameSearchResult;
            _this.classNameRepresentativeAlias = "st_representative-alias_JS";
            _this.selectorRepresentativeAlias = "." + _this.classNameRepresentativeAlias;
            _this.classNameRepresentativeFullName = "st_representative-fullname_JS";
            _this.selectorRepresentativeFullName = "." + _this.classNameRepresentativeFullName;
            _this.classNameSponsorData = "st_sponsor-data_JS";
            _this.selectorSponsorData = "." + _this.classNameSponsorData;
            _this.classNameSearchSponsor = "st_search-sponsors_JS";
            _this.selectorSearchSponsor = "." + _this.classNameSearchSponsor;
            _this.classNameFoundSponsor = "st_found-sponsors_JS";
            _this.selectorFoundSponsor = "." + _this.classNameFoundSponsor;
            _this.classNameSearchSponsorBy = "st_search-sponsor-by_JS";
            _this.selectorSearchSponsorBy = "." + _this.classNameSearchSponsorBy;
            _this.classNameRadioText = "st_radio-text";
            _this.selectorRadioText = "." + _this.classNameRadioText;
            _this.classRepresentativeBannerWrapper = "st_representative-banner--wrapper_JS";
            _this.selectorRepresentativeBannerWrapper = "." + _this.classRepresentativeBannerWrapper;
            return _this;
        }
        return StSearchSponsorClassConfig;
    }(st_module_9.StModule);
    exports.StSearchSponsorClassConfig = StSearchSponsorClassConfig;
});

define("core/shopify-app/st-modules/search-sponsor/search-sponsor-guard", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "_features.config"], function(require, exports, st_module_10, _features_config_3) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StSearchSponsorGuard = void 0;
    var StSearchSponsorGuard = function(_super) {
        __extends(StSearchSponsorGuard, _super);

        function StSearchSponsorGuard(classConfig, browserHistory, objectFormatting, generalMethods, cartComponent) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "SearchSponsorGuard";
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {
                    _this.listenForSponsorChange();
                    _this.cartComponent.subscribeRenderCart(function() {
                        var urlParams = _this.objectFormatting.convertQueryStringToObject(window.location.search);
                        var currentAlias = urlParams[_features_config_3.aliasQueryParam];
                        _this.toggleCantGoUnderCorporateSite(currentAlias === _features_config_3.defaultWebAlias);
                    });
                });
            };
            _this.toggleElementVisibility = function(element, hideElement) {
                if (hideElement) {
                    _this.hideElement(element);
                } else {
                    _this.showElement(element);
                }
            };
            _this.showElement = function(element) {
                if (_this.isElementHidden(element)) {
                    element.classList.remove("st_hidden");
                }
            };
            _this.hideElement = function(element) {
                if (!_this.isElementHidden(element)) {
                    element.classList.add("st_hidden");
                }
            };
            _this.isElementHidden = function(element) {
                return element.classList.contains("st_hidden");
            };
            _this.toggleShoppingWith = function(hideElement) {
                console.log("sss toggleShoppingWith", hideElement);
                var banner = document.querySelector(_this.classConfig.selectorRepresentativeBannerWrapper);
                _this.toggleElementVisibility(banner, hideElement);
            };
            _this.disableNonSponsor = function() {
                var nonSponsorBtn = document.querySelector(_this.classConfig.selectorNonSponsor);
                nonSponsorBtn === null || nonSponsorBtn === void 0 ? void 0 : nonSponsorBtn.remove();
            };
            _this.toggleBuying = function(hideBuying) {
                _this.toggleCheckoutButtons(hideBuying);
                _this.togglePaymentButtons(hideBuying);
                _this.toggleSearchSponsor(hideBuying);
            };
            _this.toggleSearchSponsor = function(hideElement) {
                var searchSponsorWrappers = document.querySelectorAll(".st_search-sponsor--wrapper_JS");
                searchSponsorWrappers.forEach(function(searchSponsorWrapper) {
                    _this.toggleSearchSponsorInput(searchSponsorWrapper, !hideElement);
                    _this.toggleSearchSponsorResult(searchSponsorWrapper, hideElement);
                });
            };
            _this.toggleSearchSponsorResult = function(container, hideElement) {
                var searchSponsorResultWrapper = container.querySelector(".st_search-result_JS");
                if (!!searchSponsorResultWrapper) {
                    _this.toggleElementVisibility(searchSponsorResultWrapper, hideElement);
                }
            };
            _this.toggleSearchSponsorInput = function(container, hideElement) {
                var searchSponsorInputWrapper = container.querySelector(".st_search-input_JS");
                if (!!searchSponsorInputWrapper) {
                    _this.toggleElementVisibility(searchSponsorInputWrapper, hideElement);
                }
            };
            _this.toggleCheckoutButtons = function(hideElement) {
                var checkoutButtons = document.querySelectorAll('button[name="checkout"]');
                if (checkoutButtons.length > 0) {
                    checkoutButtons.forEach(function(btn) {
                        _this.toggleElementVisibility(btn, hideElement);
                    });
                }
            };
            _this.togglePaymentButtons = function(hideElement) {
                var paymentButtonsWrapper = document.querySelectorAll(".st_product-buy-now-wrapper_JS");
                if (paymentButtonsWrapper.length > 0) {
                    paymentButtonsWrapper.forEach(function(wrp) {
                        _this.toggleElementVisibility(wrp, hideElement);
                    });
                }
            };
            _this.toggleCantGoUnderCorporateSite = function(hideElements) {
                if (!_features_config_3.canGoUnderCorporateSite) {
                    _this.disableNonSponsor();
                    _this.toggleShoppingWith(hideElements);
                    _this.toggleBuying(hideElements);
                }
            };
            _this.listenForSponsorChange = function() {
                window.addEventListener("sponsorChange", function() {
                    var urlParams = _this.objectFormatting.convertQueryStringToObject(window.location.search);
                    var currentAlias = urlParams[_features_config_3.aliasQueryParam];
                    _this.toggleCantGoUnderCorporateSite(currentAlias === _features_config_3.defaultWebAlias);
                });
            };
            _this.classConfig = classConfig;
            _this.browserHistory = browserHistory;
            _this.objectFormatting = objectFormatting;
            _this.generalMethods = generalMethods;
            _this.cartComponent = cartComponent;
            return _this;
        }
        return StSearchSponsorGuard;
    }(st_module_10.StModule);
    exports.StSearchSponsorGuard = StSearchSponsorGuard;
});

define("core/connector-app/_shared/models/customer/sponsor/customer.update.sponsor.request", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/connector-app/_shared/models/webalias/webalias.response.model", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/shopify-app/st-modules/account/_general/account-class-config", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_11) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountClassConfig = void 0;
    var StAccountClassConfig = function(_super) {
        __extends(StAccountClassConfig, _super);

        function StAccountClassConfig() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "AccountClassConfig";
            _this.classNameProvinceSelector = "st_province-selector_JS";
            _this.selectorProvinceSelector = "." + _this.classNameProvinceSelector;
            _this.classNameProvinceSource = "st_province-source_JS";
            _this.selectorProvinceSource = "." + _this.classNameProvinceSource;
            _this.classNameAccountPage = "st_account_JS";
            _this.selectorAccountPage = "." + _this.classNameAccountPage;
            _this.classNameAccountSection = "st_account-page--section_JS";
            _this.selectorAccountSection = "." + _this.classNameAccountSection;
            _this.classNameAccountContent = "st_account-page_JS";
            _this.selectorAccountContent = "." + _this.classNameAccountContent;
            _this.classNameAccountNavWrapper = "st_account-nav--wrapper_JS";
            _this.selectorAccountNavWrapper = "." + _this.classNameAccountNavWrapper;
            _this.classNameAccountNavHolder = "st_account-nav--holder_JS";
            _this.selectorAccountNavHolder = "." + _this.classNameAccountNavHolder;
            _this.classNameAccountNavHolderSingle = "st_account-nav--holder-single_JS";
            _this.selectorAccountNavHolderSingle = "." + _this.classNameAccountNavHolderSingle;
            _this.classNameAccountNavButton = "st_account-button_JS";
            _this.selectorAccountNavButton = "." + _this.classNameAccountNavButton;
            _this.classNameAccountIcon = "st_account--nav-icon_JS";
            _this.selectorAccountIcon = "." + _this.classNameAccountIcon;
            _this.classNameAccountCopyText = "st_copy-repsite_JS";
            _this.selectorAccountIconCopyText = "." + _this.classNameAccountCopyText;
            _this.classNameAccountCopyTextWrapper = "st_copy-repsite--wrapper_JS";
            _this.selectorAccountIconCopyTextWrapper = "." + _this.classNameAccountCopyTextWrapper;
            _this.classNameAccountLogout = "st_account-logout_JS";
            _this.selectorAccountLogout = "." + _this.classNameAccountLogout;
            _this.classNameAccountWebAlias = "st_input-wrapper_JS input";
            _this.selectorAccountWebAlias = "." + _this.classNameAccountWebAlias;
            _this.classNameAccountAddressesDropdown = "st_addresses-dots--button_JS";
            _this.selectorAccountAddressesDropdown = "." + _this.classNameAccountAddressesDropdown;
            _this.classNameAccountAddressesDropdownWrapper = "st_dropdown-address--wrapper";
            _this.selectorAccountAddressesDropdownWrapper = "." + _this.classNameAccountAddressesDropdownWrapper;
            _this.classNameAccountTabButton = "st_button-wrapper_JS";
            _this.selectorAccountTabButton = "." + _this.classNameAccountTabButton;
            _this.classNameAccountBackButton = "st_arrow-back--button_JS";
            _this.selectorAccountBackButton = "." + _this.classNameAccountBackButton;
            _this.classNameSingleOrder = "st_single-order_JS";
            _this.selectorSingleOrder = "." + _this.classNameSingleOrder;
            _this.classNameOpenOrderCSSClass = "st_open-single-order";
            _this.selectorOpenOrderCSSClass = "." + _this.classNameOpenOrderCSSClass;
            _this.classNameOpenSingleOrderButton = "st_open-single-order_JS";
            _this.selectorOpenSingleOrderButton = "." + _this.classNameOpenSingleOrderButton;
            _this.classNameOrderHistory = "st_order-history_JS";
            _this.selectorOrderHistory = "." + _this.classNameOrderHistory;
            _this.classNameBackToHistoryOrders = "st_back-to-history-orders_JS";
            _this.selectorBackToHistoryOrders = "." + _this.classNameBackToHistoryOrders;
            _this.classNameBackOfficeLink = "st_backoffice-link_JS";
            _this.selectorBackOfficeLink = "." + _this.classNameBackOfficeLink;
            _this.classNameWebAliasFormatting = "st_formatting-web-alias_JS";
            _this.selectorWebAliasFormatting = "." + _this.classNameWebAliasFormatting;
            _this.classNameWebAliasWrapper = "st_web-alias-wrapper_JS";
            _this.selectorWebAliasWrapper = "." + _this.classNameWebAliasWrapper;
            _this.classNameWebAliasValue = "st_web-alias-readonly-input_JS";
            _this.selectorWebAliasValue = "." + _this.classNameWebAliasValue;
            _this.classNameAddressesWrapper = "st_addresses--wrapper_JS";
            _this.selectorAddressesWrapper = "." + _this.classNameAddressesWrapper;
            _this.classNameEditWebAliasForm = "st_edit-webalias-form_JS";
            _this.selectorEditWebAliasForm = "." + _this.classNameEditWebAliasForm;
            _this.classNameSubmitButton = "st_submit--btn_JS";
            _this.selectorSubmitButton = "." + _this.classNameSubmitButton;
            _this.classNameProvinceWrapper = "st_province-wrapper_JS";
            _this.selectorProvinceWrapper = "." + _this.classNameProvinceWrapper;
            _this.classNamePersonalInfoForm = "st_personal-info-form_JS";
            _this.selectorPersonalInfoForm = "." + _this.classNamePersonalInfoForm;
            _this.classNameBusinessContent = "st_account-business--content_JS";
            _this.selectorBusinessContent = "." + _this.classNameBusinessContent;
            _this.classNameBusinessContentName = "st_account-business--name_JS";
            _this.selectorBusinessContentName = "." + _this.classNameBusinessContentName;
            _this.classNameBusinessContentRepName = "st_account-business--rep-name_JS";
            _this.selectorBusinessContentRepName = "." + _this.classNameBusinessContentRepName;
            _this.classNameBusinessContentEmail = "st_account-business--email_JS";
            _this.selectorBusinessContentEmail = "." + _this.classNameBusinessContentEmail;
            return _this;
        }
        return StAccountClassConfig;
    }(st_module_11.StModule);
    exports.StAccountClassConfig = StAccountClassConfig;
});

define("core/shopify-app/st-modules/account/blocks/personal-site/personal-site", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "_features.config"], function(require, exports, st_module_12, _features_config_4) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountPersonalSite = void 0;
    var StAccountPersonalSite = function(_super) {
        __extends(StAccountPersonalSite, _super);

        function StAccountPersonalSite(classConfig, generalMethods) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "AccountPersonalSite";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.copyRefToClipboard(_this_1.classConfig.selectorAccountIconCopyText, ".st_representative-site-link_JS");
                    _this_1.getRefCode();
                });
            };
            _this_1.getRefCode = function() {
                var propertyWrapper = document.querySelector(".st_get-ref-code_JS");
                var customersRef = propertyWrapper === null || propertyWrapper === void 0 ? void 0 : propertyWrapper.getAttribute("data-customer-tag");
                var retailInput = document.querySelectorAll(".st_retail-personal-promo-code-link_JS");
                if (_features_config_4.shareRefCodeFunctionality) {
                    _this_1.copyRefToClipboard(".st_referral-link-copy-clipboard_JS", ".st_retail-personal-promo-code-link_JS");
                    var alias = localStorage.getItem("webAlias");
                    _this_1.createLinkWithRef(alias);
                    _this_1.showIncludePromoCode();
                    _this_1.showPersonalSiteRetailBlock();
                    if (!customersRef) {
                        _this_1.createLinkWithoutRef();
                    }
                } else {
                    _this_1.hideIncludePromoCode();
                    _this_1.hidePersonalSiteRetailBlock();
                    _this_1.createLinkWithoutRef();
                }
            };
            _this_1.createLinkWithRef = function(alias) {
                var propertyWrapper = document.querySelector(".st_get-ref-code_JS");
                var customersRef = propertyWrapper === null || propertyWrapper === void 0 ? void 0 : propertyWrapper.getAttribute("data-customer-tag");
                var retailInput = document.querySelectorAll(".st_retail-personal-promo-code-link_JS");
                retailInput.forEach(function(input) {
                    input.value = window.location.protocol + "//" + window.location.host + "/?" + _features_config_4.aliasQueryParam + "=" + alias + "&" + "ref=" + customersRef;
                });
            };
            _this_1.createLinkWithoutRef = function() {
                var inputEl = document.querySelectorAll(".st_representative-site-link_JS");
                if (inputEl) {
                    inputEl.forEach(function(input) {
                        var als = localStorage.getItem("webAlias");
                        input.value = window.location.protocol + "//" + window.location.host + "/?" + _features_config_4.aliasQueryParam + "=" + als;
                    });
                }
            };
            _this_1.hidePersonalSiteRetailBlock = function() {
                var personalSiteRetailBlockWrapper = document.querySelector(".st_personal-site-retail--wrapper_JS");
                if (!!personalSiteRetailBlockWrapper) {
                    personalSiteRetailBlockWrapper.classList.add("st_hidden");
                }
            };
            _this_1.showPersonalSiteRetailBlock = function() {
                var personalSiteRetailBlockWrapper = document.querySelector(".st_personal-site-retail--wrapper_JS");
                if (!!personalSiteRetailBlockWrapper) {
                    personalSiteRetailBlockWrapper.classList.remove("st_hidden");
                }
            };
            _this_1.createLinkWithRefRep = function(alias) {
                var propertyWrapper = document.querySelector(".st_get-ref-code_JS");
                var customersRef = propertyWrapper === null || propertyWrapper === void 0 ? void 0 : propertyWrapper.getAttribute("data-customer-tag");
                var retailInput = document.querySelectorAll(".st_representative-site-link_JS");
                retailInput.forEach(function(input) {
                    var hisAlias = localStorage.getItem("webAlias");
                    input.value = window.location.protocol + "//" + window.location.host + "/?" + _features_config_4.aliasQueryParam + "=" + hisAlias + "&" + "ref=" + customersRef;
                });
            };
            _this_1.createLinkWithoutRefRep = function() {
                var inputEl = document.querySelectorAll(".st_representative-site-link_JS");
                if (inputEl) {
                    inputEl.forEach(function(input) {
                        var hisAlias = localStorage.getItem("webAlias");
                        input.value = window.location.protocol + "//" + window.location.host + "/?" + _features_config_4.aliasQueryParam + "=" + hisAlias;
                    });
                }
            };
            _this_1.includePromoCode = function(als) {
                var _this = _this_1;
                var includeInput = document.querySelector(".st_include-promo-code-input_JS");
                if (!!includeInput) {
                    var inputEl_1 = document.querySelectorAll(".st_representative-site-link_JS");
                    if (includeInput.checked) {
                        _this.createLinkWithRefRep(als);
                    } else {
                        _this.createLinkWithoutRefRep();
                    }
                    includeInput.addEventListener("change", function(event) {
                        if (!!inputEl_1) {
                            if (includeInput.checked) {
                                _this.createLinkWithRefRep(als);
                            } else {
                                _this.createLinkWithoutRefRep();
                            }
                        }
                    });
                }
            };
            _this_1.hideIncludePromoCode = function() {
                var includePromoCodeWrapper = document.querySelector(".st_include-promo-code-wrapper_JS");
                if (!!includePromoCodeWrapper) {
                    includePromoCodeWrapper.classList.add("st_hidden");
                }
            };
            _this_1.showIncludePromoCode = function() {
                var includePromoCodeWrapper = document.querySelector(".st_include-promo-code-wrapper_JS");
                if (!!includePromoCodeWrapper) {
                    includePromoCodeWrapper.classList.remove("st_hidden");
                }
            };
            _this_1.copyRefToClipboard = function(button, input) {
                var copyRepSiteButtonAll = document.querySelectorAll(button);
                if (!!copyRepSiteButtonAll) {
                    copyRepSiteButtonAll.forEach(function(btn) {
                        btn.addEventListener("click", function(e) {
                            e.preventDefault();
                            var copyText = document.querySelectorAll(input);
                            if (!!copyText) {
                                copyText.forEach(function(input) {
                                    if (!!input) {
                                        input.select();
                                        input.setSelectionRange(0, 99999);
                                        navigator.clipboard.writeText(input.value);
                                        input.style.backgroundColor = "rgb(217, 218, 220)";
                                        input.style.transition = "0.2s";
                                        setTimeout(function() {
                                            input.style.backgroundColor = "rgb(249, 249, 249)";
                                        }, 1e3);
                                    }
                                });
                            }
                        });
                    });
                }
            };
            _this_1.classConfig = classConfig;
            _this_1.generalMethods = generalMethods;
            return _this_1;
        }
        return StAccountPersonalSite;
    }(st_module_12.StModule);
    exports.StAccountPersonalSite = StAccountPersonalSite;
});

define("core/shopify-app/st-modules/webalias/webalias", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "_features.config"], function(require, exports, st_module_13, _features_config_5) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StWebAlias = void 0;
    var StWebAlias = function(_super) {
        __extends(StWebAlias, _super);

        function StWebAlias(classConfig, browserHistory, objectFormatting, cookies, customerType, generalMethods, injectRepresentativeInfo, cartComponent, searchSponsorGuard, accountPersonalSite) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "WebAlias";
            _this_1.cookieNameWebAlias = "webAlias";
            _this_1.cookieNameRepId = "repId";
            _this_1.cookieNameFirstName = "firstName";
            _this_1.cookieNameLastName = "lastName";
            _this_1.cookieNameImageUrl = "imageUrl";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    var _this = _this_1;
                    _this_1.initWebAliasFlow();
                    _this_1.initSponsorCheck();
                    console.log("lockedRepresentativeSite: ", _features_config_5.lockedRepresentativeSite);
                    console.log("canGoUnderCorporateSite: ", _features_config_5.canGoUnderCorporateSite);
                    _this_1.getSponsorInformation();
                });
            };
            _this_1.initWebAliasFlow = function() {
                if (_this_1.isCustomerRepresentative) {
                    _this_1.representativeAliasFlow();
                    return;
                }
                if (_this_1.isCustomerRetail) {
                    _this_1.retailAliasFlow();
                    return;
                }
                if (_this_1.isCustomerGuest) {
                    _this_1.guestAliasFlow();
                }
            };
            _this_1.representativeAliasFlow = function() {
                _this_1.getRepresentativesOwnInfo(_this_1.customerIdFromMetafields);
            };
            _this_1.isElementHidden = function(element) {
                return element.classList.contains("st_hidden");
            };
            _this_1.showElement = function(element) {
                if (_this_1.isElementHidden(element)) {
                    element.classList.remove("st_hidden");
                }
            };
            _this_1.hideElement = function(element) {
                if (!_this_1.isElementHidden(element)) {
                    element.classList.add("st_hidden");
                }
            };
            _this_1.toggleElementVisibility = function(element, hideElement) {
                if (hideElement) {
                    _this_1.hideElement(element);
                } else {
                    _this_1.showElement(element);
                }
            };
            _this_1.toggleShoppingWith = function(hideElement) {
                var banner = document.querySelector(_this_1.classConfig.selectorRepresentativeBannerWrapper);
                _this_1.toggleElementVisibility(banner, hideElement);
            };
            _this_1.guestAliasFlow = function() {
                var urlParams = _this_1.objectFormatting.convertQueryStringToObject(window.location.search);
                var currentAlias = urlParams[_features_config_5.aliasQueryParam];
                var urlAliasExists = !!currentAlias;
                var cookieAliasExists = !!_this_1.cookies.getCookie("webAlias");
                if (urlAliasExists) {
                    _this_1.getRepresentativesOwnInfo(currentAlias);
                    return;
                }
                if (cookieAliasExists) {
                    _this_1.injectRepInfoFromCookie();
                    return;
                }
                _this_1.injectDefaultRepInfo();
            };
            _this_1.retailAliasFlow = function() {
                var urlParams = _this_1.objectFormatting.convertQueryStringToObject(window.location.search);
                var currentAlias = urlParams[_features_config_5.aliasQueryParam];
                var urlAliasExists = !!currentAlias;
                var cookieAliasExists = !!_this_1.cookies.getCookie("webAlias");
                var isLocked = _features_config_5.lockedRepresentativeSite;
                if (isLocked) {
                    var customerIdOrAls = _this_1.customerIdFromMetafields;
                    _this_1.getCustomersRepresentativeInfo(customerIdOrAls);
                    return;
                }
                if (!isLocked) {
                    if (urlAliasExists) {
                        _this_1.getRepresentativesOwnInfo(currentAlias);
                        return;
                    } else {
                        if (cookieAliasExists) {
                            _this_1.injectRepInfoFromCookie();
                            return;
                        } else {
                            _this_1.injectDefaultRepInfo();
                            return;
                        }
                    }
                }
            };
            _this_1.handleRepresentativeInfoResponse = function(response) {
                var data = response.data,
                    status = response.status;
                var webAlias = data.webAlias,
                    repId = data.repId;
                if (status !== 200) {
                    _this_1.nonExistentRepresentativeFlow();
                    return;
                }
                if (!webAlias && webAlias === "") {
                    data = __assign(__assign({}, data), {
                        webAlias: repId
                    });
                }
                _this_1.updateCurrentRepInfo(data);
            };
            _this_1.getRepresentativesOwnInfo = function(customerIdOrAlias) {
                _this_1.getRepresentativeInfo({
                    customerIdOrAlias: customerIdOrAlias,
                    isOwnInfo: true
                }, _this_1.handleRepresentativeInfoResponse);
            };
            _this_1.getCustomersRepresentativeInfo = function(customerIdOrAlias) {
                _this_1.getRepresentativeInfo({
                    customerIdOrAlias: customerIdOrAlias,
                    isOwnInfo: false
                }, _this_1.handleRepresentativeInfoResponse);
            };
            _this_1.getRepresentativeInfo = function(webAliasRequest, handleResponse) {
                try {
                    _this_1.ajax.send({
                        endpoint: _this_1.endpoint["webalias"]["repSite"],
                        method: "post",
                        contentType: "json",
                        data: webAliasRequest,
                        callback: function(response) {
                            try {
                                var representativeInfoRes = JSON.parse(response.response);
                                handleResponse(representativeInfoRes);
                            } catch (error) {
                                _this_1.nonExistentRepresentativeFlow();
                                console.log("Response Error ------\x3e" + error);
                            }
                        }
                    });
                } catch (error) {
                    console.log("Request Error ------\x3e" + error);
                }
            };
            _this_1.getSponsorInformation = function() {
                var repIdMetafield = window.customerInfoMetafields.representativeId;
                var webAliasRequestedData = {
                    customerIdOrAlias: repIdMetafield,
                    isOwnInfo: true
                };
                _this_1.getRepresentativeInfo(webAliasRequestedData, _this_1.handleSponsorInfoResponse);
            };
            _this_1.handleSponsorInfoResponse = function(response) {
                if (response.status === 200) {
                    var sponsorInfo = response.data;
                    _this_1.injectRepresentativeInfo.injectSponsorInfoToField(sponsorInfo.firstName, sponsorInfo.lastName);
                    _this_1.accountPersonalSite.createLinkWithRef(sponsorInfo.webAlias);
                    _this_1.accountPersonalSite.includePromoCode(sponsorInfo.webAlias);
                } else {
                    _this_1.injectRepresentativeInfo.injectSponsorInfoToField("", "");
                }
            };
            _this_1.isDataEqualToStored = function(repInfo) {
                return repInfo.webAlias === _this_1.cookies.getCookie("webAlias") && repInfo.firstName === _this_1.cookies.getCookie("firstName") && repInfo.lastName === _this_1.cookies.getCookie("lastName");
            };
            _this_1.updateCurrentRepInfo = function(repInfo) {
                var webAlias = repInfo.webAlias;
                if (!_this_1.isDataEqualToStored(repInfo)) {
                    _this_1.setRepresentativeCookies(repInfo);
                }
                if (!_this_1.isAliasEqualToUrlAlias(webAlias)) {
                    _this_1.setNewAliasInUrl(webAlias);
                }
                _this_1.cartComponent.updateCartItemsProperies(webAlias);
                _this_1.toggleShoppingWith(webAlias === _features_config_5.defaultWebAlias);
                _this_1.injectRepresentativeInfo.injectToFields(repInfo);
            };
            _this_1.nonExistentRepresentativeFlow = function() {
                if (!_this_1.isCustomerRetail) {
                    _this_1.injectDefaultRepInfo();
                    return;
                }
                _this_1.injectRepInfoFromCookie();
            };
            _this_1.injectRepInfoFromCookie = function() {
                var repInfo = {
                    firstName: _this_1.cookies.getCookie(_this_1.cookieNameFirstName),
                    lastName: _this_1.cookies.getCookie(_this_1.cookieNameLastName),
                    webAlias: _this_1.cookies.getCookie(_this_1.cookieNameWebAlias),
                    repId: _this_1.cookies.getCookie(_this_1.cookieNameRepId)
                };
                var imageUrl = _this_1.cookies.getCookie(_this_1.cookieNameImageUrl);
                if (!!imageUrl && _features_config_5.additionalRepInfo) {
                    repInfo = __assign(__assign({}, repInfo), {
                        imageUrl: imageUrl
                    });
                }
                _this_1.updateCurrentRepInfo(repInfo);
            };
            _this_1.injectDefaultRepInfo = function() {
                var repInfo = {
                    webAlias: _features_config_5.defaultWebAlias,
                    firstName: _features_config_5.corporationName,
                    lastName: ""
                };
                if (_features_config_5.additionalRepInfo) {
                    repInfo = __assign(__assign({}, repInfo), {
                        imageUrl: _features_config_5.defaultCorporationImage
                    });
                }
                _this_1.updateCurrentRepInfo(repInfo);
            };
            _this_1.isAliasEqualToStored = function(alias) {
                return alias === _this_1.cookies.getCookie("webAlias");
            };
            _this_1.isAliasEqualToUrlAlias = function(alias) {
                var urlParams = _this_1.objectFormatting.convertQueryStringToObject(window.location.search);
                var currentAlias = urlParams[_features_config_5.aliasQueryParam];
                return currentAlias === alias;
            };
            _this_1.setNewAliasInUrl = function(alias) {
                var _a;
                var urlParams = _this_1.objectFormatting.convertQueryStringToObject(window.location.search);
                var newUrlParams = __assign(__assign({}, urlParams), (_a = {}, _a[_features_config_5.aliasQueryParam] = alias,
                    _a));
                var newURL = window.location.href.replace(window.location.search, "");
                _this_1.browserHistory.pushHistory(newURL, newUrlParams);
            };
            _this_1.setRepresentativeCookies = function(repInfo) {
                _this_1.cookies.setCookies(_this_1.cookieNameWebAlias, repInfo.webAlias);
                _this_1.cookies.setCookies(_this_1.cookieNameRepId, repInfo.repId);
                _this_1.cookies.setCookies(_this_1.cookieNameFirstName, repInfo.firstName);
                _this_1.cookies.setCookies(_this_1.cookieNameLastName, repInfo.lastName);
                if (_features_config_5.additionalRepInfo) {
                    _this_1.cookies.setCookies(_this_1.cookieNameImageUrl, repInfo.imageUrl);
                }
            };
            _this_1.initSponsorCheck = function() {
                var shopifyCustomerId = _this_1.shopifyCustomerId;
                if (_this_1.isTimeForSponsorCheck() && shopifyCustomerId && shopifyCustomerId !== 0) {
                    _this_1.updateCustomerSponsor(shopifyCustomerId);
                }
            };
            _this_1.updateCustomerSponsor = function(shopifyCustomerId) {
                var updateSponsorData = {
                    shopifyCustomerId: shopifyCustomerId
                };
                try {
                    _this_1.ajax.send({
                        endpoint: _this_1.endpoint["customer"]["updateSponsor"],
                        method: "post",
                        contentType: "json",
                        data: updateSponsorData
                    });
                } catch (error) {
                    console.log("Request Error ------\x3e " + error);
                }
            };
            _this_1.isTimeForSponsorCheck = function() {
                var timestamp = Date.now();
                var lastCheck = _this_1.customerSponsorLastCheck;
                var timeThreshold = _features_config_5.sponsorGenealogyTimeout ? _features_config_5.sponsorGenealogyTimeout : 9e5;
                return timestamp - lastCheck > timeThreshold;
            };
            _this_1.classConfig = classConfig;
            _this_1.browserHistory = browserHistory;
            _this_1.objectFormatting = objectFormatting;
            _this_1.cookies = cookies;
            _this_1.customerType = customerType;
            _this_1.generalMethods = generalMethods;
            _this_1.injectRepresentativeInfo = injectRepresentativeInfo;
            _this_1.cartComponent = cartComponent;
            _this_1.searchSponsorGuard = searchSponsorGuard;
            _this_1.accountPersonalSite = accountPersonalSite;
            return _this_1;
        }
        Object.defineProperty(StWebAlias.prototype, "isCustomerGuest", {
            get: function() {
                return this.customerType.get() === _features_config_5.ECustomerType.guest;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(StWebAlias.prototype, "isCustomerRetail", {
            get: function() {
                return this.customerType.get() === _features_config_5.ECustomerType.retail;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(StWebAlias.prototype, "isCustomerRepresentative", {
            get: function() {
                return this.customerType.get() === _features_config_5.ECustomerType.representative;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(StWebAlias.prototype, "customerIdFromMetafields", {
            get: function() {
                return window.customerInfoMetafields.customerId;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(StWebAlias.prototype, "shopifyCustomerId", {
            get: function() {
                return window.customerShopifyId;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(StWebAlias.prototype, "customerSponsorLastCheck", {
            get: function() {
                return window.customerSponsorLastCheck;
            },
            enumerable: false,
            configurable: true
        });
        return StWebAlias;
    }(st_module_13.StModule);
    exports.StWebAlias = StWebAlias;
});

define("core/shopify-app/st-modules/_general-methods/form/form-class-config", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_14) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StFormClassConfig = void 0;
    var StFormClassConfig = function(_super) {
        __extends(StFormClassConfig, _super);

        function StFormClassConfig() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "FormClassConfig";
            _this.classNameDateWrp = "st_date_JS";
            _this.selectorDateWrp = "." + _this.classNameDateWrp;
            _this.classNameDateYearInput = "st_date--year_JS";
            _this.selectorDateYearInput = "." + _this.classNameDateYearInput;
            _this.classNameDateMonthInput = "st_date--month_JS";
            _this.selectorDateMonthInput = "." + _this.classNameDateMonthInput;
            _this.classNameDateDayInput = "st_date--day_JS";
            _this.selectorDateDayInput = "." + _this.classNameDateDayInput;
            _this.classNameDateCompleteInput = "st_date--complete_JS";
            _this.selectorDateCompleteInput = "." + _this.classNameDateCompleteInput;
            _this.months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            return _this;
        }
        return StFormClassConfig;
    }(st_module_14.StModule);
    exports.StFormClassConfig = StFormClassConfig;
});

define("core/shopify-app/st-modules/_general-methods/form/fields/date-input", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_15) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StDateInput = void 0;
    var StDateInput = function(_super) {
        __extends(StDateInput, _super);

        function StDateInput(classConfig) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "DateInput";
            _this_1.setupDateFields = function() {
                var dateWraps = document.querySelectorAll(_this_1.classConfig.selectorDateWrp);
                dateWraps.forEach(function(dateWrp) {
                    _this_1.setupDateField(dateWrp);
                });
            };
            _this_1.setupDateField = function(dateWrap) {
                var _a;
                var dateYearInput = dateWrap.querySelector(_this_1.classConfig.selectorDateYearInput);
                var dateMonthInput = dateWrap.querySelector(_this_1.classConfig.selectorDateMonthInput);
                var dateDayInput = dateWrap.querySelector(_this_1.classConfig.selectorDateDayInput);
                var now = new Date();
                var yearNow = now.getUTCFullYear();
                _this_1.generateYears(dateYearInput, 1900, yearNow);
                dateYearInput = dateWrap.querySelector(_this_1.classConfig.selectorDateYearInput);
                var defaultYear = dateYearInput.getAttribute("data-default");
                var defaultYearIndex = !!defaultYear ? parseInt(dateYearInput.querySelector('[value="'.concat(defaultYear, '"]')).getAttribute("data-index")) : 0;
                _this_1.setSelectValue(dateYearInput, defaultYearIndex);
                _this_1.generateMonths(dateMonthInput);
                dateMonthInput = dateWrap.querySelector(_this_1.classConfig.selectorDateMonthInput);
                var defaultMonth = dateMonthInput.getAttribute("data-default");
                var defaultMonthIndex = !!defaultMonth ? parseInt(dateMonthInput.querySelector('[value="'.concat(defaultMonth, '"]')).getAttribute("data-index")) : 0;
                _this_1.setSelectValue(dateMonthInput, defaultMonthIndex);
                _this_1.generateDays(dateDayInput, (_a = parseInt(dateYearInput.value)) !== null && _a !== void 0 ? _a : yearNow, defaultMonthIndex);
                var defaultDay = dateDayInput.getAttribute("data-default");
                var defaultDayIndex = !!defaultDay ? parseInt(dateDayInput.querySelector('[value="'.concat(defaultDay, '"]')).getAttribute("data-index")) : 0;
                dateDayInput = dateWrap.querySelector(_this_1.classConfig.selectorDateDayInput);
                _this_1.setSelectValue(dateDayInput, defaultDayIndex);
                _this_1.setupEvents(dateWrap, dateYearInput, dateMonthInput, dateDayInput);
            };
            _this_1.getDays = function(year, month) {
                return new Date(year, month + 1, 0).getDate();
            };
            _this_1.generateDays = function(holder, year, month) {
                var days = _this_1.getDays(year, month);
                holder.replaceChildren();
                for (var i = 1; i <= days; i++) {
                    var option = _this_1.generateOption(i, undefined, undefined, i - 1);
                    holder.appendChild(option);
                }
                return days;
            };
            _this_1.generateMonths = function(holder) {
                for (var i = 0; i < _this_1.classConfig.months.length; i++) {
                    var option = _this_1.generateOption(i, _this_1.classConfig.months[i], undefined, i);
                    holder.appendChild(option);
                }
            };
            _this_1.generateYears = function(holder, startingYear, endYear) {
                for (var i = 0; i < endYear - startingYear; i++) {
                    var option = _this_1.generateOption(endYear - i, undefined, undefined, i);
                    holder.appendChild(option);
                }
            };
            _this_1.generateOption = function(value, displayValue, selected, elementIndex) {
                if (displayValue === void 0) {
                    displayValue = value;
                }
                if (selected === void 0) {
                    selected = false;
                }
                var option = document.createElement("option");
                option.value = "".concat(value);
                option.setAttribute("value", "".concat(value));
                option.innerHTML = "".concat(displayValue);
                if (selected) {
                    option.setAttribute("selected", "selected");
                }
                if (typeof elementIndex !== "undefined") {
                    option.setAttribute("data-index", "".concat(elementIndex));
                }
                return option;
            };
            _this_1.setSelectValue = function(holder, optionIndex) {
                var options = holder.querySelectorAll("option");
                var selected = options[holder.selectedIndex];
                if (!!selected) {
                    selected.removeAttribute("selected");
                    selected.selected = false;
                }
                optionIndex = optionIndex > options.length - 1 ? options.length - 1 : optionIndex;
                holder.selectedIndex = optionIndex;
                options[optionIndex].selected = true;
                options[optionIndex].setAttribute("selected", "selected");
            };
            _this_1.setInputValue = function(input, value) {
                input.value = value;
                input.setAttribute("value", value);
                input.dispatchEvent(new Event("change", {
                    bubbles: true
                }));
            };
            _this_1.setupEvents = function(dateWrap, yearInput, monthInput, dayInput) {
                var _this = _this_1;
                monthInput.addEventListener("change", function(e) {
                    _this.adaptDaysOnChange(dateWrap);
                    _this.completeDate(dateWrap);
                });
                yearInput.addEventListener("change", function(e) {
                    _this.adaptDaysOnChange(dateWrap);
                    _this.completeDate(dateWrap);
                });
                dayInput.addEventListener("change", function(e) {
                    _this.completeDate(dateWrap);
                });
            };
            _this_1.completeDate = function(dateWrap) {
                var yearInput = dateWrap.querySelector(_this_1.classConfig.selectorDateYearInput);
                var monthInput = dateWrap.querySelector(_this_1.classConfig.selectorDateMonthInput);
                var dayInput = dateWrap.querySelector(_this_1.classConfig.selectorDateDayInput);
                var completeInput = dateWrap.querySelector(_this_1.classConfig.selectorDateCompleteInput);
                var year = parseInt(yearInput.querySelectorAll("option")[yearInput.selectedIndex].value);
                var month = parseInt(monthInput.querySelectorAll("option")[monthInput.selectedIndex].value);
                var day = parseInt(dayInput.querySelectorAll("option")[dayInput.selectedIndex].value);
                var completeDate = "".concat(year, "-").concat(month + 1, "-").concat(day);
                _this_1.setInputValue(completeInput, completeDate);
            };
            _this_1.adaptDaysOnChange = function(dateWrap) {
                var yearInput = dateWrap.querySelector(_this_1.classConfig.selectorDateYearInput);
                var monthInput = dateWrap.querySelector(_this_1.classConfig.selectorDateMonthInput);
                var dayInput = dateWrap.querySelector(_this_1.classConfig.selectorDateDayInput);
                var year = parseInt(yearInput.querySelectorAll("option")[yearInput.selectedIndex].value);
                var month = parseInt(monthInput.querySelectorAll("option")[monthInput.selectedIndex].value);
                var day = parseInt(dayInput.querySelectorAll("option")[dayInput.selectedIndex].value);
                var maxDays = _this_1.generateDays(dayInput, year, month);
                var selectedIndex = day > maxDays ? maxDays : day;
                _this_1.setSelectValue(dayInput, selectedIndex - 1);
            };
            _this_1.classConfig = classConfig;
            return _this_1;
        }
        return StDateInput;
    }(st_module_15.StModule);
    exports.StDateInput = StDateInput;
});

define("core/shopify-app/st-modules/_general-methods/form/form", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_16) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StForm = void 0;
    var StForm = function(_super) {
        __extends(StForm, _super);

        function StForm(classConfig, dateInput) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "Form";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.dateInput.setupDateFields();
                });
            };
            _this_1.liveTrim = function(inputs) {
                inputs = inputs ? inputs : document.querySelectorAll(".st_input");
                var trimOperation = function(trigger) {
                    trigger.value = trigger.value.replace(/  +/g, " ");
                    trigger.value = trigger.value.trimStart();
                };
                inputs.forEach(function(input) {
                    input.addEventListener("keyup", function() {
                        trimOperation(this);
                    });
                    input.addEventListener("change", function() {
                        trimOperation(this);
                    });
                });
            };
            _this_1.collectFormData = function(form) {
                if (form === undefined || form === null) {
                    return false;
                }
                var data = {};
                for (var i = 0; i < form.elements.length; i++) {
                    var field = form.elements[i];
                    data = __assign(__assign({}, data), _this_1.collectField(field));
                }
                return data;
            };
            _this_1.collectField = function(field) {
                var data = {};
                if (!field.name || field.type === "file" || field.type === "reset" || field.type === "submit" || field.type === "button") return data;
                if (field.disabled && field.tagName !== "SELECT") return data;
                if (field.type === "select-multiple") {
                    data[field.name] = [];
                    for (var n = 0; n < field.options.length; n++) {
                        if (!field.options[n].selected) continue;
                        data[field.name].push(field.options[n].value);
                    }
                } else if (field.type !== "checkbox" && field.type !== "radio") {
                    data[field.name] = field.value;
                    if (field.value.toLowerCase() === "true") {
                        data[field.name] = true;
                    } else if (field.value.toLowerCase() === "false") {
                        data[field.name] = false;
                    }
                } else if (field.type === "checkbox") {
                    data[field.name] = !!field.checked;
                }
                if (field.getAttribute("data-parse") === "true") {
                    if (field.getAttribute("data-decode") !== "false") {
                        data[field.name] = decodeURIComponent(data[field.name]);
                    }
                    data[field.name] = JSON.parse(data[field.name]);
                }
                return data;
            };
            _this_1.markValidation = function(page, inputName, isValid, invalidMessage) {
                if (invalidMessage === void 0) {
                    invalidMessage = "";
                }
                page.querySelectorAll('[data-validation-visual="'.concat(inputName, '"]')).forEach(function(validationVisual) {
                    var errorMessage = validationVisual.parentElement.querySelector(".st_message-error_JS");
                    if (isValid) {
                        validationVisual.classList.remove("st_input_invalid");
                        if (!!errorMessage) {
                            errorMessage.remove();
                        }
                    } else {
                        validationVisual.classList.add("st_input_invalid");
                        if (!errorMessage) {
                            var errorMessageBlock = document.createElement("span");
                            errorMessageBlock.className = "st_message-error st_message-error_JS";
                            validationVisual.parentElement.append(errorMessageBlock);
                            errorMessage = validationVisual.parentElement.querySelector(".st_message-error_JS");
                        }
                        errorMessage.innerHTML = invalidMessage;
                    }
                });
            };
            _this_1.markValidationResults = function(page, validationResponse) {
                if (Object.keys(validationResponse).length > 0) {
                    Object.keys(validationResponse).forEach(function(paramName) {
                        _this_1.markValidation(page, paramName, validationResponse[paramName].isValid, validationResponse[paramName].message);
                    });
                }
            };
            _this_1.numbersOnly = function() {
                var numberInputs = document.querySelectorAll(".nuv_only-number_JS");
                if (numberInputs && numberInputs.length > 0) {
                    for (var i = 0; i < numberInputs.length; i++) {
                        var inputSelector = numberInputs[i];
                        inputSelector.addEventListener("keyup", function() {
                            this.value = isNaN(parseInt(this.value)) ? "" : parseInt(this.value);
                        });
                        inputSelector.addEventListener("input", function() {
                            this.value = isNaN(parseInt(this.value)) ? "" : parseInt(this.value);
                        });
                        inputSelector.addEventListener("change", function() {
                            this.value = isNaN(parseInt(this.value)) ? "" : parseInt(this.value);
                        });
                    }
                }
            };
            _this_1.formValidation = function() {
                var _this = _this_1;
                var taxId = document.querySelector('[name="enrollment[tax_id]"]');
                if (taxId && typeof taxId != "undefined") {
                    taxId.addEventListener("input", function(e) {
                        _this.applyFormatting(this);
                    });
                }
                var email = document.querySelector('[name="enrollment[email]"]');
                if (email && typeof email != "undefined") {
                    email.addEventListener("input", function(e) {
                        _this.validateEmail(this);
                    });
                }
                var upgradeEmail = document.querySelector('[name="address[email]"]');
                if (upgradeEmail && typeof upgradeEmail != "undefined") {
                    upgradeEmail.addEventListener("input", function(e) {
                        _this.validateEmail(this);
                    });
                }
            };
            _this_1.validateDateOfBirth = function() {
                var currentYear = new Date().getFullYear();
                var dateOfBirtd = document.querySelector('[name="enrollment[date_of_birtd]"]');
                if (dateOfBirtd && typeof dateOfBirtd != "undefined") {
                    var date = new Date(dateOfBirtd.value);
                    var year = date.getFullYear();
                    return year < currentYear && year > 1900;
                } else {
                    return false;
                }
            };
            _this_1.validateEmail = function(field) {
                var valid = false;
                var val = field.value;
                var at = val.indexOf("@");
                if (at >= 2) {
                    val = val.substr(at);
                    var dot = val.indexOf(".");
                    if (dot >= 2) {
                        val = val.substr(dot);
                        if (val.length >= 2) {
                            valid = true;
                            if (field.classList.contains("st-bds_invalid_input")) {
                                field.classList.remove("st-bds_invalid_input");
                            }
                        }
                    } else {
                        if (!field.classList.contains("st-bds_invalid_input")) {
                            field.classList.add("st-bds_invalid_input");
                        }
                    }
                } else {
                    if (!field.classList.contains("st-bds_invalid_input")) {
                        field.classList.add("st-bds_invalid_input");
                    }
                }
                return valid;
            };
            _this_1.applyFormatting = function(field) {
                var val = field.value;
                var format = "";
                var formatData = {
                    separator: "-",
                    format: "XXX-XX-XXXX",
                    type: "numeric"
                };
                if (formatData.type === "numeric") {
                    val = val.replace(/[^0-9]/g, "");
                }
                if (typeof formatData.format === "object") {
                    format = formatData.format[field.name];
                } else {
                    format = formatData.format;
                    var segments = formatData.separator ? formatData.format.split(formatData.separator) : [formatData.format];
                    var disp = [];
                    for (var i = 0; i < segments.length; i++) {
                        var it_1 = val.substr(0, segments[i].length);
                        if (it_1 !== "") {
                            disp.push(it_1);
                        }
                        val = val.replace(it_1, "");
                    }
                    val = disp.join(formatData.separator);
                }
                if (format.length > val.length) {
                    field.classList.add("st-bds_invalid_input");
                } else if (format.length === val.length) {
                    field.classList.remove("st-bds_invalid_input");
                } else {
                    val = val.substr(0, format.length);
                }
                field.value = val;
            };
            _this_1.clearFormatting = function(page, inputNames) {
                var _this = _this_1;
                inputNames.forEach(function(inputName) {
                    _this.markValidation(page, inputName, true, "");
                });
            };
            _this_1.dateInput = dateInput;
            _this_1.classConfig = classConfig;
            return _this_1;
        }
        return StForm;
    }(st_module_16.StModule);
    exports.StForm = StForm;
});

define("core/shopify-app/st-modules/account/account", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_17) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccount = void 0;
    var StAccount = function(_super) {
        __extends(StAccount, _super);

        function StAccount(form) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "Account";
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {
                    _this.form.liveTrim();
                });
            };
            _this.form = form;
            return _this;
        }
        return StAccount;
    }(st_module_17.StModule);
    exports.StAccount = StAccount;
});

define("core/shopify-app/st-modules/enrollment/_general/enrollment-class-config", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_18) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentClassConfig = void 0;
    var StEnrollmentClassConfig = function(_super) {
        __extends(StEnrollmentClassConfig, _super);

        function StEnrollmentClassConfig() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentClassConfig";
            _this.classNameEnrollmentWrapper = "st_enrollment_JS";
            _this.selectorEnrollmentWrapper = "." + _this.classNameEnrollmentWrapper;
            _this.classNameEnrollmentPage = "st_enrollment--page_JS";
            _this.selectorEnrollmentPage = "." + _this.classNameEnrollmentPage;
            _this.classNameEnrollmentPageShow = "st_show";
            _this.selectorEnrollmentPageShow = "." + _this.classNameEnrollmentPageShow;
            _this.classNameEnrollmentForm = "st_enrollment-section--form_JS";
            _this.selectorEnrollmentForm = "." + _this.classNameEnrollmentForm;
            _this.classNameEnrollmentPrev = "st_enrollment--prev_JS";
            _this.selectorEnrollmentPrev = "." + _this.classNameEnrollmentPrev;
            _this.classNameEnrollmentNext = "st_enrollment--next_JS";
            _this.selectorEnrollmentNext = "." + _this.classNameEnrollmentNext;
            _this.classNameEnrollmentNavWrapper = "st_enrollment-nav--wrapper_JS";
            _this.selectorEnrollmentNavWrapper = "." + _this.classNameEnrollmentNavWrapper;
            _this.classNameEnrollmentNavHolder = "st_enrollment-nav--holder_JS";
            _this.selectorEnrollmentNavHolder = "." + _this.classNameEnrollmentNavHolder;
            _this.classNameEnrollmentNavHolderSingle = "st_enrollment-nav--holder-single_JS";
            _this.selectorEnrollmentNavHolderSingle = "." + _this.classNameEnrollmentNavHolderSingle;
            _this.classNameEnrollmentNavButton = "st_enrollment-button_JS";
            _this.selectorEnrollmentNavButton = "." + _this.classNameEnrollmentNavButton;
            _this.classNameInputInvalid = "st_input_invalid";
            _this.selectorInputInvalid = "." + _this.classNameInputInvalid;
            _this.classNameElementShow = "st_show";
            _this.selectorElementShow = "." + _this.classNameElementShow;
            _this.classNameElementHide = "st_hidden";
            _this.selectorElementHide = "." + _this.classNameElementHide;
            _this.textSubmit = "Submit";
            _this.textNext = "Next";
            _this.classNameEnrollmentPrivacyForm = "st_enrollment-section--privacy-form_JS";
            _this.selectorEnrollmentPrivacyForm = "." + _this.classNameEnrollmentPrivacyForm;
            _this.classNameEnrollmentTnCField = "st_enrollment--tnc-field_JS";
            _this.selectorEnrollmentTnCField = "." + _this.classNameEnrollmentTnCField;
            _this.classNameEnrollmentAccountDetailsForm = "st_enrollment-section--account-details-form_JS";
            _this.selectorEnrollmentAccountDetailsForm = "." + _this.classNameEnrollmentAccountDetailsForm;
            _this.classNameEnrollmentAccountDetailsPhone = "st_enrollment-section--account-details-phone_JS";
            _this.selectorEnrollmentAccountDetailsPhone = "." + _this.classNameEnrollmentAccountDetailsPhone;
            _this.classNameEnrollmentBusinessDetailsWebAlias = "st_enrollment-section--business-details-web-alias_JS";
            _this.selectorEnrollmentBusinessDetailsWebAlias = "." + _this.classNameEnrollmentBusinessDetailsWebAlias;
            _this.classNameEnrollmentBusinessDetailsWebAliasPresenter = "st_enrollment-web-alias-preview_JS";
            _this.selectorEnrollmentBusinessDetailsWebAliasPresenter = "." + _this.classNameEnrollmentBusinessDetailsWebAliasPresenter;
            _this.classNameEnrollmentBusinessDetailsSSN = "st_enrollment-section--business-details-ssn_JS";
            _this.selectorEnrollmentBusinessDetailsSSN = "." + _this.classNameEnrollmentBusinessDetailsSSN;
            _this.classEnrollmentRequiredKitVariantSelect = "st_enrollment-required-kits-select_JS";
            _this.selectorEnrollmentRequiredKitVariantSelect = "." + _this.classEnrollmentRequiredKitVariantSelect;
            _this.classEnrollmentRequiredKitVariantHeading = "st_enrollment-required-kit-variant-title_JS";
            _this.selectorEnrollmentRequiredKitVariantHeading = "." + _this.classEnrollmentRequiredKitVariantHeading;
            _this.classEnrollmentRequiredKitVariantPrice = "st_enrollment-required-kit-price_JS";
            _this.selectorEnrollmentRequiredKitVariantPrice = "." + _this.classEnrollmentRequiredKitVariantPrice;
            _this.classEnrollmentRequiredKitSelectedVariantTitle = "st_enrollment-required-kits-selected-variant-title_JS";
            _this.selectorEnrollmentRequiredKitSelectedVariantTitle = "." + _this.classEnrollmentRequiredKitSelectedVariantTitle;
            _this.classEnrollmentHiddenRequiredKitInput = "st_hidden-requiredKitInput_JS";
            _this.selectorEnrollmentHiddenRequiredKitInput = "." + _this.classEnrollmentHiddenRequiredKitInput;
            _this.classEnrollmentRequiredKitWrapper = "st_consultant-kit-order--wrapper";
            _this.selectorEnrollmentRequiredKitWrapper = "." + _this.classEnrollmentRequiredKitWrapper;
            _this.classEnrollmentRequiredKitsOptionsWrapper = "st_enrollment-required-kits-options-wrapper_JS";
            _this.selectorEnrollmentRequiredKitsOptionsWrapper = "." + _this.classEnrollmentRequiredKitsOptionsWrapper;
            _this.classEnrollmentRequiredKitsText = "st_consultant-kit-text_JS";
            _this.selectorEnrollmentRequiredKitsText = "." + _this.classEnrollmentRequiredKitsText;
            _this.classEnrollmentRequiredKitsImg = "st_enrollment-required-kit-img_JS";
            _this.selectorEnrollmentRequiredKitsImg = "." + _this.classEnrollmentRequiredKitsImg;
            _this.classNameEnrollmentOptionalKitsInput = "st_optional-kits--input_JS";
            _this.selectorEnrollmentOptionalKitsInput = "." + _this.classNameEnrollmentOptionalKitsInput;
            _this.classNameEnrollmentOptionalKitsTrigger = "st_enrollment--optional-bundle-trigger_JS";
            _this.selectorEnrollmentOptionalKitsTrigger = "." + _this.classNameEnrollmentOptionalKitsTrigger;
            _this.reviewEditText = "Edit";
            _this.classNameEnrollmentReviewWrapper = "st_enrollment--review-wrapper_JS";
            _this.selectorEnrollmentReviewWrapper = "." + _this.classNameEnrollmentReviewWrapper;
            _this.classNameEnrollmentReviewParamHolder = "st_enrollment--review-param-holder_JS";
            _this.selectorEnrollmentReviewParamHolder = "." + _this.classNameEnrollmentReviewParamHolder;
            _this.classNameEnrollmentReviewCartWrapper = "st_enrollment--review-cart-wrapper_JS";
            _this.selectorEnrollmentReviewCartWrapper = "." + _this.classNameEnrollmentReviewCartWrapper;
            _this.classNameEnrollmentReviewCartContentWrapper = "st_enrollment--review-cart-content-wrapper_JS";
            _this.selectorEnrollmentReviewCartContentWrapper = "." + _this.classNameEnrollmentReviewCartContentWrapper;
            _this.classNameEnrollmentReviewCartTotalWrapper = "st_enrollment--review-cart-total-wrapper_JS";
            _this.selectorEnrollmentReviewCartTotalWrapper = "." + _this.classNameEnrollmentReviewCartTotalWrapper;
            _this.classNameEnrollmentReviewCartTotal = "st_enrollment--review-cart-total_JS";
            _this.selectorEnrollmentReviewCartTotal = "." + _this.classNameEnrollmentReviewCartTotal;
            return _this;
        }
        return StEnrollmentClassConfig;
    }(st_module_18.StModule);
    exports.StEnrollmentClassConfig = StEnrollmentClassConfig;
});

define("core/shopify-app/st-modules/enrollment/enrollment", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_19) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollment = void 0;
    var StEnrollment = function(_super) {
        __extends(StEnrollment, _super);

        function StEnrollment(classConfig) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "Enrollment";
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {
                    _this.preventFormSubmit();
                });
            };
            _this.classConfig = classConfig;
            return _this;
        }
        StEnrollment.prototype.preventFormSubmit = function(forms) {
            forms = forms ? forms : document.querySelectorAll(this.classConfig.selectorEnrollmentForm);
            if (forms.length > 0) {
                forms.forEach(function(form) {
                    form.addEventListener("submit", function(e) {
                        e.preventDefault();
                    });
                });
            }
        };
        return StEnrollment;
    }(st_module_19.StModule);
    exports.StEnrollment = StEnrollment;
});

define("core/shopify-app/st-modules/_general-methods/form/cart-manipulation", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_20) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StCartManipulation = void 0;
    var StCartManipulation = function(_super) {
        __extends(StCartManipulation, _super);

        function StCartManipulation() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "CartManipulation";
            return _this;
        }
        return StCartManipulation;
    }(st_module_20.StModule);
    exports.StCartManipulation = StCartManipulation;
});

define("core/shopify-app/st-modules/_general-methods/form/loader", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_21) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StLoader = void 0;
    var StLoader = function(_super) {
        __extends(StLoader, _super);

        function StLoader() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "Loader";
            _this.init = function() {};
            _this.on = function(triggerBtn) {
                if (!!triggerBtn && !triggerBtn.classList.contains("st_loader-active")) {
                    triggerBtn.classList.add("st_loader-active");
                }
            };
            _this.off = function(triggerBtn) {
                if (!!triggerBtn && triggerBtn.classList.contains("st_loader-active")) {
                    triggerBtn.classList.remove("st_loader-active");
                }
            };
            return _this;
        }
        return StLoader;
    }(st_module_21.StModule);
    exports.StLoader = StLoader;
});

define("core/shopify-app/st-modules/_general-methods/button/button-actions", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_22) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StButtonActions = exports.EButtonAction = void 0;
    var EButtonAction;
    (function(EButtonAction) {
        EButtonAction["enable"] = "enable";
        EButtonAction["disable"] = "disable";
        EButtonAction["toggleState"] = "toggleState";
        EButtonAction["prevent"] = "prevent";
        EButtonAction["allow"] = "allow";
        EButtonAction["addLoader"] = "addLoader";
        EButtonAction["removeLoader"] = "removeLoader";
        EButtonAction["toggleLoader"] = "toggleLoader";
    })(EButtonAction = exports.EButtonAction || (exports.EButtonAction = {}));
    var StButtonActions = function(_super) {
        __extends(StButtonActions, _super);

        function StButtonActions() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "ButtonActions";
            _this.applyToMultiple = function(buttons, action) {
                buttons.forEach(function(button) {
                    _this[action](button);
                });
            };
            _this.enable = function(button) {
                if (!!button) {
                    button.removeAttribute("disabled");
                    button.classList.remove("st-disabled");
                } else {
                    console.error("Can't perform button action!. Button is undefined.");
                }
            };
            _this.disable = function(button) {
                if (!!button) {
                    button.setAttribute("disabled", "");
                    button.classList.add("st-disabled");
                } else {
                    console.error("Can't perform button action!. Button is undefined.");
                }
            };
            _this.addLoader = function(button) {
                if (!!button) {
                    button.classList.add("st-loading");
                } else {
                    console.error("Can't perform button action!. Button is undefined.");
                }
            };
            _this.removeLoader = function(button) {
                if (!!button) {
                    button.classList.remove("st-loading");
                } else {
                    console.error("Can't perform button action!. Button is undefined.");
                }
            };
            _this.toggleState = function(button) {
                if (!!button) {
                    if (button.classList.contains("st-disabled")) {
                        _this.enable(button);
                    } else {
                        _this.disable(button);
                    }
                } else {
                    console.error("Can't perform button action!. Button is undefined.");
                }
            };
            _this.toggleLoader = function(button) {
                if (!!button) {
                    if (button.classList.contains("st-loading")) {
                        _this.removeLoader(button);
                    } else {
                        _this.addLoader(button);
                    }
                } else {
                    console.error("Can't perform button action!. Button is undefined.");
                }
            };
            _this.prevent = function(button) {
                if (!!button) {
                    _this.disable(button);
                    _this.addLoader(button);
                    button.classList.add("st-blocked");
                } else {
                    console.error("Can't perform button action!. Button is undefined.");
                }
            };
            _this.allow = function(button) {
                if (!!button) {
                    _this.enable(button);
                    _this.removeLoader(button);
                    button.classList.remove("st-blocked");
                } else {
                    console.error("Can't perform button action!. Button is undefined.");
                }
            };
            _this.isBlocked = function(button) {
                return button.classList.contains("st-blocked");
            };
            _this.isLoading = function(button) {
                return button.classList.contains("st-loading");
            };
            _this.isDisabled = function(button) {
                return button.classList.contains("st-disabled") || button.classList.contains("st-disabled");
            };
            return _this;
        }
        return StButtonActions;
    }(st_module_22.StModule);
    exports.StButtonActions = StButtonActions;
});

define("core/shopify-app/st-modules/_general-methods/notification", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_23) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StNotification = exports.ENotificationType = void 0;
    var ENotificationType;
    (function(ENotificationType) {
        ENotificationType["success"] = "success";
        ENotificationType["error"] = "error";
        ENotificationType["info"] = "info";
    })(ENotificationType = exports.ENotificationType || (exports.ENotificationType = {}));
    var StNotification = function(_super) {
        __extends(StNotification, _super);

        function StNotification() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "Notification";
            _this.createNotification = function() {
                var element = document.createElement("div");
                element.setAttribute("class", "st_notification-wrapper");
                element.setAttribute("id", "st_notification");
                var trigger = document.createElement("button");
                trigger.setAttribute("type", "button");
                trigger.dataset.close = "notification";
                trigger.innerHTML = '<svg aria-hidden="true" focusable="false" viewBox="0 0 40 40"><path d="M23.868 20.015L39.117 4.78c1.11-1.108 1.11-2.77 0-3.877-1.109-1.108-2.773-1.108-3.882 0L19.986 16.137 4.737.904C3.628-.204 1.965-.204.856.904c-1.11 1.108-1.11 2.77 0 3.877l15.249 15.234L.855 35.248c-1.108 1.108-1.108 2.77 0 3.877.555.554 1.248.831 1.942.831s1.386-.277 1.94-.83l15.25-15.234 15.248 15.233c.555.554 1.248.831 1.941.831s1.387-.277 1.941-.83c1.11-1.109 1.11-2.77 0-3.878L23.868 20.015z" /></svg>';
                element.appendChild(trigger);
                var title = document.createElement("div");
                title.setAttribute("class", "st_notification-title");
                element.appendChild(title);
                var desc = document.createElement("div");
                desc.setAttribute("class", "st_notification-description");
                element.appendChild(desc);
                return element;
            };
            _this.assembleNotification = function(type, title, description) {
                if (title === void 0) {
                    title = "";
                }
                if (description === void 0) {
                    description = "";
                }
                var typeClass = "";
                var notification = _this.createNotification();
                if (typeof description === "string") {
                    description = [description];
                }
                switch (type) {
                    case "success":
                        typeClass = "st_success";
                        break;

                    case "error":
                        typeClass = "st_error";
                        break;

                    case "info":
                        typeClass = "st_info";
                        break;
                }
                notification.classList.add(typeClass);
                var t = notification.querySelector(".st_notification-title");
                t.innerHTML = title;
                var d = notification.querySelector(".st_notification-description");
                var message = "";
                for (var i = 0; i < description.length; i++) {
                    if (i !== 0) {
                        message += "<hr>";
                    }
                    message += description[i];
                }
                d.innerHTML = message;
                return notification;
            };
            _this.showNotification = function(type, title, description, duration, preventDisappear) {
                if (type === void 0) {
                    type = ENotificationType.error;
                }
                if (title === void 0) {
                    title = "";
                }
                if (description === void 0) {
                    description = "";
                }
                if (duration === void 0) {
                    duration = 5e3;
                }
                if (preventDisappear === void 0) {
                    preventDisappear = false;
                }
                var notif = document.getElementById("st_notification");
                if (notif !== null) {
                    notif.remove();
                }
                var notification = _this.assembleNotification(type, title, description);
                var button = notification.querySelectorAll('button[data-close="notification"]')[0];
                button.addEventListener("click", function(e) {
                    var el = this.closest(".st_notification-wrapper");
                    body.removeChild(el);
                });
                var body = document.getElementsByTagName("body")[0];
                body.appendChild(notification);
                if (!preventDisappear) {
                    clearTimeout(_this.globalShowTimeout);
                    _this.globalShowTimeout = setTimeout(function() {
                        if (notification && notification.parentNode) {
                            notification.parentNode.removeChild(notification);
                        }
                    }, duration);
                }
            };
            return _this;
        }
        return StNotification;
    }(st_module_23.StModule);
    exports.StNotification = StNotification;
});

define("core/connector-app/_shared/models/enrollment/enrollment-submit/enrollment.submit.request.model", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/shopify-app/st-modules/enrollment/page/enrollment-submit", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "core/shopify-app/st-modules/_general-methods/notification"], function(require, exports, st_module_24, notification_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentActions = void 0;
    var StEnrollmentActions = function(_super) {
        __extends(StEnrollmentActions, _super);

        function StEnrollmentActions(classConfig, notification) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "EnrollmentActions";
            _this_1.submit = function(dataToSubmit) {
                var _this = _this_1;
                console.log(dataToSubmit);
                _this_1.ajax.send({
                    endpoint: _this.endpoint["enrollment"]["submit"],
                    method: "post",
                    contentType: "json",
                    data: dataToSubmit,
                    callback: function(response) {
                        try {
                            var submitResponse = JSON.parse(response.response);
                            if (response.status === 200) {
                                if (submitResponse.data.checkoutUrl && submitResponse.data.checkoutUrl !== "") {
                                    console.log(submitResponse.data.checkoutUrl);
                                    window.location.href = submitResponse.data.checkoutUrl;
                                } else {
                                    window.location.href = window.typagehandle;
                                }
                            } else {
                                _this.notification.showNotification(notification_1.ENotificationType.error, "An Error Occurred", submitResponse.message);
                            }
                        } catch (error) {
                            console.error(error);
                            _this.notification.showNotification(notification_1.ENotificationType.error, "An Error Occurred", error);
                        }
                    }
                });
            };
            _this_1.classConfig = classConfig;
            _this_1.notification = notification;
            return _this_1;
        }
        return StEnrollmentActions;
    }(st_module_24.StModule);
    exports.StEnrollmentActions = StEnrollmentActions;
});

define("core/connector-app/_shared/models/enrollment/enrollment-validation/enrollment.validation.request.model", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/connector-app/_shared/models/enrollment/enrollment-validation/enrollment.validation.response.model", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/shopify-app/st-modules/enrollment/_general/enrollment-models", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/shopify-app/st-modules/enrollment/page/enrollment-page", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_25) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentPage = void 0;
    var StEnrollmentPage = function(_super) {
        __extends(StEnrollmentPage, _super);

        function StEnrollmentPage(classConfig, generalMethods) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentPage";
            _this.maxPage = 0;
            _this.currentIndex = 0;
            _this.setMaxPage = function(maxPage) {
                _this.maxPage = maxPage;
            };
            _this.getMaxPage = function() {
                return _this.maxPage;
            };
            _this.setCurrentIndex = function(index) {
                _this.currentIndex = index;
            };
            _this.getCurrentIndex = function() {
                return _this.currentIndex;
            };
            _this.getCurrentPage = function() {
                return _this.getPageByIndex(_this.currentIndex);
            };
            _this.setupPageIndex = function(pages) {
                pages.forEach(function(page, ind) {
                    page.setAttribute("data-page-index", "" + ind);
                });
            };
            _this.getPageByIndex = function(pageIndex) {
                var wrp = document.querySelector(_this.classConfig.selectorEnrollmentWrapper);
                var pages = wrp.querySelectorAll(_this.classConfig.selectorEnrollmentPage);
                return pages[pageIndex];
            };
            _this.openPage = function(pageIndex) {
                if (pageIndex === void 0) {
                    pageIndex = 0;
                }
                var wrp = document.querySelector(_this.classConfig.selectorEnrollmentWrapper);
                var alreadyOpen = wrp.querySelector(_this.classConfig.selectorEnrollmentPage + _this.classConfig.selectorEnrollmentPageShow);
                var enrollmentPages = wrp.querySelectorAll(_this.classConfig.selectorEnrollmentPage);
                var navHolder = wrp.querySelector(_this.classConfig.selectorEnrollmentNavHolder);
                var enrollmentNavElements = navHolder.querySelectorAll(_this.classConfig.selectorEnrollmentNavHolderSingle);
                var prevButtons = wrp.querySelectorAll(_this.classConfig.selectorEnrollmentPrev);
                if (!!alreadyOpen) {
                    alreadyOpen.classList.remove(_this.classConfig.classNameElementShow);
                }
                if (enrollmentPages.length > 0) {
                    enrollmentPages[pageIndex].classList.add(_this.classConfig.classNameElementShow);
                } else {
                    console.error("Invalid page index supplied to enrollment openPage method!");
                }
                enrollmentNavElements.forEach(function(navElement, index) {
                    navElement.classList.remove("active");
                    navElement.classList.remove("current");
                    if (index < pageIndex) {
                        navElement.classList.add("active");
                    } else if (index === pageIndex) {
                        navElement.classList.add("current");
                    }
                });
                _this.setCurrentIndex(pageIndex);
                _this.changeButtonText();
                _this.prevButtonVisibility(prevButtons, pageIndex);
                _this.generalMethods.scrollTo(_this.getCurrentPage(), 500);
            };
            _this.changeButtonText = function() {
                var wrp = document.querySelector(_this.classConfig.selectorEnrollmentWrapper);
                var selectorEnrollmentNext = wrp.querySelector(_this.classConfig.selectorEnrollmentNext);
                selectorEnrollmentNext.querySelector("span").innerHTML = _this.currentIndex === _this.maxPage - 1 ? _this.classConfig.textSubmit : _this.classConfig.textNext;
            };
            _this.prevButtonVisibility = function(prevButtons, pageIndex) {
                if (pageIndex === 0) {
                    prevButtons.forEach(function(button) {
                        button.classList.add("st_hidden");
                    });
                } else {
                    prevButtons.forEach(function(button) {
                        button.classList.remove("st_hidden");
                    });
                }
            };
            _this.classConfig = classConfig;
            _this.generalMethods = generalMethods;
            return _this;
        }
        return StEnrollmentPage;
    }(st_module_25.StModule);
    exports.StEnrollmentPage = StEnrollmentPage;
});

define("core/shopify-app/st-modules/enrollment/_validation/enrollment-validation", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "core/shopify-app/st-modules/_general-methods/notification"], function(require, exports, st_module_26, notification_2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentValidation = void 0;
    var StEnrollmentValidation = function(_super) {
        __extends(StEnrollmentValidation, _super);

        function StEnrollmentValidation(classConfig, notification, enrollmentPage) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "EnrollmentValidate";
            _this_1.validationMethods = {};
            _this_1.setupValidation = function(validationClasses) {
                validationClasses.forEach(function(validationClass) {
                    var methods = validationClass.setupValidationMethods();
                    if (!!methods) {
                        _this_1.validationMethods = __assign(__assign({}, _this_1.validationMethods), methods);
                    }
                });
            };
            _this_1.getValidation = function() {
                return __assign({}, _this_1.validationMethods);
            };
            _this_1.markInvalid = function(page, inputName) {
                page.querySelectorAll('[data-validation-visual="'.concat(inputName, '"]')).forEach(function(validationVisual) {
                    validationVisual.classList.add(_this_1.classConfig.classNameInputInvalid);
                });
            };
            _this_1.clearInvalid = function(page, specificElement) {
                if (!!specificElement) {
                    specificElement.classList.remove(_this_1.classConfig.classNameInputInvalid);
                } else {
                    page.querySelectorAll(_this_1.classConfig.selectorInputInvalid).forEach(function(element) {
                        element.classList.remove(_this_1.classConfig.classNameInputInvalid);
                    });
                }
            };
            _this_1.serverValidate = function(dataToValidate, validCB, invalidCB) {
                if (validCB === void 0) {
                    validCB = function() {};
                }
                if (invalidCB === void 0) {
                    invalidCB = function() {};
                }
                var _this = _this_1;
                _this_1.ajax.send({
                    endpoint: _this.endpoint["enrollment"]["validate-data"],
                    method: "post",
                    contentType: "json",
                    data: dataToValidate,
                    callback: function(request) {
                        try {
                            var data = JSON.parse(request.response);
                            if (request.status === 200) {
                                validCB(request, data);
                            } else {
                                invalidCB({
                                    status: request.status,
                                    message: data.message
                                });
                                _this.notification.showNotification(notification_2.ENotificationType.error, "Validation Error", data.message);
                            }
                        } catch (error) {
                            invalidCB({
                                status: 500,
                                message: error.message
                            });
                            console.error(error);
                            _this.notification.showNotification(notification_2.ENotificationType.error, "Validation Error", error);
                        }
                    }
                });
            };
            _this_1.basicValidate = function(pageIndex) {
                var page, forms;
                if (typeof pageIndex !== "undefined" && pageIndex !== -1) {
                    page = _this_1.enrollmentPage.getPageByIndex(pageIndex);
                    forms = page.querySelectorAll(_this_1.classConfig.selectorEnrollmentForm);
                } else {
                    var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                    forms = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentForm);
                }
                for (var i = 0; i < forms.length; i++) {
                    var form = forms[i];
                    var sectionName = form.getAttribute("data-name");
                    var validation = _this_1.getValidation();
                    if (validation[sectionName]) {
                        var basicValidationParams = validation[sectionName].basic();
                        for (var j = 0; j < basicValidationParams.length; j++) {
                            var validationParam = basicValidationParams[j];
                            var input = form.querySelector('[name="'.concat(validationParam, '"]'));
                            if (!!input) {
                                if (typeof input.value === "undefined" || input.value === "") {
                                    return false;
                                }
                            } else {
                                console.warn('Input with name: "'.concat(validationParam, "\" was added to basic validation but doesn't exist in DOM. Skipping this field for validation."));
                            }
                        }
                    }
                }
                return true;
            };
            _this_1.basicValidationDelay = 200;
            _this_1.setupBasicValidationEvents = function(inputSelector, afterValidation) {
                var _this = _this_1;
                afterValidation(_this.runBasicValidation());
                var eventListenerFn = function() {
                    clearTimeout(_this.basicValidationTimeout);
                    _this.basicValidationTimeout = setTimeout(function() {
                        afterValidation(_this.runBasicValidation());
                    }, _this.basicValidationDelay);
                };
                inputSelector.addEventListener("input", eventListenerFn);
                inputSelector.addEventListener("change", eventListenerFn);
                inputSelector.addEventListener("paste", eventListenerFn);
            };
            _this_1.runBasicValidation = function() {
                var pageIndex = _this_1.enrollmentPage.getCurrentIndex();
                return _this_1.basicValidate(pageIndex);
            };
            _this_1.classConfig = classConfig;
            _this_1.notification = notification;
            _this_1.enrollmentPage = enrollmentPage;
            return _this_1;
        }
        return StEnrollmentValidation;
    }(st_module_26.StModule);
    exports.StEnrollmentValidation = StEnrollmentValidation;
});

define("core/shopify-app/st-modules/enrollment/_validation/enrollment-section-validation-base", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_27) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentSectionBase = void 0;
    var StEnrollmentSectionBase = function(_super) {
        __extends(StEnrollmentSectionBase, _super);

        function StEnrollmentSectionBase(args) {
            var _this = _super.call(this, args) || this;
            _this.setupValidationMethods = function() {
                var methods = {};
                methods[_this.validationName] = {
                    site: _this.validateOnSite,
                    server: _this.validateOnServer,
                    basic: _this.addToBasicValidation
                };
                return methods;
            };
            _this.addToBasicValidation = function() {
                return [];
            };
            _this.validateOnServer = function() {
                return [];
            };
            _this.validateOnSite = function() {
                return [];
            };
            return _this;
        }
        StEnrollmentSectionBase.prototype.initFields = function() {};
        StEnrollmentSectionBase.prototype.selectFields = function() {
            return [];
        };
        return StEnrollmentSectionBase;
    }(st_module_27.StModule);
    exports.StEnrollmentSectionBase = StEnrollmentSectionBase;
});

define("core/shopify-app/st-modules/enrollment/blocks/review-privacy/enrollment-section-review-privacy", ["require", "exports", "core/shopify-app/st-modules/enrollment/_validation/enrollment-section-validation-base"], function(require, exports, enrollment_section_validation_base_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentSectionPrivacy = void 0;
    var StEnrollmentSectionPrivacy = function(_super) {
        __extends(StEnrollmentSectionPrivacy, _super);

        function StEnrollmentSectionPrivacy(classConfig) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentSectionPrivacy";
            _this.validationName = "privacy";
            _this.validateOnSite = function() {
                var wrp = document.querySelector(_this.classConfig.selectorEnrollmentWrapper);
                var output = [];
                if (!!wrp) {
                    var inputs = wrp.querySelectorAll(_this.classConfig.selectorEnrollmentTnCField);
                    inputs.forEach(function(input) {
                        var fieldName = input.getAttribute("name");
                        var customMessage = input.getAttribute("data-message");
                        console.log("custom message ", customMessage, input);
                        var isChecked = input.checked === true;
                        var isRequired = !!input.getAttribute("required");
                        var isValid = isChecked && isRequired || !isRequired;
                        output[fieldName] = {
                            isValid: isValid,
                            message: !isValid ? customMessage : ""
                        };
                    });
                }
                return output;
            };
            _this.classConfig = classConfig;
            return _this;
        }
        return StEnrollmentSectionPrivacy;
    }(enrollment_section_validation_base_1.StEnrollmentSectionBase);
    exports.StEnrollmentSectionPrivacy = StEnrollmentSectionPrivacy;
});

define("core/shopify-app/st-modules/enrollment/blocks/account-details/enrollment-section-account-details", ["require", "exports", "core/shopify-app/st-modules/enrollment/_validation/enrollment-section-validation-base"], function(require, exports, enrollment_section_validation_base_2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentSectionAccountDetails = void 0;
    var StEnrollmentSectionAccountDetails = function(_super) {
        __extends(StEnrollmentSectionAccountDetails, _super);

        function StEnrollmentSectionAccountDetails() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentAccountDetails";
            _this.validationName = "account-details";
            _this.addToBasicValidation = function() {
                return ["firstName", "lastName", "phoneNumber", "dateOfBirth"];
            };
            _this.validateOnServer = function() {
                return ["firstName", "lastName", "phoneNumber", "dateOfBirth"];
            };
            return _this;
        }
        return StEnrollmentSectionAccountDetails;
    }(enrollment_section_validation_base_2.StEnrollmentSectionBase);
    exports.StEnrollmentSectionAccountDetails = StEnrollmentSectionAccountDetails;
});

define("core/shopify-app/st-modules/enrollment/blocks/business-info/enrollment-section-business-details", ["require", "exports", "core/shopify-app/st-modules/enrollment/_validation/enrollment-section-validation-base"], function(require, exports, enrollment_section_validation_base_3) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentSectionBusinessDetails = void 0;
    var StEnrollmentSectionBusinessDetails = function(_super) {
        __extends(StEnrollmentSectionBusinessDetails, _super);

        function StEnrollmentSectionBusinessDetails() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentBusinessDetails";
            _this.validationName = "business-details";
            _this.addToBasicValidation = function() {
                return ["SSN", "webAlias"];
            };
            _this.validateOnServer = function() {
                return ["SSN", "webAlias"];
            };
            return _this;
        }
        return StEnrollmentSectionBusinessDetails;
    }(enrollment_section_validation_base_3.StEnrollmentSectionBase);
    exports.StEnrollmentSectionBusinessDetails = StEnrollmentSectionBusinessDetails;
});

define("core/shopify-app/st-modules/enrollment/_validation/enrollment-validation-setup", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_28) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentValidationSetup = void 0;
    var StEnrollmentValidationSetup = function(_super) {
        __extends(StEnrollmentValidationSetup, _super);

        function StEnrollmentValidationSetup(enrollmentValidation, sectionPrivacy, sectionAccountDetails, sectionBusinessDetails) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentValidationSetup";
            _this.setupValidation = function() {
                _this.enrollmentValidation.setupValidation([_this.sectionPrivacy, _this.sectionAccountDetails, _this.sectionBusinessDetails]);
            };
            _this.enrollmentValidation = enrollmentValidation;
            _this.sectionPrivacy = sectionPrivacy;
            _this.sectionAccountDetails = sectionAccountDetails;
            _this.sectionBusinessDetails = sectionBusinessDetails;
            return _this;
        }
        return StEnrollmentValidationSetup;
    }(st_module_28.StModule);
    exports.StEnrollmentValidationSetup = StEnrollmentValidationSetup;
});

define("core/shopify-app/st-modules/enrollment/_general/enrollment-store", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_29) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentStore = void 0;
    var StEnrollmentStore = function(_super) {
        __extends(StEnrollmentStore, _super);

        function StEnrollmentStore(classConfig, cartHandler) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentStore";
            _this.dataStore = {
                shopifyId: undefined
            };
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {
                    var wrp = document.querySelector(_this.classConfig.selectorEnrollmentWrapper);
                    var shopifyIdHolder = wrp.querySelector('[name="shopifyId"]');
                    var shopifyId = parseInt(shopifyIdHolder.value);
                    _this.saveData({
                        shopifyId: shopifyId
                    });
                });
            };
            _this.saveData = function(dataToSave) {
                _this.dataStore = __assign(__assign({}, _this.dataStore), dataToSave);
                console.log("store", _this.dataStore);
                _this.updateCart({
                    attributes: __assign({}, _this.dataStore)
                }, function(cart) {
                    console.log(cart);
                });
            };
            _this.loadData = function() {
                return __assign({}, _this.dataStore);
            };
            _this.updateCart = function(params, callback) {
                _this.ajax.send({
                    endpoint: _this.cartHandler.shopifyCartApiEndpoints["update-cart"],
                    method: "POST",
                    contentType: "json",
                    data: params,
                    callback: function(request) {
                        callback(JSON.parse(request.response));
                    }
                });
            };
            _this.classConfig = classConfig;
            _this.cartHandler = cartHandler;
            return _this;
        }
        return StEnrollmentStore;
    }(st_module_29.StModule);
    exports.StEnrollmentStore = StEnrollmentStore;
});

define("core/shopify-app/st-modules/_general-methods/currency", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_30) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StCurrency = exports.EAmountType = exports.ECurrencyFormatType = void 0;
    var ECurrencyFormatType;
    (function(ECurrencyFormatType) {
        ECurrencyFormatType["withCurrency"] = "withCurrency";
        ECurrencyFormatType["withoutCurrency"] = "withoutCurrency";
    })(ECurrencyFormatType = exports.ECurrencyFormatType || (exports.ECurrencyFormatType = {}));
    var EAmountType;
    (function(EAmountType) {
        EAmountType["amount"] = "amount";
        EAmountType["amount_no_decimals"] = "amount_no_decimals";
        EAmountType["unknown"] = "unknown";
    })(EAmountType = exports.EAmountType || (exports.EAmountType = {}));
    var StCurrency = function(_super) {
        __extends(StCurrency, _super);

        function StCurrency() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "Currency";
            _this.currencyFormat = window.stCurrencyFormat;
            _this.applyFormat = function(amount, formatType) {
                if (formatType === void 0) {
                    formatType = ECurrencyFormatType.withCurrency;
                }
                var format = _this.currencyFormat[formatType];
                var amountType = _this.determineAmountType(format);
                if (amountType !== EAmountType.unknown) {
                    return format.replace("{{" + amountType + "}}", "" + amount.toFixed(2));
                } else {
                    console.error("Unrecognized price format. Returning price without currency formatting.");
                    return "" + amount;
                }
            };
            _this.determineAmountType = function(format) {
                if (format.indexOf("{{amount}}") > -1) {
                    return EAmountType.amount;
                } else if (format.indexOf("{{amount_no_decimals}}") > -1) {
                    return EAmountType.amount_no_decimals;
                } else {
                    return EAmountType.unknown;
                }
            };
            return _this;
        }
        StCurrency.prototype.commaFormattedPrice = function(amount, decimalDelimiter, thousandsDelimiter) {
            if (decimalDelimiter === void 0) {
                decimalDelimiter = ".";
            }
            if (thousandsDelimiter === void 0) {
                thousandsDelimiter = ",";
            }
            var amountComponents = String(amount).split(".", 2);
            var wholeNumber = parseInt(amountComponents[0]);
            if (isNaN(wholeNumber)) {
                return "";
            }
            var decimal = amountComponents[1];
            var minus = wholeNumber < 0 ? "-" : "";
            wholeNumber = Math.abs(wholeNumber);
            var wholeString = String(wholeNumber);
            var amountSegmented = [];
            while (wholeString.length > 3) {
                amountSegmented.unshift(wholeString.substr(wholeString.length - 3));
                wholeString = wholeString.substr(0, wholeString.length - 3);
            }
            if (wholeString.length > 0) {
                amountSegmented.unshift(wholeString);
            }
            wholeString = amountSegmented.join(thousandsDelimiter);
            decimal = decimal.length < 1 ? "" : decimalDelimiter + decimal;
            return minus + wholeString + decimal;
        };
        return StCurrency;
    }(st_module_30.StModule);
    exports.StCurrency = StCurrency;
});

define("core/shopify-app/st-modules/enrollment/blocks/review-info/enrollment-review-cart", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "core/shopify-app/st-modules/_general-methods/currency"], function(require, exports, st_module_31, currency_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentReviewCart = void 0;
    var StEnrollmentReviewCart = function(_super) {
        __extends(StEnrollmentReviewCart, _super);

        function StEnrollmentReviewCart(classConfig, store, currency) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentReviewCart";
            _this.injectCart = function() {
                var wrp = document.querySelector(_this.classConfig.selectorEnrollmentWrapper);
                var cartContent = wrp.querySelector(_this.classConfig.selectorEnrollmentReviewCartContentWrapper);
                var cartWrapper = wrp.querySelector(_this.classConfig.selectorEnrollmentReviewCartWrapper);
                var storeData = _this.store.loadData();
                var reqKits = storeData.requiredKits ? storeData.requiredKits : [];
                var optKits = storeData.optionalKits ? storeData.optionalKits : [];
                var selectedProducts = __spreadArray(__spreadArray([], reqKits, true), optKits, true);
                if (selectedProducts.length > 0) {
                    !!cartWrapper && cartWrapper.classList.remove("st_hidden");
                    !!cartContent && cartContent.classList.remove("st_hidden");
                    !!cartContent && cartContent.replaceChildren();
                    var productPrices_1 = [];
                    selectedProducts.forEach(function(selectedProduct) {
                        var imageEl = wrp.querySelector('[data-image-holder="'.concat(selectedProduct.variantId, '"]'));
                        var titleEl = wrp.querySelector('[data-title-holder="'.concat(selectedProduct.variantId, '"]'));
                        var descriptionEl = wrp.querySelector('[data-description-holder="'.concat(selectedProduct.variantId, '"]'));
                        var priceEl = wrp.querySelector('[data-price-holder="'.concat(selectedProduct.variantId, '"]'));
                        var recurringEl = wrp.querySelector('[data-recurring-holder="'.concat(selectedProduct.variantId, '"]'));
                        var sellingPlanEl = wrp.querySelector('[data-selling-plan-holder="'.concat(selectedProduct.variantId, '"]'));
                        var imageURL = !!imageEl ? imageEl.src : "";
                        var title = !!titleEl ? titleEl.innerHTML : "";
                        var description = !!descriptionEl ? descriptionEl.innerHTML : "";
                        var price = !!priceEl ? priceEl.innerHTML : "";
                        var priceRaw = !!priceEl ? parseInt(priceEl.getAttribute("data-price-raw")) : 0;
                        var recurring = !!recurringEl ? recurringEl.value === "true" : false;
                        var sellingPlan = !!sellingPlanEl ? sellingPlanEl.value : "One Time Payment";
                        var printableReviewProduct = {
                            variantId: selectedProduct.variantId,
                            image: imageURL,
                            title: title,
                            description: description,
                            price: price,
                            recurring: recurring,
                            sellingPlan: sellingPlan
                        };
                        productPrices_1.push(priceRaw);
                        if (!!cartContent) {
                            var cartMember = _this.generateCartMember(printableReviewProduct);
                            cartContent.appendChild(cartMember);
                        }
                    });
                    var cartTotalEl = wrp.querySelector(_this.classConfig.selectorEnrollmentReviewCartTotal);
                    if (!!cartTotalEl) {
                        var total = productPrices_1.reduce(function(accumulator, value) {
                            return accumulator + parseInt("".concat(value));
                        });
                        cartTotalEl.innerHTML = _this.currency.applyFormat(total / 100, currency_1.ECurrencyFormatType.withCurrency);
                    }
                } else {
                    !!cartWrapper && cartWrapper.classList.add("st_hidden");
                    !!cartContent && cartContent.classList.add("st_hidden");
                }
            };
            _this.generateCartMembers = function(products) {
                var output = [];
                products.forEach(function(productInfo) {
                    var cartMember = _this.generateCartMember(productInfo);
                    output.push(cartMember);
                });
                return output;
            };
            _this.generateCartMember = function(productInfo) {
                var wrap = document.createElement("div");
                wrap.classList.add("st_enrollment-checkout-row");
                wrap.classList.add("st_flex");
                wrap.classList.add("st_align");
                var imageWrap = document.createElement("div");
                imageWrap.classList.add("st_enrollment-image--wrapper");
                var image = document.createElement("img");
                image.src = productInfo.image;
                image.alt = productInfo.title;
                var listWrapper = document.createElement("div");
                listWrapper.classList.add("st_enrollment-list--wrapper");
                var title = document.createElement("div");
                title.classList.add("st_title");
                title.innerHTML = productInfo.title;
                var description = document.createElement("div");
                description.innerHTML = productInfo.description;
                var priceWrapper = document.createElement("div");
                priceWrapper.classList.add("st_enrollment-price--wrapper");
                var recurring = document.createElement("div");
                recurring.classList.add("st_subscription");
                recurring.classList.add("st_subscription-review");
                recurring.innerText = productInfo.sellingPlan;
                var price = document.createElement("div");
                price.classList.add("st_price");
                price.innerHTML = productInfo.price;
                imageWrap.appendChild(image);
                listWrapper.appendChild(title);
                listWrapper.appendChild(description);
                priceWrapper.appendChild(recurring);
                priceWrapper.appendChild(price);
                wrap.appendChild(imageWrap);
                wrap.appendChild(listWrapper);
                wrap.appendChild(priceWrapper);
                return wrap;
            };
            _this.classConfig = classConfig;
            _this.store = store;
            _this.currency = currency;
            return _this;
        }
        return StEnrollmentReviewCart;
    }(st_module_31.StModule);
    exports.StEnrollmentReviewCart = StEnrollmentReviewCart;
});

define("core/shopify-app/st-modules/enrollment/blocks/optional-kits/enrollment-section-optional-kits", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_32) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentOptionalKits = void 0;
    var StEnrollmentOptionalKits = function(_super) {
        __extends(StEnrollmentOptionalKits, _super);

        function StEnrollmentOptionalKits(classConfig, store, reviewCart) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "EnrollmentOptionalBundle";
            _this_1.setupButtons = function(buttons) {
                var _this = _this_1;
                buttons.forEach(function(button) {
                    button.addEventListener("click", function(e) {
                        e.preventDefault();
                        var variantId = this.getAttribute("data-variant-id");
                        var quantity = parseInt(this.getAttribute("data-quantity"));
                        var sellingPlan = this.getAttribute("data-selling-plan");
                        var selected = this.getAttribute("data-selected") === "true";
                        selected = !selected;
                        var bundleObject = {
                            variantId: "" + variantId,
                            quantity: quantity
                        };
                        if (sellingPlan && sellingPlan !== "") {
                            bundleObject.selling_plan = sellingPlan;
                        }
                        var span = this.querySelector(".st_text");
                        var icon = this.querySelector(".st_check-icon");
                        if (selected) {
                            icon.classList.remove("st_hidden");
                            span.classList.add("st_hidden");
                        } else {
                            icon.classList.add("st_hidden");
                            span.classList.remove("st_hidden");
                        }
                        _this.toggleBundleSelect(selected, bundleObject);
                        this.setAttribute("data-selected", selected);
                    });
                });
            };
            _this_1.toggleBundleSelect = function(makeSelected, bundleObject) {
                try {
                    var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                    var optionalBundlesInput = wrp.querySelector(_this_1.classConfig.selectorEnrollmentOptionalKitsInput);
                    var selectedBundles = JSON.parse(optionalBundlesInput.value);
                    if (makeSelected) {
                        var itemAlreadySelected = false;
                        for (var i = 0; i < selectedBundles.length; i++) {
                            if ("" + selectedBundles[i].variantId === "" + bundleObject.variantId) {
                                itemAlreadySelected = true;
                                break;
                            }
                        }
                        if (!itemAlreadySelected) {
                            selectedBundles.push(bundleObject);
                        }
                    } else {
                        var formattedBundles = [];
                        for (var i = 0; i < selectedBundles.length; i++) {
                            if ("" + selectedBundles[i].variantId !== "" + bundleObject.variantId) {
                                formattedBundles.push(selectedBundles[i]);
                            }
                        }
                        selectedBundles = formattedBundles;
                    }
                    optionalBundlesInput.value = JSON.stringify(selectedBundles);
                    optionalBundlesInput.setAttribute("value", optionalBundlesInput.value);
                    _this_1.store.saveData({
                        optionalKits: selectedBundles
                    });
                    _this_1.reviewCart.injectCart();
                } catch (e) {
                    console.error("An error occurred while processing toggleBundleSelect. Error message: " + e.message);
                }
            };
            _this_1.classConfig = classConfig;
            _this_1.store = store;
            _this_1.reviewCart = reviewCart;
            return _this_1;
        }
        return StEnrollmentOptionalKits;
    }(st_module_32.StModule);
    exports.StEnrollmentOptionalKits = StEnrollmentOptionalKits;
});

define("core/shopify-app/st-modules/enrollment/blocks/required-kits/enrollment-section-required-kits", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_33) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentRequiredKits = void 0;
    var StEnrollmentRequiredKits = function(_super) {
        __extends(StEnrollmentRequiredKits, _super);

        function StEnrollmentRequiredKits(classConfig, store, reviewCart) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "EnrollmentRequiredBundle";
            _this_1.init = function() {
                var _this = _this_1;
                _this_1.subscribeDOMLoaded(function() {
                    _this.store.saveData({
                        requiredKits: _this.getRequiredKits()
                    });
                    _this_1.reviewCart.injectCart();
                    _this_1.onRequiredKitVariantSelect();
                });
            };
            _this_1.getRequiredKits = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var requiredKitsHolder = wrp.querySelector('[name="requiredKits"]');
                return requiredKitsHolder ? JSON.parse(decodeURIComponent(requiredKitsHolder.value)) : [];
            };
            _this_1.format = function(sourceData) {
                var formattedData = [];
                sourceData.forEach(function(item) {
                    if (typeof item.variantId !== "undefined") {
                        var formattedItem = {
                            variantId: item.variantId.toString(),
                            quantity: item.quantity
                        };
                        if (item.selling_plan && item.selling_plan !== "") {
                            formattedItem.selling_plan = item.selling_plan + "";
                        }
                        formattedData.push(formattedItem);
                    }
                });
                return formattedData;
            };
            _this_1.onRequiredKitVariantSelect = function() {
                var _this = _this_1;
                var requiredKitWrapperList = document.querySelectorAll(_this_1.classConfig.selectorEnrollmentRequiredKitWrapper);
                if (!!requiredKitWrapperList) {
                    requiredKitWrapperList.forEach(function(requiredKitWrapper) {
                        var variantSelect = requiredKitWrapper.querySelector(_this_1.classConfig.selectorEnrollmentRequiredKitVariantSelect);
                        if (!!variantSelect) {
                            variantSelect.onchange = function() {
                                var variantValue = JSON.parse(decodeURI(variantSelect.value));
                                var optionValue = [];
                                optionValue.push(variantValue);
                                var variantHiddenWrapper = document.querySelector(_this.classConfig.selectorEnrollmentRequiredKitsOptionsWrapper);
                                var requiredKitDescription = document.querySelector(_this.classConfig.selectorEnrollmentRequiredKitsText);
                                var requiredKitImg = requiredKitWrapper.querySelector(_this.classConfig.selectorEnrollmentRequiredKitsImg);
                                var variantTitleHeading = document.querySelector(_this.classConfig.selectorEnrollmentRequiredKitVariantHeading);
                                var variantTitle = requiredKitWrapper.querySelector(_this.classConfig.selectorEnrollmentRequiredKitSelectedVariantTitle);
                                var variantTitleHidden = variantHiddenWrapper.querySelector('input[data-title-holder="'.concat(variantValue.variantId, '"]'));
                                var variantPrice = requiredKitWrapper.querySelector(_this.classConfig.selectorEnrollmentRequiredKitVariantPrice);
                                var variantPriceHidden = variantHiddenWrapper.querySelector('input[data-price-holder="'.concat(variantValue.variantId, '"]'));
                                var variantPriceRawHidden = variantHiddenWrapper.querySelector('input[data-price-raw-holder="'.concat(variantValue.variantId, '"]'));
                                var hiddenVariantInput = document.querySelector(_this.classConfig.selectorEnrollmentHiddenRequiredKitInput);
                                if (!!requiredKitDescription) {
                                    requiredKitDescription.setAttribute("data-description-holder", variantValue.variantId);
                                }
                                if (!!requiredKitImg) {
                                    requiredKitImg.setAttribute("data-image-holder", variantValue.variantId);
                                }
                                if (!!variantTitleHeading) {
                                    variantTitleHeading.innerHTML = variantTitleHidden.value;
                                    variantTitleHeading.setAttribute("data-title-holder", variantValue.variantId);
                                }
                                if (!!variantTitle) {
                                    variantTitle.innerHTML = variantTitleHidden.value;
                                }
                                if (!!variantPrice) {
                                    variantPrice.innerHTML = variantPriceHidden.value;
                                    variantPrice.setAttribute("data-price-holder", variantValue.variantId);
                                    variantPrice.setAttribute("data-price-raw", variantPriceRawHidden.value);
                                }
                                if (!!hiddenVariantInput) {
                                    delete optionValue[optionValue.length - 1].price;
                                    hiddenVariantInput.value = encodeURI(JSON.stringify(optionValue));
                                    hiddenVariantInput.setAttribute("value", JSON.stringify(optionValue));
                                    _this.store.saveData({
                                        requiredKits: optionValue
                                    });
                                    _this_1.reviewCart.injectCart();
                                }
                            };
                        }
                    });
                }
            };
            _this_1.classConfig = classConfig;
            _this_1.store = store;
            _this_1.reviewCart = reviewCart;
            return _this_1;
        }
        return StEnrollmentRequiredKits;
    }(st_module_33.StModule);
    exports.StEnrollmentRequiredKits = StEnrollmentRequiredKits;
});

define("core/shopify-app/st-modules/enrollment/blocks/review-info/enrollment-review", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_34) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentReview = void 0;
    var EFormatType;
    (function(EFormatType) {
        EFormatType["date"] = "date";
    })(EFormatType || (EFormatType = {}));
    var StEnrollmentReview = function(_super) {
        __extends(StEnrollmentReview, _super);

        function StEnrollmentReview(classConfig, store, generalMethods, enrollmentPage, currency, form, reviewCart) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "EnrollmentReview";
            _this_1.setupReview = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                if (_this_1.reviewBlockExists(wrp)) {
                    var holder = wrp.querySelector(_this_1.classConfig.selectorEnrollmentReviewParamHolder);
                    if (!!holder) {
                        _this_1.generateReviewParams(holder, _this_1.getParamInfo());
                    }
                    var paramSources = wrp.querySelectorAll("[data-review-param]");
                    _this_1.setupParamChangeEvents(paramSources);
                }
            };
            _this_1.reviewBlockExists = function(wrp) {
                var reviewSection = wrp.querySelector(_this_1.classConfig.selectorEnrollmentReviewWrapper);
                return !!reviewSection;
            };
            _this_1.getParamInfo = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var paramHolders = wrp.querySelectorAll("[data-review-param]");
                var params = [];
                var storedData = _this_1.store.loadData();
                paramHolders.forEach(function(paramHolder) {
                    var pageWrapper = _this_1.generalMethods.getClosestByClass(paramHolder, _this_1.classConfig.classNameEnrollmentPage);
                    var pageIndex = parseInt(pageWrapper.getAttribute("data-page-index"));
                    var inputName = paramHolder.getAttribute("name");
                    var formatName = paramHolder.getAttribute("data-format");
                    var param = {
                        name: paramHolder.getAttribute("data-review-param"),
                        inputName: inputName,
                        value: storedData[inputName] ? storedData[inputName] : "",
                        allowEdit: paramHolder.getAttribute("data-review-edit") !== "false",
                        pageIndex: pageIndex,
                        format: _this_1.getFormatByName(EFormatType[formatName])
                    };
                    params.push(param);
                });
                return params;
            };
            _this_1.getFormatByName = function(name) {
                if (name === EFormatType.date) {
                    return function(value) {
                        if (value && value !== "-") {
                            var dateComponents = value.split("-");
                            var days = dateComponents[2];
                            days = days.length === 1 ? "0".concat(days) : "".concat(days);
                            var months = dateComponents[1];
                            months = months.length === 1 ? "0".concat(months) : "".concat(months);
                            var years = dateComponents[0];
                            return "".concat(months, "/").concat(days, "/").concat(years);
                        } else {
                            return "";
                        }
                    };
                } else {
                    return function(value) {
                        return value;
                    };
                }
            };
            _this_1.generateReviewParams = function(holder, params) {
                var _this = _this_1;
                params.forEach(function(param, ind) {
                    var row = document.createElement("div");
                    row.classList.add("st_enrollment-business-info-row");
                    var col = document.createElement("div");
                    col.classList.add("st_info-column");
                    var colL = document.createElement("div");
                    colL.classList.add("st_col-left");
                    var colName = document.createElement("div");
                    colName.classList.add("st_name");
                    colName.innerText = param.name;
                    colL.appendChild(colName);
                    var value = typeof param.value !== "undefined" && param.value !== "" ? "" + param.value : "-";
                    var colValue = document.createElement("div");
                    colValue.classList.add("st_print-name");
                    if (param.inputName == "email") colValue.classList.add("st_email");
                    colValue.setAttribute("data-field-for", param.inputName);
                    colValue.innerText = param.format(value);
                    colL.appendChild(colValue);
                    col.appendChild(colL);
                    var colR = document.createElement("div");
                    colR.classList.add("st_col-right");
                    if (param.allowEdit) {
                        var editButton = document.createElement("button");
                        editButton.setAttribute("type", "button");
                        editButton.classList.add("st_enrollment-edit");
                        editButton.setAttribute("data-page-index", "" + param.pageIndex);
                        editButton.setAttribute("data-edit-for", param.inputName);
                        editButton.innerText = _this_1.classConfig.reviewEditText;
                        colR.appendChild(editButton);
                        editButton.addEventListener("click", function(e) {
                            e.preventDefault();
                            _this.edit(this.getAttribute("data-edit-for"), parseInt(this.getAttribute("data-page-index")));
                        });
                    }
                    col.appendChild(colR);
                    row.appendChild(col);
                    holder.appendChild(row);
                });
            };
            _this_1.setupParamChangeEvents = function(paramSources) {
                var _this = _this_1;
                paramSources.forEach(function(paramHolder) {
                    var fieldObj = _this.form.collectField(paramHolder);
                    var inputName = paramHolder.getAttribute("name");
                    var name = paramHolder.getAttribute("data-review-param");
                    var value = fieldObj[inputName];
                    _this.applyParamChange(name, inputName, value.toString());
                    paramHolder.addEventListener("keyup", function(e) {
                        var fieldObj = _this.form.collectField(this);
                        var inputName = this.getAttribute("name");
                        var name = this.getAttribute("data-review-param");
                        var value = fieldObj[inputName];
                        _this.applyParamChange(name, inputName, value.toString());
                    });
                    paramHolder.addEventListener("input", function(e) {
                        var fieldObj = _this.form.collectField(this);
                        var inputName = this.getAttribute("name");
                        var name = this.getAttribute("data-review-param");
                        var value = fieldObj[inputName];
                        _this.applyParamChange(name, inputName, value.toString());
                    });
                    paramHolder.addEventListener("change", function(e) {
                        var fieldObj = _this.form.collectField(this);
                        var inputName = this.getAttribute("name");
                        var name = this.getAttribute("data-review-param");
                        var value = fieldObj[inputName];
                        _this.applyParamChange(name, inputName, value.toString());
                    });
                    paramHolder.addEventListener("paste", function(e) {
                        var fieldObj = _this.form.collectField(this);
                        var inputName = this.getAttribute("name");
                        var name = this.getAttribute("data-review-param");
                        var value = fieldObj[inputName];
                        _this.applyParamChange(name, inputName, value.toString());
                    });
                });
            };
            _this_1.applyParamChange = function(name, inputName, value) {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var holder = wrp.querySelector('[data-review-param="'.concat(name, '"]'));
                var param = wrp.querySelector('[data-field-for="'.concat(inputName, '"]'));
                var formatName = holder.getAttribute("data-format");
                var format = _this_1.getFormatByName(EFormatType[formatName]);
                if (param) {
                    param.innerText = format(value.toString());
                } else {
                    console.error("Review template error. Couldn't find element to change parameter with name: ".concat(inputName, "."));
                }
            };
            _this_1.edit = function(holderName, pageIndex) {
                _this_1.enrollmentPage.openPage(pageIndex);
                var currentPage = _this_1.enrollmentPage.getCurrentPage();
                var holdersFirstVisual = currentPage.querySelector('[data-validation-visual="'.concat(holderName, '"]'));
                if (!!holdersFirstVisual) {
                    _this_1.generalMethods.scrollTo(holdersFirstVisual, 500);
                }
            };
            _this_1.classConfig = classConfig;
            _this_1.store = store;
            _this_1.generalMethods = generalMethods;
            _this_1.enrollmentPage = enrollmentPage;
            _this_1.currency = currency;
            _this_1.form = form;
            _this_1.reviewCart = reviewCart;
            return _this_1;
        }
        return StEnrollmentReview;
    }(st_module_34.StModule);
    exports.StEnrollmentReview = StEnrollmentReview;
});

define("core/shopify-app/st-modules/enrollment/page-header/nav/enrollment-nav", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "core/shopify-app/st-modules/_general-methods/notification", "core/shopify-app/st-modules/_general-methods/button/button-actions"], function(require, exports, st_module_35, notification_3, button_actions_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentNav = void 0;
    var StEnrollmentNav = function(_super) {
        __extends(StEnrollmentNav, _super);

        function StEnrollmentNav(classConfig, actions, optionalKits, requiredKits, store, form, buttonActions, enrollmentValidation, enrollmentValidationSetup, notification, enrollmentReview, enrollmentPage) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "EnrollmentNav";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.setupNavPages();
                    _this_1.setupButtons();
                    _this_1.setupOptionalBundles();
                    _this_1.setupBasicValidation();
                });
            };
            _this_1.setupButtons = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var pages = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPage);
                if (pages.length > 0) {
                    _this_1.enrollmentPage.setMaxPage(pages.length);
                    _this_1.enrollmentPage.setupPageIndex(pages);
                    _this_1.enrollmentReview.setupReview();
                    _this_1.openPage(_this_1.enrollmentPage.getCurrentIndex());
                    if (!!wrp) {
                        _this_1.bindEvents(wrp);
                    } else {
                        console.error("Enrollment wrapper does not exist! Cannot setup enrollment nav.");
                    }
                } else {
                    console.error("Enrollment doesn't have a page! Can't init enrollment!");
                }
            };
            _this_1.openPage = function(pageIndex) {
                _this_1.enrollmentPage.openPage(pageIndex);
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var prevButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPrev);
                if (pageIndex === 0) {
                    prevButtons.forEach(function(button) {
                        button.classList.add("st_hidden");
                    });
                } else {
                    prevButtons.forEach(function(button) {
                        button.classList.remove("st_hidden");
                    });
                }
            };
            _this_1.bindEvents = function(wrp) {
                var _this = _this_1;
                var nextButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentNext);
                var prevButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPrev);
                nextButtons.forEach(function(nextButton) {
                    nextButton.addEventListener("click", function(e) {
                        e.preventDefault();
                        if (!_this.buttonActions.isDisabled(this)) {
                            _this.nextOrSubmit();
                        }
                    });
                });
                prevButtons.forEach(function(prevButton) {
                    prevButton.addEventListener("click", function(e) {
                        e.preventDefault();
                        _this.prev();
                    });
                });
            };
            _this_1.setupOptionalBundles = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var optionalBundleTriggers = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentOptionalKitsTrigger);
                _this_1.optionalKits.setupButtons(optionalBundleTriggers);
            };
            _this_1.nextOrSubmit = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var enrollmentPages = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPage);
                var currentPage = enrollmentPages[_this_1.enrollmentPage.getCurrentIndex()];
                var forms = currentPage.querySelectorAll(_this_1.classConfig.selectorEnrollmentForm);
                var shopifyIdHolder = wrp.querySelector('[name="shopifyId"]');
                var shopifyId = parseInt(shopifyIdHolder.value);
                var serverValidationParams = {
                    shopifyId: shopifyId
                };
                var onSiteValidationFunctions = [];
                var validation = _this_1.enrollmentValidation.getValidation();
                var dataToSave = {};
                _this_1.enrollmentValidation.clearInvalid(currentPage);
                forms.forEach(function(form) {
                    var sectionName = form.getAttribute("data-name");
                    if (!!sectionName && sectionName !== "") {
                        var formData_1 = _this_1.form.collectFormData(form);
                        var paramsToValidate_1 = {};
                        dataToSave = __assign(__assign({}, dataToSave), formData_1);
                        if (validation.hasOwnProperty(sectionName)) {
                            var backendParamNames = validation[sectionName].server();
                            backendParamNames.forEach(function(param) {
                                if (typeof paramsToValidate_1[param] !== "undefined") {
                                    console.error("Duplicate setup of param with name: ".concat(param));
                                }
                                paramsToValidate_1[param] = formData_1[param];
                            });
                            serverValidationParams = __assign(__assign({}, serverValidationParams), paramsToValidate_1);
                            onSiteValidationFunctions.push(validation[sectionName].site);
                        } else {
                            console.log('Enrollment block with name "'.concat(sectionName, '" does not have registered validation class. Skipping validation.'));
                        }
                    }
                });
                var joinedValidationResponse = {};
                var nextButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentNext);
                var prevButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPrev);
                _this_1.buttonActions.applyToMultiple(nextButtons, button_actions_1.EButtonAction.prevent);
                _this_1.buttonActions.applyToMultiple(prevButtons, button_actions_1.EButtonAction.prevent);
                if (Object.keys(serverValidationParams).length > 0) {
                    _this_1.enrollmentValidation.serverValidate(serverValidationParams, function(response, validation) {
                        joinedValidationResponse = _this_1.validateOnSite(__assign({}, validation.data), onSiteValidationFunctions);
                        _this_1.afterValidation(joinedValidationResponse, dataToSave, currentPage);
                    }, function(error) {
                        console.error("An error occurred with status: ".concat(error.status, ". Message: ").concat(error.message));
                        _this_1.buttonActions.applyToMultiple(nextButtons, button_actions_1.EButtonAction.allow);
                        _this_1.buttonActions.applyToMultiple(prevButtons, button_actions_1.EButtonAction.allow);
                    });
                } else {
                    joinedValidationResponse = _this_1.validateOnSite(joinedValidationResponse, onSiteValidationFunctions);
                    _this_1.afterValidation(joinedValidationResponse, dataToSave, currentPage);
                }
            };
            _this_1.validateOnSite = function(joinedValidationResponse, onSiteValidationFunctions) {
                if (onSiteValidationFunctions === void 0) {
                    onSiteValidationFunctions = [];
                }
                var output = joinedValidationResponse;
                onSiteValidationFunctions.forEach(function(paramValidationFunction) {
                    output = __assign(__assign({}, output), paramValidationFunction());
                });
                return output;
            };
            _this_1.afterValidation = function(validationResponse, dataToSave, page) {
                if (Object.keys(validationResponse).length > 0) {
                    var hasInvalid_1 = false;
                    var errorMessage_1 = [];
                    Object.keys(validationResponse).forEach(function(paramName) {
                        if (!validationResponse[paramName].isValid) {
                            _this_1.enrollmentValidation.markInvalid(page, paramName);
                            hasInvalid_1 = true;
                            errorMessage_1.push(validationResponse[paramName].message);
                        }
                    });
                    if (hasInvalid_1) {
                        _this_1.notification.showNotification(notification_3.ENotificationType.error, "Some fields are invalid!", errorMessage_1);
                        var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                        var nextButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentNext);
                        var prevButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPrev);
                        _this_1.buttonActions.applyToMultiple(nextButtons, button_actions_1.EButtonAction.allow);
                        _this_1.buttonActions.applyToMultiple(prevButtons, button_actions_1.EButtonAction.allow);
                    } else {
                        _this_1.store.saveData(dataToSave);
                        _this_1.next();
                    }
                } else {
                    _this_1.store.saveData(dataToSave);
                    _this_1.next();
                }
            };
            _this_1.setupBasicValidation = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var paramNames = [];
                var validation = _this_1.enrollmentValidation.getValidation();
                var allFormNames = Object.keys(validation);
                allFormNames.forEach(function(formName) {
                    if (validation[formName]) {
                        paramNames = paramNames.concat(validation[formName].basic());
                    }
                });
                for (var i = 0; i < paramNames.length; i++) {
                    var param = paramNames[i];
                    var input = wrp.querySelector('[name="'.concat(param, '"]'));
                    _this_1.enrollmentValidation.setupBasicValidationEvents(input, _this_1.afterBasicValidation);
                }
            };
            _this_1.afterBasicValidation = function(valid) {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var nextButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentNext);
                if (valid) {
                    nextButtons.forEach(function(nextButton) {
                        _this_1.buttonActions.enable(nextButton);
                    });
                } else {
                    nextButtons.forEach(function(nextButton) {
                        _this_1.buttonActions.disable(nextButton);
                    });
                }
            };
            _this_1.next = function() {
                var currentIndex = _this_1.enrollmentPage.getCurrentIndex();
                if (currentIndex + 1 < _this_1.enrollmentPage.getMaxPage()) {
                    _this_1.enrollmentPage.setCurrentIndex(currentIndex + 1);
                    _this_1.openPage(currentIndex + 1);
                    var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                    var nextButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentNext);
                    var prevButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPrev);
                    _this_1.buttonActions.applyToMultiple(nextButtons, button_actions_1.EButtonAction.allow);
                    _this_1.buttonActions.applyToMultiple(prevButtons, button_actions_1.EButtonAction.allow);
                } else {
                    var data = _this_1.store.loadData();
                    var items = data.requiredKits ? _this_1.requiredKits.format(data.requiredKits) : [];
                    items = data.optionalKits ? items.concat(data.optionalKits) : items;
                    var submit = {
                        shopifyId: data.shopifyId,
                        firstName: data.firstName,
                        lastName: data.lastName,
                        phoneNumber: data.phoneNumber,
                        webAlias: data.webAlias,
                        sponsorsWebAlias: data.sponsorsWebAlias,
                        dateOfBirth: data.dateOfBirth,
                        SSN: data.SSN,
                        items: items
                    };
                    _this_1.actions.submit(submit);
                }
            };
            _this_1.prev = function() {
                var currentIndex = _this_1.enrollmentPage.getCurrentIndex();
                if (currentIndex - 1 >= 0) {
                    _this_1.enrollmentPage.setCurrentIndex(currentIndex - 1);
                    _this_1.openPage(currentIndex - 1);
                }
            };
            _this_1.setupNavPages = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var pages = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPage);
                var navHolder = wrp.querySelector(_this_1.classConfig.selectorEnrollmentNavHolder);
                if (!!navHolder) {
                    if (pages.length > 1) {
                        pages.forEach(function(page, pageIndex) {
                            var templateName = page.getAttribute("data-name");
                            var isActive = pageIndex === 0;
                            navHolder.appendChild(_this_1.navPageTemplate(pageIndex, templateName, isActive));
                        });
                    } else {
                        var navWrp = wrp.querySelector(_this_1.classConfig.selectorEnrollmentNavWrapper);
                        if (navWrp) {
                            navWrp.classList.add(_this_1.classConfig.classNameElementHide);
                        }
                    }
                } else {
                    console.error("Enrollment Nav holder not present! Navigation won't setup");
                }
            };
            _this_1.navPageTemplate = function(pageIndex, templateName, isActive) {
                if (templateName === void 0) {
                    templateName = "";
                }
                var templateNode;
                templateNode = document.createElement("div");
                templateNode.classList.add("st_header-enrollment-single-column");
                templateNode.classList.add(_this_1.classConfig.classNameEnrollmentNavHolderSingle);
                if (isActive) {
                    templateNode.classList.add("active");
                }
                var innerWrapper = document.createElement("div");
                innerWrapper.classList.add("st_flex");
                innerWrapper.classList.add("st_align");
                var button = document.createElement("button");
                button.classList.add("st_header-navigation-enrollment");
                button.classList.add(_this_1.classConfig.selectorEnrollmentNavButton);
                button.setAttribute("data-index", "".concat(pageIndex));
                var text = document.createElement("span");
                text.classList.add("st_header-text");
                text.innerHTML = templateName;
                var pageNumber = document.createElement("span");
                pageNumber.classList.add("st_number");
                pageNumber.innerHTML = "" + (pageIndex + 1);
                button.appendChild(pageNumber);
                innerWrapper.appendChild(button);
                innerWrapper.appendChild(text);
                templateNode.appendChild(innerWrapper);
                return templateNode;
            };
            _this_1.classConfig = classConfig;
            _this_1.actions = actions;
            _this_1.optionalKits = optionalKits;
            _this_1.requiredKits = requiredKits;
            _this_1.store = store;
            _this_1.form = form;
            _this_1.buttonActions = buttonActions;
            _this_1.enrollmentValidation = enrollmentValidation;
            _this_1.enrollmentValidationSetup = enrollmentValidationSetup;
            _this_1.notification = notification;
            _this_1.enrollmentReview = enrollmentReview;
            _this_1.enrollmentPage = enrollmentPage;
            _this_1.enrollmentValidationSetup.setupValidation();
            return _this_1;
        }
        return StEnrollmentNav;
    }(st_module_35.StModule);
    exports.StEnrollmentNav = StEnrollmentNav;
});

define("extension/connector-app/_shared/models/enrollment/enrollment-validation/enrollment.validation.request.model.extended", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("extension/shopify-app/st-modules/enrollment/_validation/enrollment-validation", ["require", "exports", "core/shopify-app/st-modules/enrollment/_validation/enrollment-validation", "core/shopify-app/st-modules/_general-methods/notification"], function(require, exports, enrollment_validation_1, notification_4) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentValidationExtended = void 0;
    var StEnrollmentValidationExtended = function(_super) {
        __extends(StEnrollmentValidationExtended, _super);

        function StEnrollmentValidationExtended(classConfig, notification, enrollmentPage) {
            var _this_1 = _super.call(this, classConfig, notification, enrollmentPage) || this;
            _this_1.className = "EnrollmentValidate";
            _this_1.validationMethods = {};
            _this_1.setupValidation = function(validationClasses) {
                validationClasses.forEach(function(validationClass) {
                    var methods = validationClass.setupValidationMethods();
                    if (!!methods) {
                        _this_1.validationMethods = __assign(__assign({}, _this_1.validationMethods), methods);
                    }
                });
            };
            _this_1.getValidation = function() {
                return __assign({}, _this_1.validationMethods);
            };
            _this_1.markInvalid = function(page, inputName) {
                page.querySelectorAll('[data-validation-visual="'.concat(inputName, '"]')).forEach(function(validationVisual) {
                    validationVisual.classList.add(_this_1.classConfig.classNameInputInvalid);
                });
            };
            _this_1.clearInvalid = function(page, specificElement) {
                if (!!specificElement) {
                    specificElement.classList.remove(_this_1.classConfig.classNameInputInvalid);
                } else {
                    page.querySelectorAll(_this_1.classConfig.selectorInputInvalid).forEach(function(element) {
                        element.classList.remove(_this_1.classConfig.classNameInputInvalid);
                    });
                }
            };
            _this_1.serverValidate = function(dataToValidate, validCB, invalidCB) {
                if (validCB === void 0) {
                    validCB = function() {};
                }
                if (invalidCB === void 0) {
                    invalidCB = function() {};
                }
                var _this = _this_1;
                _this_1.ajax.send({
                    endpoint: _this.endpoint["enrollment"]["validate-data"],
                    method: "post",
                    contentType: "json",
                    data: dataToValidate,
                    callback: function(request) {
                        try {
                            var data = JSON.parse(request.response);
                            if (request.status === 200) {
                                validCB(request, data);
                            } else {
                                invalidCB({
                                    status: request.status,
                                    message: data.message
                                });
                                _this.notification.showNotification(notification_4.ENotificationType.error, "Validation Error", data.message);
                            }
                        } catch (error) {
                            invalidCB({
                                status: 500,
                                message: error.message
                            });
                            console.error(error);
                            _this.notification.showNotification(notification_4.ENotificationType.error, "Validation Error", error);
                        }
                    }
                });
            };
            _this_1.basicValidate = function(pageIndex) {
                var page, forms;
                if (typeof pageIndex !== "undefined" && pageIndex !== -1) {
                    page = _this_1.enrollmentPage.getPageByIndex(pageIndex);
                    forms = page.querySelectorAll(_this_1.classConfig.selectorEnrollmentForm);
                } else {
                    var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                    forms = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentForm);
                }
                for (var i = 0; i < forms.length; i++) {
                    var form = forms[i];
                    var sectionName = form.getAttribute("data-name");
                    var validation = _this_1.getValidation();
                    if (validation[sectionName]) {
                        var basicValidationParams = validation[sectionName].basic();
                        for (var j = 0; j < basicValidationParams.length; j++) {
                            var validationParam = basicValidationParams[j];
                            var input = form.querySelector('[name="'.concat(validationParam, '"]'));
                            if (!!input) {
                                if (typeof input.value === "undefined" || input.value === "") {
                                    return false;
                                }
                            } else {
                                console.warn('Input with name: "'.concat(validationParam, "\" was added to basic validation but doesn't exist in DOM. Skipping this field for validation."));
                            }
                        }
                    }
                }
                return true;
            };
            _this_1.basicValidationDelay = 200;
            _this_1.setupBasicValidationEvents = function(inputSelector, afterValidation) {
                var _this = _this_1;
                afterValidation(_this.runBasicValidation());
                var eventListenerFn = function() {
                    clearTimeout(_this.basicValidationTimeout);
                    _this.basicValidationTimeout = setTimeout(function() {
                        afterValidation(_this.runBasicValidation());
                    }, _this.basicValidationDelay);
                };
                inputSelector.addEventListener("input", eventListenerFn);
                inputSelector.addEventListener("change", eventListenerFn);
                inputSelector.addEventListener("paste", eventListenerFn);
            };
            _this_1.runBasicValidation = function() {
                var pageIndex = _this_1.enrollmentPage.getCurrentIndex();
                return _this_1.basicValidate(pageIndex);
            };
            _this_1.classConfig = classConfig;
            _this_1.notification = notification;
            _this_1.enrollmentPage = enrollmentPage;
            return _this_1;
        }
        return StEnrollmentValidationExtended;
    }(enrollment_validation_1.StEnrollmentValidation);
    exports.StEnrollmentValidationExtended = StEnrollmentValidationExtended;
});

define("core/connector-app/_shared/models/search-sponsor/search.sponsor.response.model", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/shopify-app/st-modules/search-sponsor/search-sponsor-service", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_36) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StSearchSponsorService = void 0;
    var StSearchSponsorService = function(_super) {
        __extends(StSearchSponsorService, _super);

        function StSearchSponsorService() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "SearchSponsorService";
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {});
            };
            _this.getSponsorByPersonalInfo = function(inputValue, handleGetSponsorInfo) {
                try {
                    _this.ajax.send({
                        endpoint: _this.endpoint["searchSponsor"]["getSponsorByPersonalInfo"],
                        method: "post",
                        contentType: "json",
                        data: {
                            query: inputValue
                        },
                        callback: handleGetSponsorInfo
                    });
                } catch (error) {
                    console.log("Error occurred while getting sponsor info ---\x3e", error);
                }
            };
            _this.getSponsorInfo = function(sponsorIdOrAlias, handleGetSponsorInfo) {
                try {
                    _this.ajax.send({
                        endpoint: _this.endpoint["searchSponsor"]["getSponsorInfo"],
                        method: "post",
                        contentType: "json",
                        data: {
                            query: sponsorIdOrAlias
                        },
                        callback: handleGetSponsorInfo
                    });
                } catch (error) {
                    console.log("Error occurred while getting sponsor info ---\x3e", error);
                }
            };
            return _this;
        }
        return StSearchSponsorService;
    }(st_module_36.StModule);
    exports.StSearchSponsorService = StSearchSponsorService;
});

define("core/shopify-app/st-modules/search-sponsor/search-sponsor", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "_features.config"], function(require, exports, st_module_37, _features_config_6) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StSearchSponsor = void 0;
    var SponsorRequestType;
    (function(SponsorRequestType) {
        SponsorRequestType[SponsorRequestType["GET_BY_ID_OR_ALIAS"] = 0] = "GET_BY_ID_OR_ALIAS";
        SponsorRequestType[SponsorRequestType["GET_BY_PERSONAL_INFORMATION"] = 1] = "GET_BY_PERSONAL_INFORMATION";
    })(SponsorRequestType || (SponsorRequestType = {}));
    var StSearchSponsor = function(_super) {
        __extends(StSearchSponsor, _super);

        function StSearchSponsor(generalMethods, objectFormatting, browserHistory, classConfig, cookies, cart, sponsorService) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "SearchSponsor";
            _this.endpointString = ["getSponsorInfo", "getSponsorByPersonalInfo"];
            _this.MIN_CHAR_SEARCH_REQUIREMENT = 2;
            _this.REQUEST_DELAY = 1e3;
            _this.inputValue = "";
            _this.cookieNameWebAlias = "webAlias";
            _this.cookieNameRepId = "repId";
            _this.cookieNameFirstName = "firstName";
            _this.cookieNameLastName = "lastName";
            _this.retryWebAliasFetch = true;
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {
                    _this.initSearchBoxFunctionality();
                    _this.initRadioButtons();
                    _this.windowClick();
                    _this.triggerVisibilityOfSection();
                    _this.cart.subscribeRenderCart(function(callback) {
                        _this.changeCartEvents();
                    });
                });
            };
            _this.loaderOn = function(triggerBtn) {
                var label = _this.generalMethods.getClosestByTag(triggerBtn, "label");
                if (!!label && !label.classList.contains("st_loader-active")) {
                    label.classList.add("st_loader-active");
                }
            };
            _this.loaderOff = function(triggerBtn) {
                var label = _this.generalMethods.getClosestByTag(triggerBtn, "label");
                if (!!label && label.classList.contains("st_loader-active")) {
                    label.classList.remove("st_loader-active");
                }
            };
            _this.changeCartEvents = function() {
                _this.initSearchBoxFunctionality();
                _this.initRadioButtons();
                _this.triggerVisibilityOfSection();
            };
            _this.setRepCookies = function(repInfo) {
                _this.cookies.setCookies(_this.cookieNameWebAlias, repInfo.webAlias);
                _this.cookies.setCookies(_this.cookieNameRepId, repInfo.repId);
                _this.cookies.setCookies(_this.cookieNameFirstName, repInfo.firstName);
                _this.cookies.setCookies(_this.cookieNameLastName, repInfo.lastName);
            };
            _this.triggerVisibilityOfSection = function() {
                var searchSponsorWrappers = document.querySelectorAll(_this.classConfig.selectorSearchSponsorWrapperPage);
                searchSponsorWrappers === null || searchSponsorWrappers === void 0 ? void 0 : searchSponsorWrappers.forEach(function(searchSponsorWrapper) {
                    var customerType = window.customerInfoMetafields.customerType;
                    if (customerType == _features_config_6.ECustomerType.retail && _features_config_6.lockedRepresentativeSite || customerType == _features_config_6.ECustomerType.representative) {
                        var searchSponsorWrapperLink = searchSponsorWrapper.querySelector(_this.classConfig.selectorChangeSponsorWrapperLink);
                        searchSponsorWrapperLink === null || searchSponsorWrapperLink === void 0 ? void 0 : searchSponsorWrapperLink.classList.add("st_hidden");
                    } else {
                        var triggerForOpenSearchInput = searchSponsorWrapper.querySelector(_this.classConfig.selectorChangeSponsorWrapper);
                        triggerForOpenSearchInput === null || triggerForOpenSearchInput === void 0 ? void 0 : triggerForOpenSearchInput.addEventListener("click", function(e) {
                            e.preventDefault();
                            searchSponsorWrappers.forEach(function(wrapper) {
                                _this.defaultVisibility(wrapper);
                            });
                            _this.showSearchInput(searchSponsorWrapper);
                            _this.hideSearchResults(searchSponsorWrapper);
                        });
                        _this.nonSponsors(searchSponsorWrapper);
                    }
                });
            };
            _this.nonSponsors = function(searchSponsorWrapper) {
                var triggerForDefaultSponsorInput = searchSponsorWrapper.querySelector(_this.classConfig.selectorNonSponsor);
                triggerForDefaultSponsorInput === null || triggerForDefaultSponsorInput === void 0 ? void 0 : triggerForDefaultSponsorInput.addEventListener("click", function() {
                    _this.updateUrl(_features_config_6.defaultWebAlias);
                    _this.defaultVisibility(searchSponsorWrapper);
                    _this.getSponsorInfo(_features_config_6.defaultWebAlias);
                    _this.setSponsorWebAliasToForm(_features_config_6.defaultWebAlias);
                    _this.setNewSponsorInfoToHeader(_features_config_6.corporationName, "", _features_config_6.defaultWebAlias);
                });
            };
            _this.updateUrl = function(newAlias) {
                var _a;
                var urlParams = _this.objectFormatting.convertQueryStringToObject(window.location.search);
                var currentAlias = urlParams[_features_config_6.aliasQueryParam];
                if (currentAlias !== newAlias) {
                    urlParams = __assign(__assign({}, urlParams), (_a = {}, _a[_features_config_6.aliasQueryParam] = newAlias,
                        _a));
                    var newURL = window.location.href.replace(window.location.search, "");
                    _this.cart.updateCartItemsProperies(newAlias);
                    _this.browserHistory.pushHistory(newURL, urlParams);
                }
            };
            _this.windowClick = function() {
                document.addEventListener("click", function(e) {
                    var searchSponsorsResult = document.querySelector(_this.classConfig.selectorChooseSponsor);
                    if (!!searchSponsorsResult) {
                        if (!_this.generalMethods.getClosestByClass(e.target, "st_search-input-and-result")) {
                            var sponsorWrappers = document.querySelectorAll(_this.classConfig.selectorSearchSponsorWrapperPage);
                            sponsorWrappers === null || sponsorWrappers === void 0 ? void 0 : sponsorWrappers.forEach(function(sponsorWrapper) {
                                _this.clearSponsorSuggestions(sponsorWrapper);
                            });
                        }
                    }
                });
            };
            _this.defaultVisibility = function(searchSponsorWrapper) {
                if (!!searchSponsorWrapper) {
                    _this.hideSearchInput(searchSponsorWrapper);
                    _this.showSearchResults(searchSponsorWrapper);
                }
            };
            _this.setSponsorWebAliasToForm = function(alias) {
                if (_features_config_6.canGoUnderCorporateSite || !_features_config_6.canGoUnderCorporateSite && alias !== _features_config_6.defaultWebAlias) {
                    var sponsorWebAliasFields = document.querySelectorAll(_this.classConfig.selectorRepresentativeAlias);
                    sponsorWebAliasFields === null || sponsorWebAliasFields === void 0 ? void 0 : sponsorWebAliasFields.forEach(function(field) {
                        _this.appendValueToField(field, alias);
                    });
                }
            };
            _this.getSponsorInfo = function(sponsorIdOrAlias) {
                if (_this.lastSponsorInfo && (_this.lastSponsorInfo.webAlias === sponsorIdOrAlias || _this.lastSponsorInfo.repId === sponsorIdOrAlias)) {
                    _this.injectSponsorInfo(_this.lastSponsorInfo);
                    return;
                }
                _this.loadersOnForSponsorInfo();
                _this.sponsorService.getSponsorInfo(sponsorIdOrAlias, function(request) {
                    var _a;
                    try {
                        if (request.status === 200) {
                            var sponsorInfoResponse = JSON.parse(request.response);
                            var dataSponsors = (_a = sponsorInfoResponse.data) === null || _a === void 0 ? void 0 : _a.sponsors;
                            if (dataSponsors && dataSponsors.length > 0) {
                                var sponsorInformation = dataSponsors[0];
                                if (!sponsorInformation.webAlias && sponsorInformation.webAlias === "") {
                                    sponsorInformation.webAlias = sponsorInformation.repId;
                                }
                                _this.lastSponsorInfo = sponsorInformation;
                                _this.injectSponsorInfo(sponsorInformation);
                                _this.setRepCookies(sponsorInformation);
                            }
                        } else {
                            if (_this.retryWebAliasFetch) {
                                _this.retryWebAliasFetch = false;
                                _this.getSponsorInfo(_features_config_6.defaultWebAlias);
                            }
                        }
                    } catch (error) {
                        console.log(error);
                        _this.getSponsorInfo(_features_config_6.defaultWebAlias);
                    }
                });
            };
            _this.loadersOnForSponsorInfo = function() {
                var sponsorsData = document.querySelectorAll(_this.classConfig.selectorSponsorData);
                var svg = '<svg width="15" height="15" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg" stroke="#222" class="st_loader">\n                        <g fill="none" fill-rule="evenodd">\n                            <g transform="translate(1 1)" stroke-width="2">\n                                <circle stroke-opacity=".5" cx="18" cy="18" r="18"/>\n                                <path d="M36 18c0-9.94-8.06-18-18-18">\n                                    <animateTransform\n                                            attributeName="transform"\n                                            type="rotate"\n                                            from="0 18 18"\n                                            to="360 18 18"\n                                            dur="1s"\n                                            repeatCount="indefinite"/>\n                                </path>\n                            </g>\n                        </g>\n                    </svg>';
                sponsorsData === null || sponsorsData === void 0 ? void 0 : sponsorsData.forEach(function(sponsorData) {
                    sponsorData.innerHTML = svg;
                });
            };
            _this.injectSponsorInfo = function(sponsorInformation) {
                var sponsorIdFields = document.querySelectorAll(_this.classConfig.selectorSponsorId);
                var sponsorAliasFields = document.querySelectorAll(_this.classConfig.selectorSponsorAlias);
                var sponsorFullNameFields = document.querySelectorAll(_this.classConfig.selectorSponsorFullName);
                var sponsorInitialsFields = document.querySelectorAll(_this.classConfig.selectorSponsorInitials);
                var sponsorAddressFields = document.querySelectorAll(_this.classConfig.selectorSponsorAddress);
                _this.injectTextIntoFields(sponsorIdFields, sponsorInformation.repId);
                _this.injectTextIntoFields(sponsorAliasFields, sponsorInformation.webAlias);
                _this.injectTextIntoFields(sponsorFullNameFields, "".concat(sponsorInformation.firstName, " ").concat(sponsorInformation.lastName));
                _this.injectTextIntoFields(sponsorInitialsFields, "".concat(sponsorInformation.firstName.charAt(0)).concat(sponsorInformation.lastName.charAt(0)));
                var address = sponsorInformation.address.state && sponsorInformation.address.state !== "" ? sponsorInformation.address.state + ", " + sponsorInformation.address.city : sponsorInformation.address.city;
                _this.injectTextIntoFields(sponsorAddressFields, address);
            };
            _this.searchSponsors = function(searchWrapper) {
                var input = searchWrapper.querySelector(_this.classConfig.selectorSearchSponsor);
                if (!!input) {
                    input.addEventListener("keyup", function(e) {
                        _this.getSponsors(input);
                    });
                    input.addEventListener("input", function(e) {
                        _this.getSponsors(input);
                    });
                    input.addEventListener("paste", function(e) {
                        _this.getSponsors(input);
                    });
                }
            };
            _this.getSponsors = function(input) {
                var value = input.value;
                if (_this.inputValue === value) return;
                if (value.length < _this.MIN_CHAR_SEARCH_REQUIREMENT) {
                    var searchSponsorInputWrapper = _this.generalMethods.getClosestByClass(input, _this.classConfig.classNameSearchInput);
                    _this.clearSponsorSuggestions(searchSponsorInputWrapper);
                    _this.enableRadioButtons(input);
                    return;
                }
                _this.inputValue = value;
                var requestType = _this.getCurrentRoute(input);
                _this.loaderOn(input);
                _this.disableRadioButtons(input);
                if (requestType === SponsorRequestType.GET_BY_ID_OR_ALIAS) {
                    _this.subscribeToTimeout(input, function() {
                        _this.sponsorService.getSponsorInfo(value, function(request) {
                            return _this.handleGetSponsorsResponse(request, input);
                        });
                    });
                }
                if (requestType === SponsorRequestType.GET_BY_PERSONAL_INFORMATION) {
                    _this.subscribeToTimeout(input, function() {
                        _this.sponsorService.getSponsorByPersonalInfo(value, function(request) {
                            return _this.handleGetSponsorsResponse(request, input);
                        });
                    });
                }
            };
            _this.getCurrentRoute = function(input) {
                var route;
                var sponsorWrapper = _this.generalMethods.getClosestByClass(input, _this.classConfig.classNameSearchInput);
                var radioButtons = sponsorWrapper.querySelectorAll(_this.classConfig.selectorSearchSponsorBy);
                radioButtons === null || radioButtons === void 0 ? void 0 : radioButtons.forEach(function(radioButton, index) {
                    if (radioButton.classList.contains("st_checked")) {
                        route = index;
                    }
                });
                return route;
            };
            _this.enableRadioButtons = function(input) {
                var sponsorWrapper = _this.generalMethods.getClosestByClass(input, _this.classConfig.classNameSearchInput);
                var radioButtons = sponsorWrapper.querySelectorAll(_this.classConfig.selectorSearchSponsorBy);
                radioButtons === null || radioButtons === void 0 ? void 0 : radioButtons.forEach(function(radioButton) {
                    radioButton.removeAttribute("disabled");
                });
            };
            _this.disableRadioButtons = function(input) {
                var sponsorWrapper = _this.generalMethods.getClosestByClass(input, _this.classConfig.classNameSearchInput);
                var radioButtons = sponsorWrapper.querySelectorAll(_this.classConfig.selectorSearchSponsorBy);
                radioButtons === null || radioButtons === void 0 ? void 0 : radioButtons.forEach(function(radioButton) {
                    radioButton.setAttribute("disabled", "disabled");
                });
            };
            _this.initRadioButtons = function() {
                var radioButtonsWrappers = document.querySelectorAll(_this.classConfig.selectorSearchInput);
                radioButtonsWrappers === null || radioButtonsWrappers === void 0 ? void 0 : radioButtonsWrappers.forEach(function(radioButtonsWrapper) {
                    var radioButtons = radioButtonsWrapper.querySelectorAll(_this.classConfig.selectorSearchSponsorBy);
                    radioButtons === null || radioButtons === void 0 ? void 0 : radioButtons.forEach(function(input) {
                        input.addEventListener("click", function(e) {
                            e.preventDefault();
                            _this.handleRadioButtonStatusChange(radioButtons, radioButtonsWrapper);
                            _this.clearSearchSponsorInputValueAndSuggestions(input);
                        });
                    });
                });
            };
            _this.setChecked = function(element) {
                if (!element.classList.contains("st_checked")) {
                    element.classList.add("st_checked");
                }
                element.setAttribute("checked", "checked");
            };
            _this.removeChecked = function(element) {
                if (element.classList.contains("st_checked")) {
                    element.classList.remove("st_checked");
                }
                element.removeAttribute("checked");
            };
            _this.renderPlaceholderText = function(radioButton, wrapper) {
                var label = _this.generalMethods.getClosestByTag(radioButton, "label");
                var text = label.querySelector(_this.classConfig.selectorRadioText).textContent;
                var placeholder = wrapper.querySelector(".st_search-input .st_placeholder-text");
                placeholder.innerHTML = text;
            };
            _this.clearSearchSponsorInputValueAndSuggestions = function(input) {
                var searchSponsorWrapper = _this.generalMethods.getClosestByClass(input, _this.classConfig.classNameSearchInput);
                if (!!searchSponsorWrapper) {
                    _this.clearSearchSponsorInputValue(searchSponsorWrapper);
                    _this.clearSponsorSuggestions(searchSponsorWrapper);
                }
            };
            _this.clearSearchSponsorInputValue = function(searchSponsorWrapper) {
                var searchSponsorInput = searchSponsorWrapper.querySelector(_this.classConfig.selectorSearchSponsor);
                if (!!searchSponsorInput) {
                    searchSponsorInput.value = "";
                    searchSponsorInput.replaceChildren();
                }
            };
            _this.clearSponsorSuggestions = function(searchSponsorWrapper) {
                var searchSponsorResult = searchSponsorWrapper.querySelector(_this.classConfig.selectorFoundSponsor);
                searchSponsorResult === null || searchSponsorResult === void 0 ? void 0 : searchSponsorResult.replaceChildren();
            };
            _this.renderSuggestionsWrapper = function(sponsorsList, input) {
                var sponsorsInputWrapper = _this.generalMethods.getClosestByClass(input, _this.classConfig.classNameSearchInput);
                if (!!sponsorsInputWrapper) {
                    var sponsorsWrapper_1 = sponsorsInputWrapper.querySelector(_this.classConfig.selectorFoundSponsor);
                    if (!!sponsorsWrapper_1) {
                        sponsorsWrapper_1.classList.remove("st_hidden");
                        sponsorsWrapper_1.replaceChildren();
                        sponsorsList === null || sponsorsList === void 0 ? void 0 : sponsorsList.forEach(function(sponsor) {
                            var sponsorJson = JSON.stringify(sponsor);
                            var buttonWithSponsorInfo = _this.createDOMElement("button", "st_search-sponsor-button--result st_choose-sponsor_JS", sponsorsWrapper_1);
                            buttonWithSponsorInfo.setAttribute("type", "button");
                            buttonWithSponsorInfo.setAttribute("data-sponsor-info", sponsorJson);
                            var leftPart = _this.createDOMElement("span", "st_result-left-part", buttonWithSponsorInfo);
                            var addressPart = _this.createDOMElement("span", "st_result-address", buttonWithSponsorInfo);
                            var credentialsSection = _this.createDOMElement("span", "st_account-sponsor-credentials-section", leftPart);
                            var sponsorResultName = _this.createDOMElement("span", "st_result-name", leftPart);
                            var addressPartData = _this.createDOMElement("span", "st_sponsor-address_JS", addressPart);
                            var state = sponsor.address.state;
                            var city = sponsor.address.city;
                            var address = state && state !== "" ? state + ", " + city : city;
                            addressPartData.innerHTML = address;
                            var initialsSection = _this.createDOMElement("span", "st_account-sponsor-initials", credentialsSection);
                            var initialsJSSection = _this.createDOMElement("span", "st_sponsor-initials_JS", initialsSection);
                            initialsJSSection.innerHTML = "".concat(sponsor.firstName.charAt(0)).concat(sponsor.lastName.charAt(0));
                            var colWrapper = _this.createDOMElement("span", "st_span-full-width", sponsorResultName);
                            var fullName = _this.createDOMElement("span", "st_sponsor-fullname_JS", colWrapper);
                            fullName.innerHTML = sponsor.firstName + " " + sponsor.lastName;
                            var sponsorIdWrapper = _this.createDOMElement("span", "st_sponsor-id", colWrapper);
                            var sponsorIdNumber = _this.createDOMElement("span", "st_sponsor-id_JS", sponsorIdWrapper);
                            sponsorIdNumber.innerHTML = " (ID: " + sponsor.repId + ")";
                            var aliasWrapper = _this.createDOMElement("span", "st_sponsor-alias", sponsorResultName);
                            var aliasWrapperData = _this.createDOMElement("span", "st_sponsor-alias_JS", aliasWrapper);
                            aliasWrapperData.innerHTML = sponsor.webAlias;
                        });
                    }
                    _this.chooseSponsor(sponsorsInputWrapper);
                }
            };
            _this.createDOMElement = function(element, classNames, parentElement) {
                var newElement = document.createElement(element);
                newElement.className = classNames;
                parentElement.appendChild(newElement);
                return newElement;
            };
            _this.chooseSponsor = function(sponsorsInputWrapper) {
                var sponsorButtons = sponsorsInputWrapper.querySelectorAll(_this.classConfig.selectorChooseSponsor);
                sponsorButtons === null || sponsorButtons === void 0 ? void 0 : sponsorButtons.forEach(function(sponsor) {
                    sponsor.addEventListener("click", function(e) {
                        e.preventDefault();
                        var newSponsorJson = sponsor.getAttribute("data-sponsor-info");
                        var newSponsor = JSON.parse(newSponsorJson);
                        var sponsorWrappers = document.querySelectorAll(_this.classConfig.selectorSearchSponsorWrapperPage);
                        sponsorWrappers === null || sponsorWrappers === void 0 ? void 0 : sponsorWrappers.forEach(function(sponsorWrapper) {
                            _this.defaultVisibility(sponsorWrapper);
                        });
                        _this.updateUrl(newSponsor.webAlias);
                        _this.clearSearchSponsorInputValueAndSuggestions(e.target);
                        _this.injectSponsorInfo(newSponsor);
                        _this.setRepCookies(newSponsor);
                        _this.setSponsorWebAliasToForm(newSponsor.webAlias);
                        _this.setNewSponsorInfoToHeader(newSponsor.firstName, newSponsor.lastName, newSponsor.webAlias);
                        window.dispatchEvent(new Event("sponsorChange"));
                    });
                });
            };
            _this.setNewSponsorInfoToHeader = function(repFirstName, repLastName, webAlias) {
                var repFullNameFields = document.querySelectorAll(_this.classConfig.selectorRepresentativeFullName);
                var fullName = _this.getFullName(repFirstName, repLastName, webAlias);
                repFullNameFields === null || repFullNameFields === void 0 ? void 0 : repFullNameFields.forEach(function(field) {
                    _this.appendValueToField(field, fullName);
                });
            };
            _this.appendValueToField = function(field, value) {
                if (field.tagName.toLowerCase() === "input") {
                    field.value = value;
                } else {
                    field.innerHTML = value;
                }
            };
            _this.hideSuggestionsWrapper = function(input) {
                var sponsorsInputWrapper = _this.generalMethods.getClosestByClass(input, _this.classConfig.classNameSearchInput);
                var sponsorsWrapper = sponsorsInputWrapper === null || sponsorsInputWrapper === void 0 ? void 0 : sponsorsInputWrapper.querySelector(_this.classConfig.selectorFoundSponsor);
                sponsorsWrapper === null || sponsorsWrapper === void 0 ? void 0 : sponsorsWrapper.replaceChildren();
                sponsorsWrapper === null || sponsorsWrapper === void 0 ? void 0 : sponsorsWrapper.classList.add("st_hidden");
            };
            _this.generalMethods = generalMethods;
            _this.objectFormatting = objectFormatting;
            _this.browserHistory = browserHistory;
            _this.classConfig = classConfig;
            _this.cookies = cookies;
            _this.cart = cart;
            _this.sponsorService = sponsorService;
            return _this;
        }
        StSearchSponsor.prototype.hideSearchResults = function(searchWrapper) {
            var searchResult = searchWrapper.querySelector(this.classConfig.selectorSearchResult);
            if (!(searchResult === null || searchResult === void 0 ? void 0 : searchResult.classList.contains("st_hidden"))) {
                searchResult === null || searchResult === void 0 ? void 0 : searchResult.classList.add("st_hidden");
            }
        };
        StSearchSponsor.prototype.showSearchResults = function(searchWrapper) {
            var searchResult = searchWrapper.querySelector(this.classConfig.selectorSearchResult);
            if (searchResult === null || searchResult === void 0 ? void 0 : searchResult.classList.contains("st_hidden")) {
                searchResult === null || searchResult === void 0 ? void 0 : searchResult.classList.remove("st_hidden");
            }
        };
        StSearchSponsor.prototype.hideSearchInput = function(searchWrapper) {
            var searchInput = searchWrapper.querySelector(this.classConfig.selectorSearchInput);
            if (!(searchInput === null || searchInput === void 0 ? void 0 : searchInput.classList.contains("st_hidden"))) {
                searchInput === null || searchInput === void 0 ? void 0 : searchInput.classList.add("st_hidden");
            }
        };
        StSearchSponsor.prototype.showSearchInput = function(searchWrapper) {
            var searchInput = searchWrapper.querySelector(this.classConfig.selectorSearchInput);
            if (searchInput === null || searchInput === void 0 ? void 0 : searchInput.classList.contains("st_hidden")) {
                searchInput === null || searchInput === void 0 ? void 0 : searchInput.classList.remove("st_hidden");
            }
        };
        StSearchSponsor.prototype.initSearchBoxFunctionality = function() {
            var _this = this;
            var searchWrappers = document.querySelectorAll(this.classConfig.selectorSearchSponsorWrapperPage);
            if (searchWrappers.length > 0) {
                var customerID = window.customerInfoMetafields.customerId;
                var sponsorRepID = window.customerInfoMetafields.representativeId;
                var customerType = window.customerInfoMetafields.customerType;
                var repSite = void 0;
                if (!!customerID && _features_config_6.lockedRepresentativeSite && customerType !== _features_config_6.ECustomerType.noType) {
                    repSite = customerType === _features_config_6.ECustomerType.representative ? customerID : sponsorRepID;
                } else {
                    var webAlias = this.objectFormatting.convertQueryStringToObject(window.location.search);
                    if (!!webAlias.als) {
                        repSite = webAlias.als;
                    } else {
                        if (!!this.cookies.getCookie("webAlias")) {
                            repSite = this.cookies.getCookie("webAlias");
                        }
                    }
                }
                this.getSponsorInfo(repSite);
            }
            searchWrappers === null || searchWrappers === void 0 ? void 0 : searchWrappers.forEach(function(wrapper) {
                _this.searchSponsors(wrapper);
            });
        };
        StSearchSponsor.prototype.injectTextIntoFields = function(fields, text) {
            fields === null || fields === void 0 ? void 0 : fields.forEach(function(field) {
                field.innerHTML = text;
            });
        };
        StSearchSponsor.prototype.subscribeToTimeout = function(input, request) {
            var value = input.value;
            if (value.length > 1) {
                clearTimeout(this.requestTimeout);
                this.requestTimeout = setTimeout(request, this.REQUEST_DELAY);
            } else {
                var searchSponsorInputWrapper = this.generalMethods.getClosestByClass(input, this.classConfig.classNameSearchInput);
                this.clearSponsorSuggestions(searchSponsorInputWrapper);
                this.enableRadioButtons(input);
            }
        };
        StSearchSponsor.prototype.handleGetSponsorsResponse = function(request, input) {
            var res = JSON.parse(request.response);
            if (res.status === 200) {
                var sponsorsList = res.data.sponsors;
                if (sponsorsList.length > 0) {
                    this.loaderOff(input);
                    this.enableRadioButtons(input);
                    this.renderSuggestionsWrapper(sponsorsList, input);
                } else {
                    this.loaderOff(input);
                    this.enableRadioButtons(input);
                    this.hideSuggestionsWrapper(input);
                }
            } else {
                this.loaderOff(input);
                this.enableRadioButtons(input);
                this.hideSuggestionsWrapper(input);
            }
        };
        StSearchSponsor.prototype.handleRadioButtonStatusChange = function(radioButtons, radioButtonsWrapper) {
            var _this = this;
            radioButtons === null || radioButtons === void 0 ? void 0 : radioButtons.forEach(function(radioButton) {
                if (!!radioButton.checked) {
                    _this.setChecked(radioButton);
                    _this.renderPlaceholderText(radioButton, radioButtonsWrapper);
                } else {
                    _this.removeChecked(radioButton);
                }
            });
        };
        StSearchSponsor.prototype.getFullName = function(repFirstName, repLastName, webAlias) {
            var fullName = !!repLastName ? repFirstName : "";
            fullName = !!repLastName ? fullName.concat(" ".concat(repLastName)) : fullName;
            if (webAlias === _features_config_6.defaultWebAlias) fullName = _features_config_6.corporationName;
            return fullName;
        };
        return StSearchSponsor;
    }(st_module_37.StModule);
    exports.StSearchSponsor = StSearchSponsor;
});

define("core/shopify-app/st-modules/enrollment-account/enrollment-account-class-config", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_38) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentAccountClassConfig = void 0;
    var StEnrollmentAccountClassConfig = function(_super) {
        __extends(StEnrollmentAccountClassConfig, _super);

        function StEnrollmentAccountClassConfig() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentAccountClassConfig";
            _this.classNameEnrollmentAccountPageWrp = "st_enrollment-account-page_JS";
            _this.selectorEnrollmentAccountPageWrp = "." + _this.classNameEnrollmentAccountPageWrp;
            _this.classNameEnrollmentLoginForm = "st_enrollment-login_JS";
            _this.selectorEnrollmentLoginForm = "." + _this.classNameEnrollmentLoginForm;
            _this.classNameEnrollmentCreateAccountWrp = "st_enrollment-create-account_JS";
            _this.selectorEnrollmentCreateAccountWrp = "." + _this.classNameEnrollmentCreateAccountWrp;
            _this.classNameEnrollmentCreateAccountForm = "st_enrollment-create-account--form_JS";
            _this.selectorEnrollmentCreateAccountForm = "." + _this.classNameEnrollmentCreateAccountForm;
            _this.classNameEnrollmentCreateAccountOpenButton = "st_enrollment-create-account--open_JS";
            _this.selectorEnrollmentCreateAccountOpenButton = "." + _this.classNameEnrollmentCreateAccountOpenButton;
            _this.classNameEnrollmentCreateAccountSubmit = "st_submit--btn_JS";
            _this.selectorEnrollmentCreateAccountSubmit = "." + _this.classNameEnrollmentCreateAccountSubmit;
            _this.classNameEnrollmentAccountPassword = "st_enrollment-account-create-password_JS";
            _this.selectorEnrollmentAccountPassword = "." + _this.classNameEnrollmentAccountPassword;
            _this.classNameEnrollmentAccountRepeatPassword = "st_enrollment-account-create-repeat-password_JS";
            _this.selectorEnrollmentAccountRepeatPassword = "." + _this.classNameEnrollmentAccountRepeatPassword;
            _this.classNamePrimaryInput = "st_primary-input_JS";
            _this.selectorPrimaryInput = "." + _this.classNamePrimaryInput;
            return _this;
        }
        return StEnrollmentAccountClassConfig;
    }(st_module_38.StModule);
    exports.StEnrollmentAccountClassConfig = StEnrollmentAccountClassConfig;
});

define("core/shopify-app/st-modules/enrollment/enrollment-cleanup", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "_features.config"], function(require, exports, st_module_39, _features_config_7) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentCleanup = void 0;
    var StEnrollmentCleanup = function(_super) {
        __extends(StEnrollmentCleanup, _super);

        function StEnrollmentCleanup(cart) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "StEnrollmentCleanup";
            _this.init = function() {};
            _this.clearCartAttributes = function(callback) {
                if (callback === void 0) {
                    callback = function() {};
                }
                _this.cart.getCart(function(cartData) {
                    var paramsToClear = _features_config_7.enrollmentParams !== null && _features_config_7.enrollmentParams !== void 0 ? _features_config_7.enrollmentParams : [];
                    if (cartData.attributes) {
                        var attributesFormatted_1 = __assign({}, cartData.attributes);
                        Object.keys(attributesFormatted_1).forEach(function(param) {
                            if (paramsToClear.indexOf(param) > -1) {
                                attributesFormatted_1[param] = "";
                            }
                        });
                        _this.cart.updateCart({
                            attributes: attributesFormatted_1
                        }, callback);
                    }
                });
            };
            _this.cart = cart;
            return _this;
        }
        return StEnrollmentCleanup;
    }(st_module_39.StModule);
    exports.StEnrollmentCleanup = StEnrollmentCleanup;
});

define("core/shopify-app/st-modules/enrollment-account/enrollment-account", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "core/shopify-app/st-modules/_general-methods/notification"], function(require, exports, st_module_40, notification_5) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentAccount = void 0;
    var StEnrollmentAccount = function(_super) {
        __extends(StEnrollmentAccount, _super);

        function StEnrollmentAccount(classConfig, buttonActions, notification, form, generalMethod, enrollmentCleanup, cart) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "EnrollmentAccount";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.form.liveTrim();
                    _this_1.enrollmentLoginPreventDefault();
                    _this_1.toggleCreateAccount();
                    _this_1.enrollmentCreateAccountForm();
                });
            };
            _this_1.enrollmentLoginPreventDefault = function() {
                var _this = _this_1;
                var enrollmentForms = document.querySelectorAll(_this_1.classConfig.selectorEnrollmentLoginForm);
                enrollmentForms.forEach(function(form) {
                    form.addEventListener("submit", function(e) {
                        e.preventDefault();
                        _this.enrollmentLogin(form, _this.prepareForLogin(form));
                    });
                });
            };
            _this_1.prepareForLogin = function(form) {
                var formData = _this_1.form.collectFormData(form);
                return {
                    email: formData["customer[email]"],
                    password: formData["customer[password]"]
                };
            };
            _this_1.enrollmentLogin = function(form, formData) {
                var _this = _this_1;
                var redirectUrl = form.getAttribute("data-url");
                var submitBtn = form.querySelector(".st_submit--btn_JS");
                _this.buttonActions.prevent(submitBtn);
                var loginRequest = {};
                loginRequest.form_type = "customer_login";
                loginRequest["customer[email]"] = formData.email;
                loginRequest["customer[password]"] = formData.password;
                _this.ajax.send({
                    endpoint: window.location.protocol + "//" + window.location.hostname + "/account/login",
                    method: "post",
                    contentType: "form",
                    data: loginRequest,
                    callback: function(request) {
                        try {
                            if (request.status == 200) {
                                var redirectUrlResponse = request.responseURL.toString();
                                if (redirectUrlResponse.includes("/account/login")) {
                                    window.location.reload();
                                    _this.buttonActions.allow(submitBtn);
                                    _this.notification.showNotification(notification_5.ENotificationType.error, "Server Error", "Incorrect email or password.", 3e3, false);
                                } else {
                                    var cartData = _this.stCart.getShopifyCartData;
                                    if (cartData.attributes.email !== formData.email) {
                                        _this.enrollmentCleanup.clearCartAttributes(function() {
                                            window.location.assign(window.location.protocol + "//" + window.location.hostname + redirectUrl);
                                        });
                                    } else {
                                        window.location.assign(window.location.protocol + "//" + window.location.hostname + redirectUrl);
                                    }
                                }
                            } else {
                                window.location.reload();
                                _this.buttonActions.allow(submitBtn);
                                _this.notification.showNotification(notification_5.ENotificationType.error, "Server Error", "Incorrect email or password.", 3e3, false);
                            }
                        } catch (error) {
                            console.error(error);
                            _this.buttonActions.allow(submitBtn);
                            _this.notification.showNotification(notification_5.ENotificationType.error, "Server Error", error);
                        }
                    }
                });
            };
            _this_1.toggleCreateAccount = function() {
                var _this = _this_1;
                var createAccountBtns = document.querySelectorAll(_this_1.classConfig.selectorEnrollmentCreateAccountOpenButton);
                createAccountBtns.forEach(function(btn) {
                    btn.addEventListener("click", function(e) {
                        e.preventDefault();
                        _this.showEnrollmentCreateAccount(this);
                    });
                });
            };
            _this_1.showEnrollmentCreateAccount = function(triggerBtn) {
                console.log("showEnrollmentCreateAccount");
                var enrollmentCreateAccount = document.querySelector(_this_1.classConfig.selectorEnrollmentCreateAccountWrp);
                if (!!enrollmentCreateAccount) {
                    enrollmentCreateAccount.classList.remove("st_visibility-hidden");
                    document.body.scrollTop = 0;
                    document.documentElement.scrollTop = 0;
                    var enrollmentAccountPage = _this_1.generalMethod.getClosestByClass(triggerBtn, _this_1.classConfig.classNameEnrollmentAccountPageWrp);
                    if (!!enrollmentAccountPage) {
                        enrollmentAccountPage.classList.add("st_visibility-hidden");
                    }
                }
            };
            _this_1.enrollmentCreateAccountForm = function() {
                var _this = _this_1;
                var enrollmentCreateAccountForms = document.querySelectorAll(_this_1.classConfig.selectorEnrollmentCreateAccountForm);
                enrollmentCreateAccountForms.forEach(function(form) {
                    _this.onRepeatPassword(form);
                    form.addEventListener("submit", function(e) {
                        e.preventDefault();
                        _this.enrollmentCreateAccountFormSubmit(form);
                    });
                });
            };
            _this_1.enrollmentCreateAccountFormSubmit = function(form) {
                var _this = _this_1;
                var formData = _this.form.collectFormData(form);
                var submitBtn = form.querySelector(_this_1.classConfig.selectorEnrollmentCreateAccountSubmit);
                _this.form.clearFormatting(form, ["repeatPassword"]);
                _this.buttonActions.prevent(submitBtn);
                var passwordInputElement = document.querySelector('input[name="password"]');
                var repeatPasswordInputElement = document.querySelector('input[name="repeatPassword"]');
                if (passwordInputElement.value.length > 40) {
                    _this.notification.showNotification(notification_5.ENotificationType.error, "Validation Error", "Password cannot contain more than 40 characters!");
                    _this.buttonActions.allow(submitBtn);
                } else if (passwordInputElement.value === (repeatPasswordInputElement === null || repeatPasswordInputElement === void 0 ? void 0 : repeatPasswordInputElement.value) || !repeatPasswordInputElement) {
                    _this.ajax.send({
                        endpoint: _this.endpoint["enrollment"]["createAccount"],
                        method: "post",
                        contentType: "json",
                        data: formData,
                        callback: function(response) {
                            try {
                                var createAccountResponse = JSON.parse(response.response);
                                if (createAccountResponse.status === 200) {
                                    _this.buttonActions.allow(submitBtn);
                                    var formDataLogin = {
                                        email: formData.email,
                                        password: formData.password
                                    };
                                    _this.enrollmentLogin(form, formDataLogin);
                                } else if (createAccountResponse.status === 400) {
                                    var validationErrors = _this.prepareErrorArray(createAccountResponse.data);
                                    _this.notification.showNotification(notification_5.ENotificationType.error, "Validation Error", validationErrors);
                                    _this.buttonActions.allow(submitBtn);
                                    var errors = [];
                                    for (var validationParam in createAccountResponse.data) {
                                        var validationResult = createAccountResponse.data[validationParam];
                                        if (!validationResult.isValid) {
                                            errors.push(validationResult.message);
                                        }
                                    }
                                    _this.notification.showNotification(notification_5.ENotificationType.error, "Validation Error", errors);
                                    _this.buttonActions.allow(submitBtn);
                                } else {
                                    _this.notification.showNotification(notification_5.ENotificationType.error, "Validation Error", createAccountResponse.message);
                                    _this.buttonActions.allow(submitBtn);
                                }
                            } catch (error) {
                                console.error(error);
                                _this.notification.showNotification(notification_5.ENotificationType.error, "Server Error", error);
                                _this.buttonActions.allow(submitBtn);
                            }
                        }
                    });
                } else {
                    _this.form.markValidationResults(form, _this.checkPasswordMatch({}));
                    _this.notification.showNotification(notification_5.ENotificationType.error, "Validation Error", "Passwords not matching!");
                    _this.buttonActions.allow(submitBtn);
                }
            };
            _this_1.onRepeatPassword = function(form) {
                var _this = _this_1;
                var passwordInputElement = document.querySelector('input[name="password"]');
                var repeatPasswordInputElement = document.querySelector('input[name="repeatPassword"]');
                passwordInputElement.oninput = function(e) {
                    var validationProperties = _this.checkPasswordMatch({});
                    if (Object.keys(validationProperties).length === 0) {
                        _this.form.clearFormatting(form, ["repeatPassword"]);
                    } else {
                        _this.form.markValidationResults(form, validationProperties);
                    }
                };
                if (repeatPasswordInputElement) {
                    repeatPasswordInputElement.oninput = function() {
                        var validationProperties = _this.checkPasswordMatch({});
                        if (Object.keys(validationProperties).length === 0) {
                            _this.form.clearFormatting(form, ["repeatPassword"]);
                        } else {
                            _this.form.markValidationResults(form, validationProperties);
                        }
                    };
                }
            };
            _this_1.checkPasswordMatch = function(validationProperties) {
                var passwordInputElement = document.querySelector(_this_1.classConfig.selectorEnrollmentAccountPassword);
                var repeatPasswordInputElement = document.querySelector(_this_1.classConfig.selectorEnrollmentAccountRepeatPassword);
                if (repeatPasswordInputElement) {
                    if (passwordInputElement.value !== repeatPasswordInputElement.value) {
                        return __assign(__assign({}, validationProperties), {
                            repeatPassword: {
                                isValid: false,
                                message: "Passwords not matching!"
                            }
                        });
                    }
                }
                return validationProperties;
            };
            _this_1.prepareErrorArray = function(validationData) {
                var validationDataKeys = Object.keys(validationData);
                var errorArray = [];
                validationDataKeys.forEach(function(key) {
                    if (!validationData[key].isValid) {
                        errorArray.push(validationData[key].message);
                    }
                });
                return errorArray;
            };
            _this_1.classConfig = classConfig;
            _this_1.buttonActions = buttonActions;
            _this_1.notification = notification;
            _this_1.form = form;
            _this_1.generalMethod = generalMethod;
            _this_1.enrollmentCleanup = enrollmentCleanup;
            _this_1.stCart = cart;
            return _this_1;
        }
        return StEnrollmentAccount;
    }(st_module_40.StModule);
    exports.StEnrollmentAccount = StEnrollmentAccount;
});

define("core/shopify-app/st-modules/_general-methods/form/formatting", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_41) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StFormFormatting = void 0;
    var StFormFormatting = function(_super) {
        __extends(StFormFormatting, _super);

        function StFormFormatting() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "Formatting";
            _this.setupFormatting = function(collectionToIterate, formattingFn, callbackFn) {
                if (callbackFn === void 0) {
                    callbackFn = function(value) {};
                }
                collectionToIterate.forEach(function(input) {
                    var formattedVal = formattingFn(input.value);
                    input.value = formattedVal;
                    input.setAttribute("value", formattedVal);
                    callbackFn(formattedVal);
                    input.addEventListener("input", function(e) {
                        var formattedVal = formattingFn(this.value);
                        this.value = formattedVal;
                        this.setAttribute("value", formattedVal);
                        callbackFn(this.value);
                    });
                    input.addEventListener("keyup", function(e) {
                        var formattedVal = formattingFn(this.value);
                        this.value = formattedVal;
                        this.setAttribute("value", formattedVal);
                        callbackFn(this.value);
                    });
                    input.addEventListener("paste", function(e) {
                        var formattedVal = formattingFn(this.value);
                        this.value = formattedVal;
                        this.setAttribute("value", formattedVal);
                        callbackFn(this.value);
                    });
                });
            };
            _this.formatPhoneNumber = function(phone) {
                var phoneString = ("" + phone).replace(/\D/g, "");
                var segment1 = phoneString.slice(0, 3);
                var segment2 = phoneString.slice(3, 6);
                var segment3 = phoneString.slice(6, 10);
                return segment1 + (segment2.length > 0 ? "-" + segment2 : "") + (segment3.length > 0 ? "-" + segment3 : "");
            };
            _this.formatWebAlias = function(webAlias) {
                return webAlias.replace(/[^A-Za-z0-9\-_]/g, "");
            };
            _this.formatSSN = function(ssn) {
                var phoneString = ("" + ssn).replace(/\D/g, "");
                var segment1 = phoneString.slice(0, 3);
                var segment2 = phoneString.slice(3, 5);
                var segment3 = phoneString.slice(5, 9);
                return segment1 + (segment2.length > 0 ? "-" + segment2 : "") + (segment3.length > 0 ? "-" + segment3 : "");
            };
            return _this;
        }
        return StFormFormatting;
    }(st_module_41.StModule);
    exports.StFormFormatting = StFormFormatting;
});

define("core/shopify-app/st-modules/enrollment/blocks/account-details/account-details-helpers", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_42) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentAccountDetailsHelpers = void 0;
    var StEnrollmentAccountDetailsHelpers = function(_super) {
        __extends(StEnrollmentAccountDetailsHelpers, _super);

        function StEnrollmentAccountDetailsHelpers(formFormatting, classConfig) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentAccountDetailsHelpers";
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {
                    _this.setupPhoneFormatting();
                });
            };
            _this.setupPhoneFormatting = function(inputs) {
                var wrp = document.querySelector(_this.classConfig.selectorEnrollmentWrapper);
                var collectionToIterate = !!inputs ? inputs : wrp.querySelectorAll(_this.classConfig.selectorEnrollmentAccountDetailsPhone);
                _this.formFormatting.setupFormatting(collectionToIterate, _this.formFormatting.formatPhoneNumber);
            };
            _this.formFormatting = formFormatting;
            _this.classConfig = classConfig;
            return _this;
        }
        return StEnrollmentAccountDetailsHelpers;
    }(st_module_42.StModule);
    exports.StEnrollmentAccountDetailsHelpers = StEnrollmentAccountDetailsHelpers;
});

define("core/shopify-app/st-modules/enrollment/blocks/business-info/business-details-helpers", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_43) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentBusinessDetailsHelpers = void 0;
    var StEnrollmentBusinessDetailsHelpers = function(_super) {
        __extends(StEnrollmentBusinessDetailsHelpers, _super);

        function StEnrollmentBusinessDetailsHelpers(formatting, classConfig) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "BusinessDetailsHelpers";
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {
                    _this.setupWebAliasFormatting();
                    _this.setupSSNFormatting();
                });
            };
            _this.setupWebAliasFormatting = function(inputs) {
                var wrp = document.querySelector(_this.classConfig.selectorEnrollmentWrapper);
                var collectionToIterate = !!inputs ? inputs : wrp.querySelectorAll(_this.classConfig.selectorEnrollmentBusinessDetailsWebAlias);
                _this.formFormatting.setupFormatting(collectionToIterate, _this.formFormatting.formatWebAlias, function(value) {
                    var wrp = document.querySelector(_this.classConfig.selectorEnrollmentWrapper);
                    var webAliasPresenter = wrp.querySelector(_this.classConfig.selectorEnrollmentBusinessDetailsWebAliasPresenter);
                    if (!!webAliasPresenter) {
                        webAliasPresenter.innerText = value;
                    }
                });
            };
            _this.setupSSNFormatting = function(inputs) {
                var wrp = document.querySelector(_this.classConfig.selectorEnrollmentWrapper);
                var collectionToIterate = !!inputs ? inputs : wrp.querySelectorAll(_this.classConfig.selectorEnrollmentBusinessDetailsSSN);
                _this.formFormatting.setupFormatting(collectionToIterate, _this.formFormatting.formatSSN);
            };
            _this.formFormatting = formatting;
            _this.classConfig = classConfig;
            return _this;
        }
        return StEnrollmentBusinessDetailsHelpers;
    }(st_module_43.StModule);
    exports.StEnrollmentBusinessDetailsHelpers = StEnrollmentBusinessDetailsHelpers;
});

define("core/shopify-app/st-modules/account/header/nav/account-nav", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_44) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountNav = void 0;
    var StAccountNav = function(_super) {
        __extends(StAccountNav, _super);

        function StAccountNav(classConfig, objectFormatting, browserHistory, generalMethods) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "AccountNav";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.setupAccountNavPages();
                    _this_1.openPage();
                    _this_1.bindNavEvents();
                    _this_1.logout();
                });
            };
            _this_1.setupAccountNavPages = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorAccountPage);
                var pageWrappers = wrp.querySelectorAll(_this_1.classConfig.selectorAccountContent);
                var navHolder = wrp.querySelector(_this_1.classConfig.selectorAccountNavHolder);
                var navWrp = wrp.querySelector(_this_1.classConfig.selectorAccountNavWrapper);
                if (!!navHolder) {
                    if (pageWrappers.length > 1) {
                        pageWrappers.forEach(function(pageWrapper, pageIndex) {
                            var templateName = pageWrapper.getAttribute("data-name");
                            var svgIcon = pageWrapper.querySelector(_this_1.classConfig.selectorAccountIcon).innerHTML;
                            var page = _this_1.navPageTemplate(pageIndex, templateName, svgIcon);
                            navHolder.appendChild(page);
                        });
                        if (navWrp) {
                            navWrp.classList.remove("st_hidden");
                        }
                    } else {
                        if (navWrp) {
                            navWrp.classList.add("st_hidden");
                        }
                    }
                } else {
                    console.error("Account Nav holder not present! Navigation won't setup");
                }
            };
            _this_1.navPageTemplate = function(pageIndex, templateName, svgIcon) {
                if (templateName === void 0) {
                    templateName = "";
                }
                if (svgIcon === void 0) {
                    svgIcon = "";
                }
                var templateNode;
                templateNode = document.createElement("div");
                templateNode.classList.add("st_header-account-nav-link");
                templateNode.classList.add(_this_1.classConfig.classNameAccountNavHolderSingle);
                var button = document.createElement("button");
                button.classList.add("st_header-navigation-account", "st_account--button");
                button.classList.add(_this_1.classConfig.classNameAccountNavButton);
                button.setAttribute("data-index", "".concat(pageIndex));
                button.innerHTML = svgIcon;
                var text = document.createElement("span");
                text.classList.add("st_header-text");
                text.innerHTML = templateName.charAt(0).toUpperCase() + templateName.slice(1);
                button.appendChild(text);
                templateNode.appendChild(button);
                return templateNode;
            };
            _this_1.bindNavEvents = function() {
                var _this = _this_1;
                var navLinks = document.querySelectorAll(_this.classConfig.selectorAccountNavButton);
                navLinks.forEach(function(navLink) {
                    navLink.addEventListener("click", function(e) {
                        e.preventDefault();
                        var pageIndex = parseInt(this.getAttribute("data-index"));
                        _this.openPage(pageIndex);
                        _this.closeAddressEdit();
                        _this.closeSingleOrder();
                    });
                });
            };
            _this_1.closeAddressEdit = function() {
                var editAddressButtons = document.querySelectorAll(_this_1.classConfig.selectorAccountBackButton);
                if (!!editAddressButtons) {
                    editAddressButtons.forEach(function(editAddressButton) {
                        var addressWrapper = _this_1.generalMethods.getClosestByClass(editAddressButton, _this_1.classConfig.classNameAddressesWrapper);
                        if (!!addressWrapper) {
                            var buttonDropdown = addressWrapper.querySelector(_this_1.classConfig.selectorAccountAddressesDropdown);
                            var buttonDropdownContent = addressWrapper.querySelector(_this_1.classConfig.selectorAccountAddressesDropdownWrapper);
                            addressWrapper.classList.remove("st_hide");
                            if (!!buttonDropdown && !!buttonDropdownContent) {
                                buttonDropdown.classList.remove("active");
                                buttonDropdownContent.classList.remove("active");
                            }
                        }
                    });
                }
            };
            _this_1.closeSingleOrder = function() {
                var _this = _this_1;
                var orderHistory = document.querySelectorAll(_this.classConfig.selectorBackToHistoryOrders);
                orderHistory.forEach(function(order) {
                    var singleOrderWrapper = document.querySelector(".st_single-order_JS");
                    if (!!singleOrderWrapper) {
                        singleOrderWrapper.style.display = "none";
                    }
                    var orderWrapper = document.querySelector(".st_order-history_JS");
                    if (!!orderWrapper) {
                        orderWrapper.classList.remove(_this.classConfig.classNameOpenOrderCSSClass);
                    }
                });
            };
            _this_1.openPage = function(pageIndex) {
                var wrp = document.querySelector(_this_1.classConfig.selectorAccountPage);
                var alreadyOpen = wrp.querySelector(_this_1.classConfig.selectorAccountSection + ".st_show");
                var accountSections = wrp.querySelectorAll(_this_1.classConfig.selectorAccountSection);
                if (typeof pageIndex === "undefined") {
                    var urlParams = _this_1.objectFormatting.convertQueryStringToObject(window.location.search);
                    var maxTab = accountSections.length - 1;
                    var tabIndex = urlParams.tab ? parseInt(urlParams.tab) : 0;
                    pageIndex = isNaN(tabIndex) ? 0 : tabIndex;
                    pageIndex = tabIndex > maxTab ? maxTab : tabIndex;
                }
                var navHolder = wrp.querySelector(_this_1.classConfig.selectorAccountNavHolder);
                var AccountNavElements = navHolder.querySelectorAll(_this_1.classConfig.selectorAccountNavHolderSingle);
                if (!!alreadyOpen) {
                    alreadyOpen.classList.remove("st_show");
                }
                if (accountSections.length > pageIndex) {
                    accountSections[pageIndex].classList.add("st_show");
                } else {
                    console.error("Invalid page index supplied to Account nav openPage method!");
                }
                AccountNavElements.forEach(function(navElement, index) {
                    navElement.classList.remove("current");
                    if (index === pageIndex) {
                        _this_1.updateTabToUrl("" + pageIndex);
                        navElement.classList.add("current");
                    }
                });
            };
            _this_1.updateTabToUrl = function(activeTab) {
                var urlParams = _this_1.objectFormatting.convertQueryStringToObject(window.location.search);
                urlParams.tab = "" + activeTab;
                var newURL = window.location.href.replace(window.location.search, "");
                _this_1.browserHistory.pushHistory(newURL, urlParams);
            };
            _this_1.logout = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorAccountPage);
                var logoutBtns = wrp.querySelectorAll(_this_1.classConfig.selectorAccountLogout);
                if (!!logoutBtns) {
                    logoutBtns.forEach(function(btn) {
                        btn.addEventListener("click", function(e) {
                            e.preventDefault();
                            window.location.assign(window.location.protocol + "//" + window.location.hostname + "/account/logout");
                        });
                    });
                }
            };
            _this_1.classConfig = classConfig;
            _this_1.objectFormatting = objectFormatting;
            _this_1.browserHistory = browserHistory;
            _this_1.generalMethods = generalMethods;
            return _this_1;
        }
        return StAccountNav;
    }(st_module_44.StModule);
    exports.StAccountNav = StAccountNav;
});

define("core/connector-app/_shared/models/auth/sso.request.model", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/connector-app/_shared/models/auth/sso.response.model", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/shopify-app/st-modules/account/header/backoffice-sso/backoffice-sso", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "core/shopify-app/st-modules/_general-methods/notification"], function(require, exports, st_module_45, notification_6) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StBackofficeSSO = void 0;
    var StBackofficeSSO = function(_super) {
        __extends(StBackofficeSSO, _super);

        function StBackofficeSSO(classConfig, notification) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "BackofficeSSO";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.getSSOLinkEvent();
                });
            };
            _this_1.getSSOLinkEvent = function() {
                var _this = _this_1;
                var ssoLinks = document.querySelectorAll(_this_1.classConfig.selectorBackOfficeLink);
                for (var i = 0; i < ssoLinks.length; i++) {
                    var ssoLink = ssoLinks[i];
                    ssoLink.addEventListener("click", function(e) {
                        e.preventDefault();
                        _this.getSSOLink();
                    });
                }
            };
            _this_1.getSSOLink = function() {
                var _this = _this_1;
                var customerInfoMetafields = window.customerInfoMetafields;
                var ssoLinkRequest = {
                    customerId: customerInfoMetafields.customerId,
                    sponsorId: customerInfoMetafields.representativeId,
                    isAutoship: false,
                    customerType: customerInfoMetafields.customerType
                };
                _this_1.ajax.send({
                    endpoint: _this.endpoint["auth"]["sso"],
                    method: "post",
                    contentType: "json",
                    data: ssoLinkRequest,
                    callback: function(response) {
                        try {
                            var ssoLinkResponse = JSON.parse(response.response);
                            if (ssoLinkResponse.status === 200) {
                                var ssoLinkData = ssoLinkResponse.data;
                                if (!!ssoLinkData.ssoLink && ssoLinkData.ssoLink !== "") {
                                    window.location.href = ssoLinkData.ssoLink;
                                }
                            } else {
                                _this.notification.showNotification(notification_6.ENotificationType.error, "An Error Occurred!", ssoLinkResponse.message);
                            }
                        } catch (error) {
                            _this.notification.showNotification(notification_6.ENotificationType.error, "An Error Occurred!", error);
                        }
                    }
                });
            };
            _this_1.classConfig = classConfig;
            _this_1.notification = notification;
            return _this_1;
        }
        return StBackofficeSSO;
    }(st_module_45.StModule);
    exports.StBackofficeSSO = StBackofficeSSO;
});

define("core/shopify-app/st-modules/account/blocks/web-alias-edit/web-alias-edit", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "core/shopify-app/st-modules/_general-methods/notification"], function(require, exports, st_module_46, notification_7) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountWebAliasEdit = void 0;
    var StAccountWebAliasEdit = function(_super) {
        __extends(StAccountWebAliasEdit, _super);

        function StAccountWebAliasEdit(classConfig, generalMethods, notification, buttonActions, form, formFormatting) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "AccountWebAliasEdit";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.setupWebAliasInputEvents();
                    _this_1.editWebAlias();
                });
            };
            _this_1.setupWebAliasInputEvents = function() {
                var _this = _this_1;
                var webAliasInputsFields = document.querySelectorAll(_this_1.classConfig.selectorAccountWebAlias);
                webAliasInputsFields.forEach(function(webAliasInput) {
                    _this.injectWebAlias(webAliasInput);
                    webAliasInput.addEventListener("keyup", function() {
                        this.value = _this.formFormatting.formatWebAlias(this.value);
                        _this.injectWebAlias(this);
                    });
                    webAliasInput.addEventListener("input", function() {
                        this.value = _this.formFormatting.formatWebAlias(this.value);
                        _this.injectWebAlias(this);
                    });
                    webAliasInput.addEventListener("paste", function() {
                        this.value = _this.formFormatting.formatWebAlias(this.value);
                        _this.injectWebAlias(this);
                    });
                });
            };
            _this_1.injectWebAlias = function(webAliasInput) {
                var inputValue = webAliasInput.value;
                var webAliasWrapper = _this_1.generalMethods.getClosestByClass(webAliasInput, _this_1.classConfig.classNameWebAliasWrapper);
                var readOnlyInput = webAliasWrapper.querySelector(_this_1.classConfig.selectorWebAliasValue);
                readOnlyInput.value = inputValue;
            };
            _this_1.editWebAlias = function() {
                var _this = _this_1;
                var form = document.querySelector(_this_1.classConfig.selectorEditWebAliasForm);
                if (!!form) {
                    form.addEventListener("submit", function(e) {
                        e.preventDefault();
                        _this.submitWebAlias(this);
                    });
                }
            };
            _this_1.submitWebAlias = function(form) {
                var _this = _this_1;
                var formData = _this.form.collectFormData(form);
                var submitBtn = form.querySelector(_this_1.classConfig.selectorSubmitButton);
                _this.buttonActions.prevent(submitBtn);
                _this.ajax.send({
                    endpoint: _this.endpoint["customer"]["updateWebAlias"],
                    method: "post",
                    contentType: "json",
                    data: formData,
                    callback: function(response) {
                        try {
                            var editWebAliasResponse = JSON.parse(response.response);
                            if (editWebAliasResponse.status === 200) {
                                _this.buttonActions.allow(submitBtn);
                                window.location.reload();
                            } else if (editWebAliasResponse.status === 400) {
                                var validationProperties = editWebAliasResponse.data;
                                _this.form.markValidationResults(form, validationProperties);
                                _this.buttonActions.allow(submitBtn);
                                _this.notification.showNotification(notification_7.ENotificationType.error, "An Error Occurred", "Some fields are invalid.");
                            } else {
                                _this.notification.showNotification(notification_7.ENotificationType.error, "An Error Occurred", editWebAliasResponse.message);
                                _this.buttonActions.allow(submitBtn);
                            }
                        } catch (error) {
                            console.error(error);
                            _this.notification.showNotification(notification_7.ENotificationType.error, "Server Error", error);
                            _this.buttonActions.allow(submitBtn);
                        }
                    }
                });
            };
            _this_1.classConfig = classConfig;
            _this_1.generalMethods = generalMethods;
            _this_1.notification = notification;
            _this_1.buttonActions = buttonActions;
            _this_1.form = form;
            _this_1.formFormatting = formFormatting;
            return _this_1;
        }
        return StAccountWebAliasEdit;
    }(st_module_46.StModule);
    exports.StAccountWebAliasEdit = StAccountWebAliasEdit;
});

define("core/shopify-app/st-modules/account/blocks/addresses/addresses", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_47) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountAddresses = void 0;
    var StAccountAddresses = function(_super) {
        __extends(StAccountAddresses, _super);

        function StAccountAddresses(classConfig, generalMethods) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "AccountAddress";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.openAddressDropDown();
                    _this_1.setupAddressEdit();
                    _this_1.setupAddressProvinceField();
                });
            };
            _this_1.openAddressDropDown = function() {
                var _this = _this_1;
                var dropDownButtons = document.querySelectorAll(_this_1.classConfig.selectorAccountAddressesDropdown);
                dropDownButtons.forEach(function(dropDownButton) {
                    dropDownButton.addEventListener("click", function(e) {
                        e.preventDefault();
                        _this.openAddressActiveState(dropDownButton);
                    });
                });
            };
            _this_1.openAddressActiveState = function(dropDownButton) {
                dropDownButton.classList.toggle("active");
            };
            _this_1.setupAddressEdit = function() {
                var _this = _this_1;
                var addressTabButtons = document.querySelectorAll(_this_1.classConfig.selectorAccountTabButton);
                addressTabButtons.forEach(function(addressTabButton) {
                    addressTabButton.addEventListener("click", function(e) {
                        e.preventDefault();
                        _this.showAddressEdit(addressTabButton);
                    });
                });
                var editAddressButtons = document.querySelectorAll(_this_1.classConfig.selectorAccountBackButton);
                editAddressButtons.forEach(function(editAddressButton) {
                    editAddressButton.addEventListener("click", function(e) {
                        e.preventDefault();
                        _this.hideAddressEdit(editAddressButton);
                    });
                });
            };
            _this_1.showAddressEdit = function(addressTabButton) {
                var addressWrapper = _this_1.generalMethods.getClosestByClass(addressTabButton, _this_1.classConfig.classNameAddressesWrapper);
                if (!!addressWrapper) {
                    addressWrapper.classList.add("st_hide");
                }
            };
            _this_1.hideAddressEdit = function(editAddressButton) {
                var addressWrapper = _this_1.generalMethods.getClosestByClass(editAddressButton, _this_1.classConfig.classNameAddressesWrapper);
                if (!!addressWrapper) {
                    var buttonDropdown = addressWrapper.querySelector(".st_addresses-dots--button_JS");
                    var buttonDropdownContent = addressWrapper.querySelector(".st_dropdown-address--wrapper");
                    addressWrapper.classList.remove("st_hide");
                    buttonDropdown.classList.remove("active");
                    buttonDropdownContent.classList.remove("active");
                }
            };
            _this_1.setupAddressProvinceField = function() {
                var _this = _this_1;
                var provinceSelector = document.querySelector(_this_1.classConfig.selectorProvinceSelector);
                var provinceSource = document.querySelector(_this_1.classConfig.selectorProvinceSource);
                if (!!provinceSelector && !!provinceSource) {
                    _this_1.addProvinceOptions(provinceSelector, provinceSource);
                    provinceSource.addEventListener("change", function(e) {
                        _this.addProvinceOptions(provinceSelector, provinceSource);
                    });
                }
            };
            _this_1.addProvinceOptions = function(provinceSelector, provinceSource) {
                var selectedCountry = provinceSource.value ? provinceSource.value : provinceSource.getAttribute("data-default");
                var provinceSelectedOption = provinceSource.querySelector('option[value="'.concat(selectedCountry, '"]'));
                var provinceWrapper = _this_1.generalMethods.getClosestByClass(provinceSelector, _this_1.classConfig.classNameProvinceWrapper);
                if (!!provinceWrapper) {
                    provinceWrapper.classList.remove("st_hidden");
                }
                try {
                    var provinces = JSON.parse(provinceSelectedOption.getAttribute("data-provinces"));
                    provinceSelector.replaceChildren();
                    for (var i = 0; i < provinces.length; i++) {
                        var opt = document.createElement("option");
                        opt.value = provinces[i][0];
                        opt.innerHTML = provinces[i][1];
                        opt.setAttribute("data-ind", "" + i);
                        provinceSelector.appendChild(opt);
                    }
                    var defaultProvince = provinceSelector.getAttribute("data-default");
                    var defaultProvinceEl = provinceSelector.querySelector('option[value="'.concat(defaultProvince, '"]'));
                    var provinceOptions = provinceSelector.querySelectorAll("option");
                    var selectedOption = defaultProvince ? defaultProvinceEl : provinceOptions[0];
                    provinceSelector.value = selectedOption.value;
                    provinceSelector.selectedIndex = parseInt(selectedOption.getAttribute("data-ind"));
                    provinceOptions.forEach(function(provinceOption) {
                        provinceOption.removeAttribute("selected");
                    });
                    selectedOption.selected = true;
                    selectedOption.setAttribute("selected", "selected");
                } catch (e) {
                    console.error(e);
                    var provinceWrapper_1 = _this_1.generalMethods.getClosestByClass(provinceSelector, _this_1.classConfig.classNameProvinceWrapper);
                    if (!!provinceWrapper_1) {
                        provinceWrapper_1.classList.add("st_hidden");
                    }
                }
            };
            _this_1.classConfig = classConfig;
            _this_1.generalMethods = generalMethods;
            return _this_1;
        }
        return StAccountAddresses;
    }(st_module_47.StModule);
    exports.StAccountAddresses = StAccountAddresses;
});

define("core/connector-app/_shared/models/customer/account/customer.account.request", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("core/shopify-app/st-modules/account/blocks/personal-info/personal-info", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "core/shopify-app/st-modules/_general-methods/notification"], function(require, exports, st_module_48, notification_8) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountPersonalInfo = void 0;
    var StAccountPersonalInfo = function(_super) {
        __extends(StAccountPersonalInfo, _super);

        function StAccountPersonalInfo(classConfig, form, formFormatting, buttonActions, notification, generalMethods) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "AccountPersonalInfo";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.editPersonalInfo();
                    _this_1.setupFormatPhoneNumber();
                });
            };
            _this_1.editPersonalInfo = function() {
                var _this = _this_1;
                var form = document.querySelector(_this_1.classConfig.selectorPersonalInfoForm);
                if (!!form) {
                    form.addEventListener("submit", function(e) {
                        e.preventDefault();
                        _this.submitPersonalInfo(this);
                    });
                }
            };
            _this_1.submitPersonalInfo = function(form) {
                var _this = _this_1;
                var data = _this.form.collectFormData(form);
                var formData = {
                    firstName: data.firstName,
                    lastName: data.lastName,
                    phoneNumber: data.phoneNumber,
                    shopifyId: data.shopifyId,
                    email: data.email
                };
                var submitBtn = form.querySelector(_this_1.classConfig.selectorSubmitButton);
                _this.buttonActions.prevent(submitBtn);
                _this.ajax.send({
                    endpoint: _this.endpoint["customer"]["updatePersonalInfo"],
                    method: "post",
                    contentType: "json",
                    data: formData,
                    callback: function(response) {
                        try {
                            var editPersonalInfoResponse = JSON.parse(response.response);
                            var validationProperties = editPersonalInfoResponse.data;
                            if (editPersonalInfoResponse.status === 200) {
                                _this.buttonActions.allow(submitBtn);
                                _this.form.markValidationResults(form, validationProperties);
                                _this.notification.showNotification(notification_8.ENotificationType.success, "Success", "You have successfully modified your information.");
                                _this.updatePersonalInfoWrapperIfExist(form, formData);
                            } else if (editPersonalInfoResponse.status === 400) {
                                _this.form.markValidationResults(form, validationProperties);
                                _this.buttonActions.allow(submitBtn);
                                _this.notification.showNotification(notification_8.ENotificationType.error, "An Error Occurred", "Some fields are invalid.");
                            } else {
                                _this.buttonActions.allow(submitBtn);
                                _this.notification.showNotification(notification_8.ENotificationType.error, "An Error Occurred", editPersonalInfoResponse.message);
                            }
                        } catch (error) {
                            console.error(error);
                            _this.notification.showNotification(notification_8.ENotificationType.error, "Server Error", error);
                            _this.buttonActions.allow(submitBtn);
                        }
                    }
                });
            };
            _this_1.updatePersonalInfoWrapperIfExist = function(formSelector, formData) {
                var accountPage = _this_1.generalMethods.getClosestByClass(formSelector, _this_1.classConfig.classNameAccountPage);
                if (!!accountPage) {
                    var selectorBusinessContent = accountPage.querySelector(_this_1.classConfig.selectorBusinessContent);
                    if (!!selectorBusinessContent) {
                        var nameSelector = selectorBusinessContent.querySelector(_this_1.classConfig.selectorBusinessContentName);
                        var emailSelector = selectorBusinessContent.querySelector(_this_1.classConfig.selectorBusinessContentEmail);
                        if (!!emailSelector) {
                            emailSelector.innerHTML = formData.email;
                        }
                        if (!!nameSelector) {
                            nameSelector.innerHTML = formData.firstName + " " + formData.lastName;
                        }
                    }
                }
            };
            _this_1.setupFormatPhoneNumber = function() {
                var phoneNumberInputs = document.querySelectorAll('input[name="phoneNumber"]');
                _this_1.formFormatting.setupFormatting(phoneNumberInputs, _this_1.formFormatting.formatPhoneNumber);
            };
            _this_1.classConfig = classConfig;
            _this_1.form = form;
            _this_1.formFormatting = formFormatting;
            _this_1.buttonActions = buttonActions;
            _this_1.notification = notification;
            _this_1.generalMethods = generalMethods;
            return _this_1;
        }
        return StAccountPersonalInfo;
    }(st_module_48.StModule);
    exports.StAccountPersonalInfo = StAccountPersonalInfo;
});

define("core/shopify-app/st-modules/account/blocks/order-history/order-history", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_49) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountOrderHistory = void 0;
    var StAccountOrderHistory = function(_super) {
        __extends(StAccountOrderHistory, _super);

        function StAccountOrderHistory(classConfig, generalMethods) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "AccountOrderHistory";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.openSingleOrder();
                    _this_1.backToHistoryOrders();
                });
            };
            _this_1.openSingleOrder = function() {
                var _this = _this_1;
                var singleOrderTriggers = document.querySelectorAll(_this.classConfig.selectorOpenSingleOrderButton);
                singleOrderTriggers.forEach(function(order) {
                    order.addEventListener("click", function(e) {
                        e.preventDefault();
                        var orderId = order.getAttribute("data-order-id");
                        var orderWrapper = _this.generalMethods.getClosestByClass(this, _this.classConfig.classNameOrderHistory);
                        orderWrapper.classList.add(_this.classConfig.classNameOpenOrderCSSClass);
                        var singleOrderWrapper = orderWrapper.querySelector(_this.classConfig.selectorSingleOrder + '[data-order-id="' + orderId + '"]');
                        singleOrderWrapper.style.display = "block";
                    });
                });
            };
            _this_1.backToHistoryOrders = function() {
                var _this = _this_1;
                var orderHistory = document.querySelectorAll(_this.classConfig.selectorBackToHistoryOrders);
                orderHistory.forEach(function(order) {
                    order.addEventListener("click", function(e) {
                        e.preventDefault();
                        var singleOrderWrapper = _this.generalMethods.getClosestByClass(this, _this.classConfig.classNameSingleOrder);
                        singleOrderWrapper.style.display = "none";
                        var orderWrapper = _this.generalMethods.getClosestByClass(this, _this.classConfig.classNameOrderHistory);
                        orderWrapper.classList.remove(_this.classConfig.classNameOpenOrderCSSClass);
                    });
                });
            };
            _this_1.classConfig = classConfig;
            _this_1.generalMethods = generalMethods;
            return _this_1;
        }
        return StAccountOrderHistory;
    }(st_module_49.StModule);
    exports.StAccountOrderHistory = StAccountOrderHistory;
});

define("core/shopify-app/st-modules/enrollment-account/enrollment-account-repeat-password-validation", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_50) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentRepeatPasswordValidation = void 0;
    var StEnrollmentRepeatPasswordValidation = function(_super) {
        __extends(StEnrollmentRepeatPasswordValidation, _super);

        function StEnrollmentRepeatPasswordValidation(classConfig) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentRepeatPassword";
            _this.validateOnSite = function() {
                var wrp = document.querySelector(_this.classConfig.selectorEnrollmentAccountPageWrp);
                var output = [];
                if (!!wrp) {
                    var inputs = wrp.querySelectorAll(_this.classConfig.selectorEnrollmentAccountRepeatPassword);
                    inputs.forEach(function(input) {
                        var fieldName = input.getAttribute("name");
                        var isValid = input.value === input.value;
                        output[fieldName] = {
                            isValid: isValid,
                            message: !isValid ? "Your passwords are not matching!" : ""
                        };
                    });
                }
                return output;
            };
            _this.classConfig = classConfig;
            return _this;
        }
        return StEnrollmentRepeatPasswordValidation;
    }(st_module_50.StModule);
    exports.StEnrollmentRepeatPasswordValidation = StEnrollmentRepeatPasswordValidation;
});

define("core/shopify-app/st-modules/account-register/account-register-class-config", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_51) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountRegisterClassConfig = void 0;
    var StAccountRegisterClassConfig = function(_super) {
        __extends(StAccountRegisterClassConfig, _super);

        function StAccountRegisterClassConfig() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentAccountClassConfig";
            _this.classAccountRegisterForm = "st_account-register-form_JS";
            _this.selectorAccountRegisterForm = "." + _this.classAccountRegisterForm;
            _this.classAccountRegisterFormPreventDefault = "st_prevent-form-default_JS";
            _this.selectorAccountRegisterFormPreventDefault = "." + _this.classAccountRegisterFormPreventDefault;
            _this.classRepresentativeAlias = "st_representative-alias_JS";
            _this.selectorRepresentativeAlias = "." + _this.classRepresentativeAlias;
            _this.classRegisterPasswordInput = "st_register-password-input_JS";
            _this.selectorRegisterPasswordInput = "." + _this.classRegisterPasswordInput;
            return _this;
        }
        return StAccountRegisterClassConfig;
    }(st_module_51.StModule);
    exports.StAccountRegisterClassConfig = StAccountRegisterClassConfig;
});

define("core/shopify-app/st-modules/account-register/account-register", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "core/shopify-app/st-modules/_general-methods/notification", "_features.config"], function(require, exports, st_module_52, notification_9, _features_config_8) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountRegister = void 0;
    var StAccountRegister = function(_super) {
        __extends(StAccountRegister, _super);

        function StAccountRegister(form, notification, buttonActions, classConfig, generalMethods) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "AccountRegister";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.form.liveTrim();
                    _this_1.onSubmit();
                });
            };
            _this_1.onSubmit = function() {
                var _this = _this_1;
                var form = document.querySelector(_this_1.classConfig.selectorAccountRegisterForm);
                if (!!form) {
                    form.addEventListener("submit", function(e) {
                        _this.validateAccountCreation(this, e);
                    });
                }
            };
            _this_1.prepareErrorArray = function(validationData) {
                var validationDataKeys = Object.keys(validationData);
                var errorArray = [];
                validationDataKeys.forEach(function(key) {
                    if (!validationData[key].isValid) {
                        errorArray.push(validationData[key].message);
                    }
                });
                return errorArray;
            };
            _this_1.loginCustomer = function(formData) {
                var _this = _this_1;
                var loginPayload = {};
                loginPayload.form_type = "customer_login";
                loginPayload["customer[email]"] = formData.email;
                loginPayload["customer[password]"] = formData.password;
                _this.ajax.send({
                    endpoint: window.location.protocol + "//" + window.location.hostname + "/account/login",
                    method: "post",
                    contentType: "form",
                    data: loginPayload,
                    callback: function(response) {
                        try {
                            if (response.status == 200) {
                                var redirectUrlResponse = response.responseURL.toString();
                                if (redirectUrlResponse.includes("/account/login")) {
                                    window.location.reload();
                                    _this.revertSubmitButtonToDefault();
                                    _this.notification.showNotification(notification_9.ENotificationType.error, "Server Error", "Incorrect email or password.", 3e3, false);
                                } else {
                                    window.location.assign(redirectUrlResponse);
                                }
                            } else {
                                window.location.reload();
                                _this.revertSubmitButtonToDefault();
                                _this.notification.showNotification(notification_9.ENotificationType.error, "Server Error", "Incorrect email or password.", 3e3, false);
                            }
                        } catch (error) {
                            console.error(error);
                            _this.revertSubmitButtonToDefault();
                            _this.notification.showNotification(notification_9.ENotificationType.error, "Server Error", error);
                        }
                    }
                });
            };
            _this_1.registerCustomer = function(customerPayload) {
                var _this = _this_1;
                _this_1.ajax.send({
                    endpoint: _this_1.endpoint["enrollment"]["createAccount"],
                    method: "post",
                    contentType: "json",
                    data: customerPayload,
                    callback: function(response) {
                        try {
                            _this.loginCustomer(customerPayload);
                        } catch (error) {
                            console.error(error);
                            _this.notification.showNotification(notification_9.ENotificationType.error, "Server Error", error);
                            _this.revertSubmitButtonToDefault();
                        }
                    }
                });
            };
            _this_1.validateAccountCreation = function(form, submitEvent) {
                console.log("sss validateAccountCreation", form);
                var _this = _this_1;
                if (form.classList.contains(_this_1.classConfig.classAccountRegisterFormPreventDefault)) {
                    console.log("sss validateAccountCreation");
                    submitEvent.preventDefault();
                    var formData = _this.form.collectFormData(form);
                    var hiddenAlsInput = form.querySelector(_this_1.classConfig.selectorRepresentativeAlias);
                    if (!(hiddenAlsInput === null || hiddenAlsInput === void 0 ? void 0 : hiddenAlsInput.value) || !_features_config_8.canGoUnderCorporateSite && (hiddenAlsInput === null || hiddenAlsInput === void 0 ? void 0 : hiddenAlsInput.value) === _features_config_8.defaultWebAlias) {
                        _this.notification.showNotification(notification_9.ENotificationType.error, "Validation Error", "Web alias not entered or invalid");
                        _this.revertSubmitButtonToDefault();
                    } else {
                        var payload_1 = {
                            email: formData["customer[email]"],
                            firstName: formData["customer[first_name]"],
                            lastName: formData["customer[last_name]"],
                            password: formData["customer[password]"],
                            sponsorsWebAlias: formData["customer[note][sponsorWebAlias]"]
                        };
                        var passwordInputElement = document.querySelector('input[name="customer[password]"]');
                        var repeatPasswordInputElement = document.querySelector('input[name="repeatPassword"]');
                        if (passwordInputElement.value.length > 40) {
                            _this.notification.showNotification(notification_9.ENotificationType.error, "Validation Error", "Password cannot contain more than 40 characters!");
                            _this.revertSubmitButtonToDefault();
                        } else if (passwordInputElement.value === (repeatPasswordInputElement === null || repeatPasswordInputElement === void 0 ? void 0 : repeatPasswordInputElement.value) || !repeatPasswordInputElement) {
                            _this.ajax.send({
                                endpoint: _this.endpoint["enrollment"]["validate-data"],
                                method: "post",
                                contentType: "json",
                                data: payload_1,
                                callback: function(response) {
                                    try {
                                        var validationResponse = JSON.parse(response.response);
                                        var validationErrors = _this.prepareErrorArray(validationResponse.data);
                                        if (validationErrors.length !== 0) {
                                            _this.notification.showNotification(notification_9.ENotificationType.error, "Validation Error", validationErrors);
                                            _this.revertSubmitButtonToDefault();
                                        } else {
                                            _this.registerCustomer(payload_1);
                                        }
                                    } catch (error) {
                                        console.error(error);
                                        _this.notification.showNotification(notification_9.ENotificationType.error, "Server Error", error);
                                        _this.revertSubmitButtonToDefault();
                                    }
                                }
                            });
                        } else {
                            _this.notification.showNotification(notification_9.ENotificationType.error, "Validation Error", "Passwords not matching!");
                            _this.revertSubmitButtonToDefault();
                        }
                    }
                } else {
                    form.classList.add(_this.classConfig.classAccountRegisterFormPreventDefault);
                }
            };
            _this_1.revertSubmitButtonToDefault = function() {
                var submitBtn = document.querySelector('[type="submit"]');
                if (!!submitBtn) {
                    submitBtn.removeAttribute("aria-busy");
                }
            };
            _this_1.form = form;
            _this_1.notification = notification;
            _this_1.buttonActions = buttonActions;
            _this_1.classConfig = classConfig;
            _this_1.generalMethods = generalMethods;
            return _this_1;
        }
        return StAccountRegister;
    }(st_module_52.StModule);
    exports.StAccountRegister = StAccountRegister;
});

define("core/shopify-app/st-modules/main/auto-apply-promo", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "_features.config", "_features.config"], function(require, exports, st_module_53, _features_config_9, _features_config_10) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAutoApplyPromo = void 0;
    var StAutoApplyPromo = function(_super) {
        __extends(StAutoApplyPromo, _super);

        function StAutoApplyPromo() {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "AutoApplyPromo";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    var _a, _b;
                    var promoCode = (_b = (_a = window.stAppConfig) === null || _a === void 0 ? void 0 : _a.options) === null || _b === void 0 ? void 0 : _b.repPromoCode;
                    if (promoCode) {
                        _this_1.setupRepDiscount(promoCode);
                        _this_1.removeCodeOnLogout(promoCode);
                        if (_features_config_10.shareRefCodeFunctionality) {
                            _this_1.applyRefPromoCode();
                        }
                    }
                });
            };
            _this_1.setupRepDiscount = function(promoCode) {
                var _a, _b;
                document.cookie = "discount_code=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                var repType = (_b = (_a = window.stAppConfig.options) === null || _a === void 0 ? void 0 : _a.customerType) === null || _b === void 0 ? void 0 : _b.representative;
                var currentCustomerType = window.customerInfoMetafields.customerType;
                if (currentCustomerType === repType && _features_config_9.repDiscountWithPromoCode) {
                    _this_1.applyPromoCodeIfNeeded(promoCode);
                }
            };
            _this_1.applyRefPromoCode = function() {
                document.cookie = "discount_code=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                var refCode = localStorage.getItem("ref");
                if (!!refCode || refCode !== "null") {
                    _this_1.applyPromoCodeIfNeeded(refCode);
                }
            };
            _this_1.applyPromoCodeIfNeeded = function(promoCode) {
                if (!_this_1.isRepPromoApplied(promoCode)) {
                    var body = document.querySelector("body");
                    var iframeHolder = document.createElement("div");
                    iframeHolder.classList.add("st-autoapply-promocode");
                    var iframe = document.createElement("iframe");
                    iframe.classList.add("st_hidden");
                    iframe.src = "".concat(window.location.origin, "/discount/").concat(promoCode);
                    iframeHolder.appendChild(iframe);
                    body.insertBefore(iframeHolder, body.firstChild);
                }
            };
            _this_1.isRepPromoApplied = function(promoCode) {
                var alreadyApplied = false;
                var x = document.cookie.split("; ");
                for (var i = 0; i < x.length; i++) {
                    var c = x[i].split("=");
                    if (c[0] === "discount_code" || c[0] === "discount_code" && c[1] === promoCode) {
                        alreadyApplied = true;
                        break;
                    }
                }
                return alreadyApplied;
            };
            _this_1.removeCodeOnLogout = function(promoCode) {
                var _this = _this_1;
                var logoutLinks = document.querySelectorAll('[href*="account/logout"]');
                logoutLinks.forEach(function(logoutLink) {
                    logoutLink.addEventListener("click", function(e) {
                        if (_this.isRepPromoApplied(promoCode)) {
                            document.cookie = "discount_code=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                        }
                    });
                });
            };
            return _this_1;
        }
        return StAutoApplyPromo;
    }(st_module_53.StModule);
    exports.StAutoApplyPromo = StAutoApplyPromo;
});

define("core/shopify-app/st-modules/representative-redirect-page/representative-redirect-page-class-config", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_54) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StRepresentativeRedirectClassConfig = void 0;
    var StRepresentativeRedirectClassConfig = function(_super) {
        __extends(StRepresentativeRedirectClassConfig, _super);

        function StRepresentativeRedirectClassConfig() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "representativeRedirectClassConfig";
            _this.classNameRepRedirectCopyText = "st_copy-repsite_JS";
            _this.selectorRepRedirectIconCopyText = "." + _this.classNameRepRedirectCopyText;
            _this.classNameRepRedirectCopyTextWrapper = "st_copy-repsite--wrapper_JS";
            _this.selectorRepRedirectCopyTextWrapper = "." + _this.classNameRepRedirectCopyTextWrapper;
            _this.classNameRepRedirectLabel = "st_representative-site_JS";
            _this.selectorRepRedirectLabel = "." + _this.classNameRepRedirectLabel;
            return _this;
        }
        return StRepresentativeRedirectClassConfig;
    }(st_module_54.StModule);
    exports.StRepresentativeRedirectClassConfig = StRepresentativeRedirectClassConfig;
});

define("core/shopify-app/st-modules/representative-redirect-page/representative-redirect-page", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_55) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StRepresentativeRedirectPage = void 0;
    var StRepresentativeRedirectPage = function(_super) {
        __extends(StRepresentativeRedirectPage, _super);

        function StRepresentativeRedirectPage(classConfig, generalMethods) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "RepresentativeRedirectPage";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.copyToClipboard();
                });
            };
            _this_1.copyToClipboard = function() {
                var _this = _this_1;
                var copyRepSiteButtonAll = document.querySelectorAll(_this_1.classConfig.selectorRepRedirectIconCopyText);
                if (copyRepSiteButtonAll && copyRepSiteButtonAll.length > 0) {
                    for (var i = 0; i < copyRepSiteButtonAll.length; i++) {
                        var copyRepSiteButton = copyRepSiteButtonAll[i];
                        copyRepSiteButton.addEventListener("click", function(e) {
                            e.preventDefault();
                            var copyText = document.querySelector(_this.classConfig.selectorRepRedirectLabel);
                            if (!!copyText) {
                                var copyText_1 = document.querySelector(_this.classConfig.selectorRepRedirectLabel);
                                copyText_1.select();
                                copyText_1.setSelectionRange(0, 99999);
                                navigator.clipboard.writeText(copyText_1.value);
                                copyText_1.style.backgroundColor = "rgb(217, 218, 220)";
                                copyText_1.style.transition = "0.5s";
                                setTimeout(function() {
                                    copyText_1.style.backgroundColor = "rgb(249, 249, 249)";
                                    copyText_1.style.transition = "0.5s";
                                }, 1e3);
                            }
                        });
                    }
                }
            };
            _this_1.classConfig = classConfig;
            _this_1.generalMethods = generalMethods;
            return _this_1;
        }
        return StRepresentativeRedirectPage;
    }(st_module_55.StModule);
    exports.StRepresentativeRedirectPage = StRepresentativeRedirectPage;
});

define("core/shopify-app/st-modules/account-login/account-login-class-config", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_56) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountLoginClassConfig = void 0;
    var StAccountLoginClassConfig = function(_super) {
        __extends(StAccountLoginClassConfig, _super);

        function StAccountLoginClassConfig() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentAccountClassConfig";
            _this.classLoginPasswordInput = "st_login-password-input_JS";
            _this.selectorLoginPasswordInput = "." + _this.classLoginPasswordInput;
            _this.classLoginPasswordFormControl = "st_login-password-form-control_JS";
            _this.selectorLoginPasswordFormControl = "." + _this.classLoginPasswordFormControl;
            return _this;
        }
        return StAccountLoginClassConfig;
    }(st_module_56.StModule);
    exports.StAccountLoginClassConfig = StAccountLoginClassConfig;
});

define("core/shopify-app/st-modules/account-login/account-login", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_57) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAccountLogin = void 0;
    var StAccountLogin = function(_super) {
        __extends(StAccountLogin, _super);

        function StAccountLogin(form, notification, buttonActions, classConfig, generalMethods) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "AccountLogin";
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {
                    _this.form.liveTrim();
                });
            };
            _this.form = form;
            _this.notification = notification;
            _this.buttonActions = buttonActions;
            _this.classConfig = classConfig;
            _this.generalMethods = generalMethods;
            return _this;
        }
        return StAccountLogin;
    }(st_module_57.StModule);
    exports.StAccountLogin = StAccountLogin;
});

define("core/shopify-app/st-modules/reset-password/reset-password-class-config", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_58) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StResetPasswordClassConfig = void 0;
    var StResetPasswordClassConfig = function(_super) {
        __extends(StResetPasswordClassConfig, _super);

        function StResetPasswordClassConfig() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "ResetPasswordClassConfig";
            _this.classLoginPasswordInput = "st_reset-password-input_JS";
            _this.selectorLoginPasswordInput = "." + _this.classLoginPasswordInput;
            return _this;
        }
        return StResetPasswordClassConfig;
    }(st_module_58.StModule);
    exports.StResetPasswordClassConfig = StResetPasswordClassConfig;
});

define("core/shopify-app/st-modules/reset-password/reset-password", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_59) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StResetPassword = void 0;
    var StResetPassword = function(_super) {
        __extends(StResetPassword, _super);

        function StResetPassword(form, notification, buttonActions, classConfig, generalMethods) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "ResetPassword";
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {
                    _this.form.liveTrim();
                });
            };
            _this.form = form;
            _this.notification = notification;
            _this.buttonActions = buttonActions;
            _this.classConfig = classConfig;
            _this.generalMethods = generalMethods;
            return _this;
        }
        return StResetPassword;
    }(st_module_59.StModule);
    exports.StResetPassword = StResetPassword;
});

define("core/shopify-app/st-modules/referral/referral", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "core/shopify-app/st-modules/_general-methods/notification", "_features.config"], function(require, exports, st_module_60, notification_10, _features_config_11) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StReferral = void 0;
    var StReferral = function(_super) {
        __extends(StReferral, _super);

        function StReferral(generalMethods, objectFormatting, notification) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "Referral";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.checkTags();
                    _this_1.handlerRefBanner();
                });
            };
            _this_1.checkTags = function() {
                if (_features_config_11.shareRefCodeFunctionality) {
                    var customerTagsWrapper = document.querySelector(".st_customer-tags");
                    if (!!customerTagsWrapper) {
                        var tags = customerTagsWrapper.getAttribute("data-tags");
                        var isLogged = customerTagsWrapper.getAttribute("data-customer-id");
                        var splitStr = tags.split(",");
                        var retail = splitStr.find(function(ret) {
                            return ret.includes("retail");
                        });
                        var noOrder = splitStr.find(function(el) {
                            return el.includes("no_order");
                        });
                        if (isLogged) {
                            if (retail && noOrder) {
                                _this_1.getRefFromLink();
                                _this_1.setRefInLink();
                            } else {
                                _this_1.deleteRefCode();
                            }
                        } else {
                            _this_1.getRefFromLink();
                            _this_1.setRefInLink();
                        }
                    }
                } else {
                    _this_1.deleteRefCode();
                    _this_1.hideRef();
                }
            };
            _this_1.getRefFromLink = function() {
                var urlParams = _this_1.objectFormatting.convertQueryStringToObject(window.location.search);
                var ref = urlParams.ref;
                if (!!ref) {
                    localStorage.setItem("ref", ref);
                }
            };
            _this_1.getCode = function() {
                var tagFromNav = document.querySelector(".st_referral-code-div_JS");
                if (!!tagFromNav) {
                    return tagFromNav.getAttribute("data-customer-tags");
                }
            };
            _this_1.setRefInLink = function() {
                var refCode = localStorage.getItem("ref");
                var refCodeFromTag = _this_1.getCode();
                if (!refCode || refCode === "null" || refCode === " " || refCode === "undefined" || refCode === "") {
                    _this_1.deleteRefCode();
                } else {
                    if (refCode === refCodeFromTag) {
                        _this_1.deleteRefCode();
                    } else {
                        var params = new URLSearchParams(window.location.search);
                        if (!params.get("ref")) {
                            params.append("ref", refCode);
                        }
                        var newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname + "?" + params;
                        window.history.replaceState({
                            path: newUrl
                        }, "", newUrl);
                    }
                }
            };
            _this_1.deleteRefCode = function() {
                var params = new URLSearchParams(window.location.search);
                params.delete("ref");
                var newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
                if (!!params.toString()) {
                    newUrl += "?" + params;
                }
                window.history.replaceState({
                    path: newUrl
                }, "", newUrl);
                localStorage.removeItem("ref");
            };
            _this_1.handlerRefBanner = function() {
                var urlParams = _this_1.objectFormatting.convertQueryStringToObject(window.location.search);
                var ref = urlParams.ref;
                if (_features_config_11.shareRefCodeFunctionality) {
                    if (!!ref) {
                        _this_1.getReferralsData();
                    } else {
                        _this_1.hideRef();
                    }
                } else {
                    _this_1.hideRef();
                }
            };
            _this_1.showRef = function() {
                var refWrapper = document.querySelector(".st_referred-by-banner_JS");
                if (!!refWrapper) {
                    if (refWrapper.classList.contains("st_hidden")) {
                        refWrapper.classList.remove("st_hidden");
                    }
                }
            };
            _this_1.hideRef = function() {
                var refWrapper = document.querySelector(".st_referred-by-banner_JS");
                if (!!refWrapper) {
                    if (!refWrapper.classList.contains("st_hidden")) {
                        refWrapper.classList.add("st_hidden");
                    }
                }
            };
            _this_1.getReferralsData = function() {
                var _this = _this_1;
                var referralCode = localStorage.getItem("ref");
                var urlParams = _this_1.objectFormatting.convertQueryStringToObject(window.location.search);
                var currentAlias = urlParams[_features_config_11.aliasQueryParam];
                var refCode = {
                    promoCode: referralCode,
                    webAlias: currentAlias
                };
                _this_1.ajax.send({
                    endpoint: _this_1.endpoint["customer"]["getReferralInfo"],
                    method: "post",
                    contentType: "json",
                    data: refCode,
                    callback: function(response) {
                        try {
                            var getReferralInfo = JSON.parse(response.response);
                            if (getReferralInfo.status === 200) {
                                var refType = getReferralInfo.data.customerType;
                                if (refType === "retail") {
                                    _this.showRef();
                                    var fullname = getReferralInfo.data.firstName + " " + getReferralInfo.data.lastName;
                                    _this.writeRefName(fullname);
                                    if (getReferralInfo.data.customerSponsorMatch === false) {
                                        _this.deleteRefCode();
                                        _this.hideRef();
                                    }
                                }
                                if (refType === "representative") {
                                    if (getReferralInfo.data.customerSponsorMatch === false) {
                                        _this.deleteRefCode();
                                        _this.hideRef();
                                    }
                                }
                                if (refType === "") {
                                    console.log("INVALID REF CODE !!!!!!!!!!!");
                                    _this.deleteRefCode();
                                    _this.hideRef();
                                }
                            } else {
                                _this.notification.showNotification(notification_10.ENotificationType.error, "An Error Occurred", getReferralInfo.message);
                            }
                        } catch (error) {
                            console.error(error);
                            _this.notification.showNotification(notification_10.ENotificationType.error, "Server Error", error);
                        }
                    }
                });
            };
            _this_1.writeRefName = function(fullname) {
                var refNameSpan = document.querySelector(".st_referral-fullname_JS");
                if (!!refNameSpan) {
                    refNameSpan.innerHTML = fullname;
                }
            };
            _this_1.generalMethods = generalMethods;
            _this_1.objectFormatting = objectFormatting;
            _this_1.notification = notification;
            return _this_1;
        }
        return StReferral;
    }(st_module_60.StModule);
    exports.StReferral = StReferral;
});

define("core/shopify-app/st-modules/account/blocks/coupon-codes/coupon-codes", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module", "_features.config"], function(require, exports, st_module_61, _features_config_12) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StCouponCodes = void 0;
    var StCouponCodes = function(_super) {
        __extends(StCouponCodes, _super);

        function StCouponCodes() {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "CouponCodes";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.blockHandle();
                });
            };
            _this_1.blockHandle = function() {
                var mainWrapper = document.querySelector(".st_account-coupon-codes_wrapper_JS");
                if (!!mainWrapper) {
                    if (_features_config_12.shareRefCodeFunctionality) {
                        mainWrapper.classList.remove("st_hidden");
                        _this_1.toggleInputs();
                        _this_1.copyCode();
                        _this_1.earnedCouponCodes();
                        _this_1.redeemedCouponCodes();
                        var showInactive = false;
                        _this_1.filterStatus(showInactive);
                    } else {
                        mainWrapper.classList.add("st_hidden");
                    }
                }
            };
            _this_1.toggleInputs = function() {
                var _this = _this_1;
                var showCodeBtnField = document.querySelectorAll(".st_coupon-codes-table-codes_JS");
                if (!!showCodeBtnField) {
                    showCodeBtnField.forEach(function(el) {
                        var showCodeBtn = el.querySelector(".st_table-show-coupon_JS");
                        showCodeBtn.addEventListener("click", function(e) {
                            e.preventDefault();
                            _this.showCode(el);
                        });
                    });
                }
            };
            _this_1.showCode = function(el) {
                var showCodeBtnWrapper = el.querySelector(".st_table-coupon-code-show-wrapper_JS");
                var codeWrapper = el.querySelector(".st_table-coupon-code-input-wrapper_JS");
                if (!!showCodeBtnWrapper && !!codeWrapper) {
                    showCodeBtnWrapper.classList.add("st_hidden");
                    codeWrapper.classList.remove("st_hidden");
                }
            };
            _this_1.copyCode = function() {
                var showCodeBtnField = document.querySelectorAll(".st_coupon-codes-table-codes_JS");
                if (!!showCodeBtnField) {
                    showCodeBtnField.forEach(function(el) {
                        var copyCodeBtn = el.querySelector(".st_table-copy-coupon_JS");
                        if (!!copyCodeBtn) {
                            copyCodeBtn.addEventListener("click", function() {
                                var input = el.querySelector(".st_table-coupon-code_JS");
                                if (!!input) {
                                    input.select();
                                    input.setSelectionRange(0, 99999);
                                    navigator.clipboard.writeText(input.value);
                                    input.style.backgroundColor = "rgb(217, 218, 220)";
                                    input.style.transition = "0.2s";
                                    setTimeout(function() {
                                        input.style.backgroundColor = "rgb(249, 249, 249)";
                                    }, 1e3);
                                }
                            });
                        }
                    });
                }
            };
            _this_1.earnedCouponCodes = function() {
                var _this = _this_1;
                var earnedBtn = document.querySelector(".st_earned-coupon-codes_JS");
                if (!!earnedBtn) {
                    earnedBtn.addEventListener("click", function(e) {
                        e.preventDefault();
                        var flag = false;
                        _this.filterStatus(flag);
                    });
                }
            };
            _this_1.redeemedCouponCodes = function() {
                var _this = _this_1;
                var redeemedBtn = document.querySelector(".st_redeemed-coupon-codes_JS");
                if (!!redeemedBtn) {
                    redeemedBtn.addEventListener("click", function(e) {
                        e.preventDefault();
                        var flag = true;
                        _this.filterStatus(flag);
                    });
                }
            };
            _this_1.filterStatus = function(flag) {
                var _this = _this_1;
                var tableRows = document.querySelectorAll(".st_coupon-codes-table-row_JS");
                if (!!tableRows) {
                    tableRows.forEach(function(el) {
                        var couponStatusEl = el.querySelector(".st_coupon-codes-table-status_JS");
                        var status = couponStatusEl.getAttribute("data-status");
                        if (flag) {
                            if (status === "Active") {
                                el.classList.add("st_hidden");
                            } else {
                                el.classList.remove("st_hidden");
                            }
                        } else {
                            if (status === "Active") {
                                el.classList.remove("st_hidden");
                            } else {
                                el.classList.add("st_hidden");
                            }
                        }
                        _this.adjustTableHeader(flag);
                        _this.adjustTableForInactive(status, el);
                    });
                }
            };
            _this_1.adjustTableForInactive = function(status, el) {
                var copyBtn = el.querySelector(".st_table-copy-coupon_JS");
                var columnNameEl = document.querySelector(".st_table-head-actions_JS");
                if (!!columnNameEl) {
                    if (status === "Active") {
                        copyBtn.classList.remove("st_hidden");
                    } else {
                        copyBtn.classList.add("st_hidden");
                        _this_1.showCode(el);
                    }
                }
            };
            _this_1.adjustTableHeader = function(flag) {
                var columnNameEl = document.querySelector(".st_table-head-actions_JS");
                if (!!columnNameEl) {
                    if (flag) {
                        columnNameEl.innerHTML = "Used Promo Code";
                    } else {
                        columnNameEl.innerHTML = "Actions";
                    }
                }
            };
            return _this_1;
        }
        return StCouponCodes;
    }(st_module_61.StModule);
    exports.StCouponCodes = StCouponCodes;
});

define("extension/shopify-app/st-modules/enrollment/blocks/addresses/enrollment-addresses", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_62) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentAddresses = void 0;
    var StEnrollmentAddresses = function(_super) {
        __extends(StEnrollmentAddresses, _super);

        function StEnrollmentAddresses(formatting, store) {
            var _this_1 = _super.call(this, arguments) || this;
            _this_1.className = "EnrollmentAddresses";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.formattingZipCode();
                    _this_1.createFullAddress();
                    _this_1.collectAddress();
                });
            };
            _this_1.usZipFormat = function(zip) {
                var zipNumb = ("" + zip).replace(/\D/g, "");
                return zipNumb.slice(0, 5);
            };
            _this_1.formattingZipCode = function() {
                var enrollmentAddressesWrapper = document.querySelector(".st-enrollment-addresses-main-wrapper_JS");
                if (!!enrollmentAddressesWrapper) {
                    var zipInput = enrollmentAddressesWrapper.querySelectorAll('input[name="zipCode"]');
                    _this_1.formFormatting.setupFormatting(zipInput, _this_1.usZipFormat);
                }
            };
            _this_1.createFullAddress = function() {
                var _this = _this_1;
                var addressInputSelectors = [];
                var enrollmentAddressesWrapper = document.querySelector(".st-enrollment-addresses-main-wrapper_JS");
                if (!!enrollmentAddressesWrapper) {
                    var addressInput = enrollmentAddressesWrapper.querySelector('input[name="address"]');
                    addressInputSelectors.push(addressInput);
                    var address2Input = enrollmentAddressesWrapper.querySelector('input[name="address2"]');
                    addressInputSelectors.push(address2Input);
                    var cityInput = enrollmentAddressesWrapper.querySelector('input[name="city"]');
                    addressInputSelectors.push(cityInput);
                    var zipInput = enrollmentAddressesWrapper.querySelector('input[name="zipCode"]');
                    addressInputSelectors.push(zipInput);
                    var stateSelectEl_1 = document.querySelector(".st_enrollment-addresses-state-select_JS");
                    var stateInput_1 = enrollmentAddressesWrapper.querySelector('input[name="state"]');
                    var selectedState_1 = stateSelectEl_1.value;
                    stateInput_1.setAttribute("value", selectedState_1);
                    addressInputSelectors.push(stateInput_1);
                    var selectElement_1 = enrollmentAddressesWrapper.querySelector(".st_enrollment-addresses-country-select_JS");
                    var countryInput = enrollmentAddressesWrapper.querySelector('input[name="country"]');
                    var selectedCountry_1 = selectElement_1.value;
                    countryInput.setAttribute("value", selectedCountry_1);
                    _this_1.hideStateField(selectedCountry_1);
                    addressInputSelectors.push(countryInput);
                    var fullValue = "" + (addressInput.value !== "" && addressInput.value ? addressInput.value + "," : "") + (address2Input.value !== "" && address2Input.value ? " " + address2Input.value : "") + (cityInput.value !== "" && cityInput.value ? " " + cityInput.value + "," : "") + (zipInput.value !== "" && zipInput.value ? " " + zipInput.value + "," : "") + (selectedState_1 !== "" && selectedState_1 ? " " + selectedState_1 + "," : "") + (selectedCountry_1 !== "" && selectedCountry_1 ? " " + selectedCountry_1 : "");
                    var fullAddressInput = document.querySelector('input[name="fullAddress"]');
                    fullAddressInput.value = fullValue;
                    addressInputSelectors.forEach(function(input) {
                        var inputVal = input.value;
                        input.value = inputVal;
                        input.setAttribute("value", inputVal);
                        selectElement_1 === null || selectElement_1 === void 0 ? void 0 : selectElement_1.addEventListener("change", function(e) {
                            e.preventDefault();
                            selectedCountry_1 = selectElement_1.options[selectElement_1.selectedIndex].value;
                            var selectCountryInput = enrollmentAddressesWrapper.querySelector(".st_enrollment_address_country_JS");
                            selectCountryInput.setAttribute("value", selectedCountry_1);
                            selectCountryInput.value = selectedCountry_1;
                            _this.hideStateField(selectedCountry_1);
                            var fullAddress = _this.collectAddress();
                            _this.updateFullAddress(fullAddress);
                        });
                        stateSelectEl_1 === null || stateSelectEl_1 === void 0 ? void 0 : stateSelectEl_1.addEventListener("change", function(e) {
                            e.preventDefault();
                            selectedState_1 = stateSelectEl_1.options[stateSelectEl_1.selectedIndex].value;
                            stateInput_1.setAttribute("value", selectedState_1);
                            stateInput_1.value = selectedState_1;
                            var fullAddress = _this.collectAddress();
                            _this.updateFullAddress(fullAddress);
                        });
                        input.addEventListener("input", function(e) {
                            _this.formattingZipCode();
                            var fullAddress = _this.collectAddress();
                            _this.updateFullAddress(fullAddress);
                        });
                        input.addEventListener("keyup", function(e) {
                            _this.formattingZipCode();
                            var fullAddress = _this.collectAddress();
                            _this.updateFullAddress(fullAddress);
                        });
                        input.addEventListener("paste", function(e) {
                            _this.formattingZipCode();
                            var fullAddress = _this.collectAddress();
                            _this.updateFullAddress(fullAddress);
                        });
                    });
                }
            };
            _this_1.hideStateField = function(countryValue) {
                var stateWrp = document.querySelector(".st_state-wrp_JS");
                var stateInput = document.querySelector(".st_enrollment_address_state_JS");
                if (!!stateWrp) {
                    if (countryValue === "United States") {
                        stateWrp.classList.remove("st_hidden");
                        stateInput.setAttribute("required", "required");
                    } else {
                        stateWrp.classList.add("st_hidden");
                        stateInput.value = "";
                        stateInput.removeAttribute("required");
                    }
                }
            };
            _this_1.updateFullAddress = function(fullAddress) {
                var _this = _this_1;
                var fullAddressInput = document.querySelector('input[name="fullAddress"]');
                if (!!fullAddressInput) {
                    fullAddressInput.value = _this_1.collectAddress();
                    fullAddressInput.setAttribute("value", _this.collectAddress());
                    var changeFullAddressEvt = new CustomEvent("change");
                    fullAddressInput.dispatchEvent(changeFullAddressEvt);
                    fullAddressInput.addEventListener("paste", function(e) {
                        fullAddressInput.value = _this.collectAddress();
                        fullAddressInput.setAttribute("value", _this.collectAddress());
                    });
                    fullAddressInput.addEventListener("input", function(e) {
                        fullAddressInput.value = _this.collectAddress();
                        fullAddressInput.setAttribute("value", _this.collectAddress());
                    });
                }
            };
            _this_1.collectAddress = function() {
                var enrollmentAddressesWrapper = document.querySelector(".st-enrollment-addresses-main-wrapper_JS");
                if (!!enrollmentAddressesWrapper) {
                    var addressInput = enrollmentAddressesWrapper.querySelector('input[name="address"]');
                    var address2Input = enrollmentAddressesWrapper.querySelector('input[name="address2"]');
                    var cityInput = enrollmentAddressesWrapper.querySelector('input[name="city"]');
                    var zipInput = enrollmentAddressesWrapper.querySelector('input[name="zipCode"]');
                    var stateInput = enrollmentAddressesWrapper.querySelector('input[name="state"]');
                    var countryInput = enrollmentAddressesWrapper.querySelector('input[name="country"]');
                    if (addressInput && address2Input && cityInput && zipInput && stateInput && countryInput) {
                        return [addressInput.value, address2Input.value, cityInput.value, zipInput.value, stateInput.value, countryInput.value].reduce(function(accumulatedAddress, current) {
                            var output = accumulatedAddress;
                            if (current !== "") {
                                if (accumulatedAddress !== "") {
                                    output += ", ";
                                }
                                output += current;
                            }
                            return output;
                        }, "");
                    } {
                        console.error("Address source inputs for enrollment-addresses.collectAddress do not exist. Full address returns empty string");
                        return "";
                    }
                }
            };
            _this_1.formFormatting = formatting;
            _this_1.store = store;
            return _this_1;
        }
        return StEnrollmentAddresses;
    }(st_module_62.StModule);
    exports.StEnrollmentAddresses = StEnrollmentAddresses;
});

define("extension/shopify-app/st-modules/enrollment/blocks/business-info/enrollment-section-business-details", ["require", "exports", "core/shopify-app/st-modules/enrollment/_validation/enrollment-section-validation-base"], function(require, exports, enrollment_section_validation_base_4) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentSectionBusinessDetailsExtended = void 0;
    var StEnrollmentSectionBusinessDetailsExtended = function(_super) {
        __extends(StEnrollmentSectionBusinessDetailsExtended, _super);

        function StEnrollmentSectionBusinessDetailsExtended() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentBusinessDetails";
            _this.validationName = "business-details";
            _this.addToBasicValidation = function() {
                return ["webAlias"];
            };
            _this.validateOnServer = function() {
                return ["webAlias"];
            };
            return _this;
        }
        return StEnrollmentSectionBusinessDetailsExtended;
    }(enrollment_section_validation_base_4.StEnrollmentSectionBase);
    exports.StEnrollmentSectionBusinessDetailsExtended = StEnrollmentSectionBusinessDetailsExtended;
});

define("extension/shopify-app/st-modules/enrollment/blocks/business-info/business-details-helpers-extension", ["require", "exports", "core/shopify-app/st-modules/enrollment/blocks/business-info/business-details-helpers"], function(require, exports, business_details_helpers_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentBusinessDetailsHelpersExtension = void 0;
    var StEnrollmentBusinessDetailsHelpersExtension = function(_super) {
        __extends(StEnrollmentBusinessDetailsHelpersExtension, _super);

        function StEnrollmentBusinessDetailsHelpersExtension(formatting, classConfig) {
            var _this = _super.call(this, formatting, classConfig) || this;
            _this.className = "BusinessDetailsHelpers";
            _this.init = function() {
                _this.subscribeDOMLoaded(function() {
                    _this.setupWebAliasFormatting();
                    _this.setupSSNFormatting();
                    _this.updateSelectValue();
                });
            };
            _this.updateSelectValue = function() {
                var selectEntity = document.querySelector(".st_enrollment-entity-select_JS");
                var inputEntity = document.querySelector(".st_enrollment-entity-input_JS");
                if (!!selectEntity && inputEntity) {
                    var selectedEntity_1 = selectEntity.options[selectEntity.selectedIndex].value;
                    inputEntity.value = selectedEntity_1;
                    inputEntity.value = selectedEntity_1;
                    inputEntity.setAttribute("value", selectedEntity_1);
                    selectEntity.addEventListener("change", function(e) {
                        e.preventDefault();
                        selectedEntity_1 = selectEntity.options[selectEntity.selectedIndex].value;
                        inputEntity.value = selectedEntity_1;
                        inputEntity.setAttribute("value", selectedEntity_1);
                    });
                }
            };
            _this.formFormatting = formatting;
            _this.classConfig = classConfig;
            return _this;
        }
        return StEnrollmentBusinessDetailsHelpersExtension;
    }(business_details_helpers_1.StEnrollmentBusinessDetailsHelpers);
    exports.StEnrollmentBusinessDetailsHelpersExtension = StEnrollmentBusinessDetailsHelpersExtension;
});

define("extension/connector-app/_shared/models/enrollment/enrollment-submit/enrollment.submit.request.model.extended", ["require", "exports"], function(require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});

define("extension/shopify-app/st-modules/enrollment/page-header/nav/enrollment-nav", ["require", "exports", "core/shopify-app/st-modules/enrollment/page-header/nav/enrollment-nav", "core/shopify-app/st-modules/_general-methods/button/button-actions", "core/shopify-app/st-modules/_general-methods/notification"], function(require, exports, enrollment_nav_1, button_actions_2, notification_11) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentNavExtended = void 0;
    var IEnrollmentSectionValidationResponseExtended = function() {
        function IEnrollmentSectionValidationResponseExtended() {}
        return IEnrollmentSectionValidationResponseExtended;
    }();
    var StEnrollmentNavExtended = function(_super) {
        __extends(StEnrollmentNavExtended, _super);

        function StEnrollmentNavExtended(classConfig, actions, optionalKits, requiredKits, store, form, buttonActions, enrollmentValidation, enrollmentValidationSetup, notification, enrollmentReview, enrollmentPage) {
            var _this_1 = _super.call(this, classConfig, actions, optionalKits, requiredKits, store, form, buttonActions, enrollmentValidation, enrollmentValidationSetup, notification, enrollmentReview, enrollmentPage) || this;
            _this_1.className = "EnrollmentNav";
            _this_1.init = function() {
                _this_1.subscribeDOMLoaded(function() {
                    _this_1.setupNavPages();
                    _this_1.setupButtons();
                    _this_1.setupOptionalBundles();
                    _this_1.setupBasicValidation();
                });
            };
            _this_1.setupButtons = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var pages = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPage);
                if (pages.length > 0) {
                    _this_1.enrollmentPage.setMaxPage(pages.length);
                    _this_1.enrollmentPage.setupPageIndex(pages);
                    _this_1.enrollmentReview.setupReview();
                    _this_1.openPage(_this_1.enrollmentPage.getCurrentIndex());
                    if (!!wrp) {
                        _this_1.bindEvents(wrp);
                    } else {
                        console.error("Enrollment wrapper does not exist! Cannot setup enrollment nav.");
                    }
                } else {
                    console.error("Enrollment doesn't have a page! Can't init enrollment!");
                }
            };
            _this_1.openPage = function(pageIndex) {
                _this_1.enrollmentPage.openPage(pageIndex);
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var prevButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPrev);
                if (pageIndex === 0) {
                    prevButtons.forEach(function(button) {
                        button.classList.add("st_hidden");
                    });
                } else {
                    prevButtons.forEach(function(button) {
                        button.classList.remove("st_hidden");
                    });
                }
            };
            _this_1.bindEvents = function(wrp) {
                var _this = _this_1;
                var nextButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentNext);
                var prevButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPrev);
                nextButtons.forEach(function(nextButton) {
                    nextButton.addEventListener("click", function(e) {
                        e.preventDefault();
                        if (!_this.buttonActions.isDisabled(this)) {
                            _this.nextOrSubmit();
                        }
                    });
                });
                prevButtons.forEach(function(prevButton) {
                    prevButton.addEventListener("click", function(e) {
                        e.preventDefault();
                        _this.prev();
                    });
                });
            };
            _this_1.setupOptionalBundles = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var optionalBundleTriggers = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentOptionalKitsTrigger);
                _this_1.optionalKits.setupButtons(optionalBundleTriggers);
            };
            _this_1.nextOrSubmit = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var enrollmentPages = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPage);
                var currentPage = enrollmentPages[_this_1.enrollmentPage.getCurrentIndex()];
                var forms = currentPage.querySelectorAll(_this_1.classConfig.selectorEnrollmentForm);
                var shopifyIdHolder = wrp.querySelector('[name="shopifyId"]');
                var shopifyId = parseInt(shopifyIdHolder.value);
                var serverValidationParams = {
                    shopifyId: shopifyId
                };
                var onSiteValidationFunctions = [];
                var validation = _this_1.enrollmentValidation.getValidation();
                var dataToSave = {};
                _this_1.enrollmentValidation.clearInvalid(currentPage);
                forms.forEach(function(form) {
                    var sectionName = form.getAttribute("data-name");
                    if (!!sectionName && sectionName !== "") {
                        var formData_2 = _this_1.form.collectFormData(form);
                        var paramsToValidate_2 = {};
                        dataToSave = __assign(__assign({}, dataToSave), formData_2);
                        console.log("data to save ", dataToSave);
                        if (validation.hasOwnProperty(sectionName)) {
                            var backendParamNames = validation[sectionName].server();
                            backendParamNames.forEach(function(param) {
                                if (typeof paramsToValidate_2[param] !== "undefined") {
                                    console.error("Duplicate setup of param with name: ".concat(param));
                                }
                                paramsToValidate_2[param] = formData_2[param];
                            });
                            serverValidationParams = __assign(__assign({}, serverValidationParams), paramsToValidate_2);
                            onSiteValidationFunctions.push(validation[sectionName].site);
                        } else {
                            console.log('Enrollment block with name "'.concat(sectionName, '" does not have registered validation class. Skipping validation.'));
                        }
                    }
                });
                var joinedValidationResponse = {};
                var nextButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentNext);
                var prevButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPrev);
                _this_1.buttonActions.applyToMultiple(nextButtons, button_actions_2.EButtonAction.prevent);
                _this_1.buttonActions.applyToMultiple(prevButtons, button_actions_2.EButtonAction.prevent);
                if (Object.keys(serverValidationParams).length > 0) {
                    _this_1.enrollmentValidation.serverValidate(serverValidationParams, function(response, validation) {
                        joinedValidationResponse = _this_1.validateOnSite(__assign({}, validation.data), onSiteValidationFunctions);
                        _this_1.afterValidation(joinedValidationResponse, dataToSave, currentPage);
                    }, function(error) {
                        console.error("An error occurred with status: ".concat(error.status, ". Message: ").concat(error.message));
                        _this_1.buttonActions.applyToMultiple(nextButtons, button_actions_2.EButtonAction.allow);
                        _this_1.buttonActions.applyToMultiple(prevButtons, button_actions_2.EButtonAction.allow);
                    });
                } else {
                    joinedValidationResponse = _this_1.validateOnSite(joinedValidationResponse, onSiteValidationFunctions);
                    _this_1.afterValidation(joinedValidationResponse, dataToSave, currentPage);
                }
            };
            _this_1.validateOnSite = function(joinedValidationResponse, onSiteValidationFunctions) {
                if (onSiteValidationFunctions === void 0) {
                    onSiteValidationFunctions = [];
                }
                var output = joinedValidationResponse;
                onSiteValidationFunctions.forEach(function(paramValidationFunction) {
                    output = __assign(__assign({}, output), paramValidationFunction());
                });
                return output;
            };
            _this_1.afterValidation = function(validationResponse, dataToSave, page) {
                if (Object.keys(validationResponse).length > 0) {
                    var hasInvalid_2 = false;
                    var errorMessage_2 = [];
                    Object.keys(validationResponse).forEach(function(paramName) {
                        if (!validationResponse[paramName].isValid) {
                            _this_1.enrollmentValidation.markInvalid(page, paramName);
                            hasInvalid_2 = true;
                            errorMessage_2.push(validationResponse[paramName].message);
                        }
                    });
                    if (hasInvalid_2) {
                        _this_1.notification.showNotification(notification_11.ENotificationType.error, "Some fields are invalid!", errorMessage_2);
                        var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                        var nextButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentNext);
                        var prevButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPrev);
                        _this_1.buttonActions.applyToMultiple(nextButtons, button_actions_2.EButtonAction.allow);
                        _this_1.buttonActions.applyToMultiple(prevButtons, button_actions_2.EButtonAction.allow);
                    } else {
                        _this_1.store.saveData(dataToSave);
                        _this_1.next();
                    }
                } else {
                    _this_1.store.saveData(dataToSave);
                    _this_1.next();
                }
            };
            _this_1.setupBasicValidation = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var paramNames = [];
                var validation = _this_1.enrollmentValidation.getValidation();
                var allFormNames = Object.keys(validation);
                allFormNames.forEach(function(formName) {
                    if (validation[formName]) {
                        paramNames = paramNames.concat(validation[formName].basic());
                    }
                });
                for (var i = 0; i < paramNames.length; i++) {
                    var param = paramNames[i];
                    var input = wrp.querySelector('[name="'.concat(param, '"]'));
                    _this_1.enrollmentValidation.setupBasicValidationEvents(input, _this_1.afterBasicValidation);
                }
            };
            _this_1.afterBasicValidation = function(valid) {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var nextButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentNext);
                if (valid) {
                    nextButtons.forEach(function(nextButton) {
                        _this_1.buttonActions.enable(nextButton);
                    });
                } else {
                    nextButtons.forEach(function(nextButton) {
                        _this_1.buttonActions.disable(nextButton);
                    });
                }
            };
            _this_1.next = function() {
                var currentIndex = _this_1.enrollmentPage.getCurrentIndex();
                if (currentIndex + 1 < _this_1.enrollmentPage.getMaxPage()) {
                    _this_1.enrollmentPage.setCurrentIndex(currentIndex + 1);
                    _this_1.openPage(currentIndex + 1);
                    var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                    var nextButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentNext);
                    var prevButtons = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPrev);
                    _this_1.buttonActions.applyToMultiple(nextButtons, button_actions_2.EButtonAction.allow);
                    _this_1.buttonActions.applyToMultiple(prevButtons, button_actions_2.EButtonAction.allow);
                } else {
                    var data = _this_1.store.loadData();
                    console.log("DATAAAAAAAAAAAAAAAAAAAAAAA", data);
                    var items = data.requiredKits ? _this_1.requiredKits.format(data.requiredKits) : [];
                    items = data.optionalKits ? items.concat(data.optionalKits) : items;
                    var submit = {
                        shopifyId: data.shopifyId,
                        firstName: data.firstName,
                        lastName: data.lastName,
                        phoneNumber: data.phoneNumber,
                        webAlias: data.webAlias,
                        sponsorsWebAlias: data.sponsorsWebAlias,
                        dateOfBirth: data.dateOfBirth,
                        SSN: data.SSN,
                        items: items,
                        address: data.address,
                        address2: data.address2,
                        city: data.city,
                        country: data.country,
                        zipCode: data.zipCode,
                        state: data.state,
                        entity: data.entity,
                        receiveNotifications: true
                    };
                    _this_1.actions.submit(submit);
                }
            };
            _this_1.prev = function() {
                var currentIndex = _this_1.enrollmentPage.getCurrentIndex();
                if (currentIndex - 1 >= 0) {
                    _this_1.enrollmentPage.setCurrentIndex(currentIndex - 1);
                    _this_1.openPage(currentIndex - 1);
                }
            };
            _this_1.setupNavPages = function() {
                var wrp = document.querySelector(_this_1.classConfig.selectorEnrollmentWrapper);
                var pages = wrp.querySelectorAll(_this_1.classConfig.selectorEnrollmentPage);
                var navHolder = wrp.querySelector(_this_1.classConfig.selectorEnrollmentNavHolder);
                if (!!navHolder) {
                    if (pages.length > 1) {
                        pages.forEach(function(page, pageIndex) {
                            var templateName = page.getAttribute("data-name");
                            var isActive = pageIndex === 0;
                            navHolder.appendChild(_this_1.navPageTemplate(pageIndex, templateName, isActive));
                        });
                    } else {
                        var navWrp = wrp.querySelector(_this_1.classConfig.selectorEnrollmentNavWrapper);
                        if (navWrp) {
                            navWrp.classList.add(_this_1.classConfig.classNameElementHide);
                        }
                    }
                } else {
                    console.error("Enrollment Nav holder not present! Navigation won't setup");
                }
            };
            _this_1.navPageTemplate = function(pageIndex, templateName, isActive) {
                if (templateName === void 0) {
                    templateName = "";
                }
                var templateNode;
                templateNode = document.createElement("div");
                templateNode.classList.add("st_header-enrollment-single-column");
                templateNode.classList.add(_this_1.classConfig.classNameEnrollmentNavHolderSingle);
                if (isActive) {
                    templateNode.classList.add("active");
                }
                var innerWrapper = document.createElement("div");
                innerWrapper.classList.add("st_flex");
                innerWrapper.classList.add("st_align");
                var button = document.createElement("button");
                button.classList.add("st_header-navigation-enrollment");
                button.classList.add(_this_1.classConfig.selectorEnrollmentNavButton);
                button.setAttribute("data-index", "".concat(pageIndex));
                var text = document.createElement("span");
                text.classList.add("st_header-text");
                text.innerHTML = templateName;
                var pageNumber = document.createElement("span");
                pageNumber.classList.add("st_number");
                pageNumber.innerHTML = "" + (pageIndex + 1);
                button.appendChild(pageNumber);
                innerWrapper.appendChild(button);
                innerWrapper.appendChild(text);
                templateNode.appendChild(innerWrapper);
                return templateNode;
            };
            _this_1.classConfig = classConfig;
            _this_1.actions = actions;
            _this_1.optionalKits = optionalKits;
            _this_1.requiredKits = requiredKits;
            _this_1.store = store;
            _this_1.form = form;
            _this_1.buttonActions = buttonActions;
            _this_1.enrollmentValidation = enrollmentValidation;
            _this_1.enrollmentValidationSetup = enrollmentValidationSetup;
            _this_1.notification = notification;
            _this_1.enrollmentReview = enrollmentReview;
            _this_1.enrollmentPage = enrollmentPage;
            _this_1.enrollmentValidationSetup.setupValidation();
            return _this_1;
        }
        return StEnrollmentNavExtended;
    }(enrollment_nav_1.StEnrollmentNav);
    exports.StEnrollmentNavExtended = StEnrollmentNavExtended;
});

define("extension/shopify-app/st-modules/enrollment/blocks/addresses/enrollment-section-addresses", ["require", "exports", "core/shopify-app/st-modules/enrollment/_validation/enrollment-section-validation-base"], function(require, exports, enrollment_section_validation_base_5) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentSectionAddresses = void 0;
    var StEnrollmentSectionAddresses = function(_super) {
        __extends(StEnrollmentSectionAddresses, _super);

        function StEnrollmentSectionAddresses() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "EnrollmentSectionAddresses";
            _this.validationName = "addresses";
            _this.addToBasicValidation = function() {
                return ["address", "city", "zipCode", "state", "country"];
            };
            return _this;
        }
        return StEnrollmentSectionAddresses;
    }(enrollment_section_validation_base_5.StEnrollmentSectionBase);
    exports.StEnrollmentSectionAddresses = StEnrollmentSectionAddresses;
});

define("extension/shopify-app/st-modules/enrollment/_validation/enrollment-validation-setup", ["require", "exports", "core/shopify-app/st-modules/enrollment/_validation/enrollment-validation-setup"], function(require, exports, enrollment_validation_setup_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentValidationSetupExtended = void 0;
    var StEnrollmentValidationSetupExtended = function(_super) {
        __extends(StEnrollmentValidationSetupExtended, _super);

        function StEnrollmentValidationSetupExtended(enrollmentValidation, sectionPrivacy, sectionAccountDetails, sectionBusinessDetails, sectionAddresses) {
            var _this = _super.call(this, enrollmentValidation, sectionPrivacy, sectionAccountDetails, sectionBusinessDetails) || this;
            _this.className = "EnrollmentValidationSetup";
            _this.setupValidation = function() {
                _this.enrollmentValidation.setupValidation([_this.sectionPrivacy, _this.sectionAccountDetails, _this.sectionBusinessDetails, _this.sectionAddresses]);
            };
            _this.enrollmentValidation = enrollmentValidation;
            _this.sectionPrivacy = sectionPrivacy;
            _this.sectionAccountDetails = sectionAccountDetails;
            _this.sectionBusinessDetails = sectionBusinessDetails;
            _this.sectionAddresses = sectionAddresses;
            return _this;
        }
        return StEnrollmentValidationSetupExtended;
    }(enrollment_validation_setup_1.StEnrollmentValidationSetup);
    exports.StEnrollmentValidationSetupExtended = StEnrollmentValidationSetupExtended;
});

define("_shopify.app.di.container", ["require", "exports", "core/shopify-app/st-modules/_static/static", "core/shopify-app/st-modules/webalias/webalias", "core/shopify-app/st-modules/account/account", "core/shopify-app/st-modules/enrollment/enrollment", "core/shopify-app/st-modules/_general-methods/browser-history", "core/shopify-app/st-modules/_general-methods/form/cart-manipulation", "core/shopify-app/st-modules/_general-methods/cookies/cookies", "core/shopify-app/st-modules/_general-methods/form/customer-type", "core/shopify-app/st-modules/_general-methods/form/loader", "core/shopify-app/st-modules/_general-methods/general-methods", "core/shopify-app/st-modules/_general-methods/button/button-actions", "core/shopify-app/st-modules/_general-methods/form/form", "core/shopify-app/st-modules/_general-methods/notification", "core/shopify-app/st-modules/_general-methods/object-formatting", "core/shopify-app/st-modules/_di-container/di.container.public", "core/shopify-app/st-modules/enrollment/page/enrollment-submit", "core/shopify-app/st-modules/enrollment/_general/enrollment-class-config", "core/shopify-app/st-modules/_general-methods/form/fields/date-input", "core/shopify-app/st-modules/_general-methods/form/form-class-config", "core/shopify-app/st-modules/enrollment/blocks/review-privacy/enrollment-section-review-privacy", "core/shopify-app/st-modules/enrollment/blocks/account-details/enrollment-section-account-details", "extension/shopify-app/st-modules/enrollment/_validation/enrollment-validation", "core/shopify-app/st-modules/account/_general/account-class-config", "core/shopify-app/st-modules/webalias/inject-representative-info", "core/shopify-app/st-modules/search-sponsor/search-sponsor", "core/shopify-app/st-modules/search-sponsor/sponsor-search-class-config", "core/shopify-app/st-modules/enrollment-account/enrollment-account", "core/shopify-app/st-modules/enrollment-account/enrollment-account-class-config", "core/shopify-app/st-modules/enrollment/blocks/optional-kits/enrollment-section-optional-kits", "core/shopify-app/st-modules/enrollment/blocks/required-kits/enrollment-section-required-kits", "core/shopify-app/st-modules/enrollment/_general/enrollment-store", "core/shopify-app/st-modules/enrollment/blocks/review-info/enrollment-review", "core/shopify-app/st-modules/enrollment/page/enrollment-page", "core/shopify-app/st-modules/_general-methods/currency", "core/shopify-app/st-modules/enrollment/blocks/review-info/enrollment-review-cart", "core/shopify-app/st-modules/_general-methods/form/formatting", "core/shopify-app/st-modules/enrollment/blocks/account-details/account-details-helpers", "core/shopify-app/st-modules/webalias/webalias-class-config", "core/shopify-app/st-modules/account/header/nav/account-nav", "core/shopify-app/st-modules/account/header/backoffice-sso/backoffice-sso", "core/shopify-app/st-modules/account/blocks/web-alias-edit/web-alias-edit", "core/shopify-app/st-modules/account/blocks/personal-site/personal-site", "core/shopify-app/st-modules/account/blocks/addresses/addresses", "core/shopify-app/st-modules/account/blocks/personal-info/personal-info", "core/shopify-app/st-modules/account/blocks/order-history/order-history", "core/shopify-app/st-modules/cart/cart", "core/shopify-app/st-modules/enrollment-account/enrollment-account-repeat-password-validation", "core/shopify-app/st-modules/account-register/account-register", "core/shopify-app/st-modules/main/auto-apply-promo", "core/shopify-app/st-modules/representative-redirect-page/representative-redirect-page", "core/shopify-app/st-modules/representative-redirect-page/representative-redirect-page-class-config", "core/shopify-app/st-modules/account-register/account-register-class-config", "core/shopify-app/st-modules/account-login/account-login", "core/shopify-app/st-modules/account-login/account-login-class-config", "core/shopify-app/st-modules/search-sponsor/search-sponsor-guard", "core/shopify-app/st-modules/search-sponsor/search-sponsor-service", "core/shopify-app/st-modules/reset-password/reset-password-class-config", "core/shopify-app/st-modules/reset-password/reset-password", "core/shopify-app/st-modules/enrollment/enrollment-cleanup", "core/shopify-app/st-modules/referral/referral", "core/shopify-app/st-modules/account/blocks/coupon-codes/coupon-codes", "extension/shopify-app/st-modules/enrollment/blocks/addresses/enrollment-addresses", "extension/shopify-app/st-modules/enrollment/blocks/business-info/enrollment-section-business-details", "extension/shopify-app/st-modules/enrollment/blocks/business-info/business-details-helpers-extension", "extension/shopify-app/st-modules/enrollment/page-header/nav/enrollment-nav", "extension/shopify-app/st-modules/enrollment/_validation/enrollment-validation-setup", "extension/shopify-app/st-modules/enrollment/blocks/addresses/enrollment-section-addresses"], function(require, exports, static_2, webalias_1, account_1, enrollment_1, browser_history_1, cart_manipulation_1, cookies_1, customer_type_1, loader_1, general_methods_1, button_actions_3, form_1, notification_12, object_formatting_1, di_container_public_1, enrollment_submit_1, enrollment_class_config_1, date_input_1, form_class_config_1, enrollment_section_review_privacy_1, enrollment_section_account_details_1, enrollment_validation_2, account_class_config_1, inject_representative_info_1, search_sponsor_1, sponsor_search_class_config_1, enrollment_account_1, enrollment_account_class_config_1, enrollment_section_optional_kits_1, enrollment_section_required_kits_1, enrollment_store_1, enrollment_review_1, enrollment_page_1, currency_2, enrollment_review_cart_1, formatting_1, account_details_helpers_1, webalias_class_config_1, account_nav_1, backoffice_sso_1, web_alias_edit_1, personal_site_1, addresses_1, personal_info_1, order_history_1, cart_1, enrollment_account_repeat_password_validation_1, account_register_1, auto_apply_promo_1, representative_redirect_page_1, representative_redirect_page_class_config_1, account_register_class_config_1, account_login_1, account_login_class_config_1, search_sponsor_guard_1, search_sponsor_service_1, reset_password_class_config_1, reset_password_1, enrollment_cleanup_1, referral_1, coupon_codes_1, enrollment_addresses_1, enrollment_section_business_details_1, business_details_helpers_extension_1, enrollment_nav_2, enrollment_validation_setup_2, enrollment_section_addresses_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StAppDIConfig = void 0;
    var StAppDIConfig = function() {
        function StAppDIConfig() {
            var _this = this;
            this.className = "AppDIConfig";
            this.init = function() {};
            this.components = function() {
                _this.StStaticComponent = static_2.StStatic.Instance();
                _this.DiContainerPublicComponent = new di_container_public_1.DiContainerPublic();
                _this.StObjectFormattingComponent = new object_formatting_1.StObjectFormatting();
                _this.StBrowserHistoryComponent = new browser_history_1.StBrowserHistory(_this.StObjectFormattingComponent);
                _this.StCartManipulationComponent = new cart_manipulation_1.StCartManipulation();
                _this.StCookiesComponent = new cookies_1.StCookies();
                _this.StCustomerTypeComponent = new customer_type_1.StCustomerType();
                _this.StLoaderComponent = new loader_1.StLoader();
                _this.StButtonActionsComponent = new button_actions_3.StButtonActions();
                _this.StNotificationComponent = new notification_12.StNotification();
                _this.StFormConfigComponent = new form_class_config_1.StFormClassConfig();
                _this.StGeneralMethodsComponent = new general_methods_1.StGeneralMethods();
                _this.StCurrencyComponent = new currency_2.StCurrency();
                _this.StFormattingComponent = new formatting_1.StFormFormatting();
                _this.StAutoApplyPromoComponent = new auto_apply_promo_1.StAutoApplyPromo();
                _this.StCartComponent = new cart_1.StCart();
                _this.StEnrollmentClassConfigComponent = new enrollment_class_config_1.StEnrollmentClassConfig();
                _this.StEnrollmentAccountClassConfigComponent = new enrollment_account_class_config_1.StEnrollmentAccountClassConfig();
                _this.StEnrollmentSectionPrivacyComponent = new enrollment_section_review_privacy_1.StEnrollmentSectionPrivacy(_this.StEnrollmentClassConfigComponent);
                _this.StEnrollmentAccountDetailsHelpersComponent = new account_details_helpers_1.StEnrollmentAccountDetailsHelpers(_this.StFormattingComponent, _this.StEnrollmentClassConfigComponent);
                _this.StEnrollmentBusinessDetailsHelpersComponent = new business_details_helpers_extension_1.StEnrollmentBusinessDetailsHelpersExtension(_this.StFormattingComponent, _this.StEnrollmentClassConfigComponent);
                _this.StEnrollmentSectionAccountDetailsComponent = new enrollment_section_account_details_1.StEnrollmentSectionAccountDetails();
                _this.StEnrollmentSectionBusinessDetailsComponent = new enrollment_section_business_details_1.StEnrollmentSectionBusinessDetailsExtended();
                _this.StEnrollmentStoreComponent = new enrollment_store_1.StEnrollmentStore(_this.StEnrollmentClassConfigComponent, _this.StCartComponent);
                _this.StEnrollmentPageComponent = new enrollment_page_1.StEnrollmentPage(_this.StEnrollmentClassConfigComponent, _this.StGeneralMethodsComponent);
                _this.StAccountClassConfigComponent = new account_class_config_1.StAccountClassConfig();
                _this.StSearchSponsorClassConfigComponent = new sponsor_search_class_config_1.StSearchSponsorClassConfig();
                _this.StDateInputComponent = new date_input_1.StDateInput(_this.StFormConfigComponent);
                _this.StFormComponent = new form_1.StForm(_this.StFormConfigComponent, _this.StDateInputComponent);
                _this.StWebAliasClassConfigComponent = new webalias_class_config_1.StWebAliasClassConfig();
                _this.StInjectRepresentativeInfoComponent = new inject_representative_info_1.StInjectRepresentativeInfo(_this.StWebAliasClassConfigComponent);
                _this.StSearchSponsorGuardComponent = new search_sponsor_guard_1.StSearchSponsorGuard(_this.StSearchSponsorClassConfigComponent, _this.StBrowserHistoryComponent, _this.StObjectFormattingComponent, _this.StGeneralMethodsComponent, _this.StCartComponent);
                _this.StAccountPersonalSiteComponent = new personal_site_1.StAccountPersonalSite(_this.StAccountClassConfigComponent, _this.StGeneralMethodsComponent);
                _this.StWebAliasComponent = new webalias_1.StWebAlias(_this.StWebAliasClassConfigComponent, _this.StBrowserHistoryComponent, _this.StObjectFormattingComponent, _this.StCookiesComponent, _this.StCustomerTypeComponent, _this.StGeneralMethodsComponent, _this.StInjectRepresentativeInfoComponent, _this.StCartComponent, _this.StSearchSponsorGuardComponent, _this.StAccountPersonalSiteComponent);
                _this.StSearchSponsorService = new search_sponsor_service_1.StSearchSponsorService();
                _this.StSearchSponsorComponent = new search_sponsor_1.StSearchSponsor(_this.StGeneralMethodsComponent, _this.StObjectFormattingComponent, _this.StBrowserHistoryComponent, _this.StSearchSponsorClassConfigComponent, _this.StCookiesComponent, _this.StCartComponent, _this.StSearchSponsorService);
                _this.StEnrollmentValidationComponent = new enrollment_validation_2.StEnrollmentValidationExtended(_this.StEnrollmentClassConfigComponent, _this.StNotificationComponent, _this.StEnrollmentPageComponent);
                _this.StEnrollmentAddressesComponent = new enrollment_addresses_1.StEnrollmentAddresses(_this.StFormattingComponent, _this.StEnrollmentStoreComponent);
                _this.StEnrollmentSectionAddresssComponent = new enrollment_section_addresses_1.StEnrollmentSectionAddresses();
                _this.StEnrollmentValidationSetupComponent = new enrollment_validation_setup_2.StEnrollmentValidationSetupExtended(_this.StEnrollmentValidationComponent, _this.StEnrollmentSectionPrivacyComponent, _this.StEnrollmentSectionAccountDetailsComponent, _this.StEnrollmentSectionBusinessDetailsComponent, _this.StEnrollmentSectionAddresssComponent);
                _this.StEnrollmentReviewCartComponent = new enrollment_review_cart_1.StEnrollmentReviewCart(_this.StEnrollmentClassConfigComponent, _this.StEnrollmentStoreComponent, _this.StCurrencyComponent);
                _this.StEnrollmentOptionalKitsComponent = new enrollment_section_optional_kits_1.StEnrollmentOptionalKits(_this.StEnrollmentClassConfigComponent, _this.StEnrollmentStoreComponent, _this.StEnrollmentReviewCartComponent);
                _this.StEnrollmentRequiredKitsComponent = new enrollment_section_required_kits_1.StEnrollmentRequiredKits(_this.StEnrollmentClassConfigComponent, _this.StEnrollmentStoreComponent, _this.StEnrollmentReviewCartComponent);
                _this.StEnrollmentReviewComponent = new enrollment_review_1.StEnrollmentReview(_this.StEnrollmentClassConfigComponent, _this.StEnrollmentStoreComponent, _this.StGeneralMethodsComponent, _this.StEnrollmentPageComponent, _this.StCurrencyComponent, _this.StFormComponent, _this.StEnrollmentReviewCartComponent);
                _this.StEnrollmentActionsComponent = new enrollment_submit_1.StEnrollmentActions(_this.StEnrollmentClassConfigComponent, _this.StNotificationComponent);
                _this.StEnrollmentNavComponent = new enrollment_nav_2.StEnrollmentNavExtended(_this.StEnrollmentClassConfigComponent, _this.StEnrollmentActionsComponent, _this.StEnrollmentOptionalKitsComponent, _this.StEnrollmentRequiredKitsComponent, _this.StEnrollmentStoreComponent, _this.StFormComponent, _this.StButtonActionsComponent, _this.StEnrollmentValidationComponent, _this.StEnrollmentValidationSetupComponent, _this.StNotificationComponent, _this.StEnrollmentReviewComponent, _this.StEnrollmentPageComponent);
                _this.StEnrollmentComponent = new enrollment_1.StEnrollment(_this.StEnrollmentClassConfigComponent);
                _this.StEnrollmentCleanupComponent = new enrollment_cleanup_1.StEnrollmentCleanup(_this.StCartComponent);
                _this.StEnrollmentAccountComponent = new enrollment_account_1.StEnrollmentAccount(_this.StEnrollmentAccountClassConfigComponent, _this.StButtonActionsComponent, _this.StNotificationComponent, _this.StFormComponent, _this.StGeneralMethodsComponent, _this.StEnrollmentCleanupComponent, _this.StCartComponent);
                _this.StAccountNavComponent = new account_nav_1.StAccountNav(_this.StAccountClassConfigComponent, _this.StObjectFormattingComponent, _this.StBrowserHistoryComponent, _this.StGeneralMethodsComponent);
                _this.StBackofficeSSOComponent = new backoffice_sso_1.StBackofficeSSO(_this.StAccountClassConfigComponent, _this.StNotificationComponent);
                _this.StAccountWebAliasEditComponent = new web_alias_edit_1.StAccountWebAliasEdit(_this.StAccountClassConfigComponent, _this.StGeneralMethodsComponent, _this.StNotificationComponent, _this.StButtonActionsComponent, _this.StFormComponent, _this.StFormattingComponent);
                _this.StAccountAddressesComponent = new addresses_1.StAccountAddresses(_this.StAccountClassConfigComponent, _this.StGeneralMethodsComponent);
                _this.StAccountPersonalInfoComponent = new personal_info_1.StAccountPersonalInfo(_this.StAccountClassConfigComponent, _this.StFormComponent, _this.StFormattingComponent, _this.StButtonActionsComponent, _this.StNotificationComponent, _this.StGeneralMethodsComponent);
                _this.StAccountOrderHistoryComponent = new order_history_1.StAccountOrderHistory(_this.StAccountClassConfigComponent, _this.StGeneralMethodsComponent);
                _this.StAccountComponent = new account_1.StAccount(_this.StFormComponent);
                _this.StAccountLoginClassConfigComponent = new account_login_class_config_1.StAccountLoginClassConfig();
                _this.StAccountLoginComponent = new account_login_1.StAccountLogin(_this.StFormComponent, _this.StNotificationComponent, _this.StButtonActionsComponent, _this.StAccountLoginClassConfigComponent, _this.StGeneralMethodsComponent);
                _this.StAccountRegisterClassConfigComponent = new account_register_class_config_1.StAccountRegisterClassConfig();
                _this.StAccountRegisterComponent = new account_register_1.StAccountRegister(_this.StFormComponent, _this.StNotificationComponent, _this.StButtonActionsComponent, _this.StAccountRegisterClassConfigComponent, _this.StGeneralMethodsComponent);
                _this.StResetPasswordClassConfigComponent = new reset_password_class_config_1.StResetPasswordClassConfig();
                _this.StResetPasswordComponent = new reset_password_1.StResetPassword(_this.StFormComponent, _this.StNotificationComponent, _this.StButtonActionsComponent, _this.StResetPasswordClassConfigComponent, _this.StGeneralMethodsComponent);
                _this.StEnrollmentRepeatPasswordValidationComponent = new enrollment_account_repeat_password_validation_1.StEnrollmentRepeatPasswordValidation(_this.StEnrollmentAccountClassConfigComponent);
                _this.StRepresentativeRedirectClassConfigComponent = new representative_redirect_page_class_config_1.StRepresentativeRedirectClassConfig();
                _this.StRepresentativeRedirectComponent = new representative_redirect_page_1.StRepresentativeRedirectPage(_this.StRepresentativeRedirectClassConfigComponent, _this.StGeneralMethodsComponent);
                _this.StReferralComponent = new referral_1.StReferral(_this.StGeneralMethodsComponent, _this.StObjectFormattingComponent, _this.StNotificationComponent);
                _this.StCouponCodesComponent = new coupon_codes_1.StCouponCodes();
            };
            this.hierarchy = function(appName) {
                var hierarchy = [_this.DiContainerPublicComponent, _this.StStaticComponent];
                switch (appName) {
                    case "main":
                        hierarchy = hierarchy.concat([_this.StAutoApplyPromoComponent, _this.StWebAliasComponent, _this.StSearchSponsorGuardComponent, _this.StSearchSponsorComponent, _this.StReferralComponent]);
                        break;

                    case "account":
                        hierarchy = hierarchy.concat([_this.StAccountComponent, _this.StAccountNavComponent, _this.StBackofficeSSOComponent, _this.StAccountWebAliasEditComponent, _this.StAccountPersonalSiteComponent, _this.StAccountAddressesComponent, _this.StAccountPersonalInfoComponent, _this.StAccountOrderHistoryComponent, _this.StCouponCodesComponent]);
                        break;

                    case "account-login":
                        hierarchy = hierarchy.concat([_this.StAccountLoginComponent]);
                        break;

                    case "account-register":
                        hierarchy = hierarchy.concat([_this.StAccountRegisterComponent]);
                        break;

                    case "reset-password":
                        hierarchy = hierarchy.concat([_this.StResetPasswordComponent]);
                        break;

                    case "enrollment":
                        hierarchy = hierarchy.concat([_this.StEnrollmentComponent, _this.StEnrollmentReviewComponent, _this.StEnrollmentNavComponent, _this.StEnrollmentAccountDetailsHelpersComponent, _this.StEnrollmentBusinessDetailsHelpersComponent, _this.StEnrollmentAddressesComponent]);
                        break;

                    case "enrollment-account":
                        hierarchy = hierarchy.concat([_this.StEnrollmentAccountComponent, _this.StEnrollmentRepeatPasswordValidationComponent]);
                        break;

                    case "checkout":
                        hierarchy = hierarchy.concat([]);
                        break;

                    case "representative-redirect-page":
                        hierarchy = hierarchy.concat([_this.StRepresentativeRedirectComponent, _this.StRepresentativeRedirectClassConfigComponent, _this.StGeneralMethodsComponent]);
                        break;

                    case "enrollment-thank-you":
                        hierarchy = hierarchy.concat([]);
                        break;

                    default:
                        console.error("Unrecognized app provided to st-app. App name: " + appName);
                }
                return hierarchy;
            };
            this.components();
        }
        Object.defineProperty(StAppDIConfig, "Instance", {
            get: function() {
                return this._instance || (this._instance = new this());
            },
            enumerable: false,
            configurable: true
        });
        return StAppDIConfig;
    }();
    exports.StAppDIConfig = StAppDIConfig;
});

define("core/shopify-app/st-modules/_di-container/di.container", ["require", "exports", "_shopify.app.di.container", "core/shopify-app/st-modules/_di-container/di.container.setup"], function(require, exports, _shopify_app_di_container_1, di_container_setup_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StDIContainer = void 0;
    var StDIContainer = function() {
        function StDIContainer() {
            this.className = "DI";
        }
        StDIContainer.run = function(appName) {
            new di_container_setup_1.StDIContainerSetup(appName, _shopify_app_di_container_1.StAppDIConfig);
        };
        return StDIContainer;
    }();
    exports.StDIContainer = StDIContainer;
});

define("core/shopify-app/st-modules/_general-methods/init-retry", ["require", "exports", "core/shopify-app/st-modules/_static/static"], function(require, exports, static_3) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StInitRetry = void 0;
    var StInitRetry = function() {
        function StInitRetry() {
            var _this_1 = this;
            this.className = "InitRetry";
            this.recursiveInitRetry = 0;
            this.timeout = 200;
            this.init = function() {};
            this.initWithCondition = function(params) {
                var _this = _this_1;
                var def = {
                    conditionGeneratorParams: [],
                    callbackParams: [],
                    noOfRetries: 6
                };
                var completeParams = __assign(__assign({}, def), params);
                var initCondition = completeParams.conditionGenerator.apply(_this, completeParams.conditionGeneratorParams);
                if (initCondition) {
                    completeParams.callback.apply(_this, completeParams.callbackParams);
                } else {
                    setTimeout(function() {
                        if (_this.recursiveInitRetry < completeParams.noOfRetries) {
                            _this.recursiveInitRetry++;
                            _this.initWithCondition(completeParams);
                        }
                    }, _this_1.timeout);
                }
            };
            this.endpoint = static_3.StStatic.Instance().obtainStaticEndpoints();
        }
        StInitRetry.Instance = function() {
            return this._instance || (this._instance = new this());
        };
        return StInitRetry;
    }();
    exports.StInitRetry = StInitRetry;
});

define("core/shopify-app/st-modules/_general-methods/shopify-ajax", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_63) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StShopifyAjax = void 0;
    var StShopifyAjax = function(_super) {
        __extends(StShopifyAjax, _super);

        function StShopifyAjax() {
            var _this = _super.call(this, arguments) || this;
            _this.className = "ShopifyAjax";
            _this.updateCartAttributes = function(attributes, callback, callbackParams) {
                if (callback === void 0) {
                    callback = function() {};
                }
                if (callbackParams === void 0) {
                    callbackParams = [];
                }
                if (!!attributes) {
                    var fnReference_1 = _this;
                    var request_2 = new XMLHttpRequest();
                    request_2.open("POST", "/cart/update.js", true);
                    request_2.withCredentials = true;
                    request_2.setRequestHeader("Content-Type", "application/json");
                    request_2.onreadystatechange = function() {
                        if (request_2.readyState === 4) {
                            try {
                                var resp = JSON.parse(request_2.response);
                                callbackParams.unshift(resp);
                                callback.apply(fnReference_1, callbackParams);
                            } catch (e) {
                                console.error(e);
                                console.error("Failed to update shopify cart attributes!");
                            }
                        }
                    };
                    request_2.send(JSON.stringify({
                        attributes: attributes
                    }));
                }
            };
            return _this;
        }
        return StShopifyAjax;
    }(st_module_63.StModule);
    exports.StShopifyAjax = StShopifyAjax;
});

define("core/shopify-app/st-modules/enrollment/enrollment-cleanup-checkout", ["require", "exports", "core/shopify-app/st-modules/_di-container/st.module"], function(require, exports, st_module_64) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.StEnrollmentCleanupCheckout = void 0;
    var StEnrollmentCleanupCheckout = function(_super) {
        __extends(StEnrollmentCleanupCheckout, _super);

        function StEnrollmentCleanupCheckout(enrollmentCleanup) {
            var _this = _super.call(this, arguments) || this;
            _this.className = "StEnrollmentCleanupCheckout";
            _this.init = function() {
                _this.enrollmentCleanup.clearCartAttributes();
            };
            _this.enrollmentCleanup = enrollmentCleanup;
            return _this;
        }
        return StEnrollmentCleanupCheckout;
    }(st_module_64.StModule);
    exports.StEnrollmentCleanupCheckout = StEnrollmentCleanupCheckout;
});

(function() {
    "use strict";
    class StApp extends HTMLElement {
        static get observedAttributes() {
            return ["app"];
        }
        constructor() {
            super();
        }
        attributeChangedCallback(name, oldValue, newValue) {
            if (name === "app" && oldValue !== newValue) {
                this.initApp(newValue);
            }
        }
        initApp(appName) {
            require(["core/shopify-app/st-modules/_di-container/di.container"], function(module) {
                module.StDIContainer.run(appName);
            });
        }
    }
    customElements.define("st-app", StApp);
})();

window.define = null;