export const VIDEO_TYPE = 'youtube';
